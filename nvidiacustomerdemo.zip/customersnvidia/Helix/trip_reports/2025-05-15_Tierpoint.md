Trip Report | Tierpoint | Helix

Customer: Helix
AE: David
Topic: Tierpoint
Meeting Date 05/15/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

SHI/TierPoint to prepare tailored recommendations for HelixESG:

Review HelixESG’s workload inventory and backup requirements in more detail Prepare Azure Local/Hyper-V and DR/backup cost comparisons, pros/cons Assess migration path and impact to legal hold backup compliance

06/10

2

David A

Address potential transition plan for hardware lifecycle and OpEx shift

06/10

Item Owner Next Steps/Detail Due Date 1 Manuel Z

SHI/TierPoint to prepare tailored recommendations for HelixESG:

Review HelixESG’s workload inventory and backup requirements in more detail Prepare Azure Local/Hyper-V and DR/backup cost comparisons, pros/cons Assess migration path and impact to legal hold backup compliance

SHI/TierPoint to prepare tailored recommendations for HelixESG:

Review HelixESG’s workload inventory and backup requirements in more detail Prepare Azure Local/Hyper-V and DR/backup cost comparisons, pros/cons Assess migration path and impact to legal hold backup compliance

Review HelixESG’s workload inventory and backup requirements in more detail Prepare Azure Local/Hyper-V and DR/backup cost comparisons, pros/cons Assess migration path and impact to legal hold backup compliance 06/10 2 David A

Address potential transition plan for hardware lifecycle and OpEx shift

Address potential transition plan for hardware lifecycle and OpEx shift

Address potential transition plan for hardware lifecycle and OpEx shift 06/10

Summary

Call brought together representatives from HelixESG, SHI, and TierPoint to discuss HelixESG’s VMware renewal challenges, dissatisfaction with Broadcom’s post-acquisition changes, and the exploration of VMware alternatives. HelixESG’s IT leader, Steve Wren, outlined their hybrid on-prem/O365 environment, recent consolidation to full O365, hardware lifecycle, backup requirements (including legal hold and tape), and strong interest in eventually moving out of a disliked Lumen colo. TierPoint and SHI described their approach: workload analysis for best-fit solutions (public cloud, hosted private cloud, or hybrid), highlighting Azure Local (Hyper-V based) managed by TierPoint as an easy, low-friction VMware exit with disaster recovery and backup savings. The conversation focused on both the cost and operational efficiencies, migration strategy, and the challenges of hardware refresh cycles and admin overhead. Next steps include further workload/environment assessment and scheduling a follow-up call to deep-dive on solutions.

Agenda

Review HelixESG’s current VMware environment and renewals Discuss dissatisfaction with Broadcom/VMware changes and explore alternatives Overview of TierPoint & SHI’s cloud/hosted/OpEx solutions, with focus on Azure Local (Hyper-V) Discuss HelixESG’s hardware lifecycle, data center situation, and backup/legal hold requirements Outline migration path and next steps

Review HelixESG’s current VMware environment and renewals Discuss dissatisfaction with Broadcom/VMware changes and explore alternatives Overview of TierPoint & SHI’s cloud/hosted/OpEx solutions, with focus on Azure Local (Hyper-V) Discuss HelixESG’s hardware lifecycle, data center situation, and backup/legal hold requirements Outline migration path and next steps

Opps Identified & BANTC

Opportunity 1: Migration from VMware to Alternative
Hosted/Cloud Solution
• B: Budget – Cost reduction is a key concern, but
Steve indicates savings would be attractive (20-30% in DR/backup) and current hardware is all owned, 2-3 years old (potential to shift CapEx → OpEx).
• A: Authority – Steve Wren is the IT
lead/decision-maker for HelixESG.
• N: Need – Strong need to exit VMware (due to
Broadcom changes) and Lumen colo (due to outages, poor experience), reduce admin overhead, maintain legal hold backup compliance, and future-proof environment.
• T: Timeline – Next renewal cycle is immediate
concern; hardware is mid-lifecycle (2-3 years old), but exit from Lumen and VMware is a “short or long-term goal.” Migration to O365 is nearly complete within 1.5 months.
• C: Competition – Consideration for both public cloud
(Azure/AWS) and hosted private cloud (Azure Local via TierPoint). No strong competitor named; VMware is being phased out regardless.
Opportunity 2: Backup, Disaster Recovery, and Legal
Hold Compliance
• B: Budget – Backup costs (especially tape, Wasabi,
Veeam, O365) are significant; looking for cost-effective alternatives that maintain legal hold compliance.
• A: Authority – Steve Wren and HelixESG
legal/compliance teams would influence this.
• N: Need – Must have robust, long-term backup/DR due
to perpetual legal hold.
• T: Timeline – Ongoing; aligned with broader
migration.
• C: Competition – Existing solution: tapes for
on-prem, Veeam + Wasabi for O365.

Initiatives

Storage (hardware refresh, SAN, tape, OpEx transition)

Security

(backup, disaster recovery, legal hold compliance) Cloud Migration (Azure Local/Hyper-V, public cloud exploration) Both

Security and Storage are relevant

Storage (hardware refresh, SAN, tape, OpEx transition)

Security

(backup, disaster recovery, legal hold compliance) Cloud Migration (Azure Local/Hyper-V, public cloud exploration) Both

Security and Storage are relevant

Tech Profile Updates

All hardware (Cisco blades, Dell PowerStore SAN, tapes) is owned, ~2-3 years old 100% offshore model; Houston data center for on-prem Migration to O365 nearly complete; all Exchange/mail, user drives now in OneDrive Backups: tape (for legal hold), Veeam to Wasabi (O365) Hybrid environment, looking to move out of Lumen colo due to outages and poor experience VMware currently used, but seeking alternatives due to Broadcom changes

All hardware (Cisco blades, Dell PowerStore SAN, tapes) is owned, ~2-3 years old 100% offshore model; Houston data center for on-prem Migration to O365 nearly complete; all Exchange/mail, user drives now in OneDrive Backups: tape (for legal hold), Veeam to Wasabi (O365) Hybrid environment, looking to move out of Lumen colo due to outages and poor experience VMware currently used, but seeking alternatives due to Broadcom changes

Meeting Notes

Environment

Hybrid model: O365 (nearly all workloads migrated), with remaining on-prem

infrastructure in Lumen colo (Houston)

Hardware: Cisco blades, Dell PowerStore SAN, tapes, all owned by HelixESG, 2-3 years old Backups: Tape (on-prem, for legal hold), Veeam to Wasabi (O365) Lumen colo is problematic (multiple outages, circuit issues), driving desire to exit VMware used for virtualization, but dissatisfaction with Broadcom acquisition and support/policy changes

Hybrid model: O365 (nearly all workloads migrated), with remaining on-prem

infrastructure in Lumen colo (Houston)

Hardware: Cisco blades, Dell PowerStore SAN, tapes, all owned by HelixESG, 2-3 years old Backups: Tape (on-prem, for legal hold), Veeam to Wasabi (O365) Lumen colo is problematic (multiple outages, circuit issues), driving desire to exit VMware used for virtualization, but dissatisfaction with Broadcom acquisition and support/policy changes

Detailed Discussion

HelixESG’s migration to O365 has freed up significant on-prem capacity; next step is full exit from on-prem data center (except for ships) Cost savings discussed: while VMware and Azure Local costs are similar for production workloads, DR/backup savings (20-30%) are significant Azure Local (Hyper-V) presented as a bridge solution: hosted private cloud managed by TierPoint, using Azure-native tools, easing migration/testing into full public cloud if desired TierPoint’s OpEx model highlighted as way to avoid hardware refresh headaches, ensure predictable spend, and reduce admin overhead Steve Wren emphasized need for robust backup due to legal hold; tape is currently used because of cost and compliance Hardware lifecycle: staggered, but most equipment 2-3 years old (some blades possibly older) Short and long-term goal: exit Lumen colo, reduce VMware dependency, improve operational efficiency

HelixESG’s migration to O365 has freed up significant on-prem capacity; next step is full exit from on-prem data center (except for ships) Cost savings discussed: while VMware and Azure Local costs are similar for production workloads, DR/backup savings (20-30%) are significant Azure Local (Hyper-V) presented as a bridge solution: hosted private cloud managed by TierPoint, using Azure-native tools, easing migration/testing into full public cloud if desired TierPoint’s OpEx model highlighted as way to avoid hardware refresh headaches, ensure predictable spend, and reduce admin overhead Steve Wren emphasized need for robust backup due to legal hold; tape is currently used because of cost and compliance Hardware lifecycle: staggered, but most equipment 2-3 years old (some blades possibly older) Short and long-term goal: exit Lumen colo, reduce VMware dependency, improve operational efficiency

Technical Notes

Azure Local (TierPoint managed, Hyper-V) integrates with Azure-native management tools, enabling hybrid deployments and seamless future migration to public Azure Azure Site Recovery recommended for DR; low cost, uses Azure licenses and storage, supports testing Backups: current solution is Veeam to Wasabi for O365, tape for on-prem due to indefinite legal hold DR/backup in Azure Local can provide 20-30% cost savings over current VMware setup TierPoint provides all server, switching, storage infrastructure as an OpEx solution; customer manages up to hypervisor, TierPoint can manage higher up the stack if desired Hardware refresh cycles are getting shorter due to security patching requirements (risk of running unsupported hardware even if hardware itself is still viable) Lumen colo’s circuit issues and data center outages have triggered multiple service interruptions

Azure Local (TierPoint managed, Hyper-V) integrates with Azure-native management tools, enabling hybrid deployments and seamless future migration to public Azure Azure Site Recovery recommended for DR; low cost, uses Azure licenses and storage, supports testing Backups: current solution is Veeam to Wasabi for O365, tape for on-prem due to indefinite legal hold DR/backup in Azure Local can provide 20-30% cost savings over current VMware setup TierPoint provides all server, switching, storage infrastructure as an OpEx solution; customer manages up to hypervisor, TierPoint can manage higher up the stack if desired Hardware refresh cycles are getting shorter due to security patching requirements (risk of running unsupported hardware even if hardware itself is still viable) Lumen colo’s circuit issues and data center outages have triggered multiple service interruptions List all speakers/Participants of Transcript:

Steve Wren (HelixESG, IT lead/decision-maker) David Atkinson (SHI, Account Team) Bob Brown (TierPoint, Solutions/Cloud Specialist) Micah Moseley (SHI, Account Team) Manuel Zelaya (SHI, present but not speaking in transcript; current user) Unnamed Broadcom/VMware rep (referenced in anecdote)

Steve Wren (HelixESG, IT lead/decision-maker) David Atkinson (SHI, Account Team) Bob Brown (TierPoint, Solutions/Cloud Specialist) Micah Moseley (SHI, Account Team) Manuel Zelaya (SHI, present but not speaking in transcript; current user) Unnamed Broadcom/VMware rep (referenced in anecdote)

Potential Next Steps

Schedule follow-up meeting next Wednesday or Thursday after 11am (Steve Wren, David Atkinson, Bob Brown, Micah Moseley, TierPoint team)

Schedule follow-up meeting next Wednesday or Thursday after 11am (Steve Wren, David Atkinson, Bob Brown, Micah Moseley, TierPoint team)

Action: David Atkinson to coordinate with TierPoint and send calendar invite Owner: David Atkinson (to Steve Wren, Bob Brown, Micah Moseley, TierPoint)

Action: David Atkinson to coordinate with TierPoint and send calendar invite Owner: David Atkinson (to Steve Wren, Bob Brown, Micah Moseley, TierPoint)

Pre-meeting Q&A/prep: Steve Wren to send any additional questions or requirements to David Atkinson ahead of next call

Pre-meeting Q&A/prep: Steve Wren to send any additional questions or requirements to David Atkinson ahead of next call

Action: Steve Wren to email/relay questions to SHI team Owner: Steve Wren (to David Atkinson/SHI/TierPoint)

Action: Steve Wren to email/relay questions to SHI team Owner: Steve Wren (to David Atkinson/SHI/TierPoint)

SHI/TierPoint to prepare tailored recommendations for HelixESG:

SHI/TierPoint to prepare tailored recommendations for HelixESG:

Review HelixESG’s workload inventory and backup requirements in more detail Prepare Azure Local/Hyper-V and DR/backup cost comparisons, pros/cons Assess migration path and impact to legal hold backup compliance Owner: Bob Brown/Micah Moseley (to Steve Wren, with input from David Atkinson/Manuel Zelaya)

Review HelixESG’s workload inventory and backup requirements in more detail Prepare Azure Local/Hyper-V and DR/backup cost comparisons, pros/cons Assess migration path and impact to legal hold backup compliance Owner: Bob Brown/Micah Moseley (to Steve Wren, with input from David Atkinson/Manuel Zelaya)

Address potential transition plan for hardware lifecycle and OpEx shift:

Address potential transition plan for hardware lifecycle and OpEx shift:

Owner: Bob Brown/Micah Moseley (to Steve Wren, input from David Atkinson)

Owner: Bob Brown/Micah Moseley (to Steve Wren, input from David Atkinson)

If additional questions from TierPoint/SHI arise, they will reach out to Steve Wren before next meeting

If additional questions from TierPoint/SHI arise, they will reach out to Steve Wren before next meeting

Action: Ongoing Q&A loop Owner: David Atkinson, Micah Moseley, Bob Brown

Action: Ongoing Q&A loop Owner: David Atkinson, Micah Moseley, Bob Brown
