Trip Report | Tierpoint | Helix

Customer: Helix
AE: David A
Topic: Tierpoint
Meeting Date 07/26/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

confirm when new vulnerability management services are ready and schedule future discussion.

07

2

Tony A

to follow up with Steve Wren in ~2 weeks for status.

Item Owner Next Steps/Detail Due Date 1 Manuel Z confirm when new vulnerability management services are ready and schedule future discussion. 07 2 Tony A to follow up with Steve Wren in ~2 weeks for status.

Summary

Summary

This session brought together HelixESG (Steve Wren and team), SHI (David Atkinson), and TierPoint (Bob Brown, Eric Morrison, Stephen Leaman, et al.) for a detailed review and follow-up on cost estimates and solution architecture for a VMware alternative. The primary business drivers are mitigating rising and unpredictable VMware costs (especially post-Broadcom), modernizing aging hardware, moving to an OpEx model, and setting up a 3–5 year migration path toward cloud-native infrastructure. TierPoint presented three options: VMware private cloud, Azure Native, and Azure Local (Azure Arc-enabled hybrid HCI), recommending Azure Local for its hybrid flexibility, centralized management, DR/backup integration, and future Azure-native extensibility. Cost, operational overhead, hardware lifecycle, and vulnerability management were central to the discussion. While Azure Local was most expensive, it best aligns with HelixESG’s gradual migration goals and operational requirements. Vulnerability management remains a major pain point; TierPoint hinted at upcoming solutions. Next steps are internal cost review, scenario modeling, and a potential follow-up on vulnerability management offerings.

Agenda

Introductions & recap of business objectives TierPoint overview and cloud alternatives portfolio Review of technical requirements and HelixESG project goals Detailed walkthrough of VMware, Azure Native, and Azure Local options Azure Local hybrid architecture, management, DR, and backup review Pricing breakdown, TCO and cost displacement discussion Customer feedback, pain points, and next steps Vulnerability management challenges and new potential solutions

Introductions & recap of business objectives TierPoint overview and cloud alternatives portfolio Review of technical requirements and HelixESG project goals Detailed walkthrough of VMware, Azure Native, and Azure Local options Azure Local hybrid architecture, management, DR, and backup review Pricing breakdown, TCO and cost displacement discussion Customer feedback, pain points, and next steps Vulnerability management challenges and new potential solutions

Opps Identified & BANTC

Opportunity 1: Azure Local Hybrid Cloud Migration

B: HelixESG
is budgeting for infrastructure modernization; cost sensitivity is critical; looking for clear OpEx vs. CapEx justification.
A: Steve
Wren (HelixESG), SHI (David Atkinson), TierPoint (Bob Brown, Eric Morrison, Stephen Leaman)
N: High
— Urgency due to VMware cost volatility, hardware refresh needs, DR/backup
requirements, and future scalability.
T: Immediate/short-term;
internal cost analysis underway, decision expected in ~2 weeks.
C: Steve
Wren, David Atkinson, TierPoint team

B: HelixESG
is budgeting for infrastructure modernization; cost sensitivity is critical; looking for clear OpEx vs. CapEx justification.
A: Steve
Wren (HelixESG), SHI (David Atkinson), TierPoint (Bob Brown, Eric Morrison, Stephen Leaman)
N: High
— Urgency due to VMware cost volatility, hardware refresh needs, DR/backup
requirements, and future scalability.
T: Immediate/short-term;
internal cost analysis underway, decision expected in ~2 weeks.
C: Steve
Wren, David Atkinson, TierPoint team
Opportunity 2: Vulnerability Management Services

B: Not
yet budgeted; significant pain due to volume and complexity of vulnerability management; business case may be needed.
A: Steve
Wren (HelixESG), Stephen Leaman (TierPoint), SHI
N: High
— Overwhelmed by vulnerability scan results; current process is manual and
inefficient.
T: Medium-term;
follow-up expected when TierPoint’s new service is available.
C: Steve
Wren, Stephen Leaman

B: Not
yet budgeted; significant pain due to volume and complexity of vulnerability management; business case may be needed.
A: Steve
Wren (HelixESG), Stephen Leaman (TierPoint), SHI
N: High
— Overwhelmed by vulnerability scan results; current process is manual and
inefficient.
T: Medium-term;
follow-up expected when TierPoint’s new service is available.
C: Steve
Wren, Stephen Leaman

Initiatives

Security: DR/backup, firewall management, vulnerability management (future) Storage/Infra: Hybrid cloud migration (Azure Local), hardware refresh, OpEx transformation

Security: DR/backup, firewall management, vulnerability management (future) Storage/Infra: Hybrid cloud migration (Azure Local), hardware refresh, OpEx transformation

Tech Profile Updates

Current State: 37 VMs, 113 vCPU, 25TB storage; legacy hardware; tape for legal retention; VMware licensing up for renewal. Cloud Options: VMware private cloud (3-tier, Pinnacle partner), Azure Native (cloud-only), Azure Local (Dell HCI, Azure Arc, hybrid, centralized management). DR/Backup: Commvault managed backup, Azure Site Recovery, IPsec replication, managed runbooks, annual DR test. Security: Firewalls (managed or BYO), DR/backup; vulnerability management is manual and multi-tool (third-party scan, SCCM, PatchMyPC, manual server patching). Challenges: Cost justification (hard savings vs. soft), minimal day-to-day IT savings, hardware lifecycle, legal tape retention, vulnerability management volume.

Current State: 37 VMs, 113 vCPU, 25TB storage; legacy hardware; tape for legal retention; VMware licensing up for renewal. Cloud Options: VMware private cloud (3-tier, Pinnacle partner), Azure Native (cloud-only), Azure Local (Dell HCI, Azure Arc, hybrid, centralized management). DR/Backup: Commvault managed backup, Azure Site Recovery, IPsec replication, managed runbooks, annual DR test. Security: Firewalls (managed or BYO), DR/backup; vulnerability management is manual and multi-tool (third-party scan, SCCM, PatchMyPC, manual server patching). Challenges: Cost justification (hard savings vs. soft), minimal day-to-day IT savings, hardware lifecycle, legal tape retention, vulnerability management volume.

Meeting Notes

Environment

HelixESG: Oil & gas, heavy legal/data retention, cost-conscious, aims for gradual cloud migration, values operational stability, no current business/user pressure to accelerate public cloud. SHI: Account management, proposal coordination, escalation point. TierPoint: Solution architecture, managed services, hybrid/cloud/DR/backup/soon vulnerability management offerings.

HelixESG: Oil & gas, heavy legal/data retention, cost-conscious, aims for gradual cloud migration, values operational stability, no current business/user pressure to accelerate public cloud. SHI: Account management, proposal coordination, escalation point. TierPoint: Solution architecture, managed services, hybrid/cloud/DR/backup/soon vulnerability management offerings.

Detailed Discussion

Business Drivers: Reduce VMware costs and risk, modernize hardware, move to OpEx, enable future cloud migration, maintain business continuity. Azure Local Recommendation: Hybrid cloud (Dell HCI, Azure Arc), centralized Azure management, supports both VMs and Azure-native services, flexible for on-prem or TierPoint DC, ruggedized options for remote sites. DR/Backup: Managed Commvault, annual DR test, Azure Site Recovery, offsite options available. Pricing: Azure Local is most expensive, but aligns with HelixESG’s 3–5 year plan; Azure Native (lowest cost, 1-yr RI), VMware (3-yr max, uncertain pricing post-Broadcom). Customer Feedback: Cost is critical; minimal operational savings except VMware patching; hardware replacement driven by security support; vulnerability management is the largest operational pain point (out of scope for infra project). Vulnerability Management: Current process is labor-intensive; interested in solutions that consolidate and automate patching/remediation; TierPoint to follow up with new offerings.

Business Drivers: Reduce VMware costs and risk, modernize hardware, move to OpEx, enable future cloud migration, maintain business continuity. Azure Local Recommendation: Hybrid cloud (Dell HCI, Azure Arc), centralized Azure management, supports both VMs and Azure-native services, flexible for on-prem or TierPoint DC, ruggedized options for remote sites. DR/Backup: Managed Commvault, annual DR test, Azure Site Recovery, offsite options available. Pricing: Azure Local is most expensive, but aligns with HelixESG’s 3–5 year plan; Azure Native (lowest cost, 1-yr RI), VMware (3-yr max, uncertain pricing post-Broadcom). Customer Feedback: Cost is critical; minimal operational savings except VMware patching; hardware replacement driven by security support; vulnerability management is the largest operational pain point (out of scope for infra project). Vulnerability Management: Current process is labor-intensive; interested in solutions that consolidate and automate patching/remediation; TierPoint to follow up with new offerings.

Technical Notes

Dell AX760 nodes, NVMe storage, 25Gbps networking, managed firewalls, Commvault backup, 3-node cluster (scalable). Azure Arc enables hybrid management; Azure portal is single pane of glass for cloud and on-prem. DR/backup: IPsec to Azure, pay for compute only when used; runbook management included. Legacy tapes required for legal; backup retention on disk cost-prohibitive. Patch management: SCCM, PatchMyPC, manual server work, third-party vulnerability scans. Pain points: VMware cost/volatility, data center dislike, hardware lifecycle, vulnerability volume.

Dell AX760 nodes, NVMe storage, 25Gbps networking, managed firewalls, Commvault backup, 3-node cluster (scalable). Azure Arc enables hybrid management; Azure portal is single pane of glass for cloud and on-prem. DR/backup: IPsec to Azure, pay for compute only when used; runbook management included. Legacy tapes required for legal; backup retention on disk cost-prohibitive. Patch management: SCCM, PatchMyPC, manual server work, third-party vulnerability scans. Pain points: VMware cost/volatility, data center dislike, hardware lifecycle, vulnerability volume. List all speakers/Participants of Transcript:

Steve Wren (HelixESG) David Atkinson (SHI) Bob Brown (TierPoint, Solutions Engineer) Eric Morrison (TierPoint, Solutions Architect) Stephen Leaman (TierPoint, Cloud Specialist) Daniil Zaika (TierPoint, Cloud Team) Kelsey Laycock (TierPoint, Channel) Micah Moseley (TierPoint) Others: HelixESG internal IT (referenced)

Steve Wren (HelixESG) David Atkinson (SHI) Bob Brown (TierPoint, Solutions Engineer) Eric Morrison (TierPoint, Solutions Architect) Stephen Leaman (TierPoint, Cloud Specialist) Daniil Zaika (TierPoint, Cloud Team) Kelsey Laycock (TierPoint, Channel) Micah Moseley (TierPoint) Others: HelixESG internal IT (referenced)

Potential Next Steps

Internal Cost Review

Internal Cost Review

Action: Steve Wren to review pricing/options and align with budget process in next two weeks. Participants: Steve Wren

Action: Steve Wren to review pricing/options and align with budget process in next two weeks. Participants: Steve Wren

Follow-up Scheduling

Follow-up Scheduling

Action: TierPoint (Bob Brown/David Atkinson) to follow up with Steve Wren in ~2 weeks for status. Participants: Bob Brown, David Atkinson, Steve Wren

Action: TierPoint (Bob Brown/David Atkinson) to follow up with Steve Wren in ~2 weeks for status. Participants: Bob Brown, David Atkinson, Steve Wren

Vulnerability Management Solution Exploration

Vulnerability Management Solution Exploration

Action: Stephen Leaman to confirm when new vulnerability management services are ready and schedule future discussion. Participants: Stephen Leaman (to Steve Wren)

Action: Stephen Leaman to confirm when new vulnerability management services are ready and schedule future discussion. Participants: Stephen Leaman (to Steve Wren)

Scenario Optimization

Scenario Optimization

Action: TierPoint to provide further breakdowns or optimization (DR, backup, BYO licensing, hardware spec changes) as requested by HelixESG. Participants: Bob Brown, Eric Morrison, Stephen Leaman (to Steve Wren)

Action: TierPoint to provide further breakdowns or optimization (DR, backup, BYO licensing, hardware spec changes) as requested by HelixESG. Participants: Bob Brown, Eric Morrison, Stephen Leaman (to Steve Wren)

General Support/Q&A

General Support/Q&A

Action: SHI/TierPoint to remain available for clarifications and additional scenario modeling. Participants: David Atkinson, TierPoint team

Action: SHI/TierPoint to remain available for clarifications and additional scenario modeling. Participants: David Atkinson, TierPoint team From <https://mindspark.shi.com/My_Agents>
