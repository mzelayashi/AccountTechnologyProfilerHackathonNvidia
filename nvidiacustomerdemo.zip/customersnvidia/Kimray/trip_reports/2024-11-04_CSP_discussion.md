Trip Report | CSP discussion | Kimray

Customer: Kimray
AE: Felix M
Topic: CSP discussion
Meeting Date 11/04/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Felix M

Provide a quote on annual and monthly options for NCE and MPSA licensing

11/13

2

Felix M

Set up a follow-up meeting to review proposals and audit findings, potentially within the next few weeks.

11/13

Item Owner Next Steps/Detail Due Date 1 Felix M Provide a quote on annual and monthly options for NCE and MPSA licensing 11/13 2 Felix M Set up a follow-up meeting to review proposals and audit findings, potentially within the next few weeks. 11/13

Summary

Discussed Microsoft's CSP (Cloud Solution Provider) and NPSA (Nonprofit Software Assurance) licensing agreements in the context of an oil and gas company's cyclical business nature and, which has recently

Technical Notes

Licensing Details: Discussion on various Microsoft licensing options like M365 E3, CSP, and MPSA. Dynamics CRM: Underutilization leading to potential removal from the environment. Technical Audit: Plan to audit current license usage to ensure alignment with actual needs.

Licensing Details: Discussion on various Microsoft licensing options like M365 E3, CSP, and MPSA. Dynamics CRM: Underutilization leading to potential removal from the environment. Technical Audit: Plan to audit current license usage to ensure alignment with actual needs.

Agenda

Review current Microsoft licensing agreements and explore flexibility options. Discuss potential consolidation of software services and cost-saving strategies. Address issues related to specific software usage and licensing, especially Dynamics. Explore alternative Microsoft licensing structures and their implications.

Review current Microsoft licensing agreements and explore flexibility options. Discuss potential consolidation of software services and cost-saving strategies. Address issues related to specific software usage and licensing, especially Dynamics. Explore alternative Microsoft licensing structures and their implications.

Opps Identified & BANTC

Opportunity: Transition to Month-to-Month Licensing for Flexibility

Opportunity: Transition to Month-to-Month Licensing for Flexibility

B (Budget): Cost savings from avoiding yearly contracts, especially on underutilized software like Dynamics. A (Authority): Decision involves VP and systems team. N (Need): Flexibility in software licensing due to workforce reduction and underutilization of certain software. T (Timing): Before December 20th, when current agreements expire. C (Competition): Existing vendor agreements; exploring SHI as a new partner.

B (Budget): Cost savings from avoiding yearly contracts, especially on underutilized software like Dynamics. A (Authority): Decision involves VP and systems team. N (Need): Flexibility in software licensing due to workforce reduction and underutilization of certain software. T (Timing): Before December 20th, when current agreements expire. C (Competition): Existing vendor agreements; exploring SHI as a new partner.

Opportunity: Consolidation of Licensing Services

Opportunity: Consolidation of Licensing Services

B (Budget): Potential cost savings from service consolidation. A (Authority): Decisions require input from systems team and VP. N (Need): Simplification of vendor management and potential cost reduction. T (Timing): Prior to upcoming renewals and potential layoffs. C (Competition): Multiple vendors currently being used.

B (Budget): Potential cost savings from service consolidation. A (Authority): Decisions require input from systems team and VP. N (Need): Simplification of vendor management and potential cost reduction. T (Timing): Prior to upcoming renewals and potential layoffs. C (Competition): Multiple vendors currently being used.

Initiatives

Security: Emphasis on maintaining secure software environments with DLP (Data Loss Prevention) and other security measures.

Security: Emphasis on maintaining secure software environments with DLP (Data Loss Prevention) and other security measures.

Tech Profile Updates

Current use of Microsoft Dynamics, Office 365, and other Microsoft services. Exploration of moving from annual to month-to-month agreements for licensing flexibility. Potential transition from Dynamics due to underutilization.

Current use of Microsoft Dynamics, Office 365, and other Microsoft services. Exploration of moving from annual to month-to-month agreements for licensing flexibility. Potential transition from Dynamics due to underutilization.

Meeting Notes

Environment

Oil and gas industry, experiencing cyclical challenges and workforce reductions. Need for software licensing flexibility to align with business fluctuations.

Oil and gas industry, experiencing cyclical challenges and workforce reductions. Need for software licensing flexibility to align with business fluctuations.

Detailed Discussion

Microsoft Dynamics Licensing: Company has been paying $3300/month for nine years without proper utilization. Plans to discontinue use by December. Licensing Flexibility: Interest in transitioning to month-to-month licenses for better cost management and flexibility. Service Consolidation: Desire to consolidate vendors and services to simplify management and potentially reduce costs. Alternative Licensing Structures: Discussed options like EA and MPSA, including their benefits and constraints.

Microsoft Dynamics Licensing: Company has been paying $3300/month for nine years without proper utilization. Plans to discontinue use by December. Licensing Flexibility: Interest in transitioning to month-to-month licenses for better cost management and flexibility. Service Consolidation: Desire to consolidate vendors and services to simplify management and potentially reduce costs. Alternative Licensing Structures: Discussed options like EA and MPSA, including their benefits and constraints.

Technical Notes

Licensing Details: Discussion on various Microsoft licensing options like M365 E3, CSP, and MPSA. Dynamics CRM: Underutilization leading to potential removal from the environment. Technical Audit: Plan to audit current license usage to ensure alignment with actual needs.

Licensing Details: Discussion on various Microsoft licensing options like M365 E3, CSP, and MPSA. Dynamics CRM: Underutilization leading to potential removal from the environment. Technical Audit: Plan to audit current license usage to ensure alignment with actual needs. List all speakers/Participants of Transcript:

Seth Felix Menchaca Tyler Rodgers Manuel Zelaya

Seth Felix Menchaca Tyler Rodgers Manuel Zelaya
