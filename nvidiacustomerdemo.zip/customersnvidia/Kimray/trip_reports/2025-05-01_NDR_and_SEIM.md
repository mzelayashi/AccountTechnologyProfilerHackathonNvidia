Trip Report | NDR and SEIM | Kimray

Customer: Kimray
AE: Manuel Z
Topic: NDR and SEIM
Meeting Date 05/01/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Felix

Explore cost-effective NDR solutions and schedule a follow-up discussion with Cisco and Meraki representatives.

05/01

2

Manuel

Potentially set up a demo and discovery call with Sumo Logic for SIEM solutions. Discuss with Luz Angeles

05/01

3

Felix

Forward information to Luz and create Internal sync

Item Owner Next Steps/Detail Due Date 1 Felix Explore cost-effective NDR solutions and schedule a follow-up discussion with Cisco and Meraki representatives. 05/01 2 Manuel Potentially set up a demo and discovery call with Sumo Logic for SIEM solutions. Discuss with Luz Angeles 05/01 3 Felix Forward information to Luz and create Internal sync

Summary

The meeting focused on resolving technical issues, exploring potential technological solutions, and discussing future initiatives between SHI and Kimray. Key topics included VPN configurations using Meraki and Cisco Secure Connect, split tunneling challenges, Network Detection Response (NDR) solutions, and log aggregation tools. The participants also discussed the integration of cloud services and a potential shift to Azure application proxy for zero trust strategies. The conversation concluded with an overview of email security challenges, data loss prevention using Microsoft Purview, and the need for a robust SIM solution to enhance security monitoring capabilities.

Agenda

Technical issues resolution VPN and network security configurations Evaluation of NDR and SIEM solutions Cloud services and zero trust strategies Email

security and DLP enhancements

Next steps and action items

Technical issues resolution VPN and network security configurations Evaluation of NDR and SIEM solutions Cloud services and zero trust strategies Email

security and DLP enhancements

Next steps and action items

Opps Identified & BANTC

Opportunity 1: Network Detection
Response (NDR)

B: Kimray
lacks NDR capabilities to monitor lateral movement and enhance security.
A: Rylee
Hulgan and the IT team are key decision-makers.
N: Immediate
need to strengthen security monitoring.
T: Implementation
expected by 2027 due to ongoing ERP project.
C: Budget
constraints and exploration of cost-effective solutions.

B: Kimray
lacks NDR capabilities to monitor lateral movement and enhance security.
A: Rylee
Hulgan and the IT team are key decision-makers.
N: Immediate
need to strengthen security monitoring.
T: Implementation
expected by 2027 due to ongoing ERP project.
C: Budget
constraints and exploration of cost-effective solutions.
Opportunity 2: SEIM Solution

B: Kimray
requires log aggregation to improve security insights and integration with existing tools.
A: Rylee
Hulgan is leading the search for a disruptor in the SIM market.
N: Critical
need to integrate logs from CrowdStrike, Okta, and other tools.
T: Evaluation
of options ongoing; Sumo Logic identified as a potential candidate.
C: Cost
and flexibility are major concerns.

B: Kimray
requires log aggregation to improve security insights and integration with existing tools.
A: Rylee
Hulgan is leading the search for a disruptor in the SIM market.
N: Critical
need to integrate logs from CrowdStrike, Okta, and other tools.
T: Evaluation
of options ongoing; Sumo Logic identified as a potential candidate.
C: Cost
and flexibility are major concerns.

Initiatives

Security

Infrastructure

Security

Infrastructure

Tech Profile Updates

Kimray's current infrastructure includes Meraki VPN configurations, reliance on Microsoft Purview for DLP, and a need for enhanced log aggregation and NDR capabilities. The company is exploring cloud solutions and zero trust strategies with Azure.

Meeting Notes

Environment

Kimray operates a hybrid work environment with a mix of on-premises and cloud services. Security enhancements are critical to support business operations and protect sensitive data.

Detailed Discussion

The discussion covered VPN configurations using Meraki and Cisco Secure Connect, emphasizing split tunneling issues and security measures involving Okta verification. The need for NDR solutions to track lateral movement was highlighted, with Cisco and Meraki options explored. Participants discussed potential SIM solutions, with Sumo Logic considered for its integration capabilities. The exploration of Azure application proxy for zero trust strategies was mentioned, alongside ongoing ERP projects delaying further implementations.

Technical Notes

Meraki VPN configurations require specific settings for secure connections. Okta integration involves real-time two-factor authentication and SAML tagging. Split tunneling configured for point-to-point connections; issues with IP address conflicts noted. Microsoft Purview used for DLP and sensitivity labeling; file labeling under consideration. Sumo Logic and CrowdStrike API integration explored for enhanced security monitoring.

Meraki VPN configurations require specific settings for secure connections. Okta integration involves real-time two-factor authentication and SAML tagging. Split tunneling configured for point-to-point connections; issues with IP address conflicts noted. Microsoft Purview used for DLP and sensitivity labeling; file labeling under consideration. Sumo Logic and CrowdStrike API integration explored for enhanced security monitoring. List all speakers/Participants of Transcript:

Rylee Hulgan (Kimray) Josh Gold (SHI Representative) Felix Menchaca (SHI Representative) Manuel Zelaya (SHI Labs Representative) Jacob Holmes (Kimray)

Rylee Hulgan (Kimray) Josh Gold (SHI Representative) Felix Menchaca (SHI Representative) Manuel Zelaya (SHI Labs Representative) Jacob Holmes (Kimray)

Potential Next steps

Action Item 1: Explore cost-effective NDR solutions and schedule a follow-up discussion with Cisco and Meraki representatives.

Action Item 1: Explore cost-effective NDR solutions and schedule a follow-up discussion with Cisco and Meraki representatives.

Responsible: Josh Gold and Rylee Hulgan to coordinate.

Responsible: Josh Gold and Rylee Hulgan to coordinate.

Action Item 2: Set up a demo and discovery call with Sumo Logic for SIM solutions.

Action Item 2: Set up a demo and discovery call with Sumo Logic for SIM solutions.

Responsible: Manuel Zelaya to organize and involve Rylee Hulgan.

Responsible: Manuel Zelaya to organize and involve Rylee Hulgan.

Action Item 3: Investigate Azure application proxy for potential zero trust strategy implementation.

Action Item 3: Investigate Azure application proxy for potential zero trust strategy implementation.

Responsible: Rylee Hulgan to evaluate and discuss with SHI team.

Responsible: Rylee Hulgan to evaluate and discuss with SHI team.

Action Item 4: Review email security options and consider modern solutions like Abnormal Security.

Action Item 4: Review email security options and consider modern solutions like Abnormal Security.

Responsible: Felix Menchaca to provide insights and support to Rylee Hulgan.

Responsible: Felix Menchaca to provide insights and support to Rylee Hulgan.

Action Item 5: Schedule a meeting to prioritize security gaps and deliver a resource list to Kimray's IT team.

Action Item 5: Schedule a meeting to prioritize security gaps and deliver a resource list to Kimray's IT team. From <https://mindspark.shi.com/My_Favorites>
