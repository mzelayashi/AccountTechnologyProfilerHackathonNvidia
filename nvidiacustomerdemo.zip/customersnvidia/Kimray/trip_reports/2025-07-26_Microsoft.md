Trip Report | Microsoft | Kimray

Customer: Kimray
AE: Felix M
Topic: Microsoft
Meeting Date 07/26/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Felix M

end pro form for manufacturer release; Rylee to review/sign and return for SHI to gain visibility into renewals (esp. MPSA, SOTI, Azure).

08/15

2

Manuel

coordinate a targeted, non-product-centric session on SIEM/log ingestion, focusing on Kimray’s multi-platform needs; schedule for Q4 or as time permits.

08/15

Item Owner Next Steps/Detail Due Date 1 Felix M end pro form for manufacturer release; Rylee to review/sign and return for SHI to gain visibility into renewals (esp. MPSA, SOTI, Azure). 08/15 2 Manuel coordinate a targeted, non-product-centric session on SIEM/log ingestion, focusing on Kimray’s multi-platform needs; schedule for Q4 or as time permits. 08/15

Summary

Project & Renewal Discussion | Kimray + SHI his collaborative session between Kimray (Rylee Hulgan, Jacob Holmes) and SHI (Felix Menchaca, Tyler Rodgers) focused on ongoing renewal management, vendor consolidation, cloud optimization, and security posture advancement. Kimray expressed a strong desire to move renewals and project support to SHI, citing better alignment and responsiveness than legacy vendors. The team discussed the process for shifting renewals (especially MPSA, SOTI, and Azure Global Access), using SHI’s pro form for manufacturer release, and the need for improved support with SQL and cloud services. Security priorities centered on ingesting, correlating, and acting on logs across on-prem, cloud, and storage platforms in a resource-constrained environment. There is openness to targeted, non-product-centric security workshops and to future networking refreshes, but AI initiatives are on hold, managed by a different team. SHI’s advisory and renewal management services are positioned as a strategic differentiator for Kimray’s IT and security roadmap.

Agenda

Review current renewal landscape and vendor migration to SHI Discuss pro form process for renewal visibility and management Address Azure/AWS cloud environment and support needs Explore current and future security posture, log ingestion, and SIEM/SOC requirements Touch on AI journey, market security alerts, and next steps

Review current renewal landscape and vendor migration to SHI Discuss pro form process for renewal visibility and management Address Azure/AWS cloud environment and support needs Explore current and future security posture, log ingestion, and SIEM/SOC requirements Touch on AI journey, market security alerts, and next steps

Opps Identified & BANTC

Opportunity 1: Renewal & Project Migration to SHI
(MPSA, SOTI, Azure, etc.)

B: Kimray
is seeking to migrate as many renewals/projects as possible to SHI for improved service and consolidation; MPSA and SOTI are in scope, with Azure Global Access as a next target.
A: Rylee
Hulgan (Kimray), Felix Menchaca, Tyler Rodgers (SHI), Kimray leadership for approvals.
N: Immediate
for MPSA, SOTI, Azure; ongoing as other renewals/projects come due.
T: Now
— pro form to be (re-)executed; ongoing for future renewals.
C: Rylee
Hulgan, Felix Menchaca, Tyler Rodgers, SHI renewal/Cloud teams.

B: Kimray
is seeking to migrate as many renewals/projects as possible to SHI for improved service and consolidation; MPSA and SOTI are in scope, with Azure Global Access as a next target.
A: Rylee
Hulgan (Kimray), Felix Menchaca, Tyler Rodgers (SHI), Kimray leadership for approvals.
N: Immediate
for MPSA, SOTI, Azure; ongoing as other renewals/projects come due.
T: Now
— pro form to be (re-)executed; ongoing for future renewals.
C: Rylee
Hulgan, Felix Menchaca, Tyler Rodgers, SHI renewal/Cloud teams.
Opportunity 2: Azure Cloud Optimization and SQL
Support

B: Kimray
is heavily invested in Azure (database services, Intra, P2 licensing) and needs advanced SQL/DB support; current partners are inadequate.
A: Rylee
Hulgan, Kimray SQL team, SHI Azure/SQL specialists.
N: High
— current partner (Pinnacle) cannot support advanced needs; Kimray wants
to enable better SQL/ERP integration, especially for NetSuite.
T: Near-term;
initial conversations to be scheduled after MPSA transition.
C: Rylee
Hulgan, Felix Menchaca, SHI Azure/SQL/Cloud teams.

B: Kimray
is heavily invested in Azure (database services, Intra, P2 licensing) and needs advanced SQL/DB support; current partners are inadequate.
A: Rylee
Hulgan, Kimray SQL team, SHI Azure/SQL specialists.
N: High
— current partner (Pinnacle) cannot support advanced needs; Kimray wants
to enable better SQL/ERP integration, especially for NetSuite.
T: Near-term;
initial conversations to be scheduled after MPSA transition.
C: Rylee
Hulgan, Felix Menchaca, SHI Azure/SQL/Cloud teams.
Opportunity 3: Security Posture Improvement & Log
Ingestion

B: Kimray
needs a SIEM/log ingestion solution that is simple, cost-effective, and can ingest logs from on-prem, storage, VMware, cloud, and machine data; resource constraints require a lightweight, targeted approach.
A: Rylee
Hulgan, Jacob Holmes, Felix Menchaca, SHI Security/SIEM experts.
N: Medium/High
— limited current visibility; recent incidents have highlighted the gap;
resource and time constraints are a challenge.
T: Q4
or when capacity allows, but initial scoping can begin now.
C: Rylee
Hulgan, Felix Menchaca, SHI security team.

B: Kimray
needs a SIEM/log ingestion solution that is simple, cost-effective, and can ingest logs from on-prem, storage, VMware, cloud, and machine data; resource constraints require a lightweight, targeted approach.
A: Rylee
Hulgan, Jacob Holmes, Felix Menchaca, SHI Security/SIEM experts.
N: Medium/High
— limited current visibility; recent incidents have highlighted the gap;
resource and time constraints are a challenge.
T: Q4
or when capacity allows, but initial scoping can begin now.
C: Rylee
Hulgan, Felix Menchaca, SHI security team.
Opportunity 4: Network Refresh (Future)

B: Kimray
is considering a Meraki/Cisco network refresh in the next 12–24 months.
A: Rylee
Hulgan, Jacob Holmes, Felix Menchaca.
N: Low/Medium
— early-stage, but SHI should stay engaged.
T: 2026
or as business needs evolve.
C: Rylee
Hulgan, Jacob Holmes, Felix Menchaca.

B: Kimray
is considering a Meraki/Cisco network refresh in the next 12–24 months.
A: Rylee
Hulgan, Jacob Holmes, Felix Menchaca.
N: Low/Medium
— early-stage, but SHI should stay engaged.
T: 2026
or as business needs evolve.
C: Rylee
Hulgan, Jacob Holmes, Felix Menchaca.
Opportunity 5: AI Briefings/Workshops (Future)

B: AI/automation
initiatives are owned by a different team (Daniel Younger); Kimray is not ready to engage but may revisit after data/ERP projects.
A: Daniel
Younger (Kimray), Felix Menchaca (SHI).
N: Low
— at least 8 months out; SHI to send info for future reference.
T: 2026.
C: Daniel
Younger, Felix Menchaca.

B: AI/automation
initiatives are owned by a different team (Daniel Younger); Kimray is not ready to engage but may revisit after data/ERP projects.
A: Daniel
Younger (Kimray), Felix Menchaca (SHI).
N: Low
— at least 8 months out; SHI to send info for future reference.
T: 2026.
C: Daniel
Younger, Felix Menchaca.

Initiatives

Security: Log ingestion/SIEM, posture review, endpoint/network/cloud security, SharePoint vulnerability awareness. Storage/Cloud: Azure optimization, SQL support, NetSuite/ERP integration, AWS as tertiary/DR and DNS only. Both: Renewal/project management, vendor consolidation, network refresh (future), AI (future).

Security: Log ingestion/SIEM, posture review, endpoint/network/cloud security, SharePoint vulnerability awareness. Storage/Cloud: Azure optimization, SQL support, NetSuite/ERP integration, AWS as tertiary/DR and DNS only. Both: Renewal/project management, vendor consolidation, network refresh (future), AI (future).

Tech Profile Updates

MPSA, SOTI, and Azure Global Access targeted for SHI management. Azure is the primary cloud platform (DB, Intra, P2, DLP, NetSuite integration); AWS used for DR and DNS (Route 53).

Security

No separate cybersecurity team; log ingestion and SIEM are emerging priorities; Crowdstrike in use for endpoint. Network: Currently Meraki; potential refresh in 1–2 years. AI: Not currently a focus; separate team (Daniel Younger) handling AI/data initiatives. Cameras/access control: Security is Genetec; not open to change.

MPSA, SOTI, and Azure Global Access targeted for SHI management. Azure is the primary cloud platform (DB, Intra, P2, DLP, NetSuite integration); AWS used for DR and DNS (Route 53).

Security

No separate cybersecurity team; log ingestion and SIEM are emerging priorities; Crowdstrike in use for endpoint. Network: Currently Meraki; potential refresh in 1–2 years. AI: Not currently a focus; separate team (Daniel Younger) handling AI/data initiatives. Cameras/access control: Security is Genetec; not open to change.

Meeting Notes

Environment

Kimray is moving toward vendor consolidation with SHI due to perceived value and responsiveness. Current cloud, database, and security projects are resourced-constrained, with limited IT/security staff. Organizational policy keeps security/camera/access control decisions strictly within the

security team (Genetec).

ERP/data modernization (NetSuite, Azure SQL) is a major business driver.

Kimray is moving toward vendor consolidation with SHI due to perceived value and responsiveness. Current cloud, database, and security projects are resourced-constrained, with limited IT/security staff. Organizational policy keeps security/camera/access control decisions strictly within the

security team (Genetec).

ERP/data modernization (NetSuite, Azure SQL) is a major business driver.

Detailed Discussion

Renewals: MPSA, SOTI, Azure Global Access are priorities for migration to SHI; pro form process used for manufacturer release; vendor loyalty is strong once value is demonstrated. Cloud: Azure is the primary platform for databases, Intra, DLP, and ERP integration. SQL support is a pain point; AWS is only for DR/DNS. Security: No formal cybersecurity team; log ingestion and SIEM are urgent needs, especially for machine logs and multi-platform integration. Kimray seeks a non-product-centric, consultative approach—targeted, actionable guidance over sales. Network: Meraki currently in use; dissatisfaction with post-acquisition Cisco experience; network refresh in 1–2 years. AI: Not a current focus; Daniel Younger’s team is in charge. SHI to provide info for future engagement. Market Alerts: SHI made Kimray aware of SharePoint zero-day and Ingram Micro cyberattack.

Renewals: MPSA, SOTI, Azure Global Access are priorities for migration to SHI; pro form process used for manufacturer release; vendor loyalty is strong once value is demonstrated. Cloud: Azure is the primary platform for databases, Intra, DLP, and ERP integration. SQL support is a pain point; AWS is only for DR/DNS. Security: No formal cybersecurity team; log ingestion and SIEM are urgent needs, especially for machine logs and multi-platform integration. Kimray seeks a non-product-centric, consultative approach—targeted, actionable guidance over sales. Network: Meraki currently in use; dissatisfaction with post-acquisition Cisco experience; network refresh in 1–2 years. AI: Not a current focus; Daniel Younger’s team is in charge. SHI to provide info for future engagement. Market Alerts: SHI made Kimray aware of SharePoint zero-day and Ingram Micro cyberattack.

Technical Notes

Pro form is the tool for manufacturer/renewal visibility; MPSA is not currently with Pinnacle and can be moved. Azure SQL integration with NetSuite is prioritized for ease of use and security consistency. AWS used for Route 53 DNS and offsite DR; Azure’s DNS not preferred. SIEM/log ingestion solution must support on-prem, VMware, Cohesity, Pier, and Azure; needs simplicity, affordability, and actionable reporting.

Security

posture review completed; SHI can provide targeted, expert-led workshops as needed. Machine log ingestion and local log management are high on the wish list. Camera/access control: Genetec is the standard, no changes considered.

Pro form is the tool for manufacturer/renewal visibility; MPSA is not currently with Pinnacle and can be moved. Azure SQL integration with NetSuite is prioritized for ease of use and security consistency. AWS used for Route 53 DNS and offsite DR; Azure’s DNS not preferred. SIEM/log ingestion solution must support on-prem, VMware, Cohesity, Pier, and Azure; needs simplicity, affordability, and actionable reporting.

Security

posture review completed; SHI can provide targeted, expert-led workshops as needed. Machine log ingestion and local log management are high on the wish list. Camera/access control: Genetec is the standard, no changes considered. List all speakers/Participants of Transcript:

Felix Menchaca (SHI) Tyler Rodgers (SHI) Rylee Hulgan (Kimray) Manuel Zelaya (SHI) Jacob Holmes (Kimray) Daniel Younger (Kimray, referenced, AI/data) Jeremy Biggs (Kimray, referenced, security/camera) Joey Nickel, Tyler Parker (SHI, referenced, Azure/Cloud)

Felix Menchaca (SHI) Tyler Rodgers (SHI) Rylee Hulgan (Kimray) Manuel Zelaya (SHI) Jacob Holmes (Kimray) Daniel Younger (Kimray, referenced, AI/data) Jeremy Biggs (Kimray, referenced, security/camera) Joey Nickel, Tyler Parker (SHI, referenced, Azure/Cloud)

Potential Next Steps

Pro Form for Renewals

Pro Form for Renewals

Action: Felix to (re-)send pro form for manufacturer release; Rylee to review/sign and return for SHI to gain visibility into renewals (esp. MPSA, SOTI, Azure). Participants: Felix Menchaca (to Rylee Hulgan)

Action: Felix to (re-)send pro form for manufacturer release; Rylee to review/sign and return for SHI to gain visibility into renewals (esp. MPSA, SOTI, Azure). Participants: Felix Menchaca (to Rylee Hulgan)

Azure/SQL Support Engagement

Azure/SQL Support Engagement

Action: SHI to organize an intro call between Kimray’s SQL/cloud team and SHI’s Azure/SQL specialists to scope support/optimization opportunities. Participants: Felix Menchaca (to Rylee Hulgan, SHI Azure Team)

Action: SHI to organize an intro call between Kimray’s SQL/cloud team and SHI’s Azure/SQL specialists to scope support/optimization opportunities. Participants: Felix Menchaca (to Rylee Hulgan, SHI Azure Team)

Security & SIEM/Log Ingestion

Workshop

Security & SIEM/Log Ingestion

Workshop

Action: SHI to coordinate a targeted, non-product-centric session on SIEM/log ingestion, focusing on Kimrays multi-platform needs; schedule for Q4 or as time permits. Participants: Felix Menchaca (to Rylee Hulgan, Jacob Holmes, SHI Security Team)

Action: SHI to coordinate a targeted, non-product-centric session on SIEM/log ingestion, focusing on Kimrays multi-platform needs; schedule for Q4 or as time permits. Participants: Felix Menchaca (to Rylee Hulgan, Jacob Holmes, SHI Security Team)

Network Refresh Opportunity Tracking

Network Refresh Opportunity Tracking

Action: Felix to note network refresh timeline (2026) and maintain ongoing communication on options. Participants: Felix Menchaca (to Rylee Hulgan, Jacob Holmes)

Action: Felix to note network refresh timeline (2026) and maintain ongoing communication on options. Participants: Felix Menchaca (to Rylee Hulgan, Jacob Holmes)

AI Briefings (Future)

AI Briefings (Future)

Action: Felix to send Daniel Younger an informational email about SHI’s AI value-add/briefings for future engagement. Participants: Felix Menchaca (to Daniel Younger)

Action: Felix to send Daniel Younger an informational email about SHI’s AI value-add/briefings for future engagement. Participants: Felix Menchaca (to Daniel Younger)

Market Security Updates

Market Security Updates

Action: Felix to continue providing timely alerts on major vulnerabilities and vendor risks (e.g., SharePoint, Ingram Micro). Participants: Felix Menchaca (to Kimray team)

Action: Felix to continue providing timely alerts on major vulnerabilities and vendor risks (e.g., SharePoint, Ingram Micro). Participants: Felix Menchaca (to Kimray team)

General Follow-Up

General Follow-Up

Action: Felix to send meeting recap and

next steps summary to all participants.

Participants: Felix Menchaca (to Kimray team)

Action: Felix to send meeting recap and

next steps summary to all participants.

Participants: Felix Menchaca (to Kimray team)
