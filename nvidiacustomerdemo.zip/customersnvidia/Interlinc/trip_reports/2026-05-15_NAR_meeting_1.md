Trip Report | NAR meeting 1 | Interlinc

Customer: Interlinc
AE: Jax M
Topic: NAR meeting 1
Meeting Date 05/15/2026

*Internal notes – Please read and edit before sending externally*

Summary

Summary: • This call was a Network Architecture Review (NAR) kickoff between SHI and Interlinc focused on understanding the customer’s current network, cloud, and security

security posture, and operational efficiency.

Agenda: • Introductions and roles • Overview of SHI Network Architecture Review (NAR) process • Customer environment discovery (network, cloud, WAN, security, management) • Identification of pain points and gaps • Discussion of future considerations (Zero Trust, SASE, DR) • Outline of next steps and deliverables [Interlinc...Recording | Video]

Opps Identified

& BANTC
Opportunity 1:
Network Visibility & Monitoring Solution • B: Not explicitly defined, but clear operational gap affecting troubleshooting efficiency and user experience
• A: IT team (Nam, Jason and team) are primary validators; leadership influence
Security Modernization (Zero Trust / NAC / SSE) • B: Not stated, but tied to broader security posture improvements • A: IT team drives architecture; leadership input required for strategy changes • N: Medium – no NAC, no device authentication, shared Wi-Fi passwords, flat network • T: Mid-to-long term • C: Increasing importance due to modern security requirements and lack of segmentation [Interlinc...Recording | Video]
Opportunity 3:
Branch Infrastructure Refresh (SonicWall upgrades) • B: Not defined • A: IT team • N: Medium – branch devices (TZ350/500) are aging and not receiving updates • T: Mid-term refresh aligned with cloud migration • C: Driven by end-of-life risk and support limitations [Interlinc...Recording | Video]
Opportunity 4:
Disaster Recovery & Ransomware Readiness • B: Not defined • A: IT + leadership • N: Medium – DR exists via Druva but lacks tested failover validation • T: Mid-term • C: Risk mitigation and compliance-driven opportunity [Interlinc...Recording | Video] Initiatives: • Cloud Migration (SharePoint / OneDrive) – Security + Operational Efficiency • Reduced VPN Dependency / Cloud-first App Access – Security + Network Simplification • Exploration of SonicWall Cloud Secure Edge – Security • Potential Zero Trust evaluation – Security • Disaster Recovery improvement (AWS DR + Druva validation) – Security Tech Profile Updates: • Cloud: AWS primary (Ohio region, Virginia DR region) • Networking: SonicWall NSV + branch SonicWalls • WAN: Internet + VPN-based connectivity • Wireless: Ubiquiti Wi-Fi (older AC generation) • Security: SonicWall IPS enabled, Rapid7 SIEM, Windows Defender • Endpoint / RMM: NinjaOne • Ticketing: Freshservice • Backup: Druva (EC2)

Meeting Notes

Environment: • Predominantly AWS-hosted infrastructure (12/14 servers in AWS) • Two VPCs with Transit Gateway (secondary VPC minimally used) • SonicWall NSV acts as central hub for all branch connectivity • 6 branch offices connected via VPN; others operate independently • Corporate office has HA SonicWall with dual ISP (AT&T primary, Comcast backup) • End-user apps largely cloud accessible (Encompass does not require VPN) [Interlinc...Recording | Video] Detailed Discussion: • Customer is transitioning away from traditional VPN-based file access toward cloud platforms (OneDrive/SharePoint) • Network architecture is simple/flat with minimal segmentation and centralized firewalling • Branch offices rely on single firewall designs without redundancy • Security posture is basic (IPS enabled, no NAC, no strong identity-based access control) • Monitoring and observability are limited, creating challenges in diagnosing network issues • Small IT team supports entire infrastructure, including

Technical Notes

• AWS-only infrastructure for compute (EC2-based, no containers) • SonicWall
NSV in AWS used as central aggregation point for all offices • Branch devices: TZ350, TZ370, TZ500 models (some outdated) • Dual ISP failover configured active-passive at HQ • DHCP handled by SonicWall; DNS handled by domain controllers • Wi-Fi: Ubiquiti APs (AC generation, shared password auth) • No NAC / 802.1X / device authentication in wired or wireless networks • No microsegmentation or Zero Trust controls in AWS or on-prem • SIEM: Rapid7 capturing logs from DCs, endpoints, and firewalls • RMM: NinjaOne for patching, monitoring, remote access • No NetFlow or traffic analytics capabilities • Monitoring is ICMP-based with alerting into Freshservice • Voice: RingCentral (cloud-based telephony) [Interlinc...Recording | Video] List all speakers/Participants of Transcript (titles and companies): • Jax Miley – Account / Customer Engagement Lead (SHI) • Scott Jester – Network Architecture Lead (SHI) • Nick Handel – Network Engineer / Architect (SHI) • Nam Nguyen – IT Engineer / Systems & Network Admin (Interlinc) • Jason Stark – IT Leadership / Decision Influencer (Interlinc) Potential Next Steps: • Scott Jester → Interlinc IT Team: Request for network diagrams and additional documentation to enrich analysis • Interlinc IT Team (Nam) → SHI: Provided high-level network diagram during call • SHI (Scott + Nick) → Interlinc: Build and deliver NAR findings presentation with recommendations and roadmap • SHI → Interlinc: Potential follow-up engagement for Secure Connect / SASE / Zero Trust briefing • SHI internal teams → Scott: Coordinate AWS diagram normalization and possibly schedule screen-share session for deeper cloud mapping • Future joint session (SHI + Interlinc): Review findings, validate recommendations, and prioritize roadmap items • Potential future workshop: Security architecture (Zero Trust / NAC / SSE) • Potential future engagement: Network visibility / observability tooling evaluation
