Trip Report | Delinia Dem | HW Resources

Customer: HW Resources
AE: Leslie S
Topic: Delinia Dem
Meeting Date 12/16/2025

*Internal notes – Please read and edit before sending externally*

Summary

This meeting involved a detailed technical and business discussion between Delinea (vendor) and the customer team regarding Privileged Access Management (PAM), identity governance, password rotation automation, vendor access control, and environments. The meeting concluded with licensing discussions, the customer’s environment size estimates (700 workstations, 100 servers), and agreement to review pricing with a follow‑up meeting on Friday at 9:00 AM.

Agenda

• Review customer

environment challenges and drivers

• Demonstration
of Secret Server vaulting, discovery, password rotation, and dependencies
• Overview of JIT
elevation and privileged access workflows
• Discussion of
contractor and vendor access scenarios
• Identity
posture and entitlement mapping module
• Licensing,
packaging, and next steps

Opportunities Identified & BANTC

Opportunity 1: Privileged Access Management Platform
(Secret Server + JIT + Vendor Access + Discovery) B (Business Need):
• Multiple AD
domains with limited visibility and inconsistent access patterns
• Lack of
password rotation across service accounts and local admin accounts
• SOX compliance
and audit preparation
• Developer
pushing ERP updates without segregation of duties
• No session
recording or access audit trail
• Need simplified
vendor remote access without VPN A (Authority):
• Paul Wilhelm
leads the evaluation and will present numbers to his boss for approval
• Boss has budget
expectations and authority for purchasing decisions N (Need Urgency / Timing):

environment may add deployment complexity

Initiatives

Security Initiatives

• PAM
implementation across multi‑domain AD environment
• SOX compliance
readiness and audit trail improvements
• Session
recording and privileged access governance
• Vendor access
hardening and MFA enforcement
• Identity
posture and entitlement mapping Storage Initiatives:
• None directly
discussed Both:
• None

Tech Profile Updates

• Hybrid
identity: On‑prem AD + Entra (Azure AD) sync
• ERP system with
developer‑driven updates; lacking change visibility
• Multidomain
(four AD domains across sister companies)
• Bitwarden used
for credential storage today
• Duo used for
workstation authentication and MFA
• Mix of on‑prem
VMware and AWS for sister company
• Workstations
~700, servers ~100

Meeting Notes

Environment

Technical Notes (Granular)

• Discovery
micro‑engines scan AD OUs for service accounts, scheduled tasks, and local admin accounts
• Rotation engine
iterates dependencies: services, tasks, application pools, text files
• Password
rotation done by bridge box (agentless)
• For deeper
server-level recording, an agent is required
• MFA enforced at
secret access or privilege elevation events
• JIT elevation
can restrict user to only allowed apps (PowerShell, Notepad, etc.)
• Bridge Box acts
as proxy for automating rotation and session launching
• Contractors can
be assigned cloud accounts → vendor role → trimmed UI
• No need for VPN
or AD account for vendor login
• Identity
posture supports AWS, Entra ID, AD, Okta, Ping

ROLES (Titles & Companies)

Customer (End‑User Organization)

Potential Next Steps

1. Vendor to send pricing comparison (Action: David →
Paul)
• David will
compile EOY pricing compared to January pricing.
• Paul will
review with his boss.
