Trip Report | Storage Options | HW Resources

Customer: HW Resources
AE: Leslie Schmulson
Topic: Storage Options
Meeting Date 10/10/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

Live Optics Analysis

Manuel

Manuel to set up Live Optics session.

10/17/24

SHI One Portal Access

Leslie

Leslie to set up access for Paul to the SHI One portal.

10/17/24

Follow-Up Discussion

Leslie

Review outcomes from Live Optics and SHI One portal evaluation

10/24/24

Item Owner Next Steps/Detail Due Date Live Optics Analysis Manuel Manuel to set up Live Optics session. 10/17/24 SHI One Portal Access Leslie Leslie to set up access for Paul to the SHI One portal. 10/17/24 Follow-Up Discussion Leslie Review outcomes from Live Optics and SHI One portal evaluation 10/24/24

Summary

The conversation centered on evaluating cloud versus on-premise infrastructure for cost efficiency and operational stability. Paul Wilhelm expressed concerns over the high AWS spend, currently at $3.5 million annually, and discussed options including staying on-premise or moving more workloads to the cloud. The discussion included technical details about current infrastructure, such as VMware usage and storage capacity. Suggested using Live Optics for a comprehensive environment analysis. Introduced the SHI One portal as a tool to assist in decision-making and infrastructure evaluation.

Agenda

Evaluate current cloud and on-premise infrastructure costs and benefits. Discuss potential migration strategies and infrastructure management. Explore SHI One portal capabilities for infrastructure analysis.

Evaluate current cloud and on-premise infrastructure costs and benefits. Discuss potential migration strategies and infrastructure management. Explore SHI One portal capabilities for infrastructure analysis.

Opportunities Identified & BANTC

Opportunity: Cloud Migration Cost Analysis

Opportunity: Cloud Migration Cost Analysis

B: NOT
DETAILED Budget constraints due to high AWS spend.
A: Paul
Wilhelm, IT decision-maker, with Wendy as a higher-up.
N: Need
to reduce costs and improve infrastructure efficiency. T: Q4 strategy meeting for potential PO in Q1
C: Currently
reviewing cloud versus on-premise options.

B: NOT
DETAILED Budget constraints due to high AWS spend.
A: Paul
Wilhelm, IT decision-maker, with Wendy as a higher-up.
N: Need
to reduce costs and improve infrastructure efficiency. T: Q4 strategy meeting for potential PO in Q1
C: Currently
reviewing cloud versus on-premise options.

Initiatives

Storage: Consideration of replacing Dell PowerStore with alternatives like Pure Storage.

Storage: Consideration of replacing Dell PowerStore with alternatives like Pure Storage.

Tech Profile Updates

Current use of VMware for virtualization. Existing infrastructure includes Dell and HP hosts, with some AWS services. Storage primarily on Dell PowerStore, considering alternatives.

Current use of VMware for virtualization. Existing infrastructure includes Dell and HP hosts, with some AWS services. Storage primarily on Dell PowerStore, considering alternatives.

Meeting Notes

Environment

Data center primarily on-premise with cloud elements. Use of SD-WAN for connectivity across locations. Evaluation of AWS, on-premise, and hybrid solutions for infrastructure.

Data center primarily on-premise with cloud elements. Use of SD-WAN for connectivity across locations. Evaluation of AWS, on-premise, and hybrid solutions for infrastructure.

Detailed Discussion

Paul Wilhelm detailed the financial shock of AWS costs and the directive from his boss to explore options. Discussion on virtualization and storage capacity with VMware and Dell PowerStore. Manuel Zelaya proposed using Live Optics for a detailed environment analysis. Leslie Schmulson introduced SHI One portal for infrastructure evaluation and management.

Paul Wilhelm detailed the financial shock of AWS costs and the directive from his boss to explore options. Discussion on virtualization and storage capacity with VMware and Dell PowerStore. Manuel Zelaya proposed using Live Optics for a detailed environment analysis. Leslie Schmulson introduced SHI One portal for infrastructure evaluation and management.

Technical Notes

Current environment runs approximately 100 VMs using VMware. Storage setup includes 37 TB on PowerStore, with 21 TB in use. DR replication to AWS using Druva. SD-WAN implemented with Silver Peak (Aruba).

Current environment runs approximately 100 VMs using VMware. Storage setup includes 37 TB on PowerStore, with 21 TB in use. DR replication to AWS using Druva. SD-WAN implemented with Silver Peak (Aruba). List all speakers/Participants of Transcript:

Leslie Schmulson Paul Wilhelm Manuel Zelaya

Leslie Schmulson Paul Wilhelm Manuel Zelaya
