# Trip Report — AmeriVet + SHI | Intro Meeting
_2026-06-05_

AmeriVet + SHI | Intro Meeting
I found 31 meetings in the search results, including this exact match, and this meeting was transcribed. The analysis below is based on the transcript and meeting metadata only.
Summary
This was an introductory relationship-building call between Jax Miley and Stephen Drake from SHI and Nicholas Sherman from AmeriVet, who said he had been in the role of Director of Information Security for less than a month and was still “drinking from the fire hose.” The business purpose of the call was to establish how SHI can support AmeriVet’s security program, explain SHI’s role as a broad technology advisor and procurement/support partner, and identify where SHI can help accelerate evaluation and selection of security technologies. The conversation made clear that AmeriVet’s immediate security priorities are maturing its security program, strengthening policies/processes/procedures, moving toward PCI compliance, and closing clear control gaps—especially around DLP.
The most concrete opportunity uncovered was DLP. Nicholas Sherman explicitly said AmeriVet has a DLP need and gave a practical test case: he emailed himself a bogus Social Security number and credit card number and the email passed through, which he called out as a serious gap. He also described a broader requirement that extends beyond email into web traffic, including the desire to prevent sensitive data from being typed into tools like ChatGPT. SHI positioned itself not only as a reseller or broker of vendors, but as an advisor that can reduce evaluation overhead by building comparison matrices, bringing in SMEs, narrowing a long list of options, coordinating demos, and helping with pricing leverage across competing vendors.
A second major business theme was operational efficiency in security evaluation. Nicholas Sherman explained that his decision process typically includes hearing the vendor pitch, seeing a demo, optionally doing a proof of concept, and checking with trusted advisors and peers. He also said he prefers to first see whether current platforms can cover the need before adding more point tools, because consolidating tools reduces portal sprawl and troubleshooting overhead. SHI responded directly to that buyer behavior by describing a structured comparison-chart process, SME-led follow-up discussions, and a security posture review process that can feed recommendations into the SHI1 platform.
A third business theme was sequencing. Both SHI and AmeriVet acknowledged that some deeper engagements should wait until Nicholas Sherman is more acclimated to the environment. That applied especially to SHI’s security posture review engagement, which SHI said is interview-based, aligned to the NIST framework, and produces short-term and long-term recommendations. By contrast, the DLP conversation was treated as the first area worth actively “kicking the tires on” now. The call therefore served both as an intro meeting and as a prioritization session that separated near-term work from later-stage strategic assessment.
Agenda
Introductory discussion and relationship building between SHI and AmeriVet security leadership.
Overview of Nicholas Sherman’s background, current role, and early priorities at AmeriVet.
Review of SHI’s role, current AmeriVet relationship, and support model across hardware, cybersecurity, Microsoft, datacenter, storage, and networking.
Discussion of AmeriVet’s renewal landscape and active security tool context, including CrowdStrike, KnowBe4, Abnormal, and 1Password.
Identification of DLP as an immediate security gap and early priority.
Explanation of SHI comparison-chart methodology, SME support, and vendor narrowing process.
Overview of SHI’s security posture review engagement and how it maps into the SHI1 platform.
Discussion of future monthly syncs, partner education sessions, and possible executive briefing center engagement.
Opps Identified & BANTC
Opportunity 1: DLP and related data-classification evaluation
This was the clearest immediate opportunity raised on the call. Nicholas Sherman said DLP is on the roadmap, confirmed there is a DLP need, and provided a direct example of test data passing through email controls. SHI and AmeriVet then aligned on next steps around comparison charts and SME follow-up for web and email DLP, with classification tools also discussed because AmeriVet currently does not have a data-classification tool in place.
B: Budget was not discussed in the transcript.
A: Nicholas Sherman, Director of Information Security at AmeriVet, is the active security stakeholder defining the need and evaluating the space; final purchasing authority was not explicitly discussed.
N: Clear need for DLP across email and ideally web traffic; need to prevent exposure of sensitive data such as Social Security numbers and credit card numbers; related need to identify sensitive data more formally through classification.
T: Near-term. Stephen Drake explicitly said DLP seems like the first thing to start evaluating now, and SHI agreed to begin comparison work.
C: Explicit competitive/solution context included Abnormal’s DLP beta, existing-platform evaluation, and the possibility of multiple vendors being narrowed via SHI comparison charts and later demos.
Opportunity 2: Security posture review engagement plus SHI1 recommendations workflow
SHI introduced its security posture review as a structured, interview-based engagement aligned to NIST that produces a red/yellow/green assessment and short-term/long-term recommendations inside SHI1. Both SHI and AmeriVet agreed this looked valuable, but the timing should likely wait until Nicholas Sherman has had more time to learn the environment.
B: Budget was not discussed in the transcript.
A: Nicholas Sherman expressed interest and said they could revisit the engagement in a month or two; SHI suggested the best timing might be in months three through six once he has more tribal knowledge. Final approval authority was not explicitly discussed.
N: Need for a structured understanding of overall security posture, mapped recommendations, and a way to prioritize short-term and long-term remediation.
T: Deferred, not immediate. SHI recommended revisiting after more acclimation.
C: No direct competing service or vendor was named for this engagement in the transcript.
Opportunity 3: Password-management replacement
Nicholas Sherman said one of the three key items on his list was 1Password and that AmeriVet was looking at replacing it. However, he also said Jason Marves had already narrowed it down to two options and was working through that process, with Nicholas Sherman having provided his recommendation based on prior use. This is a real opportunity area, but SHI involvement did not appear to be the priority at this stage of the call.
B: Budget was not discussed in the transcript.
A: Jason Marves appears to be actively working the evaluation; Nicholas Sherman is influencing with his recommendation. Final decision authority was not explicitly discussed.
N: Replace 1Password.
T: Active now, but already narrowed to two options according to Nicholas Sherman.
C: Two final candidate solutions were referenced, but the transcript does not name them.
Initiatives
Security: Formalizing and strengthening the security program, including policies, processes, and procedures.
Security: Working toward PCI compliance.
Security: Evaluating DLP for email and potentially web traffic.
Security: Considering data classification as a related need because sensitive data must be identified in order to protect it effectively.
Security: Replacing 1Password.
Security: Possible future security posture review engagement and mapping recommendations into SHI1.
Storage: No storage initiative was identified in the transcript.
Tech Profile Updates
AmeriVet previously used Mimecast for email security gateway functionality and transitioned to Abnormal; SHI described that work as beginning with DMARC and then expanding into evaluating a different SEG.
Abnormal has a DLP offering in beta, which Nicholas Sherman acknowledged as one possible option.
AmeriVet has a “large CrowdStrike suite,” and Nicholas Sherman said the CrowdStrike renewal runs through March 2028 on what he described as a three-year term.
KnowBe4 was discussed as the current awareness/phishing training-related tool, and Nicholas Sherman said that renewal runs through December 2027.
1Password is being evaluated for replacement.
AmeriVet does not currently have a data-classification tool in place, according to Nicholas Sherman.
SHI said SHI1 is already heavily used by AmeriVet project manager personnel.
The proposed security posture review is interview-based, not agent-based, and follows the NIST framework.
Meeting Notes
Nicholas Sherman introduced himself as new to AmeriVet, less than a month into the Director of Information Security role, with a background in security and compliance and a broader IT history of more than 20 years.
He said his roadmap includes strengthening the security program and working toward PCI compliance.
SHI described its current relationship with AmeriVet and its role as a broad technology partner that can support hardware, cybersecurity, Microsoft, datacenter, storage, and networking needs.
The conversation reviewed current tool context and renewals, including CrowdStrike, KnowBe4, Abnormal, and 1Password.
DLP surfaced as the first significant near-term initiative because test sensitive data passed through email controls unblocked.
SHI proposed a comparison-led evaluation process supported by SMEs to reduce the burden of researching many vendors.
SHI also introduced its security posture review and SHI1-based recommendations workflow, with both sides agreeing the engagement seemed valuable but should likely wait until Nicholas Sherman is further acclimated.
The meeting closed with agreement to start on DLP comparison work, maintain monthly syncs, and use Teams as a faster communication path.
Environment
The available transcript indicates a Microsoft Teams meeting with SHI and AmeriVet participants and a 30-minute duration.
The environment details explicitly discussed were primarily security-tool and evaluation-process related rather than infrastructure topology or architecture specifics.
Known environment/tool references included CrowdStrike, Abnormal, KnowBe4, 1Password, and SHI1.
The transcript indicates a current control gap around DLP, and no data-classification tooling in place to Nicholas Sherman’s knowledge.
Nicholas Sherman explicitly said he was still understanding AmeriVet’s configurations and layouts, so detailed environment discovery was not yet complete at the time of the call.
Detailed Discussion
The first portion of the call focused on introductions and context-setting. Jax Miley described himself as the SHI account executive supporting AmeriVet and explained that SHI currently helps AmeriVet most heavily on the hardware side but can also support broader technology categories. Nicholas Sherman then described his background and stated that he had joined AmeriVet recently as Director of Information Security, with major focus areas around security, compliance, and PCI readiness. That established the frame for the rest of the discussion: SHI was meeting a newly arrived security leader and trying to show how it could accelerate his onboarding and evaluation workload.
The middle of the meeting centered on tool landscape and prioritization. SHI reviewed some historical engagement points, including the prior Mimecast-to-Abnormal work, then checked in on renewals and potential dissatisfaction or change candidates. Nicholas Sherman identified three main items on his list, two of which were discussed in depth: DLP and 1Password replacement. The DLP conversation became the most important because he immediately tied it to a real-world exposure test and confirmed it was an active need. Beyond email, he also broadened the requirement to web traffic and explicitly referenced blocking users from typing sensitive data into ChatGPT or similar destinations.
A meaningful portion of the call also explored buying behavior and how to streamline evaluation. Stephen Drake asked how Nicholas Sherman normally evaluates products, and the answer was structured and practical: listen to the pitch, review slides, see a demo, possibly run a proof of concept, then validate with peers and trusted advisors. Nicholas Sherman also made clear that, where possible, he prefers using existing platforms if they adequately satisfy requirements, because consolidation has operational value and reduces tool sprawl. SHI then aligned its value proposition to that exact approach, offering comparison matrices, expert review, narrower shortlists, and SME-led follow-up discussions.
The latter part of the discussion introduced higher-level SHI services. SHI explained its security posture review as a two-meeting, interview-based process that aligns findings to the NIST framework and generates actionable recommendations in SHI1. The tone of the exchange suggested interest, but both sides recognized that it would be better to revisit once Nicholas Sherman has learned more about AmeriVet’s existing configurations, layouts, and tribal knowledge. The call then closed on more tactical planning: monthly syncs, possible partner/SME educational sessions, DLP comparison work, and a later possible executive briefing center visit.
Technical Notes
Nicholas Sherman performed a simple validation test by emailing himself a bogus Social Security number and credit card number, and the message passed through; this was the clearest technical evidence cited on the call for a DLP gap.
The desired DLP coverage is not limited to email. He explicitly said web traffic should ideally be covered as well, including blocking scenarios where users try to enter sensitive data into ChatGPT.
Abnormal’s DLP capability was described as being in beta and was acknowledged as one possible route.
The call separated possible control domains into email DLP, web traffic DLP, and discussion around classification/data-layer-related needs.
Stephen Drake explicitly suggested two separate comparison charts for DLP—one for web traffic and one for email—and then pivoted the third area away from data-layer DLP toward classification tools once Nicholas Sherman said AmeriVet does not currently have data-classification tooling.
The logic for classification was stated plainly: AmeriVet must know which data is sensitive before it can protect it correctly.
Nicholas Sherman said his normal evaluation process includes a demo every time, with proof of concept if warranted.
He also said he prefers to examine existing platforms first to see whether they meet minimum requirements, even if they are not “best of breed,” because reducing portal sprawl and simplifying troubleshooting has operational value.
SHI’s comparison process was described as producing both a detailed PDF and an interactive HTML format.
SHI said SME follow-up would occur after comparison review so the conversation can narrow around what AmeriVet is specifically trying to achieve and what current platforms may already provide.
The security posture review was described as interview-based, not agent-based, consisting of an initial questionnaire meeting and a second meeting after about one to two weeks to review the results.
SHI said the security posture review follows the NIST framework and provides red/yellow/green scoring plus short-term and long-term recommendations.
SHI said those recommendations can be surfaced in SHI1 and, through SHI Labs, some solutions can be explored via on-demand demo environments rather than going directly to an OEM site.
CrowdStrike renewal timing was stated as March 2028. KnowBe4 renewal timing was stated as December 2027.
1Password replacement is already in progress internally, with two options apparently narrowed down outside this meeting.
ROLES
Jax Miley — Account Executive, SHI. He explicitly described himself as the account executive supporting AmeriVet and said he handles all things IT from the SHI side.
Nicholas Sherman — Director of Information Security, AmeriVet. He explicitly introduced himself with that title and described his background as security and compliance focused.
Stephen Drake — SHI leader/manager over Jax Miley. The transcript explicitly says he is Jax Miley’s “upline manager,” but does not state a formal job title.
Manuel Zelaya — SHI invitee listed in meeting metadata. The transcript snippet does not show spoken participation or state a role/title for him. Invite-only metadata does not confirm participation.
Kat Mullen — AmeriVet optional invitee listed in meeting metadata. The transcript snippet does not show spoken participation or state a role/title for her, and invite-only metadata does not confirm participation.
Potential Next steps
Stephen Drake to Jax Miley: initiate comparison-chart work for DLP, specifically separate views for web traffic and email, and include classification-tool analysis because AmeriVet does not currently have data-classification tooling. Involved: Stephen Drake, Jax Miley, Nicholas Sherman.
SHI to Nicholas Sherman: schedule a follow-up conversation with a DLP SME after the comparison materials are ready so AmeriVet can review questions, get recommendations, and discuss how and when to proceed. Involved: Jax Miley, Stephen Drake, Nicholas Sherman, SHI DLP SME.
Jax Miley to Nicholas Sherman: continue or establish monthly syncs with the information-security side of the house, and use those meetings for alignment plus selective vendor/partner education with advance notice. Involved: Jax Miley, Nicholas Sherman, relevant AmeriVet security stakeholders, occasional SHI partners/SMEs.
Jax Miley to Nicholas Sherman: connect over Teams for faster day-to-day communication. Involved: Jax Miley, Nicholas Sherman.
SHI and AmeriVet to revisit the security posture review later, once Nicholas Sherman has had more time to understand configurations, layouts, and tribal knowledge. SHI framed this as likely better in a later onboarding window rather than immediately. Involved: Nicholas Sherman, Jax Miley, Stephen Drake, SHI security SME.
SHI to Nicholas Sherman: send executive briefing center details for a possible future visit, with Stephen Drake suggesting a later timing such as October or even next year rather than the next July event. Involved: Jax Miley, Stephen Drake, Nicholas Sherman.
AmeriVet internal follow-up on password management remains with Jason Marves and Nicholas Sherman based on the transcript, since Nicholas Sherman said the field was already narrowed to two options and he had already given his recommendation. Involved: Jason Marves, Nicholas Sherman.

4 Jun
Thursday
11:00 AM - 11:30 AM
J
Jax Miley organized this
Ask
Loading
