Trip Report | POC Results | AmeriVet

Customer: AmeriVet
AE: Jax M
Topic: POC Results
Meeting Date 11/03/2025

*Internal notes – Please read and edit before sending externally*

Summary

• The meeting focused on reviewing the results of a
Proof of Concept (POC) for a security solution, primarily email security, DLP, and DMARC management, with the customer evaluating Checkpoint’s Infinity portal as a potential replacement for Mimecast.
• Participants discussed the value of consolidated
security management, advanced search and reporting features, and integration with existing tools (Microsoft 365, Mimecast, KnowBe4).
• The customer is considering migration timing,
contract implications, and technical fit, with a decision likely tied to the end of their Mimecast contract.
• Key business aspects include risk reduction,
compliance (PII/PHI handling), operational efficiency, and reporting for C-suite and regulatory needs.
• The meeting included a live walkthrough of the
portal, technical Q&A, and planning for further DMARC testing and trial extension.

Agenda

• Kickoff and introductions
• Review of POC results and portal features
• DMARC, SPF, DKIM configuration and management
• Phishing event analysis and reporting
• Search, quarantine, and reporting capabilities
• Integration with existing security stack (Mimecast,
KnowBe4, Microsoft)
• Next steps and trial extension planning

Opps Identified & BANTC

Opportunity 1: Migration from
Mimecast to Checkpoint Infinity Portal for Email Security
• B: Amerivet and related orgs need improved email
security, DLP, and consolidated management, with a focus on compliance and operational efficiency.
• A: Decision-makers include Mark, VicTorey, Kat, and
Jax, with input from Eric and James (Checkpoint). Kat and Mark are key for contract and technical decisions.
• N: Urgency is moderate; contract with Mimecast ends
in March/April, but migration could occur earlier if business/technical needs are met and contract terms allow.
• T: Timeline is tied to Mimecast contract end, but
trial extension and pre-configuration are possible to accelerate transition.
• C: Budget and contract terms are under review; Jax
and Eric discussed possible compensation for unused Mimecast contract period if migration occurs early.
Opportunity 2: DMARC, SPF, DKIM
Management and Reporting
• B: Need for automated, consolidated DMARC/SPF/DKIM
management and reporting for compliance and visibility.
• A: Mark and VicTorey are technical leads; James and
Eric (Checkpoint) provide guidance and support.
• N: Immediate need to test DMARC with Amerivet
domain; trial extended for further validation.
• T: Testing to occur during extended trial; migration
timing depends on results and contract.
• C: No explicit budget discussion, but part of
broader security solution evaluation.

Initiatives

• Security: Email security, DLP, phishing detection,
DMARC/SPF/DKIM management, unified quarantine, advanced search/reporting.
• Storage: Not discussed as a primary initiative in
this meeting.

Tech Profile Updates

• Testing Checkpoint Infinity portal for email
security, DLP, and DMARC management.
• Integration with Microsoft 365, Mimecast, KnowBe4.
• Evaluating transition from Mimecast to Checkpoint.
• Exploring use of unified quarantine and advanced
search features.
• Considering InfoSec mailbox for alert/report
consolidation.

Meeting Notes

Environment

• Amerivet and related domains, Microsoft 365 tenant,
Mimecast as current email security gateway, KnowBe4 for phishing reporting, GoDaddy for DNS management.

Detailed Discussion

• DMARC, SPF, DKIM: James explained configuration
options, including using hosted mailbox or customer’s own mailbox for DMARC reports. Mark clarified their domains are managed independently in GoDaddy, each with its own SPF/DKIM.
• Phishing Analysis: James demonstrated portal’s
phishing event breakdown, NLP-based detection, sender reputation modeling, and comparison with Microsoft’s verdicts.
• Quarantine/Search: Portal offers unified quarantine
and fast search (Mail Explorer), with advanced query options for deep dives.
• Reporting: Weekly security checkup reports,
customizable queries, and upcoming AI Copilot for natural language search/reporting.
• Integration: Discussion on how Mimecast currently
blocks some threats before reaching Checkpoint; allow-listing for testing; KnowBe4 button for phishing reporting.
• Trial Extension: Agreed to extend trial for further
DMARC testing and to align with team PTO schedules.
• Migration Planning: Discussion on contract timing,
possible compensation for unused Mimecast period, and pre-configuration for smooth transition.

Technical Notes

• DMARC setup: Options for hosted mailbox or customer
mailbox; DNS record updates required.
• SPF/DKIM: Limit of 10 domains per SPF record unless
using macros or text compression; Mark’s domains managed independently, each with own SPF/DKIM.
• Phishing detection: NLP, sender reputation, vendor
impersonation, entity recognition; detection of modern attacks with no links/attachments.
• Quarantine: Unified across Microsoft and Checkpoint;
manual and automated options; Mail Explorer for search and action.
• Reporting: Security checkup report auto-sent weekly
to admins; customizable queries exportable as CSV; AI Copilot for natural language search/reporting (feature in development).
• Integration: Mimecast blocks some threats before
Checkpoint; allow-listing for testing; KnowBe4 button supported for phishing reporting.
• System logs: Full audit trail of user actions in
portal, including email body views and policy changes.

ROLES

• James (Aaron) Genereaux – Checkpoint, technical
lead/presenter
• VicTorey McCray – Amerivet, technical lead
• Mark Berry – Amerivet, technical lead/administrator
• Eric Owings – Checkpoint, account manager/support
• Jax Miley – Checkpoint, customer success/quoting
• Kat Mullen – Amerivet, decision-maker
• Manuel Zelaya – SHI, participant
• Steve Park – Amerivet, participant
• Unknown Speaker – Checkpoint (support, quoting, or
technical)

Potential Next steps

• Mark to update Amerivet domain DMARC DNS record to
route reports to shared inbox for further testing (Mark to team).
• James to extend trial for another week to allow
DMARC testing and align with team PTO (James to team).
• Eric to coordinate next meeting for Thursday the
13th, confirm time with Mark, VicTorey, Steve, and Jax (Eric to team).
• Jax to send calendar invite for next meeting, loop
in Kat and others as needed (Jax to team).
• Mark to verify DMARC inbox configuration and confirm
data flow for testing (Mark to team).
• Team to review security checkup reports and consider
custom reporting needs (VicTorey, Mark, Kat to Checkpoint).
• Eric and Jax to discuss possible compensation for
unused Mimecast contract period if migration occurs before contract end (Eric/Jax to Kat/Mark).
• Team to consider allow-listing an inbox in Mimecast
for more accurate testing of Checkpoint detection (Mark, VicTorey, James).
• Team to plan for migration timing and
pre-configuration if decision to move forward is made

Trip Report | AmeriVet + SHI | Checkpoint POC/POV

CRM Link:    https://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=9ba1d1ad-4871-455a-b37b-9b5e9d70a869

Customer

AE

Topic

District

Meeting Date

Amerivet

Jax M

avenon

TOLA1

10/27

*Internal notes – Please read and edit before sending
externally*

Summary

• The meeting focused on initiating a Proof of Concept
(POC) for Checkpoint Avenon, specifically targeting email and collaboration security for AmeriVet’s Office 365 environment. The team discussed user and admin setup, policy configuration, integration with Exchange and OneDrive, and future options for DMARC and other SaaS applications. The goal is to evaluate Checkpoint’s capabilities in threat detection, DLP, and broader SaaS security, with a collaborative approach between AmeriVet and Checkpoint teams. Key business aspects include improving security posture, streamlining alert management, and ensuring seamless deployment and user experience.

Agenda

• Confirm team attendance and roles
• Initiate POC setup for Checkpoint Avenon
• Configure user/admin permissions and policies
• Connect Office 365 Mail and OneDrive
• Discuss DMARC and other SaaS integrations
• Plan next steps and schedule follow-up meeting

Opps Identified & BANTC

Opportunity 1: Checkpoint Avenon POC
for Email & Collaboration Security
• B (Budget): AmeriVet is evaluating Checkpoint as a
potential replacement or supplement to existing solutions (e.g., Mimecast), indicating budget allocation for security improvements.
• A (Authority): Mark Berry is the primary admin and
decision-maker for the POC; Anu Joseph is the account manager; Jax Miley and Eric Owings are involved in coordination.
• N (Need): Need for enhanced email security, DLP, and
streamlined alerting; interest in DMARC and SaaS app monitoring.
• T (Timeline): POC setup is immediate, with a
follow-up meeting scheduled for next week to review data population and progress.
• C (Competition): Existing solution (Mimecast) is
referenced; Checkpoint is being compared for features and integration.
Opportunity 2: DMARC Policy &
SaaS Application Monitoring
• B: Potential future budget for DMARC and additional
SaaS security modules (security awareness, archiving, leaked credentials, etc.).
• A: Mark Berry and AmeriVet’s migration team; James
(Checkpoint) provides technical guidance.
• N: Need for DMARC policy management and monitoring,
as well as visibility into OneDrive and other SaaS apps.
• T: To be determined after initial POC; DMARC setup
depends on mailbox routing and migration status.
• C: Existing DMARC setup managed by another team;
Checkpoint’s DMARC and SaaS modules are under evaluation.

Initiatives

• Security: Email threat detection, DLP, DMARC, SaaS
app monitoring (OneDrive, Teams, SharePoint)
• Storage: OneDrive file scanning and monitoring

Tech Profile Updates

• Office 365 Mail integrated with Checkpoint Avenon
for threat and DLP detection
• OneDrive added for file scanning and monitoring
• DMARC, security awareness, archiving, leaked
credentials, and SSPM modules available for trial
• Admin and user roles configured for granular
permissions and alert management

Meeting Notes

Environment

• AmeriVet’s Office 365 tenant
• Admin access via Infinity portal
• Users: Mark Berry (primary admin), VicTorey McCray,
Steve Park, Jax Miley, Eric Owings, Anu Joseph, James (Aaron) Genereaux, Christopher (Chris) Tidwell

Detailed Discussion

• Team confirmed attendance and readiness for POC
• Mark Berry set up account and shared screen for
configuration
• Admin and user roles assigned with specific
permissions for email and alert access
• Exchange integration initiated via Enterprise App
Connector; admin credentials required
• Detect mode policies created for threat and DLP (no
remediation actions during POC)
• Alert routing discussed; recommendation to use an
InfoSec group mailbox
• OneDrive integration added for file scanning;
similar process to email setup
• DMARC monitoring discussed; options depend on
mailbox routing and DNS configuration
• Additional modules (security awareness, archiving,
etc.) available for trial
• Next meeting scheduled for data review and further
configuration

Technical Notes

• Admins must be assigned specific service roles for
email and alert permissions
• “Receive alerts” and “Read email bodies” permissions
are configurable per user
• Detect mode policies for threat and DLP created for
all users/groups; no remediation during POC
• Exchange integration via Enterprise App Connector
requires admin credentials
• OneDrive integration uses existing connector; scans
files for threats and DLP
• DMARC monitoring can auto-detect if reports are
routed to domain mailbox; otherwise, DNS update required
• Alert routing best practice: InfoSec group mailbox
for high-volume alerts
• Additional SaaS apps (Teams, SharePoint) can be
added via security settings
• Data population and baseline learning for phishing
detection may take 24–48 hours

ROLES

• Mark Berry – Admin, AmeriVet
• VicTorey McCray – AmeriVet
• Steve Park – AmeriVet
• Jax Miley – AmeriVet
• Eric Owings – AmeriVet
• Anu Joseph – Account Manager, Checkpoint
• James (Aaron) Genereaux – Email & Collaboration

Security Specialist, Checkpoint

• Christopher (Chris) Tidwell – Security Engineer,
Checkpoint

Potential Next steps

• Mark Berry to monitor data population and confirm
alert routing setup (InfoSec mailbox)
• James to support ongoing portal configuration and
answer technical questions
• Anu Joseph to coordinate next meeting and serve as
primary contact for questions
• Jax Miley to facilitate meeting invites and
scheduling
• Mark Berry to check DMARC report routing and update
DNS if needed for Checkpoint monitoring
• Team to reconvene next week to review populated data
and discuss further configuration or expansion (OneDrive, DMARC, other SaaS apps)

Trip Report | AmeriVet + SHI | Checkpoint POC/POV

CRM Link:    https://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=9ba1d1ad-4871-455a-b37b-9b5e9d70a869

Customer

AE

Topic

District

Meeting Date

Amerivet

Jax M

avenon

TOLA1

10/27

*Internal notes – Please read and edit before sending
externally*

Summary

• The meeting focused on initiating a Proof of Concept
(POC) for Checkpoint Avenon, specifically targeting email and collaboration security for AmeriVet’s Office 365 environment. The team discussed user and admin setup, policy configuration, integration with Exchange and OneDrive, and future options for DMARC and other SaaS applications. The goal is to evaluate Checkpoint’s capabilities in threat detection, DLP, and broader SaaS security, with a collaborative approach between AmeriVet and Checkpoint teams. Key business aspects include improving security posture, streamlining alert management, and ensuring seamless deployment and user experience.

Agenda

• Confirm team attendance and roles
• Initiate POC setup for Checkpoint Avenon
• Configure user/admin permissions and policies
• Connect Office 365 Mail and OneDrive
• Discuss DMARC and other SaaS integrations
• Plan next steps and schedule follow-up meeting

Opps Identified & BANTC

Opportunity 1: Checkpoint Avenon POC
for Email & Collaboration Security
• B (Budget): AmeriVet is evaluating Checkpoint as a
potential replacement or supplement to existing solutions (e.g., Mimecast), indicating budget allocation for security improvements.
• A (Authority): Mark Berry is the primary admin and
decision-maker for the POC; Anu Joseph is the account manager; Jax Miley and Eric Owings are involved in coordination.
• N (Need): Need for enhanced email security, DLP, and
streamlined alerting; interest in DMARC and SaaS app monitoring.
• T (Timeline): POC setup is immediate, with a
follow-up meeting scheduled for next week to review data population and progress.
• C (Competition): Existing solution (Mimecast) is
referenced; Checkpoint is being compared for features and integration.
Opportunity 2: DMARC Policy &
SaaS Application Monitoring
• B: Potential future budget for DMARC and additional
SaaS security modules (security awareness, archiving, leaked credentials, etc.).
• A: Mark Berry and AmeriVet’s migration team; James
(Checkpoint) provides technical guidance.
• N: Need for DMARC policy management and monitoring,
as well as visibility into OneDrive and other SaaS apps.
• T: To be determined after initial POC; DMARC setup
depends on mailbox routing and migration status.
• C: Existing DMARC setup managed by another team;
Checkpoint’s DMARC and SaaS modules are under evaluation.

Initiatives

• Security: Email threat detection, DLP, DMARC, SaaS
app monitoring (OneDrive, Teams, SharePoint)
• Storage: OneDrive file scanning and monitoring

Tech Profile Updates

• Office 365 Mail integrated with Checkpoint Avenon
for threat and DLP detection
• OneDrive added for file scanning and monitoring
• DMARC, security awareness, archiving, leaked
credentials, and SSPM modules available for trial
• Admin and user roles configured for granular
permissions and alert management

Meeting Notes

Environment

• AmeriVet’s Office 365 tenant
• Admin access via Infinity portal
• Users: Mark Berry (primary admin), VicTorey McCray,
Steve Park, Jax Miley, Eric Owings, Anu Joseph, James (Aaron) Genereaux, Christopher (Chris) Tidwell

Detailed Discussion

• Team confirmed attendance and readiness for POC
• Mark Berry set up account and shared screen for
configuration
• Admin and user roles assigned with specific
permissions for email and alert access
• Exchange integration initiated via Enterprise App
Connector; admin credentials required
• Detect mode policies created for threat and DLP (no
remediation actions during POC)
• Alert routing discussed; recommendation to use an
InfoSec group mailbox
• OneDrive integration added for file scanning;
similar process to email setup
• DMARC monitoring discussed; options depend on
mailbox routing and DNS configuration
• Additional modules (security awareness, archiving,
etc.) available for trial
• Next meeting scheduled for data review and further
configuration

Technical Notes

• Admins must be assigned specific service roles for
email and alert permissions
• “Receive alerts” and “Read email bodies” permissions
are configurable per user
• Detect mode policies for threat and DLP created for
all users/groups; no remediation during POC
• Exchange integration via Enterprise App Connector
requires admin credentials
• OneDrive integration uses existing connector; scans
files for threats and DLP
• DMARC monitoring can auto-detect if reports are
routed to domain mailbox; otherwise, DNS update required
• Alert routing best practice: InfoSec group mailbox
for high-volume alerts
• Additional SaaS apps (Teams, SharePoint) can be
added via security settings
• Data population and baseline learning for phishing
detection may take 24–48 hours

ROLES

• Mark Berry – Admin, AmeriVet
• VicTorey McCray – AmeriVet
• Steve Park – AmeriVet
• Jax Miley – AmeriVet
• Eric Owings – AmeriVet
• Anu Joseph – Account Manager, Checkpoint
• James (Aaron) Genereaux – Email & Collaboration

Security Specialist, Checkpoint

• Christopher (Chris) Tidwell – Security Engineer,
Checkpoint

Potential Next steps

• Mark Berry to monitor data population and confirm
alert routing setup (InfoSec mailbox)
• James to support ongoing portal configuration and
answer technical questions
• Anu Joseph to coordinate next meeting and serve as
primary contact for questions
• Jax Miley to facilitate meeting invites and
scheduling
• Mark Berry to check DMARC report routing and update
DNS if needed for Checkpoint monitoring
• Team to reconvene next week to review populated data
and discuss further configuration or expansion (OneDrive, DMARC, other SaaS apps)

Trip Report | AmeriVet + SHI | Checkpoint POC/POV

Trip Report | AmeriVet + SHI | Checkpoint POC/POV

CRM Link:    https://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=9ba1d1ad-4871-455a-b37b-9b5e9d70a869

Customer

AE

Topic

District

Meeting Date

Amerivet

Jax M

avenon

TOLA1

10/27

*Internal notes – Please read and edit before sending
externally*

Summary

• The meeting focused on initiating a Proof of Concept
(POC) for Checkpoint Avenon, specifically targeting email and collaboration security for AmeriVet’s Office 365 environment. The team discussed user and admin setup, policy configuration, integration with Exchange and OneDrive, and future options for DMARC and other SaaS applications. The goal is to evaluate Checkpoint’s capabilities in threat detection, DLP, and broader SaaS security, with a collaborative approach between AmeriVet and Checkpoint teams. Key business aspects include improving security posture, streamlining alert management, and ensuring seamless deployment and user experience.

Agenda

• Confirm team attendance and roles
• Initiate POC setup for Checkpoint Avenon
• Configure user/admin permissions and policies
• Connect Office 365 Mail and OneDrive
• Discuss DMARC and other SaaS integrations
• Plan next steps and schedule follow-up meeting

Opps Identified & BANTC

Opportunity 1: Checkpoint Avenon POC
for Email & Collaboration Security
• B (Budget): AmeriVet is evaluating Checkpoint as a
potential replacement or supplement to existing solutions (e.g., Mimecast), indicating budget allocation for security improvements.
• A (Authority): Mark Berry is the primary admin and
decision-maker for the POC; Anu Joseph is the account manager; Jax Miley and Eric Owings are involved in coordination.
• N (Need): Need for enhanced email security, DLP, and
streamlined alerting; interest in DMARC and SaaS app monitoring.
• T (Timeline): POC setup is immediate, with a
follow-up meeting scheduled for next week to review data population and progress.
• C (Competition): Existing solution (Mimecast) is
referenced; Checkpoint is being compared for features and integration.
Opportunity 2: DMARC Policy &
SaaS Application Monitoring
• B: Potential future budget for DMARC and additional
SaaS security modules (security awareness, archiving, leaked credentials, etc.).
• A: Mark Berry and AmeriVet’s migration team; James
(Checkpoint) provides technical guidance.
• N: Need for DMARC policy management and monitoring,
as well as visibility into OneDrive and other SaaS apps.
• T: To be determined after initial POC; DMARC setup
depends on mailbox routing and migration status.
• C: Existing DMARC setup managed by another team;
Checkpoint’s DMARC and SaaS modules are under evaluation.

Initiatives

• Security: Email threat detection, DLP, DMARC, SaaS
app monitoring (OneDrive, Teams, SharePoint)
• Storage: OneDrive file scanning and monitoring

Tech Profile Updates

• Office 365 Mail integrated with Checkpoint Avenon
for threat and DLP detection
• OneDrive added for file scanning and monitoring
• DMARC, security awareness, archiving, leaked
credentials, and SSPM modules available for trial
• Admin and user roles configured for granular
permissions and alert management

Meeting Notes

Environment

• AmeriVet’s Office 365 tenant
• Admin access via Infinity portal
• Users: Mark Berry (primary admin), VicTorey McCray,
Steve Park, Jax Miley, Eric Owings, Anu Joseph, James (Aaron) Genereaux, Christopher (Chris) Tidwell

Detailed Discussion

• Team confirmed attendance and readiness for POC
• Mark Berry set up account and shared screen for
configuration
• Admin and user roles assigned with specific
permissions for email and alert access
• Exchange integration initiated via Enterprise App
Connector; admin credentials required
• Detect mode policies created for threat and DLP (no
remediation actions during POC)
• Alert routing discussed; recommendation to use an
InfoSec group mailbox
• OneDrive integration added for file scanning;
similar process to email setup
• DMARC monitoring discussed; options depend on
mailbox routing and DNS configuration
• Additional modules (security awareness, archiving,
etc.) available for trial
• Next meeting scheduled for data review and further
configuration

Technical Notes

• Admins must be assigned specific service roles for
email and alert permissions
• “Receive alerts” and “Read email bodies” permissions
are configurable per user
• Detect mode policies for threat and DLP created for
all users/groups; no remediation during POC
• Exchange integration via Enterprise App Connector
requires admin credentials
• OneDrive integration uses existing connector; scans
files for threats and DLP
• DMARC monitoring can auto-detect if reports are
routed to domain mailbox; otherwise, DNS update required
• Alert routing best practice: InfoSec group mailbox
for high-volume alerts
• Additional SaaS apps (Teams, SharePoint) can be
added via security settings
• Data population and baseline learning for phishing
detection may take 24–48 hours

ROLES

• Mark Berry – Admin, AmeriVet
• VicTorey McCray – AmeriVet
• Steve Park – AmeriVet
• Jax Miley – AmeriVet
• Eric Owings – AmeriVet
• Anu Joseph – Account Manager, Checkpoint
• James (Aaron) Genereaux – Email & Collaboration

Security Specialist, Checkpoint

• Christopher (Chris) Tidwell – Security Engineer,
Checkpoint

Potential Next steps

• Mark Berry to monitor data population and confirm
alert routing setup (InfoSec mailbox)
• James to support ongoing portal configuration and
answer technical questions
• Anu Joseph to coordinate next meeting and serve as
primary contact for questions
• Jax Miley to facilitate meeting invites and
scheduling
• Mark Berry to check DMARC report routing and update
DNS if needed for Checkpoint monitoring
• Team to reconvene next week to review populated data
and discuss further configuration or expansion (OneDrive, DMARC, other SaaS apps)

CRM Link:    https://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=9ba1d1ad-4871-455a-b37b-9b5e9d70a869

Customer

AE

Topic

District

Meeting Date

Amerivet

Jax M

avenon

TOLA1

10/27
