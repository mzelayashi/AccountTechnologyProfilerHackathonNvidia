Trip Report | End User Environemnt | AmeriVet

Customer: AmeriVet
AE: Jax M
Topic: End User Environemnt
Meeting Date 01/21/2026

*Internal notes – Please read and edit before sending externally*

Summary

This call involved a collaborative working session between AmeriVet and SHI, joined by multiple engineering, infrastructure, architecture, and EUC specialists. The business purpose centered on evaluating the current AmeriVet end‑user compute (EUC) environment, understanding pain points across 214 veterinary clinic locations, and determining alternative device, browser, VDI, or thin‑client strategies that could reduce hardware costs, simplify deployments, and streamline IT operations. AmeriVet is undergoing a large‑scale tech refresh initiative—standardizing and modernizing endpoint devices while transitioning practice management tools from legacy, on‑prem, client‑server models toward cloud‑based SaaS platforms. Because many

Security and governance

considerations around enterprise browsers (Island, Cloudflare, Palo Alto, Crowdstrike) Hybrid workflows where some devices may continue as full Windows PCs due to requirements for specialized applications Workflows related to potential Azure Virtual Desktop or Windows 365 models, including usage concerns and cost unpredictability The need for potential hardware with integrated RFID/NFC capabilities and healthcare‑adjacent form factors Capacity planning for ~2,500 users/devices and hardware distribution (approx. 80% workstations, 20% laptops)

Deployment processes using Autopilot and Intune Device configurations currently used (Dell Micro OptiPlex, Intel i5, 8–16GB RAM, 128GB SSD) Operational pain points involving site‑specific configuration, printers, lab equipment, X‑ray devices, specialized software, and legacy Windows machines Exploration of thinclient strategies (IGEL, 10ZiG, repurposing existing hardware)

Security and governance

considerations around enterprise browsers (Island, Cloudflare, Palo Alto, Crowdstrike) Hybrid workflows where some devices may continue as full Windows PCs due to requirements for specialized applications Workflows related to potential Azure Virtual Desktop or Windows 365 models, including usage concerns and cost unpredictability The need for potential hardware with integrated RFID/NFC capabilities and healthcare‑adjacent form factors Capacity planning for ~2,500 users/devices and hardware distribution (approx. 80% workstations, 20% laptops) The goal was to determine future‑state EUC direction and outline follow-up actions related to trials, licensing requests, hardware evaluations, and detailed technical reviews.

Agenda

• Review
AmeriVet’s current EUC environment and deployment workflow
• Evaluate cost
pressures and hardware right‑sizing opportunities
• Assess
viability of thin‑client strategies and enterprise browser options
• Discuss SaaS
transition, specialized device requirements, printers, and clinic‑based equipment
• Explore Azure
Virtual Desktop / Windows 365 alternatives
• Identify next
steps and vendor follow‑ups

Opportunities Identified & BANTC

Opportunity 1: Thin Client Conversion & Hardware
Refresh Optimization
B – Budget:
AmeriVet is sensitive to rising hardware costs (RAM, SSD) and is actively exploring lower‑cost alternatives such as repurposed hardware running thin‑client OS or low‑cost purpose‑built thin clients. Budget exists for future refresh but cost containment is a priority.
A – Authority:
Primary decision makers: Jason (Director of Solutions Architecture), Ethan (Director of Infrastructure), Dieter (Director of IT for Automation). SHI representatives influencing solution design: Marc, Jarrett, Jesse, Flaminio.
N – Need:
Reduce hardware cost, simplify management, increase security, support mixed SaaS and limited legacy workloads, repurpose existing hardware, support 214 locations with minimal onsite intervention.
T – Timeline:
Evaluation estimated to begin in approximately one month; not immediate but aligned with 2026 refresh cycle.
C – Competition:
Thin‑client OS vendors: IGEL and 10ZiG are primary considerations. Hardware vendors: Dell, HP, LG. Enterprise browsers: Island, Cloudflare, Palo Alto, Crowdstrike.
Opportunity 2: Enterprise Browser Deployment (Island /
Cloudflare / Others)
B – Budget:
Browser licensing would fall under security and management budgets. Goal is to reduce endpoint overhead and improve data governance.
A – Authority:
Jason and Dieter determine security and endpoint strategy; Ethan sets overall infrastructure direction.
N – Need:
Secure access to SaaS apps, limit data exfiltration, enable granular policy control, support BYOD scenarios, reduce management of Windows endpoints.
T – Timeline:
Trials requested soon; can be evaluated alongside thin‑client testing.
C – Competition:
Island appears preferred for simplicity; alternatives include Cloudflare, Palo Alto, and Crowdstrike.
Opportunity 3: Azure Virtual Desktop / Windows 365
Exploration
B – Budget:
AVD consumption costs are a concern; Windows 365 has predictable subscription fees. Costs must be justified vs. thin‑client + secure‑browser models.
A – Authority:
Same triad: Jason, Ethan, Dieter.
N – Need:
Support for limited Windows‑dependent workloads without heavy on‑prem infrastructure.
T – Timeline:
Exploratory only, no immediate purchase.
C – Competition:
Competes with secure browser strategy and thin‑client use cases.

Initiatives

(Indicate whether Security, Storage, or Both)
• EUC Modernization & Thin‑Client Strategy –

Security

• Enterprise Browser Enablement for SaaS‑First Model
– Security
• Practice Management System Cloud Migration –

Security

• Hardware Right‑Sizing & Cost Optimization –

Security

• Potential AVD/Windows 365 Strategy – Security
(No storage

initiatives surfaced in this call.)

Tech Profile Updates

• Current
devices: Dell OptiPlex Micro Form Factor, i5, 8–16GB RAM, 128GB storage
• Device count:
Approx. 2,500 users/devices
• Mix: Roughly
80% workstations, 20% laptops
• 214 distributed
clinic locations
• Use of Intune +
Autopilot with pre‑staging and white‑glove configuration
• Many workloads
moving to SaaS web‑based apps
• Limited
client‑server apps for lab and X‑ray systems
• X‑ray equipment
aged, often Windows 7‑dependent, running at the clinic only
• No central data
center; equipment is site‑specific
• Printer setup,
site customizations remain significant operational burden
• No desire for
VDI infrastructure; cloud‑only considered if necessary

Meeting Notes

• SHI reviewed
AmeriVet’s current refresh challenges and objectives.
• AmeriVet
expressed that many workloads are moving to web‑based/SaaS platforms; browser‑only workflows may serve most users.
• Legacy
workloads limit complete transition to thin clients, particularly X‑ray machines, specialized software, and lab systems requiring Windows.
• Cost pressure
due to global RAM/NVMe shortages and price increases was a major theme.
• Enterprise
browsers were explored as a secure, low‑cost alternative to full Windows machines.
• IGEL vs. 10ZiG
discussed heavily, focusing on OS repurposing and support models.
• AVD and Windows
365 discussed as possible but likely excessive for SaaS‑only users.
•
Healthcare‑style all‑in‑one devices with integrated RFID/NFC are of interest.
• Followup
required on hardware options, licensing trials, and ratio of laptops/workstations.

Environment

• 214 clinics
with differing practice management systems
• No centralized
on‑prem infrastructure
• Mixed legacy
and modern applications
• Windows‑based
workflows for certain medical systems
• Increasing
dependency on SaaS and thin browser‑based applications
• Autopilot and
Intune are core deployment/management tools
• Multivendor
hardware environment

Detailed Discussion

• AmeriVet is
transitioning away from legacy practice management systems to a cloud‑based SaaS model.
• Most daily
workflows in clinics rely only on a browser once the transition completes.
• Specialized
systems such as X‑ray, lab software, boarding/room management tools still require native Windows.
• These systems
often run on older hardware, sometimes as old as Windows 7, and cannot be virtualized or shifted to thin clients.
• Deployment is
handled via Autopilot with white‑glove preparation; however, site‑specific tasks (printers, specialized apps) slow down the process.
• Thin‑client
solutions were compared:

IGEL: Strong support, customizable, but perceived as expensive 10ZiG: Strong Linux OS alternative, hardware includes lifetime license, lower cost Browser‑only endpoints dramatically reduce need for Windows maintenance
• Enterprise browsers allow security controls (whitelisting,
restricted copy/paste, device health checks, policy granularity).
• Island I/O highlighted as simpler to deploy than others.
• AVD/Windows 365:
Provides Windows in the cloud Expensive, unpredictable consumption RDP protocol limitations Not a match for predominantly SaaS workflows
• Hardware exploration: all‑in‑one devices with RFID/NFC for
tap‑and‑go login are appealing, especially for clinical workflows.
• Need estimations: 2,500 users/devices, mostly workstations with
some laptops.

IGEL: Strong support, customizable, but perceived as expensive 10ZiG: Strong Linux OS alternative, hardware includes lifetime license, lower cost Browser‑only endpoints dramatically reduce need for Windows maintenance
• Enterprise browsers allow security controls (whitelisting,
restricted copy/paste, device health checks, policy granularity).
• Island I/O highlighted as simpler to deploy than others.
• AVD/Windows 365:
Provides Windows in the cloud Expensive, unpredictable consumption RDP protocol limitations Not a match for predominantly SaaS workflows
• Hardware exploration: all‑in‑one devices with RFID/NFC for
tap‑and‑go login are appealing, especially for clinical workflows.
• Need estimations: 2,500 users/devices, mostly workstations with
some laptops.

Technical Notes

• Autopilot used
for provisioning with additional manual prep steps at SHI prior to shipping.
• Intune enrolled
devices with site‑specific configuration during deployment.
• Current
hardware spec is over‑provisioned for upcoming SaaS‑based workflows.
• Thin client OS
must support repurposing existing hardware and embedding browsers.
• IGEL and 10ZiG
both support repurposing legacy hardware into Linux‑based thin clients.
• 10ZiG hardware
includes lifetime OS license, reducing subscription overhead.
• Enterprise
browser needs discussed:

URL whitelisting Policy‑based controls Device posture checking SaaS‑exclusive access BYOD support
• Chrome embedded is possible but lacks enforced security
controls.
• X‑ray equipment often cannot be upgraded or virtualized; must
remain Windows‑based.
• AVD requires careful cost management due to consumption billing.
• Windows 365 predictable billing but still adds OS management
overhead.
• Network segmentation for legacy X‑ray systems may be needed in the
future.
• RFID/NFC tap‑and‑go authentication hardware exists and is
desirable.

URL whitelisting Policy‑based controls Device posture checking SaaS‑exclusive access BYOD support
• Chrome embedded is possible but lacks enforced security
controls.
• X‑ray equipment often cannot be upgraded or virtualized; must
remain Windows‑based.
• AVD requires careful cost management due to consumption billing.
• Windows 365 predictable billing but still adds OS management
overhead.
• Network segmentation for legacy X‑ray systems may be needed in the
future.
• RFID/NFC tap‑and‑go authentication hardware exists and is
desirable. ROLES: Speakers / Participants AmeriVet
• Jason Marves –
Director of Solutions Architecture
• Ethan Johnson –
Director of Infrastructure and Engineering
• Dieter Karkut –
Director of IT (Automation) SHI / Vendor
• Jax Miley – SHI
Representative
• Marc Murphy –
Client Solution Executive (EUC)
• Jarrett Taranto
– Pre‑Sales Solution Specialist (EUC, device management)
• Jesse Stapleton
– Pre‑Sales Solutions Engineer (EUC)
• Flaminio
Guerrero – Solutions Architect (Virtualization, VDI)
• Unknown Speaker
– Unidentified participant with small contributions

Potential Next Steps

• SHI to gather thin‑client hardware options

Speaker: Marc To: AmeriVet team Includes healthcare‑focused all‑in‑one options, RFID/NFC‑integrated hardware.

Speaker: Marc To: AmeriVet team Includes healthcare‑focused all‑in‑one options, RFID/NFC‑integrated hardware.
• SHI to coordinate trial licenses for IGEL, 10ZiG, and
Island

Speaker: Flaminio To: Jason, Ethan, Dieter Will request trial quantities for testing repurposed hardware and browser policies.

Speaker: Flaminio To: Jason, Ethan, Dieter Will request trial quantities for testing repurposed hardware and browser policies.
• AmeriVet to provide laptop‑to‑workstation ratio

Speaker: Marc requested Responded by: Jason (approx. 80% workstations, 20% laptops) Action: SHI to refine future pricing based on confirmed ratios.

Speaker: Marc requested Responded by: Jason (approx. 80% workstations, 20% laptops) Action: SHI to refine future pricing based on confirmed ratios.
• AmeriVet to validate number of required licenses
(estimated 2,500)

Speaker: Flaminio To: Jason For preliminary vendor quoting and capacity planning.

Speaker: Flaminio To: Jason For preliminary vendor quoting and capacity planning.
• Review of integrated tap‑and‑go authentication device
options

Speaker: Jason To: SHI Needed to support clinic authentication workflows.

Speaker: Jason To: SHI Needed to support clinic authentication workflows.
• Follow‑up deep dive session on enterprise
browser and thin‑client OS selection.

Speaker: Flaminio To: AmeriVet Will walk through Island, Cloudflare, Palo Alto comparisons.

Speaker: Flaminio To: AmeriVet Will walk through Island, Cloudflare, Palo Alto comparisons.
