Trip Report | Checkpoint | AmeriVet

Customer: AmeriVet
AE: Jax
Topic: Checkpoint
Meeting Date 10/13/2025

*Internal notes – Please read and edit before sending externally*

Summary

Summary

• The meeting focused on evaluating Check Point
Harmony Email & Collaboration as a potential replacement for Mimecast, with a strong emphasis on DMARC, SPF, DKIM management, and advanced email security features. The customer team (Mary Bedside) is seeking improved DMARC monitoring, automated reporting, and integration with their existing ticketing and security awareness platforms. The vendor (Checkpoint) presented their API-based architecture, unified quarantine, Threat Cloud AI, and behavioral detection capabilities, highlighting technical differentiators and integration options. The discussion included comparisons to Red Sift and KnowBe4, and explored practical deployment, reporting, and remediation workflows.
• Key business aspects include the need for
consolidated security management, automation of reporting and alerting, seamless integration with existing tools, and enhanced protection against

Agenda

• Introductions and role clarification
• Review of current email security environment and
challenges
• Demo of Check Point Harmony Email &
Collaboration platform
• Deep dive into DMARC, SPF, DKIM management and
reporting
• Discussion of integration with ticketing and

security awareness platforms

• Comparison with Red Sift and current solutions
• Q&A and next steps

Opps Identified & BANTC

Opportunity 1: Replacement of
Mimecast with Check Point Harmony Email & Collaboration (including DMARC management)
• B: Customer (Mary Bedside team) is seeking a new
solution as Mimecast contract is coming due next year; business need for improved DMARC, SPF, DKIM monitoring and reporting, and unified security management.
• A: Kat Mullen, VicTorey McCray, Mark Berry (customer
team) are decision makers; Jax Miley is facilitating; Josh Radko and Aaron Genereaux (Checkpoint) are vendor contacts.
• N: High—customer lacks DMARC policy and monitoring,
wants automation and integration, and is actively evaluating alternatives.
• T: Contract renewal timeline is next year; DMARC
solution needed before renewal; Red Sift is also being considered.

Initiatives

• Security: Email security, DMARC/SPF/DKIM management,
BEC and phishing protection, security awareness training integration
• Storage: Not discussed

Tech Profile Updates

• Customer currently uses Mimecast for SEG, KnowBe4
for security awareness training, and Freshservice for ticketing.
• Considering Red Sift for DMARC.
• Evaluating Check Point Harmony Email &
Collaboration for unified email security, DMARC/SPF/DKIM management, and integration with existing platforms.

Meeting Notes

Environment

• Microsoft 365 tenant
• Multiple domains and subdomains
• Mimecast SEG in place
• KnowBe4 for security awareness
• Freshservice for ticketing
• No DMARC policy currently set; SPF managed manually;
DKIM handled by Mimecast

Detailed Discussion

• DMARC, SPF, DKIM Management: Aaron explained Check
Point’s approach to monitoring domains/subdomains, ingesting Ruas/Rus, and updating DNS/DKIM records via UI wizard. No automated DNS changes; manual process with guidance.
• Reporting & Alerting: Kat requested automated
monthly reporting and alerting for DMARC failures; Aaron confirmed email alerts are possible but not threshold-based or fully automated—manual review required. Open API available for integration, but email-based alerts preferred for Freshservice.
• Integration: VicTorey asked about KnowBe4
integration; Aaron confirmed seamless integration is common.
• Architecture: Aaron described API-based, pre-inbox
detection and remediation, unified quarantine across Microsoft and Check Point, and Threat Cloud AI for global threat intelligence and sandboxing.
• BEC & Impersonation: Behavioral detection stack
with ability to lock out compromised accounts, monitor internal, inbound, and outbound email, and detect domain/name impersonation using AI and machine learning.
• Policy & Remediation: Policies based on
detection confidence; unified quarantine allows bulk release or quarantine across Microsoft and Check Point.

Technical Notes

• DMARC monitoring includes domain/subdomain tracking,
Ruas/Rus ingestion, and manual DNS/DKIM updates via UI wizard.
• No automated DNS record changes; manual process with
step-by-step guidance.
• Open API available; email alerts preferred for
integration with Freshservice.
• Unified quarantine across Microsoft and Check Point;
supports bulk release/quarantine actions.
• Threat Cloud AI provides global threat intelligence,
sandboxing, and rapid IOC updates.
• BEC detection uses behavioral analysis, impossible
travel, device profiling, and inbox rule changes; supports account lockout from UI.
• Phishing detection uses 200+ AI/ML engines; policies
based on confidence levels; supports supervised/semi-supervised machine learning for tuning.
• Integration with KnowBe4 for security awareness
training is supported.
• Impersonation protection includes domain, vendor,
and employee-level detection using AI models and email signature/title extraction.

ROLES

• Kat Mullen (Customer, Mary Bedside team)
• VicTorey McCray (Customer, Mary Bedside team)
• Mark Berry (Customer, Mary Bedside team)
• Jax Miley (Facilitator, Mary Bedside team)
• Josh Radko (Vendor, Check Point)
• Aaron Genereaux (Vendor, Check Point)
• Brittany (Customer, Mary Bedside team, absent)
• Steve Park (Customer, Mary Bedside team, invited but
not confirmed present)
• Eric (Vendor, Check Point, main email security rep,
absent)
• Unknown Speaker (not identified)

Potential Next steps

• Aaron to send recap email summarizing demo and
technical details to customer team (requested by VicTorey).
• Kat, VicTorey, and Mark to review Check Point
offering internally and compare with Red Sift and current Mimecast setup.
