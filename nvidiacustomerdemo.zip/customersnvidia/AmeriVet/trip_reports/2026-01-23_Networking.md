Trip Report | Networking | AmeriVet

Customer: AmeriVet
AE: Jax M
Topic: Networking
Meeting Date 01/23/2026

*Internal notes – Please read and edit before sending externally*

Summary

This call involved AmeriVet (the customer) and SHI (the vendor) discussing how SHI can support AmeriVet’s large‑scale network technology rollout across more than 200 veterinary clinic locations. AmeriVet is currently battling slow turnaround times for network stack configuration and staging using their existing vendor and is exploring whether SHI can take over the end‑to‑end networking preparation, warehousing, staging, and deployment workflows. The conversation focuses heavily on how SHI’s Data Center Factory (Ridge) can accelerate configuration, standardization, bench testing, template management, and logistics. AmeriVet is undergoing ongoing mergers and acquisitions, leading to highly inconsistent network environments at each clinic. The business themes revolve around improving speed, reducing lead times, making configuration predictable, building standardized templates, and allowing AmeriVet to scale from roughly 50 completed clinic conversions to more than 160 remaining sites. They need a reliable partner to accelerate deployment, reduce manual configuration, support just‑in‑time shipping, and give more operational flexibility. Overall, SHI presented a Bronze/Silver/Gold model for staging and configuration, explained operations, SLAs, first‑article testing, inventory storage, template usage, and ways to streamline workflows. AmeriVet expressed strong interest pending pricing review. Next steps involve pricing delivery and internal review, followed by a potential kickoff and first article build if AmeriVet elects to proceed.

Agenda

• Review
AmeriVet’s current networking deployment workflow and constraints
• Understand
SHI’s configuration lab, warehousing, and fulfillment capabilities
• Explore
requirements for Unifi‑based deployments at hundreds of veterinary sites
• Discuss
potential acceleration paths for staging/configuration (Bronze/Silver/Gold tiers)
• Identify
methods for template usage, standardized designs, and first article build
• Review ordering
process, inventory handling, logistics, and just‑in‑time shipping
• Determine next
steps involving pricing, evaluation, and potential kickoff

Opportunities Identified & BANTC

Opportunity 1 – SHI to Replace Current Network
Config/Lab Partner for AmeriVet B (Budget): AmeriVet is actively requesting pricing for SHI’s Bronze/Silver/Gold services. They are replacing a current vendor that delivers 3‑week turnaround times. They are seeking cost‑effective improvements. A (Authority): Ethan Johnson appears to be leading the networking decision process. Jason is also on the networking team. They will review pricing and likely escalate internally. N (Need):
• Reduce 3‑week
lead times to ~5 days
• Standardize
configurations across 160+ remaining clinics
• Reduce manual
configuration effort
• Improve
staging, testing, and readiness prior to deployment
• Enable
synchronized delivery with workstations for de novo builds T (Timeline): AmeriVet wants to accelerate immediately, pending pricing and first article build. No specific dates given, but urgency is clear. C (Competition): Their current configuration vendor, which provides slow turnaround times. SHI is positioned to win based on speed and process maturity.

Initiatives

• Networking Deployment Acceleration – Primary
initiative; related to infrastructure operations
• Configuration Standardization – Applies to
networking; not security or storage
• Operational Scaling: Warehouse + Logistics –
Supply chain and deployment initiative (All initiatives fall under Infrastructure / Networking, not security or storage.)

Tech Profile Updates

• AmeriVet uses Unifi Site Manager, not Fortinet (historically
used Fortinet).
• They currently
manage UDM Pro, Unifi switches, APs, and workstations through separate vendors.
• Multitemplate
and multi‑design environment due to mergers and acquisitions.
• Evaluating
SHI’s Bronze (DOA check), Silver (intermediate), and Gold (full config) service tiers.
• Interested in
template‑based deployment, potential golden images, and workflow automation.

Meeting Notes

• AmeriVet is
rolling out tech refresh across 214 sites; ~50 completed, ~160 remaining.
• Clinics
acquired through M&A have inconsistent topologies; standardization is required.
• Current
configuration partner’s cycle is too slow (3 weeks).
• SHI can stage
and configure equipment in 1–5 days depending on tier.
• SHI proposed
first‑article build → workbook → standardized ongoing process.
• SHI can store
inventory for 12 months for free.
• Ordering can be
done manually (email/Teams) or via SHI’s ordering portal.
• SHI offers
“pick & ship,” “config + ship,” and “finished goods” pre‑built options.
• SHI handles
workstations through a separate facility but can coordinate consolidated shipping.
• SHI confirms
just‑in‑time shipping availability.
• Pricing will be
sent to AmeriVet for review.

Environment

• Customer:
AmeriVet – nationwide veterinary clinic operator with large geographic footprint
• Vendor: SHI –
Data Center Factory (Ridge) + End User Compute team (Knox)
• Networking
platform: Unifi stack (UDM Pro, switches, APs)
• Management
platform: Unifi Site Manager under AmeriVet admin account
• Deployment
constraints: inconsistent clinic networks due to acquisitions, limited internal staffing

Detailed Discussion

• Jax introduced
the objective: understand networking needs and potential SHI support model.
• AmeriVet’s
refresh involves adopting UDM Pros, switches, APs, and workstations, staged in a “config lab.”
• Current
vendor’s staging process is slow, especially during parallel weekly refresh activities.
• Ethan requested
clearer view into SHI’s turnaround time if they purchase the remaining equipment through SHI.
• Joe (SHI)
explained staging workflows:
– Same‑day bench
for simple requests
– 2–3 days for
config tasks
– ~5 days total
for end‑to‑end picking-to-shipping for full network kits
• SHI supports
adoption into Unifi portals if given proper access levels.
• Template
limitations discussed:
– AmeriVet’s
VLANs vary per clinic due to lack of standardization
– Potential
future approach: multiple templates tied to clinic categories
• SHI uses a
workbook process to standardize tasks and requirements.
• First article
build = validating the workbook through hands-on execution of representative models.
• Ordering
options: manual or via SHI’s ordering portal.
• Workstations
are handled separately but can be co‑shipped for de novo build scenarios.
• SHI confirmed
capability for just-in-time delivery for new construction projects.
• Next steps
involve pricing review, and if approved, SHI will initiate inventory agreement and kickoff.

Technical Notes

• Unifi Site
Manager used for device adoption and management.
• AmeriVet
invites employees to Site Manager for managing locations.
• Devices require
Internet connectivity in the bench environment to adopt into the Unifi portal.
• SHI’s bench
tests include: power-on, DOA checks, burn‑in tests (~4 hours), optional labeling.
• SHI’s Gold
level involves applying AmeriVet’s Unifi configuration templates (not creating templates).
• SHI requires
appropriate portal access for applying templates or adopting devices.
• Standardization
challenges stem from per‑hospital unique VLANs, SSIDs, and IP schemes. ROLES: Speakers / Participants (Only roles, no company links, no pronouns unless in transcript)
• Ethan Johnson – Networking lead / AmeriVet IT
• Jason Marves – Networking team / AmeriVet IT
• Jax Miley – SHI Account Team / Customer-facing
representative
• Joe Wainscott – SHI Data Center Factory /
Technical Operations Lead
• Manuel Zelaya- SHI SE

Potential Next Steps

• Joe → Jax
Joe will send pricing for Bronze, Silver, Gold network kit services to Jax. Action: Joe to deliver pricing.
• Jax → Ethan & Jason
Jax will forward SHI pricing to AmeriVet for internal review. Action: Jax to transmit pricing package.
• AmeriVet (Ethan/Team) → SHI
AmeriVet will review SHI pricing and determine interest in moving forward. Action: AmeriVet decision on adopting SHI as new config/staging vendor.
• If AmeriVet approves – Joint Action
– Execute
inventory agreement (12‑month free storage).
– Schedule a
kickoff call with SHI’s project team.
– Begin building
the detailed workbook.
– Schedule first
article build to validate the configuration workflow. Participants: Jax, Joe, AmeriVet networking team, SHI PM team.
• Future Meeting
Based on AmeriVet approval, another meeting will be scheduled to walk through first article build details and confirm processes.
