Trip Report | AI discovery | AmeriVet

Customer: AmeriVet
AE: Jax M
Topic: AI discovery
Meeting Date 07/01/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Jax M

Coordinate pilot store onboarding project with field services

07/11

2

Manuel Z

Assist inAI questionnaire to be completed and internal workshop

07/12

Item Owner Next Steps/Detail Due Date 1 Jax M Coordinate pilot store onboarding project with field services 07/11 2 Manuel Z Assist inAI questionnaire to be completed and internal workshop 07/12

Summary

AmeriVet is in an active phase of IT modernization and operational optimization, focusing on automation, service improvements, and the exploration of AI-driven initiatives. The organization is currently reliant on warehouse/configuration and field services for device deployments and ongoing operations, and is assessing the SHI portal for future workflow automation and streamlined procurement. A critical area of focus is the transition of help desk services, as the contract with Xerox for level 1 support is expiring in April/May 2026; AmeriVet requires an improved, integrated help desk solution that minimizes friction for end users. AI is a strategic priority, with AmeriVet preparing to complete an AI pre-workshop questionnaire and move toward a use case discovery workshop with SHI to evaluate practical AI implementations across HR and IT. The onboarding/offboarding process is also being targeted for automation to reduce manual IT workload, with SHI providing solution options. Proactive Renewal Management (PRM) and Security Posture Review (SPR) are scheduled for inclusion in the next Quarterly Business Review (QBR), which will also highlight SHI offerings relevant to AmeriVet’s evolving needs. Upcoming events include an Apple Vision Pro Executive Briefing Center (EBC) session and a QBR, both likely virtual. Decision makers are actively engaged, and the partnership is characterized by open, candid discussion around operational pain points and future-state goals. Customer Technical Environment Notes:

Heavy use of warehouse and configuration services for device lifecycle management Field services required for pilot store and ongoing deployments SHI portal under evaluation for workflow automation and procurement efficiencies Current level 1 help desk contract with Xerox (expires April/May 2026) Manual onboarding/offboarding processes in place; automation under consideration Preparing for AI use case exploration, with HR and IT committee involvement Proactive renewal management and security reviews planned as part of QBR cadence

Heavy use of warehouse and configuration services for device lifecycle management Field services required for pilot store and ongoing deployments SHI portal under evaluation for workflow automation and procurement efficiencies Current level 1 help desk contract with Xerox (expires April/May 2026) Manual onboarding/offboarding processes in place; automation under consideration Preparing for AI use case exploration, with HR and IT committee involvement Proactive renewal management and security reviews planned as part of QBR cadence Agenda: • Progress check on existing projects and operational priorities • Review of SHI portal for automation opportunities • Update on help desk support plans and contract timelines • AI initiative preparation and workshop planning • Review of onboarding/offboarding automation possibilities • Planning for upcoming QBR/EBC sessions and executive engagement

Opps Identified & BANTC

Opportunity 1: Help Desk Transition & Improvement
• B: Current Xerox contract expiring; AmeriVet seeking improved, integrated
level 1 help desk support • A: Dieter Karkut (Director of IT Infrastructure & Operations) • N: Seamless transition required to avoid service disruptions; focus on end-user experience and integration with existing processes • T: Contract ends April/May 2026; planning and evaluation required well in advance • C: Dependent on SHI’s ability to present a compelling, integrated help desk solution
Opportunity 2: Onboarding/Offboarding Automation • B:
Manual onboarding/offboarding processes currently in place; desire to automate and reduce IT workload • A: Dieter Karkut, HR/IT committee • N: Increase efficiency, reduce manual errors, and improve employee experience • T: Ongoing; pilot store onboarding automation in progress, details being finalized • C: Requires SHI to present viable automation solutions and coordinate with AmeriVet’s HR/IT stakeholders
Opportunity 3: AI Use Case Discovery &
Implementation • B: Strategic initiative to leverage AI in HR and IT operations
• A: Dieter Karkut, HR/AI committee • N: Identify and validate practical AI use
cases through a discovery workshop • T: AI pre-workshop questionnaire due 7/8; workshop to follow upon completion • C: Success contingent on SHI’s AI capabilities and AmeriVet’s internal alignment
Opportunity 4: Proactive Renewal Management &
Security Review • B: Need for structured renewal management and security posture assessment • A: Dieter Karkut, IT leadership • N: Minimize risk of missed renewals, ensure up-to-date security practices • T: To be addressed in upcoming QBR (Q3 2025) • C: SHI to provide value through PRM/SPR offerings and QBR engagement

Initiatives (Security or Storage or both)

Security

Security Posture Review, help desk service improvement Operations/Automation: Onboarding/offboarding workflow automation, AI use case discovery, PRM No current storage initiatives noted

Security

Security Posture Review, help desk service improvement Operations/Automation: Onboarding/offboarding workflow automation, AI use case discovery, PRM No current storage initiatives noted

Tech Profile Updates

Evaluation of SHI portal for procurement/automation Transition planning for help desk support (Xerox to new provider) AI discovery and HR/IT automation initiatives underway Focus on improving operational efficiency and IT service delivery

Evaluation of SHI portal for procurement/automation Transition planning for help desk support (Xerox to new provider) AI discovery and HR/IT automation initiatives underway Focus on improving operational efficiency and IT service delivery

Meeting Notes

Warehouse/configuration and field services are operational priorities SHI portal automation discussed for future workflows Help desk contract with Xerox set to expire; transition planning needed AI pre-workshop questionnaire to be completed by HR/AI committee Onboarding automation for pilot stores under review QBR and EBC sessions scheduled; Apple Vision Pro EBC on August 8th PRM/SPR to be included in upcoming QBR

Warehouse/configuration and field services are operational priorities SHI portal automation discussed for future workflows Help desk contract with Xerox set to expire; transition planning needed AI pre-workshop questionnaire to be completed by HR/AI committee Onboarding automation for pilot stores under review QBR and EBC sessions scheduled; Apple Vision Pro EBC on August 8th PRM/SPR to be included in upcoming QBR

Detailed Discussion Notes

SHI to send 1-year Freshservice quote (completed) SHI coordinating on pilot store onboarding project with field services (due EOW) SHI providing onboarding/offboarding automation options (ongoing) AmeriVet to send updated onboarding Mac form (due EOD) and runbook (due EOW) AI questionnaire to be completed and internal workshop scheduled (due 7/8) QBR/EBC scheduling to be confirmed with John (due EOW) PRM and SPR to be central topics in next QBR

SHI to send 1-year Freshservice quote (completed) SHI coordinating on pilot store onboarding project with field services (due EOW) SHI providing onboarding/offboarding automation options (ongoing) AmeriVet to send updated onboarding Mac form (due EOD) and runbook (due EOW) AI questionnaire to be completed and internal workshop scheduled (due 7/8) QBR/EBC scheduling to be confirmed with John (due EOW) PRM and SPR to be central topics in next QBR Next Steps/detail: Person name responsible Action

SHI (Jax Miley): Send Freshservice quote through portal – Completed SHI (Jax Miley): Coordinate pilot store onboarding project with field services
– Due EOW
SHI (Jax Miley): Provide onboarding/offboarding automation options – Ongoing AmeriVet (Dieter Karkut): Send updated onboarding Mac form for pilot stores – Due EOD AmeriVet (Richard): Update runbook for pilot stores – Due EOW AmeriVet (Dieter): Forward AI pre-workshop questionnaire to HR/AI lead – Due 7/8 AmeriVet (Dieter): Discuss QBR/EBC scheduling with John, confirm format – Due EOW

SHI (Jax Miley): Send Freshservice quote through portal – Completed SHI (Jax Miley): Coordinate pilot store onboarding project with field services
– Due EOW
SHI (Jax Miley): Provide onboarding/offboarding automation options – Ongoing AmeriVet (Dieter Karkut): Send updated onboarding Mac form for pilot stores – Due EOD AmeriVet (Richard): Update runbook for pilot stores – Due EOW AmeriVet (Dieter): Forward AI pre-workshop questionnaire to HR/AI lead – Due 7/8 AmeriVet (Dieter): Discuss QBR/EBC scheduling with John, confirm format – Due EOW List all speakers/Participants of Transcript:

Dieter Karkut, Director of IT Infrastructure & Operations, AmeriVet Richard (AmeriVet, project/runbook owner) John (AmeriVet, QBR/EBC scheduling) Jax Miley, Commercial Account Executive, SHI Stephen Drake, SHI (copied on communications) Manuel Zelaya, Commercial Solutions Engineer, SHI

Dieter Karkut, Director of IT Infrastructure & Operations, AmeriVet Richard (AmeriVet, project/runbook owner) John (AmeriVet, QBR/EBC scheduling) Jax Miley, Commercial Account Executive, SHI Stephen Drake, SHI (copied on communications) Manuel Zelaya, Commercial Solutions Engineer, SHI
