Trip Report | CSM Progress | AmeriVet

Customer: AmeriVet
AE: Jax M
Topic: CSM Progress
Meeting Date 06/04/2026

*Internal notes – Please read and edit before sending externally*

Summary

This was an introductory alignment call between SHI and AmeriVet focused on onboarding Nicholas Sherman, AmeriVet’s new Director of Information Security, and establishing how SHI can support AmeriVet’s security roadmap. The conversation centered on understanding Nick’s priorities, clarifying SHI’s role as a strategic advisor and reseller, and identifying immediate and future areas where SHI can add value. From a business standpoint, the call confirmed that AmeriVet is in an early-stage security assessment period under new leadership. Nick is still learning the environment, building a renewals inventory, and identifying where controls are missing or underdeveloped. His near-term mission is to strengthen the overall security program, improve policies/processes/procedures, and move toward PCI compliance. The most concrete business and technical opportunity identified was Data Loss Prevention (DLP). Nick explicitly stated there is a real DLP gap today and described testing the environment by emailing a bogus Social Security number and credit card number to himself, which passed through successfully. That validates a live business risk around sensitive data exposure and creates an immediate discussion around email DLP, web DLP, and potentially supporting data classification capabilities. A secondary opportunity discussed was password manager replacement. Nick confirmed 1Password is expected to go away, though that initiative appears to already be narrowed by another AmeriVet stakeholder and is less open-ended than the DLP opportunity. SHI also introduced two strategic value-added motions for future engagement: security comparison matrices to narrow vendor choices and a Security Posture Review (SPR), which is a NIST-aligned, interview-based assessment engagement. While AmeriVet showed interest, both parties agreed the SPR would be more appropriate after Nick has had more time to understand the current environment. The call also set the foundation for an ongoing working relationship through monthly syncs, potential partner education sessions, and follow-up around DLP comparison work. Overall, the meeting was successful in establishing trust, surfacing actionable needs, and defining the first likely project path.

This was an introductory alignment call between SHI and AmeriVet focused on onboarding Nicholas Sherman, AmeriVet’s new Director of Information Security, and establishing how SHI can support AmeriVet’s security roadmap. The conversation centered on understanding Nick’s priorities, clarifying SHI’s role as a strategic advisor and reseller, and identifying immediate and future areas where SHI can add value. From a business standpoint, the call confirmed that AmeriVet is in an early-stage security assessment period under new leadership. Nick is still learning the environment, building a renewals inventory, and identifying where controls are missing or underdeveloped. His near-term mission is to strengthen the overall security program, improve policies/processes/procedures, and move toward PCI compliance. The most concrete business and technical opportunity identified was Data Loss Prevention (DLP). Nick explicitly stated there is a real DLP gap today and described testing the environment by emailing a bogus Social Security number and credit card number to himself, which passed through successfully. That validates a live business risk around sensitive data exposure and creates an immediate discussion around email DLP, web DLP, and potentially supporting data classification capabilities. A secondary opportunity discussed was password manager replacement. Nick confirmed 1Password is expected to go away, though that initiative appears to already be narrowed by another AmeriVet stakeholder and is less open-ended than the DLP opportunity. SHI also introduced two strategic value-added motions for future engagement: security comparison matrices to narrow vendor choices and a Security Posture Review (SPR), which is a NIST-aligned, interview-based assessment engagement. While AmeriVet showed interest, both parties agreed the SPR would be more appropriate after Nick has had more time to understand the current environment. The call also set the foundation for an ongoing working relationship through monthly syncs, potential partner education sessions, and follow-up around DLP comparison work. Overall, the meeting was successful in establishing trust, surfacing actionable needs, and defining the first likely project path.

Agenda

Introductions and role/background overview Understand Nicholas Sherman’s responsibilities and current priorities at AmeriVet Explain SHI support model and advisory capabilities Review current AmeriVet

security initiatives and renewals

Identify near-term

security needs and solution gaps

Introduce SHI comparison matrix capability and Security Posture Review offering Discuss cadence for future collaboration and follow-up actions

Introductions and role/background overview Understand Nicholas Sherman’s responsibilities and current priorities at AmeriVet Explain SHI support model and advisory capabilities Review current AmeriVet

security initiatives and renewals

Identify near-term

security needs and solution gaps

Introduce SHI comparison matrix capability and Security Posture Review offering Discuss cadence for future collaboration and follow-up actions

Opps Identified & BANTC

Opportunity 1: Data Loss Prevention (DLP) / Sensitive
Data Protection

B: Budget was not discussed
or confirmed during the meeting.
A: Economic buyer not
identified on this call. Nicholas Sherman appears to be a key technical/security decision-maker and sponsor for evaluation.
N: Clear need identified.
AmeriVet currently has a DLP gap. Nicholas validated that sensitive content could pass through email controls, creating risk around regulated and confidential data. Need spans at least email and web traffic, with related discussion around data classification.
T: Immediate exploratory
phase. SHI committed to begin comparison work next. Timing appears near-term as the first security initiative to “kick the tires on.”
C: Competition not yet
formally defined. Existing platform consideration includes Abnormal’s DLP beta. SHI discussed evaluating the market and also checking whether current platforms can meet minimum requirements to reduce tool sprawl.

B: Budget was not discussed
or confirmed during the meeting.
A: Economic buyer not
identified on this call. Nicholas Sherman appears to be a key technical/security decision-maker and sponsor for evaluation.
N: Clear need identified.
AmeriVet currently has a DLP gap. Nicholas validated that sensitive content could pass through email controls, creating risk around regulated and confidential data. Need spans at least email and web traffic, with related discussion around data classification.
T: Immediate exploratory
phase. SHI committed to begin comparison work next. Timing appears near-term as the first security initiative to “kick the tires on.”
C: Competition not yet
formally defined. Existing platform consideration includes Abnormal’s DLP beta. SHI discussed evaluating the market and also checking whether current platforms can meet minimum requirements to reduce tool sprawl.
Opportunity 2: Data Classification / Information
Protection Foundation

B: Budget was not discussed
or confirmed.
A: Economic buyer not
identified. Nicholas Sherman is the relevant security stakeholder.
N: Need identified
indirectly. AmeriVet does not appear to have current data classification tooling. SHI and AmeriVet both acknowledged the logic that data must be identified/classified before it can be properly protected.
T: Early-stage; likely to
follow or complement DLP exploration.
C: Competition not
discussed. No vendors were named for classification during this call.

B: Budget was not discussed
or confirmed.
A: Economic buyer not
identified. Nicholas Sherman is the relevant security stakeholder.
N: Need identified
indirectly. AmeriVet does not appear to have current data classification tooling. SHI and AmeriVet both acknowledged the logic that data must be identified/classified before it can be properly protected.
T: Early-stage; likely to
follow or complement DLP exploration.
C: Competition not
discussed. No vendors were named for classification during this call.
Opportunity 3: Password Manager Replacement

B: Budget was not
discussed.
A: Jason appears involved
in driving this project internally at AmeriVet; final decision authority was not confirmed.
N: Need exists because
1Password is expected to be replaced.
T: In progress already.
Nicholas said Jason has narrowed the field to approximately two options and Nick has already provided a recommendation based on prior experience.
C: Active competition
exists, but specific vendors were not named in this meeting.

B: Budget was not
discussed.
A: Jason appears involved
in driving this project internally at AmeriVet; final decision authority was not confirmed.
N: Need exists because
1Password is expected to be replaced.
T: In progress already.
Nicholas said Jason has narrowed the field to approximately two options and Nick has already provided a recommendation based on prior experience.
C: Active competition
exists, but specific vendors were not named in this meeting.
Opportunity 4: Security Posture Review (SPR)
Engagement

B: No budget discussion.
SHI positioned this as a value-add engagement.
A: Nicholas Sherman would
likely be a participant/sponsor; broader AmeriVet security/IT leadership may be involved.
N: Need is present from a
strategic perspective: new security leadership, desire to understand current posture, identify gaps/overlap, and align short- and long-term improvements.
T: Deferred to a later
timeframe, likely month 3–6 after Nicholas is more acclimated to the environment.
C: No competitive
alternatives discussed.

B: No budget discussion.
SHI positioned this as a value-add engagement.
A: Nicholas Sherman would
likely be a participant/sponsor; broader AmeriVet security/IT leadership may be involved.
N: Need is present from a
strategic perspective: new security leadership, desire to understand current posture, identify gaps/overlap, and align short- and long-term improvements.
T: Deferred to a later
timeframe, likely month 3–6 after Nicholas is more acclimated to the environment.
C: No competitive
alternatives discussed.

Initiatives

Security

Stand up and mature AmeriVet’s security program under new leadership Improve policies, processes, and procedures Work toward PCI compliance Evaluate DLP solutions for email and web traffic Consider data classification capabilities to support information protection strategy Replace 1Password with a different password management platform Revisit a broader Security Posture Review after Nicholas has more environmental context Continue monthly security-focused syncs with SHI and selective vendor/partner education sessions

Security

Stand up and mature AmeriVet’s security program under new leadership Improve policies, processes, and procedures Work toward PCI compliance Evaluate DLP solutions for email and web traffic Consider data classification capabilities to support information protection strategy Replace 1Password with a different password management platform Revisit a broader Security Posture Review after Nicholas has more environmental context Continue monthly security-focused syncs with SHI and selective vendor/partner education sessions

Stand up and mature AmeriVet’s security program under new leadership Improve policies, processes, and procedures Work toward PCI compliance Evaluate DLP solutions for email and web traffic Consider data classification capabilities to support information protection strategy Replace 1Password with a different password management platform Revisit a broader Security Posture Review after Nicholas has more environmental context Continue monthly security-focused syncs with SHI and selective vendor/partner education sessions

Tech Profile Updates

AmeriVet has Abnormal in place for secure email/security-related capabilities; Abnormal DLP beta was mentioned as a possible option. AmeriVet previously used Mimecast and transitioned to Abnormal with SHI support. AmeriVet uses a substantial CrowdStrike footprint, with renewal already extended through March
2028.
KnowBe4 is in place for security awareness/phishing-related functions, with renewal through December
2027.
1Password is in place today but is expected to be replaced. AmeriVet does not currently appear to have a data classification tool in place. SHI introduced SHI1 as a portal AmeriVet project managers already use, and described how recommendations/assessments can flow into that platform. SHI introduced its Security Posture Review (SPR) offering as an interview-based, NIST-aligned assessment. AmeriVet is interested in reducing tool sprawl and prefers consolidated capabilities where existing platforms can meet minimum requirements.

AmeriVet has Abnormal in place for secure email/security-related capabilities; Abnormal DLP beta was mentioned as a possible option. AmeriVet previously used Mimecast and transitioned to Abnormal with SHI support. AmeriVet uses a substantial CrowdStrike footprint, with renewal already extended through March
2028.
KnowBe4 is in place for security awareness/phishing-related functions, with renewal through December
2027.
1Password is in place today but is expected to be replaced. AmeriVet does not currently appear to have a data classification tool in place. SHI introduced SHI1 as a portal AmeriVet project managers already use, and described how recommendations/assessments can flow into that platform. SHI introduced its Security Posture Review (SPR) offering as an interview-based, NIST-aligned assessment. AmeriVet is interested in reducing tool sprawl and prefers consolidated capabilities where existing platforms can meet minimum requirements.

Meeting Notes

Environment

New Director of Information Security recently joined AmeriVet and is still in early onboarding. AmeriVet security program is in a discovery and prioritization stage.

Security leadership is

actively building a renewals list to understand current tools and terms.

Security priorities

include compliance readiness, protection of sensitive data, and rationalization of tooling. SHI already has an established multi-threaded relationship with AmeriVet across hardware, project management, IT leadership, and security-related conversations. AmeriVet has an existing pattern of using SHI both for procurement support and advisory comparisons.

New Director of Information Security recently joined AmeriVet and is still in early onboarding. AmeriVet security program is in a discovery and prioritization stage.

Security leadership is

actively building a renewals list to understand current tools and terms.

Security priorities

include compliance readiness, protection of sensitive data, and rationalization of tooling. SHI already has an established multi-threaded relationship with AmeriVet across hardware, project management, IT leadership, and security-related conversations. AmeriVet has an existing pattern of using SHI both for procurement support and advisory comparisons.

Detailed Discussion

Jax Miley opened the call by introducing SHI’s role and explaining that SHI supports AmeriVet across hardware and broader IT categories including Microsoft, cybersecurity, datacenter, storage, and networking. Nicholas Sherman introduced himself as the new Director of Information Security. He shared that although he has over 20 years in IT and roughly 15 years focused on security and compliance, he has been at AmeriVet less than a month and is still absorbing the environment. Nick described his top-level mandate as strengthening the security program and improving governance-related elements such as policies, processes, procedures, and alignment toward PCI compliance. Jax and Stephen then guided the conversation toward how SHI can help reduce time spent in research and product evaluation. Stephen explained SHI’s capability to build vendor comparison matrices and supplement those with subject matter expert conversations so AmeriVet can narrow large markets down to a manageable shortlist. The conversation then moved into concrete AmeriVet security needs. Jax referenced prior context from other AmeriVet leaders, including discussion around DLP. Nick confirmed DLP is indeed a need and added an important real-world validation example: he tested the environment by sending a bogus SSN and credit card number via email and it passed through. This strongly reinforced the existence of a control gap. The parties discussed that DLP may need to be considered across multiple control points, especially email and web traffic, and Stephen suggested a classification discussion as well since AmeriVet does not appear to have a classification tool. Nick explained his evaluation approach: hear the pitch, review slides, see a demo, and if relevant run a proof of concept, while also consulting trusted advisors and peers to avoid wasting time on poor-fit vendors. An important buying preference emerged: Nick values consolidation and wants to first assess whether existing platforms can satisfy requirements before introducing net-new tools. He specifically stated that if an existing platform meets minimum needs, even if not category best-of-breed, that may still be preferable because of operational simplicity and reduced portal/tool sprawl. SHI then introduced the Security Posture Review (SPR), describing it as a two-meeting, interview-based assessment aligned to NIST with short- and long-term recommendations and possible integration into SHI1. Nick reacted positively, but Stephen recommended deferring that engagement until Nick has been in-role longer and has gained more tribal knowledge of the environment. Jax also discussed the possibility of recurring monthly syncs and brief partner education sessions. Nick was open to those sessions as long as there are no surprises and they are relevant to his priorities. Near the end of the meeting, Stephen proposed immediate next work around DLP by requesting comparison charts for web DLP and email DLP, and possibly a third around classification tools. Nick agreed this direction made sense. Jax also checked on the 1Password replacement effort. Nick responded that Jason already has that narrowed to about two options and that he has already given Jason his recommendation, implying SHI may not need to drive the front end of that project right now. The meeting concluded with agreement to pursue DLP-related follow-up, maintain ongoing communication, and revisit broader assessment work later.

Jax Miley opened the call by introducing SHI’s role and explaining that SHI supports AmeriVet across hardware and broader IT categories including Microsoft, cybersecurity, datacenter, storage, and networking. Nicholas Sherman introduced himself as the new Director of Information Security. He shared that although he has over 20 years in IT and roughly 15 years focused on security and compliance, he has been at AmeriVet less than a month and is still absorbing the environment. Nick described his top-level mandate as strengthening the security program and improving governance-related elements such as policies, processes, procedures, and alignment toward PCI compliance. Jax and Stephen then guided the conversation toward how SHI can help reduce time spent in research and product evaluation. Stephen explained SHI’s capability to build vendor comparison matrices and supplement those with subject matter expert conversations so AmeriVet can narrow large markets down to a manageable shortlist. The conversation then moved into concrete AmeriVet security needs. Jax referenced prior context from other AmeriVet leaders, including discussion around DLP. Nick confirmed DLP is indeed a need and added an important real-world validation example: he tested the environment by sending a bogus SSN and credit card number via email and it passed through. This strongly reinforced the existence of a control gap. The parties discussed that DLP may need to be considered across multiple control points, especially email and web traffic, and Stephen suggested a classification discussion as well since AmeriVet does not appear to have a classification tool. Nick explained his evaluation approach: hear the pitch, review slides, see a demo, and if relevant run a proof of concept, while also consulting trusted advisors and peers to avoid wasting time on poor-fit vendors. An important buying preference emerged: Nick values consolidation and wants to first assess whether existing platforms can satisfy requirements before introducing net-new tools. He specifically stated that if an existing platform meets minimum needs, even if not category best-of-breed, that may still be preferable because of operational simplicity and reduced portal/tool sprawl. SHI then introduced the Security Posture Review (SPR), describing it as a two-meeting, interview-based assessment aligned to NIST with short- and long-term recommendations and possible integration into SHI1. Nick reacted positively, but Stephen recommended deferring that engagement until Nick has been in-role longer and has gained more tribal knowledge of the environment. Jax also discussed the possibility of recurring monthly syncs and brief partner education sessions. Nick was open to those sessions as long as there are no surprises and they are relevant to his priorities. Near the end of the meeting, Stephen proposed immediate next work around DLP by requesting comparison charts for web DLP and email DLP, and possibly a third around classification tools. Nick agreed this direction made sense. Jax also checked on the 1Password replacement effort. Nick responded that Jason already has that narrowed to about two options and that he has already given Jason his recommendation, implying SHI may not need to drive the front end of that project right now. The meeting concluded with agreement to pursue DLP-related follow-up, maintain ongoing communication, and revisit broader assessment work later.

Technical Notes

Nicholas Sherman is newly in role and is still discovering the current-state security stack, renewals, configurations, and layout of the environment. PCI compliance is on his roadmap, indicating future importance of data handling controls, policy maturity, and auditability. DLP need is concrete, not theoretical:

Nick tested the current environment by emailing a bogus Social Security number and credit card number. The message passed through, indicating a lack of effective controls or enforcement for that data type in at least one channel.

DLP scope discussed:

Email DLP was explicitly required. Web traffic DLP was also called out to prevent users from manually entering sensitive data into web applications such as generative AI tools. Data-layer DLP was mentioned but not prioritized on this call.

Data classification:

Stephen asked whether AmeriVet has data classification tools in place. Nick said no, not to his knowledge. Both parties acknowledged protection strategy depends on understanding which data is sensitive.

Existing platforms/products discussed:

Abnormal

Currently in the

environment

Has a DLP capability in beta Also mentioned as having security awareness/phishing-related functionality Was part of a prior transition from Mimecast

Mimecast

Historical secure email gateway/security tool that AmeriVet previously used SHI helped transition away from it to Abnormal

CrowdStrike

Large suite present in

environment

Renewal date discussed as March 2028 under a three-year term Stephen asked conceptually what DLP solutions CrowdStrike may have as part of platform consolidation thinking

KnowBe4

Present in environment for security awareness/phishing-related use Renewal date discussed as December 2027 Nick said the team is still getting its hands around usage/management of it

1Password

In use today Planned for replacement

Evaluation methodology preferred by customer:

Sales pitch and slides are acceptable starting points Demo is mandatory Proof of concept is appropriate when needed Peer/trusted advisor input is important to validate viability Reducing the number of vendors evaluated is highly valued

Operational preference:

Nick wants to avoid tool sprawl Consolidation is a positive if existing platforms can meet minimum requirements A “good enough within current platform” outcome may be preferable to “absolute best-of-breed” if operationally simpler

SHI comparison services:

SHI can build comparison matrices in PDF and interactive HTML format SHI can pair comparison content with subject matter expert review sessions Initial path proposed was multiple DLP-related comparison sets rather than jumping directly into demos

SHI Security Posture Review (SPR):

Interview based only No agent deployment or tooling installation Follows the NIST framework Produces short-term and long-term recommendations Can feed output/recommendations into SHI1

SHI1 / Labs:

SHI described on-demand lab/demo environments available in SHI1 These can allow customers to preview tooling/UI without going directly to OEM websites Jax noted that some tools can be spun up on demand, while others require SHI assistance

Nicholas Sherman is newly in role and is still discovering the current-state security stack, renewals, configurations, and layout of the environment. PCI compliance is on his roadmap, indicating future importance of data handling controls, policy maturity, and auditability. DLP need is concrete, not theoretical:

Nick tested the current environment by emailing a bogus Social Security number and credit card number. The message passed through, indicating a lack of effective controls or enforcement for that data type in at least one channel.

Nick tested the current environment by emailing a bogus Social Security number and credit card number. The message passed through, indicating a lack of effective controls or enforcement for that data type in at least one channel. DLP scope discussed:

Email DLP was explicitly required. Web traffic DLP was also called out to prevent users from manually entering sensitive data into web applications such as generative AI tools. Data-layer DLP was mentioned but not prioritized on this call.

Email DLP was explicitly required. Web traffic DLP was also called out to prevent users from manually entering sensitive data into web applications such as generative AI tools. Data-layer DLP was mentioned but not prioritized on this call. Data classification:

Stephen asked whether AmeriVet has data classification tools in place. Nick said no, not to his knowledge. Both parties acknowledged protection strategy depends on understanding which data is sensitive.

Stephen asked whether AmeriVet has data classification tools in place. Nick said no, not to his knowledge. Both parties acknowledged protection strategy depends on understanding which data is sensitive. Existing platforms/products discussed:

Abnormal

Currently in the

environment

Has a DLP capability in beta Also mentioned as having security awareness/phishing-related functionality Was part of a prior transition from Mimecast

Mimecast

Historical secure email gateway/security tool that AmeriVet previously used SHI helped transition away from it to Abnormal

CrowdStrike

Large suite present in

environment

Renewal date discussed as March 2028 under a three-year term Stephen asked conceptually what DLP solutions CrowdStrike may have as part of platform consolidation thinking

KnowBe4

Present in environment for security awareness/phishing-related use Renewal date discussed as December 2027 Nick said the team is still getting its hands around usage/management of it

1Password

In use today Planned for replacement

Abnormal

Currently in the

environment

Has a DLP capability in beta Also mentioned as having security awareness/phishing-related functionality Was part of a prior transition from Mimecast

Currently in the

environment

Has a DLP capability in beta Also mentioned as having security awareness/phishing-related functionality Was part of a prior transition from Mimecast Mimecast

Historical secure email gateway/security tool that AmeriVet previously used SHI helped transition away from it to Abnormal

Historical secure email gateway/security tool that AmeriVet previously used SHI helped transition away from it to Abnormal CrowdStrike

Large suite present in

environment

Renewal date discussed as March 2028 under a three-year term Stephen asked conceptually what DLP solutions CrowdStrike may have as part of platform consolidation thinking

Large suite present in

environment

Renewal date discussed as March 2028 under a three-year term Stephen asked conceptually what DLP solutions CrowdStrike may have as part of platform consolidation thinking KnowBe4

Present in environment for security awareness/phishing-related use Renewal date discussed as December 2027 Nick said the team is still getting its hands around usage/management of it

Present in environment for security awareness/phishing-related use Renewal date discussed as December 2027 Nick said the team is still getting its hands around usage/management of it 1Password

In use today Planned for replacement

In use today Planned for replacement Evaluation methodology preferred by customer:

Sales pitch and slides are acceptable starting points Demo is mandatory Proof of concept is appropriate when needed Peer/trusted advisor input is important to validate viability Reducing the number of vendors evaluated is highly valued

Sales pitch and slides are acceptable starting points Demo is mandatory Proof of concept is appropriate when needed Peer/trusted advisor input is important to validate viability Reducing the number of vendors evaluated is highly valued Operational preference:

Nick wants to avoid tool sprawl Consolidation is a positive if existing platforms can meet minimum requirements A “good enough within current platform” outcome may be preferable to “absolute best-of-breed” if operationally simpler

Nick wants to avoid tool sprawl Consolidation is a positive if existing platforms can meet minimum requirements A “good enough within current platform” outcome may be preferable to “absolute best-of-breed” if operationally simpler SHI comparison services:

SHI can build comparison matrices in PDF and interactive HTML format SHI can pair comparison content with subject matter expert review sessions Initial path proposed was multiple DLP-related comparison sets rather than jumping directly into demos

SHI can build comparison matrices in PDF and interactive HTML format SHI can pair comparison content with subject matter expert review sessions Initial path proposed was multiple DLP-related comparison sets rather than jumping directly into demos SHI Security Posture Review (SPR):

Interview based only No agent deployment or tooling installation Follows the NIST framework Produces short-term and long-term recommendations Can feed output/recommendations into SHI1

Interview based only No agent deployment or tooling installation Follows the NIST framework Produces short-term and long-term recommendations Can feed output/recommendations into SHI1 SHI1 / Labs:

SHI described on-demand lab/demo environments available in SHI1 These can allow customers to preview tooling/UI without going directly to OEM websites Jax noted that some tools can be spun up on demand, while others require SHI assistance

SHI described on-demand lab/demo environments available in SHI1 These can allow customers to preview tooling/UI without going directly to OEM websites Jax noted that some tools can be spun up on demand, while others require SHI assistance

ROLES

Jax Miley — Commercial Inside Account Executive, SHI Stephen Drake — SHI leader/manager supporting the account; Jax’s upline manager, SHI Nicholas Sherman — Director of Information Security, AmeriVet Manuel Zelaya — SHI participant on the meeting invite Kat Mullen — AmeriVet participant referenced on the invite and in discussion Vic — AmeriVet IT/security stakeholder referenced in discussion Steve Park — Former AmeriVet security leader/predecessor referenced in discussion Jason Marves — AmeriVet stakeholder involved in password manager replacement discussion Mark Berry — AmeriVet stakeholder referenced in discussion around tooling/experience

Jax Miley — Commercial Inside Account Executive, SHI Stephen Drake — SHI leader/manager supporting the account; Jax’s upline manager, SHI Nicholas Sherman — Director of Information Security, AmeriVet Manuel Zelaya — SHI participant on the meeting invite Kat Mullen — AmeriVet participant referenced on the invite and in discussion Vic — AmeriVet IT/security stakeholder referenced in discussion Steve Park — Former AmeriVet security leader/predecessor referenced in discussion Jason Marves — AmeriVet stakeholder involved in password manager replacement discussion Mark Berry — AmeriVet stakeholder referenced in discussion around tooling/experience

Potential Next steps

SHI (Stephen/Jax) to initiate DLP comparison work for AmeriVet / Nicholas Sherman

Stephen explicitly directed Jax to start comparison charts for:

Email DLP Web traffic DLP Potentially data classification tools

Involved: Stephen Drake, Jax Miley, Nicholas Sherman

Follow-up meeting with SHI DLP subject matter expert

Stephen proposed a follow-up conversation after the comparison charts are delivered so AmeriVet can review findings, ask questions, and determine how/when to proceed. Involved: Nicholas Sherman, Jax Miley, SHI DLP SME, likely Stephen Drake

Monthly sync cadence between SHI and AmeriVet security

Jax said he would send monthly syncs and continue using Teams/email/calls as needed. Nick agreed to ongoing engagement and was open to partner education sessions when relevant and announced in advance. Involved: Jax Miley, Nicholas Sherman, potentially Stephen Drake and other AmeriVet IT/security stakeholders

Revisit

Security Posture Review in 3–6 months

Stephen recommended deferring the SPR until Nick is more acclimated and has gained more tribal knowledge. This should become a future strategic checkpoint once Nick has better current-state visibility. Involved: Nicholas Sherman, Jax Miley, Stephen Drake, AmeriVet IT/security team

Monitor password manager replacement but do not force immediate SHI intervention

Jax asked whether SHI should begin working the 1Password replacement. Nick indicated Jason already has that down to roughly two options and Nick has already provided his recommendation. Action is likely to monitor rather than drive unless AmeriVet later requests SHI help. Involved: Nicholas Sherman, Jason Marves, Jax Miley

Direct communication setup

Jax stated he would connect with Nick on Teams for faster communication. Involved: Jax Miley, Nicholas Sherman

Future executive briefing / EBC invitation

Jax mentioned SHI executive briefing opportunities in Austin; Stephen suggested a later timeframe such as October or next year given Nick’s onboarding stage. Involved: Jax Miley, Stephen Drake, Nicholas Sherman

SHI (Stephen/Jax) to initiate DLP comparison work for AmeriVet / Nicholas Sherman

Stephen explicitly directed Jax to start comparison charts for:

Email DLP Web traffic DLP Potentially data classification tools

Involved: Stephen Drake, Jax Miley, Nicholas Sherman

Stephen explicitly directed Jax to start comparison charts for:

Email DLP Web traffic DLP Potentially data classification tools

Email DLP Web traffic DLP Potentially data classification tools Involved: Stephen Drake, Jax Miley, Nicholas Sherman Follow-up meeting with SHI DLP subject matter expert

Stephen proposed a follow-up conversation after the comparison charts are delivered so AmeriVet can review findings, ask questions, and determine how/when to proceed. Involved: Nicholas Sherman, Jax Miley, SHI DLP SME, likely Stephen Drake

Stephen proposed a follow-up conversation after the comparison charts are delivered so AmeriVet can review findings, ask questions, and determine how/when to proceed. Involved: Nicholas Sherman, Jax Miley, SHI DLP SME, likely Stephen Drake Monthly sync cadence between SHI and AmeriVet security

Jax said he would send monthly syncs and continue using Teams/email/calls as needed. Nick agreed to ongoing engagement and was open to partner education sessions when relevant and announced in advance. Involved: Jax Miley, Nicholas Sherman, potentially Stephen Drake and other AmeriVet IT/security stakeholders

Jax said he would send monthly syncs and continue using Teams/email/calls as needed. Nick agreed to ongoing engagement and was open to partner education sessions when relevant and announced in advance. Involved: Jax Miley, Nicholas Sherman, potentially Stephen Drake and other AmeriVet IT/security stakeholders Revisit

Security Posture Review in 3–6 months

Stephen recommended deferring the SPR until Nick is more acclimated and has gained more tribal knowledge. This should become a future strategic checkpoint once Nick has better current-state visibility. Involved: Nicholas Sherman, Jax Miley, Stephen Drake, AmeriVet IT/security team

Stephen recommended deferring the SPR until Nick is more acclimated and has gained more tribal knowledge. This should become a future strategic checkpoint once Nick has better current-state visibility. Involved: Nicholas Sherman, Jax Miley, Stephen Drake, AmeriVet IT/security team Monitor password manager replacement but do not force immediate SHI intervention

Jax asked whether SHI should begin working the 1Password replacement. Nick indicated Jason already has that down to roughly two options and Nick has already provided his recommendation. Action is likely to monitor rather than drive unless AmeriVet later requests SHI help. Involved: Nicholas Sherman, Jason Marves, Jax Miley

Jax asked whether SHI should begin working the 1Password replacement. Nick indicated Jason already has that down to roughly two options and Nick has already provided his recommendation. Action is likely to monitor rather than drive unless AmeriVet later requests SHI help. Involved: Nicholas Sherman, Jason Marves, Jax Miley Direct communication setup

Jax stated he would connect with Nick on Teams for faster communication. Involved: Jax Miley, Nicholas Sherman

Jax stated he would connect with Nick on Teams for faster communication. Involved: Jax Miley, Nicholas Sherman Future executive briefing / EBC invitation

Jax mentioned SHI executive briefing opportunities in Austin; Stephen suggested a later timeframe such as October or next year given Nick’s onboarding stage. Involved: Jax Miley, Stephen Drake, Nicholas Sherman

Jax mentioned SHI executive briefing opportunities in Austin; Stephen suggested a later timeframe such as October or next year given Nick’s onboarding stage. Involved: Jax Miley, Stephen Drake, Nicholas Sherman
