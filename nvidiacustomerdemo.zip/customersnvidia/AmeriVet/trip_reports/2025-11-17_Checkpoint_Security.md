Trip Report | Checkpoint Security | AmeriVet

Customer: AmeriVet
AE: Jax M
Topic: Checkpoint Security
Meeting Date 11/17/2025

*Internal notes – Please read and edit before sending externally*

Summary

The meeting was a follow-up checkpoint between AmeriVet and SHI regarding the ongoing Proof of Concept (POC) with Check Point’s security platform. The primary goal was to review POC results, validate functionality, and discuss next steps toward production deployment. Key topics included phishing detection performance, Data Loss Prevention (DLP) capabilities, encryption workflows, malware tuning, shadow IT visibility, partner risk scoring, and DMARC/DKIM configuration. The discussion also touched on consolidation benefits, optional modules (security awareness training, archiving, leaked credentials), and integration with existing tools like KnowBe4. AmeriVet expressed satisfaction with visibility and ease of configuration but noted internal deliberation is needed before finalizing vendor selection. The trial has 11 days remaining, and AmeriVet plans to compare Check Point against another vendor before making a decision.

Agenda

Review POC progress and telemetry data. Validate phishing detection and DLP functionality. Demonstrate encryption policy configuration. Address malware false positives and allow-listing. Explore shadow IT and partner risk analytics. Discuss DMARC/DKIM setup and monitoring. Clarify pricing and optional modules. Plan next steps and internal evaluation.

Review POC progress and telemetry data. Validate phishing detection and DLP functionality. Demonstrate encryption policy configuration. Address malware false positives and allow-listing. Explore shadow IT and partner risk analytics. Discuss DMARC/DKIM setup and monitoring. Clarify pricing and optional modules. Plan next steps and internal evaluation.

Opportunities Identified & BANTC

Opportunity 1: Email Security & DLP Deployment

B (Budget): Base security included; DLP confirmed as part of quote. Additional modules (training, archiving) are extra cost. A (Authority): Decision-making involves AmeriVet IT leadership (VicTorey, Kat, Mark) and possibly procurement. N (Need): Strong need for phishing protection, DLP visibility, encryption for PHI/PII, and risk reduction. T (Timeline): 11 days left in trial; decision expected within weeks after internal review. C (Competition): Another vendor is being evaluated concurrently.

B (Budget): Base security included; DLP confirmed as part of quote. Additional modules (training, archiving) are extra cost. A (Authority): Decision-making involves AmeriVet IT leadership (VicTorey, Kat, Mark) and possibly procurement. N (Need): Strong need for phishing protection, DLP visibility, encryption for PHI/PII, and risk reduction. T (Timeline): 11 days left in trial; decision expected within weeks after internal review. C (Competition): Another vendor is being evaluated concurrently.
Opportunity 2: Security Awareness Training

B: Separate cost; not included
in current quote.
A: AmeriVet team (Kat, Mark)
will revisit post current KnowBe4 contract (March/April).
N: Desire for integrated
platform and tailored phishing simulations.
T: Potential revisit early next
year.
C: Current KnowBe4 contract in
place.

B: Separate cost; not included
in current quote.
A: AmeriVet team (Kat, Mark)
will revisit post current KnowBe4 contract (March/April).
N: Desire for integrated
platform and tailored phishing simulations.
T: Potential revisit early next
year.
C: Current KnowBe4 contract in
place.

Initiatives

Security: Email security, phishing detection, DLP, encryption, shadow IT, partner risk, DMARC/DKIM compliance. Storage: Not applicable in this discussion.

Security: Email security, phishing detection, DLP, encryption, shadow IT, partner risk, DMARC/DKIM compliance. Storage: Not applicable in this discussion.

Tech Profile Updates

AmeriVet uses Microsoft 365 (email, OneDrive). Existing DLP via Mimecast; evaluating Check Point for enhanced visibility. KnowBe4 for security awareness training. ScreenConnect used for remote support (allow-listed during session). DMARC currently set to “none”; DKIM keys configured and monitored.

AmeriVet uses Microsoft 365 (email, OneDrive). Existing DLP via Mimecast; evaluating Check Point for enhanced visibility. KnowBe4 for security awareness training. ScreenConnect used for remote support (allow-listed during session). DMARC currently set to “none”; DKIM keys configured and monitored.

Meeting Notes

Environment: Veterinary services organization with Microsoft-centric infrastructure. Heavy email traffic with PHI/PII exchange. Compliance and risk management are priorities.

Detailed Discussion

POC Status: Extended trial; telemetry reviewed (618 phishing events in 7 days, 608 blocked by Check Point). DLP: Granular visibility into subject, body, attachments; HIPAA violations flagged; encryption workflows demonstrated. Malware: 27 detections, mostly ScreenConnect executables; allow-listed to reduce false positives. Shadow IT: Identified unsanctioned apps; process shown for approving/dismissing events. Partner Risk: Vendors scored by malicious activity history; global breach intelligence integrated. DMARC/DKIM: Monitoring active; AmeriVet policy at “none”; guidance provided for moving to quarantine/reject. Optional Modules: Security awareness training, archiving, leaked credentials, DMARC, SSPM discussed. Integration: KnowBe4 allow-listing steps shared; phishing report workflows explained.

POC Status: Extended trial; telemetry reviewed (618 phishing events in 7 days, 608 blocked by Check Point). DLP: Granular visibility into subject, body, attachments; HIPAA violations flagged; encryption workflows demonstrated. Malware: 27 detections, mostly ScreenConnect executables; allow-listed to reduce false positives. Shadow IT: Identified unsanctioned apps; process shown for approving/dismissing events. Partner Risk: Vendors scored by malicious activity history; global breach intelligence integrated. DMARC/DKIM: Monitoring active; AmeriVet policy at “none”; guidance provided for moving to quarantine/reject. Optional Modules: Security awareness training, archiving, leaked credentials, DMARC, SSPM discussed. Integration: KnowBe4 allow-listing steps shared; phishing report workflows explained.

Technical Notes

Encryption policy setup: Navigate to Policy → Office → New Policy → Prevent inline → Select users/groups → Configure DLP categories → Enable encryption under DLP workflows. DLP detection granularity: Subject, body, attachments; HIPAA violations enumerated. Malware tuning: Allow-list ScreenConnect via “Report as not malicious.” Shadow IT: Approve apps (e.g., SharePoint), dismiss events; iterative cleanup process. DMARC: Collect RUAs/RUFs; monitor SPF pass rates; update MX records via UI. DKIM: Key management through wizard; add/update keys with notes. Phishing report integration: Configure mailbox for KnowBe4; workflows range from manual review to SOC service.

Security awareness training

Policy creation includes user targeting, scheduling, failure actions, and training modules; unique feature—real attack-based simulations.

Encryption policy setup: Navigate to Policy → Office → New Policy → Prevent inline → Select users/groups → Configure DLP categories → Enable encryption under DLP workflows. DLP detection granularity: Subject, body, attachments; HIPAA violations enumerated. Malware tuning: Allow-list ScreenConnect via “Report as not malicious.” Shadow IT: Approve apps (e.g., SharePoint), dismiss events; iterative cleanup process. DMARC: Collect RUAs/RUFs; monitor SPF pass rates; update MX records via UI. DKIM: Key management through wizard; add/update keys with notes. Phishing report integration: Configure mailbox for KnowBe4; workflows range from manual review to SOC service.

Security awareness training

Policy creation includes user targeting, scheduling, failure actions, and training modules; unique feature—real attack-based simulations.

ROLES

AmeriVet:

VicTorey – IT Lead Kat – IT Team Member Mark – IT Team Member Steve – IT Team Member

Vendor (Check Point):

James – Security Engineer / Product Specialist Eric – Account Manager Christopher – Technical Specialist

SHI:

Jax Miley – Partner Representative Manuel Zelaya - SHI SE

AmeriVet:

VicTorey – IT Lead Kat – IT Team Member Mark – IT Team Member Steve – IT Team Member

VicTorey – IT Lead Kat – IT Team Member Mark – IT Team Member Steve – IT Team Member Vendor (Check Point):

James – Security Engineer / Product Specialist Eric – Account Manager Christopher – Technical Specialist

James – Security Engineer / Product Specialist Eric – Account Manager Christopher – Technical Specialist SHI:

Jax Miley – Partner Representative Manuel Zelaya - SHI SE

Jax Miley – Partner Representative Manuel Zelaya - SHI SE

Potential Next Steps

Internal Review:

Who: VicTorey, Kat, Mark Action: Convene internally to compare Check Point vs. other vendor; finalize decision in coming weeks.

Vendor Follow-up:

Who: James → AmeriVet team Action: Send allow-list instructions for KnowBe4 phishing campaigns.

DMARC Policy Setup:

Who: AmeriVet IT team Action: Begin testing DMARC policy creation; move from “none” toward quarantine.

Security

Awareness Training Evaluation:

Who: AmeriVet IT leadership Action: Revisit Check Point training module post KnowBe4 contract (March/April).

POC Monitoring:

Who: AmeriVet team Action: Continue reviewing phishing events and tuning false positives during remaining trial period.

Internal Review:

Who: VicTorey, Kat, Mark Action: Convene internally to compare Check Point vs. other vendor; finalize decision in coming weeks.

Who: VicTorey, Kat, Mark Action: Convene internally to compare Check Point vs. other vendor; finalize decision in coming weeks. Vendor Follow-up:

Who: James → AmeriVet team Action: Send allow-list instructions for KnowBe4 phishing campaigns.

Who: James → AmeriVet team Action: Send allow-list instructions for KnowBe4 phishing campaigns. DMARC Policy Setup:

Who: AmeriVet IT team Action: Begin testing DMARC policy creation; move from “none” toward quarantine.

Who: AmeriVet IT team Action: Begin testing DMARC policy creation; move from “none” toward quarantine.

Security

Awareness Training Evaluation:

Who: AmeriVet IT leadership Action: Revisit Check Point training module post KnowBe4 contract (March/April).

Who: AmeriVet IT leadership Action: Revisit Check Point training module post KnowBe4 contract (March/April). POC Monitoring:

Who: AmeriVet team Action: Continue reviewing phishing events and tuning false positives during remaining trial period.

Who: AmeriVet team Action: Continue reviewing phishing events and tuning false positives during remaining trial period.
