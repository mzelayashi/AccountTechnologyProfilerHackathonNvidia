Trip Report | AI discovery | AmeriVet

Customer: AmeriVet
AE: Jax M
Topic: AI discovery
Meeting Date 06/25/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Jax M

coordinate with Dieter and Mark to schedule a workshop with AmeriVet’s AI committee and relevant stakeholders.

07/11

2

Manuel Z

present potential technical approaches for scalable, secure chatbot integration

07/1

Item Owner Next Steps/Detail Due Date 1 Jax M coordinate with Dieter and Mark to schedule a workshop with AmeriVet’s AI committee and relevant stakeholders. 07/11 2 Manuel Z present potential technical approaches for scalable, secure chatbot integration 07/1

Summary

This was an AI discovery call between AmeriVet and SHI to explore AmeriVet’s vision for leveraging AI—particularly generative AI—to improve intranet/document search and HR/IT self-service. AmeriVet is considering overlaying OpenAI on SharePoint to enable employees to query company information and reduce support tickets, but faces technical and licensing challenges. SHI shared their own AI journey (Project Mindspark), described their full-stack AI advisory and services capabilities, and discussed key success factors: executive sponsorship, cross-functional steering, workforce adoption, and data readiness. The call identified the need for a use case discovery workshop to define high-impact, low-effort pilots and map AmeriVet’s next steps. Discussion included data sources (SharePoint, Snowflake), measurement (ticket count reduction), adoption, governance, and change management. The group agreed to schedule a workshop with the AmeriVet AI committee.

Agenda

Introductions AmeriVet’s AI goals and intranet/HR bot vision Technical and licensing challenges (OpenAI, SharePoint, Teams, Copilot) SHI’s

Opps Identified & BANTC

Opportunity: AI-Powered Intranet & Knowledge Management for AmeriVet

B (Budget): AmeriVet wants to avoid licensing all 3500 users individually; cost optimization is key. Executive leadership is supportive, but project must be scalable and cost-effective. A (Authority): Executive leadership (CHRO, CIO, COO) is driving the AI vision. Dieter Karkut (Director of IT) and Mark Berry (Lead SaaS Admin) are key project owners. AI committee is in place. N (Need): Unified, AI-powered search/chatbot for HR/IT and eventually all departments, capable of accessing SharePoint docs and corporate data, reducing ticket volumes, and increasing workforce efficiency. T (Timeline): No fixed deadline; execs want fast progress (ideally July 1), but IT leadership prioritizes doing it right over moving too quickly. C (Competition): Mix of DIY approaches (OpenAI, Copilot, custom bots), commercial platforms (Glean, Moveworks, Icertis, etc.), and SHI’s own advisory/services. AmeriVet is open to off-the-shelf or managed solutions.

B (Budget): AmeriVet wants to avoid licensing all 3500 users individually; cost optimization is key. Executive leadership is supportive, but project must be scalable and cost-effective. A (Authority): Executive leadership (CHRO, CIO, COO) is driving the AI vision. Dieter Karkut (Director of IT) and Mark Berry (Lead SaaS Admin) are key project owners. AI committee is in place. N (Need): Unified, AI-powered search/chatbot for HR/IT and eventually all departments, capable of accessing SharePoint docs and corporate data, reducing ticket volumes, and increasing workforce efficiency. T (Timeline): No fixed deadline; execs want fast progress (ideally July 1), but IT leadership prioritizes doing it right over moving too quickly. C (Competition): Mix of DIY approaches (OpenAI, Copilot, custom bots), commercial platforms (Glean, Moveworks, Icertis, etc.), and SHI’s own advisory/services. AmeriVet is open to off-the-shelf or managed solutions.

Initiatives

AI/Workforce Productivity (primary): AI-powered knowledge management, chatbots, intranet search Security/Governance (secondary): Policy, compliance, change management for AI usage Storage/Data (supporting): SharePoint, Snowflake, Workday as primary data sources

AI/Workforce Productivity (primary): AI-powered knowledge management, chatbots, intranet search Security/Governance (secondary): Policy, compliance, change management for AI usage Storage/Data (supporting): SharePoint, Snowflake, Workday as primary data sources

Tech Profile Updates

Collaboration/Source of Truth: Microsoft 365 (Teams, SharePoint, OneDrive, Outlook), Workday, Snowflake (for business data) Current AI Usage: 20 OpenAI enterprise licenses, HR/IT GPTs in training, Copilot tested (not preferred) Data Team: Uses Snowflake for analytics; may need to be included in future discussions Adoption: Early pilot users; execs supportive; adoption and expansion plan TBD Pain Points: Licensing model limitations, need for scalable access, integration challenges (custom GPT API, Teams chatbot, etc.)

Collaboration/Source of Truth: Microsoft 365 (Teams, SharePoint, OneDrive, Outlook), Workday, Snowflake (for business data) Current AI Usage: 20 OpenAI enterprise licenses, HR/IT GPTs in training, Copilot tested (not preferred) Data Team: Uses Snowflake for analytics; may need to be included in future discussions Adoption: Early pilot users; execs supportive; adoption and expansion plan TBD Pain Points: Licensing model limitations, need for scalable access, integration challenges (custom GPT API, Teams chatbot, etc.)

Meeting Notes

Environment

AmeriVet is a fast-growing veterinary group with 200+ practices and strong executive support for innovation and AI. Current state: Ad hoc SharePoint sites, high support ticket volumes, limited HR/IT self-service. AI initiative originated from executive request and is steered by an internal AI committee.

AmeriVet is a fast-growing veterinary group with 200+ practices and strong executive support for innovation and AI. Current state: Ad hoc SharePoint sites, high support ticket volumes, limited HR/IT self-service. AI initiative originated from executive request and is steered by an internal AI committee.

Detailed Discussion

AmeriVet described their goal: AI assistant for all staff to answer questions, retrieve docs/links, and reduce simple support tickets. Explored technical blockers: OpenAI API can’t access custom GPTs; Copilot not ideal; need for a scalable, secure, cost-effective solution. SHI shared experience with Project Mindspark: company-wide AI assistant, SharePoint integration, 75% adoption, measurable productivity gains. SHI described services: advisory, AI readiness, use case workshops, labs for experimentation, and security/governance frameworks. ROI/impact measured by support ticket reduction (HR gets ~3000/month), time savings, and adoption rates. Data team uses Snowflake for business analytics; may be involved in future phases. Governance, policy, and change management are not yet established but flagged as critical for success. SHI recommended a use case discovery workshop to prioritize and map actionable pilots.

AmeriVet described their goal: AI assistant for all staff to answer questions, retrieve docs/links, and reduce simple support tickets. Explored technical blockers: OpenAI API can’t access custom GPTs; Copilot not ideal; need for a scalable, secure, cost-effective solution. SHI shared experience with Project Mindspark: company-wide AI assistant, SharePoint integration, 75% adoption, measurable productivity gains. SHI described services: advisory, AI readiness, use case workshops, labs for experimentation, and security/governance frameworks. ROI/impact measured by support ticket reduction (HR gets ~3000/month), time savings, and adoption rates. Data team uses Snowflake for business analytics; may be involved in future phases. Governance, policy, and change management are not yet established but flagged as critical for success. SHI recommended a use case discovery workshop to prioritize and map actionable pilots.

Technical Notes

OpenAI’s enterprise API does not access custom GPTs; Teams chatbot would need a different approach. Copilot is available but not preferred; AmeriVet would prefer leveraging OpenAI or a third-party platform. Data sources: SharePoint (primary), Workday (HR), Snowflake (business analytics). SHI lab can enable POC/pilots in a secure environment without exposing PII. Governance, policy (acceptable use), and change management will become increasingly important as adoption scales.

OpenAI’s enterprise API does not access custom GPTs; Teams chatbot would need a different approach. Copilot is available but not preferred; AmeriVet would prefer leveraging OpenAI or a third-party platform. Data sources: SharePoint (primary), Workday (HR), Snowflake (business analytics). SHI lab can enable POC/pilots in a secure environment without exposing PII. Governance, policy (acceptable use), and change management will become increasingly important as adoption scales. List all speakers/Participants of Transcript:

Jax Miley (SHI) Tyler Webb (SHI, Director of AI Pre-Sales) Stephen Drake (SHI) Mark Berry (AmeriVet, Lead SaaS Admin) Dieter Karkut (AmeriVet, Director of IT) Dieter’s AI committee (referenced, not present) Others referenced: Data team, HR, C-suite (not present)

Jax Miley (SHI) Tyler Webb (SHI, Director of AI Pre-Sales) Stephen Drake (SHI) Mark Berry (AmeriVet, Lead SaaS Admin) Dieter Karkut (AmeriVet, Director of IT) Dieter’s AI committee (referenced, not present) Others referenced: Data team, HR, C-suite (not present)

Potential Next steps

Schedule Use Case Discovery Workshop

Schedule Use Case Discovery Workshop

SHI (Tyler Webb, Jax Miley, Stephen Drake) to coordinate with Dieter and Mark to schedule a workshop with AmeriVet’s AI committee and relevant stakeholders. Action: Tyler Webb/Jax Miley → Dieter Karkut/Mark Berry

SHI (Tyler Webb, Jax Miley, Stephen Drake) to coordinate with Dieter and Mark to schedule a workshop with AmeriVet’s AI committee and relevant stakeholders. Action: Tyler Webb/Jax Miley → Dieter Karkut/Mark Berry

Engage AmeriVet Data Team

Engage AmeriVet Data Team

Include data team in future calls to discuss data architecture (Snowflake, SharePoint, Workday) and integration needs. Action: Dieter Karkut/Mark Berry

Include data team in future calls to discuss data architecture (Snowflake, SharePoint, Workday) and integration needs. Action: Dieter Karkut/Mark Berry

Define Success Metrics

Define Success Metrics

AmeriVet to baseline HR/IT ticket volumes and current self-service usage to measure future AI impact. Action: Dieter Karkut/HR/IT

AmeriVet to baseline HR/IT ticket volumes and current self-service usage to measure future AI impact. Action: Dieter Karkut/HR/IT

Explore Technical Solutions

Explore Technical Solutions

SHI to present potential technical approaches for scalable, secure chatbot integration (e.g., SharePoint+AI, alternative platforms). Action: SHI (Tyler Webb/Stephen Drake)

SHI to present potential technical approaches for scalable, secure chatbot integration (e.g., SharePoint+AI, alternative platforms). Action: SHI (Tyler Webb/Stephen Drake)

Initiate Governance/Policy Planning

Initiate Governance/Policy Planning

AmeriVet to begin drafting acceptable use policy, compliance, and change management framework for AI tools. Action: Dieter Karkut/AI Committee

AmeriVet to begin drafting acceptable use policy, compliance, and change management framework for AI tools. Action: Dieter Karkut/AI Committee

Prepare for Lab or Pilot (Phase 2)

Prepare for Lab or Pilot (Phase 2)

Pending workshop outcomes, SHI can propose lab/POC engagement to accelerate pilot development. Action: SHI (Tyler Webb) → AmeriVet

Pending workshop outcomes, SHI can propose lab/POC engagement to accelerate pilot development. Action: SHI (Tyler Webb) → AmeriVet
