Trip Report | Imprivata | AmeriVet

Customer: AmeriVet
AE: Jax M
Topic: Imprivata
Meeting Date 12/08/2025

*Internal notes – Please read and edit before sending externally*

Summary

AmeriVet and SHI met with Imprivata to review pricing and deployment strategy for Imprivatas Access Management (AM) and Single Sign-On (SSO) solution aimed at reducing authentication friction for AmeriVet’s cloud PIMS application. The discussion covered:

Commercial alignment: AmeriVet requested significant price reductions, removal or reduction of the SSPW (Self-Service Password Reset) license if Azure reset is used, free training for two admins, and lower-cost options for badge readers and

security keys.

Technical prerequisites: Transition from POC (public-facing appliances) to production requires non-public deployment behind Azure VWAN/VPN to meet security and legal requirements.

Infrastructure

readiness: Clinics need static IPs and ISP standardization; SHI proposed an Azure Landing Zone engagement to establish secure, scalable architecture. Operational considerations: Staged purchasing model suggested to achieve tier discounts while paying as hospitals roll out. Next steps: Revise quote, schedule technical deep dive, send Imprivata SOW and support documentation, and coordinate ISP/static IP remediation.

Commercial alignment: AmeriVet requested significant price reductions, removal or reduction of the SSPW (Self-Service Password Reset) license if Azure reset is used, free training for two admins, and lower-cost options for badge readers and

security keys.

Technical prerequisites: Transition from POC (public-facing appliances) to production requires non-public deployment behind Azure VWAN/VPN to meet security and legal requirements.

Infrastructure

readiness: Clinics need static IPs and ISP standardization; SHI proposed an Azure Landing Zone engagement to establish secure, scalable architecture. Operational considerations: Staged purchasing model suggested to achieve tier discounts while paying as hospitals roll out. Next steps: Revise quote, schedule technical deep dive, send Imprivata SOW and support documentation, and coordinate ISP/static IP remediation.

Agenda

Introductions across AmeriVet, SHI, and Imprivata. Review of Imprivata pricing: licenses, services, training, hardware. Deployment approach: production architecture vs. POC. Azure Landing Zone overview and prerequisites. ISP/static IP requirements and SHI’s support role. Scheduling follow-ups and document handoffs.

Introductions across AmeriVet, SHI, and Imprivata. Review of Imprivata pricing: licenses, services, training, hardware. Deployment approach: production architecture vs. POC. Azure Landing Zone overview and prerequisites. ISP/static IP requirements and SHI’s support role. Scheduling follow-ups and document handoffs.

Opportunities Identified & BANTC

Opportunity 1: Imprivata AM/SSO Rollout

B (Budget): AmeriVet wants pricing reduced, SSPW removed/reduced, free training, and lower-cost hardware. A (Authority): Kat Mullen (VP) drives commercial decisions; Jason and Dieter handle technical; Natalie (Imprivata) and Jax (SHI) manage vendor side. N (Need): Passwordless SSO for PIMS, endpoint login, optional lock-screen password reset. T (Timeline): Follow-up next week; full rollout after Azure landing zone readiness. C (Competition): Alternatives like YubiKey and internal Azure reset workflows.

B (Budget): AmeriVet wants pricing reduced, SSPW removed/reduced, free training, and lower-cost hardware. A (Authority): Kat Mullen (VP) drives commercial decisions; Jason and Dieter handle technical; Natalie (Imprivata) and Jax (SHI) manage vendor side. N (Need): Passwordless SSO for PIMS, endpoint login, optional lock-screen password reset. T (Timeline): Follow-up next week; full rollout after Azure landing zone readiness. C (Competition): Alternatives like YubiKey and internal Azure reset workflows.
Opportunity 2: Azure Landing Zone Engagement

B: New engagement; cost
clarity needed.
A: AmeriVet technical team +
SHI architects.
N: Secure, scalable Azure

environment for Imprivata and other vendors.

T: Must precede full
rollout.
C: Internal implementation
or other partners.

B: New engagement; cost
clarity needed.
A: AmeriVet technical team +
SHI architects.
N: Secure, scalable Azure

environment for Imprivata and other vendors.

T: Must precede full
rollout.
C: Internal implementation
or other partners.
Opportunity 3: ISP & Static IP Standardization

B: Vendor selection
underway; SHI offers advisory support.
A: Kat leads; Matthew Bracy
(SHI) supports.
N: Static IPs required for
VPN; many clinics on residential ISPs.
T: During tech refresh;
Ethan to implement.
C: Multiple MSP/carrier
options.

B: Vendor selection
underway; SHI offers advisory support.
A: Kat leads; Matthew Bracy
(SHI) supports.
N: Static IPs required for
VPN; many clinics on residential ISPs.
T: During tech refresh;
Ethan to implement.
C: Multiple MSP/carrier
options.
Opportunity 4: Hardware Optimization

B: Reduce cost for readers
and security keys.
A: Kat directs; Jax/Natalie
to adjust quote.
N: Compatibility with
existing badges; minimize lanyards.
T: Align with rollout.
C: Non-Imprivata sourcing
options.

B: Reduce cost for readers
and security keys.
A: Kat directs; Jax/Natalie
to adjust quote.
N: Compatibility with
existing badges; minimize lanyards.
T: Align with rollout.
C: Non-Imprivata sourcing
options.

Initiatives

Security: Identity & access management, VPN/VWAN architecture, endpoint authentication, compliance. Storage: Not applicable.

Security: Identity & access management, VPN/VWAN architecture, endpoint authentication, compliance. Storage: Not applicable.

Tech Profile Updates

Azure-only environment (Entra ID), no hybrid. Production requires non-public deployment behind VPN/VWAN. Static IPs mandatory; ISP variability noted. Authentication friction with AD-connected PIMS; SSPW optional if Azure reset retained. Hardware strategy: fixed-frequency NFC readers preferred; stickers for legacy badges.

Azure-only environment (Entra ID), no hybrid. Production requires non-public deployment behind VPN/VWAN. Static IPs mandatory; ISP variability noted. Authentication friction with AD-connected PIMS; SSPW optional if Azure reset retained. Hardware strategy: fixed-frequency NFC readers preferred; stickers for legacy badges.

Meeting Notes

Imprivata explained license structure and ongoing vs. one-time costs. AmeriVet challenged SSPW cost and requested free training. Hardware discussion: frequency standards, badge stickers. Support model: 24/7 Imprivata support for software only. Architecture: POC was public; production must be non-public with VPN/VWAN. SHI proposed Azure Landing Zone engagement. Static IP remediation discussed; SHI can assist. Scheduling: Kat open next week for pricing review; separate technical session needed.

Imprivata explained license structure and ongoing vs. one-time costs. AmeriVet challenged SSPW cost and requested free training. Hardware discussion: frequency standards, badge stickers. Support model: 24/7 Imprivata support for software only. Architecture: POC was public; production must be non-public with VPN/VWAN. SHI proposed Azure Landing Zone engagement. Static IP remediation discussed; SHI can assist. Scheduling: Kat open next week for pricing review; separate technical session needed.

Environment

Cloud: Azure Entra ID; appliances inside trusted network. Sites: Mixed ISP types; static IPs required. Governance: Strong

security and compliance posture.

Cloud: Azure Entra ID; appliances inside trusted network. Sites: Mixed ISP types; static IPs required. Governance: Strong

security and compliance posture.

Detailed Discussion

Licensing: SSO/AM bundle for endpoint login and app SSO; SSPW for lock-screen reset. Hardware: Fixed-frequency readers cheaper than universal; stickers for legacy badges. Support: Imprivata covers platform only; Azure networking is customer/SHI responsibility. Architecture: VPN/VWAN mandatory for production; offline modes supported. Rollout: Tier discount strategy with staged payments. ISP: Static IPs needed; SHI offers advisory role.

Licensing: SSO/AM bundle for endpoint login and app SSO; SSPW for lock-screen reset. Hardware: Fixed-frequency readers cheaper than universal; stickers for legacy badges. Support: Imprivata covers platform only; Azure networking is customer/SHI responsibility. Architecture: VPN/VWAN mandatory for production; offline modes supported. Rollout: Tier discount strategy with staged payments. ISP: Static IPs needed; SHI offers advisory role.

Technical Notes

Authentication modalities: badge, PIN, password, facial. SSPW: Optional if Azure reset used. Imprivata appliances: deploy inside Azure LAN; VPN required. Offline behavior: badge/PIN/password/fingerprint work; push/FaceID and new enrollment do not. Readers: Fixed-frequency preferred; stickers for legacy badges. Support SLA: P1 response within 30–60 minutes. Azure Landing Zone: Discovery → design → deployment; includes automation, policy enforcement, identity management. Static IPs: Required for VPN; tech refresh to implement.

Authentication modalities: badge, PIN, password, facial. SSPW: Optional if Azure reset used. Imprivata appliances: deploy inside Azure LAN; VPN required. Offline behavior: badge/PIN/password/fingerprint work; push/FaceID and new enrollment do not. Readers: Fixed-frequency preferred; stickers for legacy badges. Support SLA: P1 response within 30–60 minutes. Azure Landing Zone: Discovery → design → deployment; includes automation, policy enforcement, identity management. Static IPs: Required for VPN; tech refresh to implement.

ROLES

Kat Mullen — VP,

Infrastructure Ops & Security, AmeriVet

Jason Marves — Director of Solutions Architecture, AmeriVet Dieter Karkut — Technical stakeholder, AmeriVet Natalie Flynn Account Manager, Imprivata Taylor LeBlanc — Sales Engineer, Imprivata Jax Miley — Account Executive, SHI Stephen Drake  Sales Leader, SHI Matthew Bracy Solution Specialist, Service Providers Practice, SHI Manuel Zelaya — Commercial Solutions Engineer, SHI

Kat Mullen — VP,

Infrastructure Ops & Security, AmeriVet

Jason Marves — Director of Solutions Architecture, AmeriVet Dieter Karkut — Technical stakeholder, AmeriVet Natalie Flynn Account Manager, Imprivata Taylor LeBlanc — Sales Engineer, Imprivata Jax Miley — Account Executive, SHI Stephen Drake  Sales Leader, SHI Matthew Bracy Solution Specialist, Service Providers Practice, SHI Manuel Zelaya — Commercial Solutions Engineer, SHI

Potential Next Steps

Revise Imprivata Quote

Kat → Natalie & Jax: Adjust pricing, remove/reduce SSPW, free training, cheaper hardware.

Send Documentation

Natalie → AmeriVet: SOW and support handbook.

Schedule Technical Session

Include Jason, Dieter, Mark; SHI + Imprivata to cover Azure landing zone, VPN, static IP plan.

Commercial Follow-Up

Natalie ↔ Kat (+ Jason): 20-min next week for pricing review.

Azure Landing Zone Engagement

SHI ↔ AmeriVet: Initiate discovery/design/deployment.

ISP/Static IP Plan

AmeriVet (Ethan)  SHI (Matthew): Inventory and implement static IPs.

Optional POC Validation in Production Topology

Jason/Dieter ↔ Imprivata: Test behind VPN if approved.

Revise Imprivata Quote

Kat → Natalie & Jax: Adjust pricing, remove/reduce SSPW, free training, cheaper hardware.

Kat → Natalie & Jax: Adjust pricing, remove/reduce SSPW, free training, cheaper hardware. Send Documentation

Natalie → AmeriVet: SOW and support handbook.

Natalie → AmeriVet: SOW and support handbook. Schedule Technical Session

Include Jason, Dieter, Mark; SHI + Imprivata to cover Azure landing zone, VPN, static IP plan.

Include Jason, Dieter, Mark; SHI + Imprivata to cover Azure landing zone, VPN, static IP plan. Commercial Follow-Up

Natalie ↔ Kat (+ Jason): 20-min next week for pricing review.

Natalie ↔ Kat (+ Jason): 20-min next week for pricing review. Azure Landing Zone Engagement

SHI ↔ AmeriVet: Initiate discovery/design/deployment.

SHI ↔ AmeriVet: Initiate discovery/design/deployment. ISP/Static IP Plan

AmeriVet (Ethan)  SHI (Matthew): Inventory and implement static IPs.

AmeriVet (Ethan)  SHI (Matthew): Inventory and implement static IPs. Optional POC Validation in Production Topology

Jason/Dieter ↔ Imprivata: Test behind VPN if approved.

Jason/Dieter ↔ Imprivata: Test behind VPN if approved.
