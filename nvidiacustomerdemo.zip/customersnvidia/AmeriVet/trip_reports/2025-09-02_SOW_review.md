Trip Report | SOW review | AmeriVet

Customer: AmeriVet
AE: Jax
Topic: SOW review
Meeting Date 09/02/2025

*Internal notes – Please read and edit before sending externally*

Summary

• The meeting focused on reviewing a Statement of Work
(SOW) for deploying and managing technology at two proof-of-concept locations, with the goal of establishing a scalable process for future rollouts across the US. The discussion covered the scope of services (site surveys, cabling, network equipment, workstation and printer setup, and security camera installation), deliverables (including a detailed runbook), pricing structure (time and materials, do-not-exceed cap), and project management approach. Key business aspects included flexibility in scope, clear delineation of responsibilities, cost transparency, and the importance of documentation for

Agenda

• Review of SOW and project scope
• Discussion of deliverables and documentation
(runbook)
• Clarification of pricing, billing, and travel
policies
• Roles and responsibilities (vendor and customer)
• Out-of-scope items and change request process
• Project timeline and next steps

Opps Identified & BANTC

• Opportunity 1: Proof-of-concept deployment for
remote hands, physical installation, and network setup at two sites, with potential for broader US rollout
• B (Budget): Do-not-exceed cap of $37,730, billed on

Initiatives

• Security: Security camera installation and cabling
included in scope
• Storage: Not explicitly discussed

Tech Profile Updates

• Standard Cat 6 cabling (not Cat 6A)
• Existing racks and patch panels at all locations
• No high voltage, core drilling, or fiber runs in
scope
• Network equipment provided by customer; vendor
handles physical install and labeling
• Workstations and printers mapped to network, with
drivers loaded by customer

Meeting Notes

Environment

• Two proof-of-concept sites in San Antonio, with
potential for national rollout
• Existing infrastructure includes racks, patch
panels, and standard office layouts
• Ceiling heights assumed to be under 14 feet; no
scissor lifts anticipated

Detailed Discussion

• Vendor (Ben, Dave) outlined the SOW, emphasizing
flexibility and willingness to clarify or adjust language as needed
• Site surveys will document cabling, rack, and device
inventory, including photos and floor plan annotations
• Runbook deliverable will capture step-by-step
procedures, photos, and documentation for repeatability
• Workstation and printer setup includes before/after
photos, cable management, and mapping printers to workstations
• Old equipment will be prepped for return shipping,
but recycling is customer’s responsibility
• Structured cabling includes two data drops per
desktop, one per camera, with neat dressing and labeling
• Network equipment install includes mounting,

Technical Notes

• Site survey to capture device counts, port status,
rack/cabinet details, wall/ceiling composition, and pathways
• Photos required for all network racks, cable
management, asset tags, and before/after device states
• Access points: hardware inspection, mounting, cable
management, and connectivity verification
• Workstations: connect to patch panels, power,
peripherals; printers mapped to workstations; drivers loaded by customer
• Structured cabling: Cat 6, RJ45 faceplates,
punch-down service mounts, Velcro ties, J hooks
• Network equipment: physical install, labeling, port
mapping, wire management (provided by customer)
• Security cameras: mounting, cabling, connectivity,
and cable management
• No network layer troubleshooting or ISP/firewall
config; only physical install and connectivity
• All cable drops tested and guaranteed; vendor will
fix any non-working drops at no charge
• Project managed via Teams, with real-time updates
and status calls
• Overtime billed at 1.25x; off-hours at 1.5x standard
rate
• Invoicing is monthly, net 30; final acceptance via
DocuSign List all speakers/Participants of Transcript:
• Ben Bonner
• Dave Engelman
• Richard Cox
• Dieter Karkut

Potential Next steps

• Ben to resend sample runbook to Richard, who
requested it be surfaced in his inbox
• Customer (Richard, Dieter) to review SOW with Chris,
John, and Stacia for feedback and approval
