Trip Report | Imprivata | AmeriVet

Customer: AmeriVet
AE: Jax M
Topic: Imprivata
Meeting Date 10/07/2025

*Internal notes – Please read and edit before sending externally*

Summary

• The meeting focused on evaluating and streamlining
print management and authentication solutions for veterinary practices, with a particular emphasis on integrating Imprivata for secure access and efficient user workflows. Participants discussed current pain points with manual print driver deployment, the need for scalable solutions, and the desire to minimize additional tools and costs. The group explored leveraging existing tools (like Datto and Intune), the feasibility of using NFC-enabled devices and badges, and the importance of future-proofing for larger hospital environments. There was a strong focus on practical deployment, user experience, and balancing security with operational efficiency. The team also discussed proof-of-concept (POC) testing, hardware compatibility, and badge/fob management, with an eye toward scalable rollout and cost management.

Agenda

• Review current print management challenges and
solutions
• Discuss Imprivata integration and user
authentication workflows
• Explore hardware options (readers, tablets,
badges/fobs)
• Plan POC deployment at a pilot site
• Address badge/fob logistics and customization
• Discuss network architecture and security for
production rollout
• Outline next steps and responsibilities

Opps Identified & BANTC

Opportunity 1: Streamlined Print
Management & Authentication for Veterinary Practices
• B (Budget): Concerns about high costs of third-party
print management tools; preference for leveraging existing investments (Datto, Intune, Imprivata) and minimizing new spend.
• A (Authority): Decision-makers include Kat, Dieter,
Richard, and Taylor, with input from IT and implementation teams.
• N (Need): Need for scalable, automated print driver
deployment, secure authentication, and efficient user workflows across multiple locations and device types.
• T (Timeline): POC at Animal Kindness to begin within
a week; broader rollout contingent on successful testing and implementation planning.
• C (Competition): Competing solutions include manual
installs, Bayesian, and other third-party print management tools; preference is to avoid additional products if possible.
Opportunity 2: Badge/Fob/NFC Device
Standardization and Management
• B: Cost sensitivity around badge/fob procurement and
replacement; interest in durable, cost-effective options.
• A: Kat, Dieter, Richard, Taylor, and
marketing/implementation teams involved in decision-making.
• N: Need for reliable, user-friendly, and
customizable authentication tokens (cards, fobs, wristbands) that are easy to manage and reissue.
• T: Selection and procurement to align with POC and
phased rollout schedule.
• C: Options include generic cards, fobs, wristbands,
and potential for custom-branded items; must balance durability, cost, and user preference.

Initiatives

• Security: Imprivata authentication, badge/fob
management, multi-factor authentication, and PIN enforcement.
• Storage: Not a primary focus in this meeting.

Tech Profile Updates

• Moving toward Imprivata for authentication and print
management integration.
• Evaluating Android tablets (with NFC) and existing
Windows devices for compatibility.
• Using Datto and Intune for device and driver
deployment.
• Considering generic and custom NFC badges/fobs for
user authentication.

Meeting Notes

Environment

• Veterinary practice environments with varying sizes,
from small clinics to large hospitals (potentially 300+ users).
• Mix of Windows workstations, Android tablets, Zebra
printers, and existing HID/NFC readers.
• Use of Datto RMM, Intune MDM, and Imprivata for
device and user management.

Detailed Discussion

• Print management is currently labor-intensive;
manual driver installs are not scalable.
• Existing solutions (Bayesian, Direct Print IO) are
either too costly or lack required features.
• Imprivata can trigger scripts for driver deployment
and user profile setup, reducing manual effort.
• Shared/generic accounts vs. individual profiles:
multi-user desktop mode tested for scalability; up to 25 profiles per workstation before oldest is purged.
• Android tablets for mobile workflows: NFC required;
some models (e.g., Lenovo Tab) lack NFC, so Samsung Galaxy Tabs preferred.
• Badge/fob options: durability, cost, and user
preference discussed; wristbands, cards, and fobs all considered.
• Customization: Practices may want custom-branded
badges/fobs; process for ordering and reissuing discussed.
• Security: Multi-factor authentication (NFC + PIN)
required; encrypted cards available but costly and not deemed necessary for this use case.
• Network: Site-to-site VPN or reverse proxy for
secure appliance access; Azure-hosted appliances preferred for scalability and security.

Technical Notes

• Imprivata can trigger scripts (CMD, VBS, etc.) at
login/logout for driver deployment.
• Multi-user desktop mode allows up to 25 concurrent
profiles; oldest purged as new users log in.
• Android device compatibility hinges on NFC support;
Samsung Galaxy Tabs recommended.
• Badge/fob management: Only one active badge per user
recommended; system purges/revokes old badges automatically.
• PIN required for authentication; mitigates risk of
badge cloning.
• Datto and Intune can be used for driver and app
deployment to Windows and Android devices.
• Zebra printers supported via Zebra app on Android;
configuration via MDM possible.
• HID 5022/5023 readers confirmed compatible for POC;
additional readers available if needed.
• Custom badge/fob/wristband options available; cost
and durability considerations discussed.
• Network appliances can be accessed securely via
Azure; reverse proxy or VPN options available.

ROLES

• Taylor LeBlanc – Solutions Engineer, Imprivata
• Richard Cox – IT, AmeriVet
• Dieter Karkut – IT, AmeriVet
• Kat Mullen – IT/Operations, AmeriVet
• Cameron DeLaFuente – IT, AmeriVet
• Jax Miley – SHI (Vendor/Reseller)
• Mark Berry – AmeriVet
• Unknown Speaker – (role not specified, likely
AmeriVet or vendor support)

Potential Next steps

• Richard to coordinate with Kurt at Animal Kindness
for POC deployment and communicate with Jen for logistics.
• Dieter to provide workstation details for POC and
assist with software installation and configuration.
• Taylor to provide list of compatible NFC cards/fobs
and follow up on recommended Android tablet models.
• Jax to send quotes for smart keys/fobs and
coordinate with Taylor on hardware needs for POC.
• Cameron to test HID readers on test units and report
compatibility.
• Kat to oversee badge/fob selection process and
ensure alignment with practice needs and cost considerations.
• Taylor, Richard, and Dieter to schedule a deeper
architecture discussion to finalize network and security design for production rollout.
• Jax to coordinate with marketing for badge
reels/lanyards and ensure they are bundled with badge/fob shipments as needed.
• All: Monitor POC results at Animal Kindness and
adjust rollout plan based on feedback and technical findings.
