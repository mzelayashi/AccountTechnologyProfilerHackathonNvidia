Trip Report | Monthly Review | Jacob Holmes

Customer: Jacob Holmes
AE: Felix Menchaca
Topic: Monthly Review
Meeting Date 10/09/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

Review

Felix Menchaca

Review Opps Identified below with Riley

11/09

Item Owner Next Steps/Detail Due Date Review Felix Menchaca Review Opps Identified below with Riley 11/09

Summary

New core Sales Engineer (SC) for the district was presented, who is replacing Joe Lyman. The discussion focused on understanding the current projects, challenges, and opportunities with Jacob Holmes and Felix Menchaca. Key topics included upcoming renewals, security solutions, cloud management, and ongoing ERP projects.

Agenda

Introduction of Manuel Zelaya as the new core SC. Review of current projects and priorities. Discussion on upcoming Mimecast renewal. Exploration of security solutions with Verkada and Genetec. Consideration of Rapid7 for SIEM solutions. Discussion on AWS cloud management. Inquiry into data-driven decision-making initiatives.

Introduction of Manuel Zelaya as the new core SC. Review of current projects and priorities. Discussion on upcoming Mimecast renewal. Exploration of security solutions with Verkada and Genetec. Consideration of Rapid7 for SIEM solutions. Discussion on AWS cloud management. Inquiry into data-driven decision-making initiatives.

Opps Identified & BANTC

Mimecast Renewal

Mimecast Renewal

B: Jacob
Holmes
A: Riley,
possibly Director Seth
N: Evaluate
renewal with current setup or explore alternatives.
T: March
renewal, December deadline for changes.
C: Auto-renewal
unless alternatives are considered.

B: Jacob
Holmes
A: Riley,
possibly Director Seth
N: Evaluate
renewal with current setup or explore alternatives.
T: March
renewal, December deadline for changes.
C: Auto-renewal
unless alternatives are considered.

Security Solutions with Verkada and

Genetec

Security Solutions with Verkada and

Genetec

B: Jacob
Holmes, Director of Security Jeremy
A: Security
Team
N: Evaluate
current Genetec system vs. potential alternatives.
T: No
immediate timeline; ongoing discussion.
C: Interest
in exploring cost and retention options.

B: Jacob
Holmes, Director of Security Jeremy
A: Security
Team
N: Evaluate
current Genetec system vs. potential alternatives.
T: No
immediate timeline; ongoing discussion.
C: Interest
in exploring cost and retention options.

Rapid7 SIEM Solution

Rapid7 SIEM Solution

B: Jacob
Holmes
A: Riley
N: Assess
interest in SIEM solutions for security.
T: Q4
of this year or Q1 of next year.
C: To
be discussed further with Riley.

B: Jacob
Holmes
A: Riley
N: Assess
interest in SIEM solutions for security.
T: Q4
of this year or Q1 of next year.
C: To
be discussed further with Riley.

AWS Cloud Management

AWS Cloud Management

B: Jacob
Holmes
A: Riley
N: Potential
cost reduction and management improvement.
T: Indefinite
due to focus on Project Fusion.
C: Interest
exists but currently deprioritized.

B: Jacob
Holmes
A: Riley
N: Potential
cost reduction and management improvement.
T: Indefinite
due to focus on Project Fusion.
C: Interest
exists but currently deprioritized.

Initiatives

Security

Exploring physical security solutions and SIEM options. Storage: On-premise storage solutions with Genetec.

Security

Exploring physical security solutions and SIEM options. Storage: On-premise storage solutions with Genetec.

Tech Profile Updates

Genetec system in use for surveillance, door, and window sensors. No cloud replication; entirely on-premise. Ongoing ERP transition to NetSuite.

Genetec system in use for surveillance, door, and window sensors. No cloud replication; entirely on-premise. Ongoing ERP transition to NetSuite.

Meeting Notes

Environment

Main HQ in Oklahoma City with several satellite sites. Extensive use of Genetec for security across multiple locations.

Main HQ in Oklahoma City with several satellite sites. Extensive use of Genetec for security across multiple locations.

Detailed Discussion Notes

Manuel introduced as the new core SC to replace Joe Lyman. Mimecast renewal discussed with an emphasis on the 90-day auto-renewal. Verkada's physical security solutions were discussed but not a current priority due to Genetec's usage. Rapid7 and SIEM solutions were identified as potential future interests. AWS cloud management was noted but deprioritized due to Project Fusion. Manuel inquired about data-driven decision-making initiatives, which are not currently in place but have been discussed internally.

Manuel introduced as the new core SC to replace Joe Lyman. Mimecast renewal discussed with an emphasis on the 90-day auto-renewal. Verkada's physical security solutions were discussed but not a current priority due to Genetec's usage. Rapid7 and SIEM solutions were identified as potential future interests. AWS cloud management was noted but deprioritized due to Project Fusion. Manuel inquired about data-driven decision-making initiatives, which are not currently in place but have been discussed internally.
