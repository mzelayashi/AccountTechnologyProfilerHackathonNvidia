Trip Report | Imprivata | Imprivata

Customer: Imprivata
AE: Jax M
Topic: Imprivata
Meeting Date 12/01/2025

*Internal notes – Please read and edit before sending externally*

Summary

Summary

The meeting focused on aligning SHI and Imprivata teams regarding Amerivet’s technology challenges and next steps for deploying Imprivata’s on-prem badge authentication solution in a fully Azure-based environment. Key business aspects included:

Customer

Environment

Amerivet operates a 100% Azure SaaS environment with no LAN or VPN, creating architectural incompatibilities with Imprivata’s on-prem solution. Current State: POC is functional but not production-ready due to public-facing appliances and lack of secure networking. Challenges:

Lack of static IPs and enterprise-grade networking across 224+ vet clinics. Disaggregated ISP contracts and unmanaged devices.

Environment

Amerivet operates a 100% Azure SaaS environment with no LAN or VPN, creating architectural incompatibilities with Imprivata’s on-prem solution. Current State: POC is functional but not production-ready due to public-facing appliances and lack of secure networking. Challenges:

Lack of static IPs and enterprise-grade networking across 224+ vet clinics. Disaggregated ISP contracts and unmanaged devices.

Agenda

Catch Stephen up on Amerivet project status. Discuss delayed invoicing and tier discounting. Review Dieter’s email on Azure VPN feasibility. Address technical architecture gaps and managed services options. Plan for next meeting with Kat and Jason (Amerivet leadership). Align on pricing strategy and rollout timelines. Explore opportunities for Azure re-architecture and ISP aggregation.

Catch Stephen up on Amerivet project status. Discuss delayed invoicing and tier discounting. Review Dieter’s email on Azure VPN feasibility. Address technical architecture gaps and managed services options. Plan for next meeting with Kat and Jason (Amerivet leadership). Align on pricing strategy and rollout timelines. Explore opportunities for Azure re-architecture and ISP aggregation.

Opportunities Identified & BANTC

Opportunity 1: Imprivata Badge Authentication Rollout

B (Budget): Amerivet has requested credit limit increase; pricing manager engagement underway. A (Authority): Kat (new leadership) and Jason (Director of Solutions Architecture) are key decision-makers. N (Need): Eliminate password friction for frontline workers; secure authentication integrated with Provet EMR. T (Timeline): Strategic phased rollout; initial meeting with Kat next Monday to finalize plan. C (Competition): Internal resistance due to Azure-only environment; no direct competitor mentioned.

B (Budget): Amerivet has requested credit limit increase; pricing manager engagement underway. A (Authority): Kat (new leadership) and Jason (Director of Solutions Architecture) are key decision-makers. N (Need): Eliminate password friction for frontline workers; secure authentication integrated with Provet EMR. T (Timeline): Strategic phased rollout; initial meeting with Kat next Monday to finalize plan. C (Competition): Internal resistance due to Azure-only environment; no direct competitor mentioned.
Opportunity 2: Azure Landing Zone & Network
Modernization

B: Potential upsell via
SHI’s Azure services and CSP migration.
A: Kat and Amerivet IT
leadership.
N: Current architecture
lacks VPN, static IPs, and enterprise security; high risk of compromise.
T: Immediate need before
full Imprivata deployment; leverage next call to position solution.
C: Internal Amerivet team or
third-party MSP could handle, but SHI aims to own this.

B: Potential upsell via
SHI’s Azure services and CSP migration.
A: Kat and Amerivet IT
leadership.
N: Current architecture
lacks VPN, static IPs, and enterprise security; high risk of compromise.
T: Immediate need before
full Imprivata deployment; leverage next call to position solution.
C: Internal Amerivet team or
third-party MSP could handle, but SHI aims to own this.
Opportunity 3: ISP Aggregation & TEM Services

B: Savings through
consolidated contracts; rebate opportunity for SHI.
A: Amerivet procurement and
IT leadership.
N: Disaggregated ISP
contracts hinder static IP implementation.
T: Medium-term initiative
tied to rollout scalability.
C: Other telecom
aggregators; SHI wants to position as strategic partner.

B: Savings through
consolidated contracts; rebate opportunity for SHI.
A: Amerivet procurement and
IT leadership.
N: Disaggregated ISP
contracts hinder static IP implementation.
T: Medium-term initiative
tied to rollout scalability.
C: Other telecom
aggregators; SHI wants to position as strategic partner.

Initiatives

Security: VPN implementation, Azure landing zone re-architecture, ISP aggregation. Identity & Access: Imprivata badge authentication deployment. Networking: Static IP enablement across 224+ sites.

Security: VPN implementation, Azure landing zone re-architecture, ISP aggregation. Identity & Access: Imprivata badge authentication deployment. Networking: Static IP enablement across 224+ sites.

Tech Profile Updates

Amerivet:

Fully Azure SaaS environment, no LAN/VPN. Intune-managed devices; tested reverse proxy VPN via Intune (works but requires static IPs). Mixed networking hardware (Netgear, Ubiquiti, Fortinet, Cisco). 224 clinics, scaling to 400 in two years. Provet EMR adoption replacing unsecured legacy system.

Amerivet:

Fully Azure SaaS environment, no LAN/VPN. Intune-managed devices; tested reverse proxy VPN via Intune (works but requires static IPs). Mixed networking hardware (Netgear, Ubiquiti, Fortinet, Cisco). 224 clinics, scaling to 400 in two years. Provet EMR adoption replacing unsecured legacy system.

Fully Azure SaaS environment, no LAN/VPN. Intune-managed devices; tested reverse proxy VPN via Intune (works but requires static IPs). Mixed networking hardware (Netgear, Ubiquiti, Fortinet, Cisco). 224 clinics, scaling to 400 in two years. Provet EMR adoption replacing unsecured legacy system.

Meeting Notes

Environment

No enterprise-grade networking; Comcast home-grade ISP prevalent. Public-facing appliances during POC (unsupported for production). Lack of static IPs blocks Intune VPN solution.

No enterprise-grade networking; Comcast home-grade ISP prevalent. Public-facing appliances during POC (unsupported for production). Lack of static IPs blocks Intune VPN solution.

Detailed Discussion

Pricing: Explore delayed invoicing and co-terming licenses for phased rollout; need timeline from Amerivet. Technical Architecture: Current state incompatible with Imprivata; requires VPN or Azure redesign. POC Friction: Frontline workers lacked passwords; workaround implemented via token-based portal. Leadership Dynamics: Kat driving urgency; wants clarity on “uplift” concerns and project closure. Strategic Angle: Position SHI for Azure CSP migration and ISP consolidation.

Pricing: Explore delayed invoicing and co-terming licenses for phased rollout; need timeline from Amerivet. Technical Architecture: Current state incompatible with Imprivata; requires VPN or Azure redesign. POC Friction: Frontline workers lacked passwords; workaround implemented via token-based portal. Leadership Dynamics: Kat driving urgency; wants clarity on “uplift” concerns and project closure. Strategic Angle: Position SHI for Azure CSP migration and ISP consolidation.

Technical Notes

Imprivata solution requires callback to AD; Amerivet lacks VPN or LAN. Tested Intune reverse proxy VPN; works but needs static IPs per site. Clinics lack enterprise routers; many run Comcast residential service.

Security risk

public-facing appliances during POC. Badge readers and cards required for rollout. Licensing model: 12-month term; need co-terming strategy for phased deployment. Provet EMR integration validated; friction due to password binding resolved via token portal.

Imprivata solution requires callback to AD; Amerivet lacks VPN or LAN. Tested Intune reverse proxy VPN; works but needs static IPs per site. Clinics lack enterprise routers; many run Comcast residential service.

Security risk

public-facing appliances during POC. Badge readers and cards required for rollout. Licensing model: 12-month term; need co-terming strategy for phased deployment. Provet EMR integration validated; friction due to password binding resolved via token portal.

ROLES

Natalie Flynn: SHI Account Manager (Boston-based). Stephen Drake: SHI Leadership / Direct Line Leader. Taylor LeBlanc: Imprivata Technical Resource / Sales Engineer. Jax Miley: SHI Sales Representative. Manuel Zelaya: SHI Commercial Solutions Engineer (Austin).

Natalie Flynn: SHI Account Manager (Boston-based). Stephen Drake: SHI Leadership / Direct Line Leader. Taylor LeBlanc: Imprivata Technical Resource / Sales Engineer. Jax Miley: SHI Sales Representative. Manuel Zelaya: SHI Commercial Solutions Engineer (Austin).

Potential Next Steps

Natalie → Pricing Manager: Validate co-terming and delayed invoicing model; share recommendation with SHI team before Kat call. Stephen & Jax → Matt Bracey: Send transcript notes; discuss ISP aggregation strategy. Stephen → SHI Azure Team: Prepare landing zone architecture slides for next Amerivet meeting. Jax → Kat: Clarify “uplift” concerns; confirm agenda for Monday’s call (Kat + Jason only). Natalie → Kat: Attempt one-on-one connection before group call to build rapport. Taylor → SHI Team: Share POC friction details and resolution for context in next meeting.

Natalie → Pricing Manager: Validate co-terming and delayed invoicing model; share recommendation with SHI team before Kat call. Stephen & Jax → Matt Bracey: Send transcript notes; discuss ISP aggregation strategy. Stephen → SHI Azure Team: Prepare landing zone architecture slides for next Amerivet meeting. Jax → Kat: Clarify “uplift” concerns; confirm agenda for Monday’s call (Kat + Jason only). Natalie → Kat: Attempt one-on-one connection before group call to build rapport. Taylor → SHI Team: Share POC friction details and resolution for context in next meeting.
