Trip Report | Veam Kasken | Bristow

Customer: Bristow
AE: Nicole A
Topic: Veam Kasken
Meeting Date 2026

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Dee Taylor

prepare a quote for 20 nodes with potential discounts.

02/15

2

Nathan

send any additional questions or clarifications to the Veeam/Kasten team.

02/15

Item Owner Next Steps/Detail Due Date 1 Dee Taylor prepare a quote for 20 nodes with potential discounts. 02/15 2 Nathan send any additional questions or clarifications to the Veeam/Kasten team. 02/15

Summary

The meeting focused on introducing and demonstrating the capabilities of Veeam's Kasten product for Kubernetes backup and data resiliency to the Bristow team. Bristow is currently exploring Kubernetes solutions for a government contract in the UK and is considering the adoption of Kasten to ensure operational coverage in AWS cloud environments. The conversation primarily revolved around understanding Bristow's current Kubernetes implementation, addressing backup and restore needs, and exploring Kasten's features such as disaster recovery, ransomware protection, and multi-cluster management. Licensing and potential scaling options were also discussed to align with Bristow's expected production environment.

Agenda

Introduction of Veeam/Kasten team and Bristow representatives. Overview of Kasten's functionalities and benefits for Kubernetes environments. Detailed demo of Kasten's features. Discussion on licensing, trial periods, and node coverage. Next steps and quotation process.

Introduction of Veeam/Kasten team and Bristow representatives. Overview of Kasten's functionalities and benefits for Kubernetes environments. Detailed demo of Kasten's features. Discussion on licensing, trial periods, and node coverage. Next steps and quotation process.

Opps Identified & BANTC

Opportunity: Adoption of Kasten for Kubernetes backup solutions.

Opportunity: Adoption of Kasten for Kubernetes backup solutions.

B: Bristow
needs a robust backup solution for their Kubernetes workloads in the AWS cloud as part of a government contract.
A: Decision-makers
include Nathan Trahan and potentially other stakeholders involved in the deployment and management of Kubernetes environments.
N: Approximately
12-18 nodes initially, with potential expansion as the environment goes live.
T: Immediate
exploration phase with a potential decision towards the middle of the year post-audits.
C: Critical
for ensuring data resiliency and compliance with government contracts.

B: Bristow
needs a robust backup solution for their Kubernetes workloads in the AWS cloud as part of a government contract.
A: Decision-makers
include Nathan Trahan and potentially other stakeholders involved in the deployment and management of Kubernetes environments.
N: Approximately
12-18 nodes initially, with potential expansion as the environment goes live.
T: Immediate
exploration phase with a potential decision towards the middle of the year post-audits.
C: Critical
for ensuring data resiliency and compliance with government contracts.

Initiatives

Security: Ransomware protection and data security features. Storage: Backup and disaster recovery solutions for Kubernetes environments.

Security: Ransomware protection and data security features. Storage: Backup and disaster recovery solutions for Kubernetes environments.

Tech Profile Updates

Current environment includes AWS EKS clusters with 12 nodes across four instances (2 production, 2 development). Use of Terraform for infrastructure management, indicating a preference for automated deployment processes.

Current environment includes AWS EKS clusters with 12 nodes across four instances (2 production, 2 development). Use of Terraform for infrastructure management, indicating a preference for automated deployment processes.

Meeting Notes

Environment

AWS cloud environment with Kubernetes workloads managed via OpenShift distribution. Current focus is on ensuring operational coverage and backup solutions before full production rollout.

AWS cloud environment with Kubernetes workloads managed via OpenShift distribution. Current focus is on ensuring operational coverage and backup solutions before full production rollout.

Detailed Discussion

Kasten Features: Data resiliency, backup and restore capabilities, disaster recovery, data freedom (cross-cloud migration), ransomware protection, and multi-cluster management. Backup Strategy: Importance of backing up data externally to prevent data loss in case of cluster failures. Restore Capabilities: Granular restore options, transform sets for cross-environment restores, and compliance with regulatory requirements. Licensing: Free trial for clusters up to five nodes, with evaluation licenses for larger setups. Licensing based on worker nodes, not application count or data size.

Kasten Features: Data resiliency, backup and restore capabilities, disaster recovery, data freedom (cross-cloud migration), ransomware protection, and multi-cluster management. Backup Strategy: Importance of backing up data externally to prevent data loss in case of cluster failures. Restore Capabilities: Granular restore options, transform sets for cross-environment restores, and compliance with regulatory requirements. Licensing: Free trial for clusters up to five nodes, with evaluation licenses for larger setups. Licensing based on worker nodes, not application count or data size.

Technical Notes

Kasten integrates with existing infrastructure management tools like Terraform. Supports multi-cloud environments with flexible backup storage options. Provides role-based access control and multi-tenancy features for secure and efficient management.

Kasten integrates with existing infrastructure management tools like Terraform. Supports multi-cloud environments with flexible backup storage options. Provides role-based access control and multi-tenancy features for secure and efficient management. List all speakers/Participants of Transcript:

Nicole Agoncillo Brendan Foye Brody Kovacs Nathan Trahan Dee Taylor Hoang Cao Satheesh Mohandass

Nicole Agoncillo Brendan Foye Brody Kovacs Nathan Trahan Dee Taylor Hoang Cao Satheesh Mohandass

Potential Next steps

Quotation Preparation:

Quotation Preparation:

Action: Dee Taylor to prepare a quote for 20 nodes with potential discounts. Participants: Dee Taylor, Nicole Agoncillo, Nathan Trahan. Timeline: Quote expected by end of day or next morning.

Action: Dee Taylor to prepare a quote for 20 nodes with potential discounts. Participants: Dee Taylor, Nicole Agoncillo, Nathan Trahan. Timeline: Quote expected by end of day or next morning.

Further Evaluation:

Further Evaluation:

Action: Bristow team to further evaluate Kasten in their environment. Participants: Nathan Trahan, Hoang Cao, and other relevant team members.

Action: Bristow team to further evaluate Kasten in their environment. Participants: Nathan Trahan, Hoang Cao, and other relevant team members.

Follow-up Questions:

Follow-up Questions:

Action: Nathan Trahan to send any additional questions or clarifications to the Veeam/Kasten team. Participants: Nathan Trahan, Satheesh Mohandass.

Action: Nathan Trahan to send any additional questions or clarifications to the Veeam/Kasten team. Participants: Nathan Trahan, Satheesh Mohandass.
