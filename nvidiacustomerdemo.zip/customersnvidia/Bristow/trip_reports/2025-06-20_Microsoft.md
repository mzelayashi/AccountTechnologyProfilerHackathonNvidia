Trip Report | Microsoft | Bristow

Customer: Bristow
AE: Nicole A
Topic: Microsoft
Meeting Date 06/20/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Nicole & MS team

send final side-by-side pricing for EA and CSP, including flexible billing options, annual/monthly commitments, and “no Teams” E3 SKUs as relevant.

07/05

2

Manuel Z

Assist in  consider SHI’s multi-OEM support package as alternative to Microsoft Unified Support

07/05

Item Owner Next Steps/Detail Due Date 1 Nicole & MS team send final side-by-side pricing for EA and CSP, including flexible billing options, annual/monthly commitments, and “no Teams” E3 SKUs as relevant. 07/05 2 Manuel Z Assist in  consider SHI’s multi-OEM support package as alternative to Microsoft Unified Support 07/05

Summary

This meeting between Bristow Group and SHI focused on Microsoft licensing optimization, specifically evaluating Bristow’s current Microsoft licensing environment and considering options for Enterprise Agreement (EA) consolidation versus remaining on a Cloud Solution Provider (CSP) model. The group discussed ongoing efforts to right-size licensing through SHI’s Insight tool, data analysis, and defining user personas. Bristow is seeking simplification and cost savings, aiming to co-term multiple agreements, reduce manual renewals, and ensure licensing matches actual user needs (including downgrades for pilots). The conversation also covered required support packages, upcoming renewal timing, and the pros/cons of EA vs. CSP, with SHI offering additional support options. Final pricing and side-by-side comparisons are pending, with next steps outlined for both parties.

Agenda

• Confirm Bristow’s progress using the SHI Insight
tool for license analysis
• Discuss Bristow’s internal optimization (personas,
right-sizing, data collection)
• Clarify SHI’s deeper optimization services (device
discovery, audit defense, etc.)
• Compare EA and CSP models (cost, process, support,
co-terming)
• Review specifics regarding MPSA renewals and
potential EA migration
• Address Azure consumption and future integration
• Outline next steps, data needs, and timelines

Opps Identified & BANTC

Opportunity 1: Microsoft Licensing Optimization (EA vs
CSP Consolidation)

B (Budget): Bristow is cost-conscious, seeking overall reduction in Microsoft spend and simplification of renewals. Will consider EA if savings outweigh additional support costs (Unified Support). A (Authority): IT leadership team on the call (Adil Ahmed, Marc Cougle, Carl Heasman) are driving licensing and renewal decisions; final approvals likely with this group. N (Need): Co-terming and consolidating multiple licensing agreements, reducing manual overhead, right-sizing based on actual use (including downgrades for pilots), and optimizing support costs. T (Timeline): Several renewals upcoming; aiming to align/plan over “next several weeks, month really.” Azure EA integration is a 12-month future conversation. C (Competition): Direct Microsoft, other resellers, and status quo (current CSP/MPSA structure). SHI is differentiating with deeper optimization services and support options.

B (Budget): Bristow is cost-conscious, seeking overall reduction in Microsoft spend and simplification of renewals. Will consider EA if savings outweigh additional support costs (Unified Support). A (Authority): IT leadership team on the call (Adil Ahmed, Marc Cougle, Carl Heasman) are driving licensing and renewal decisions; final approvals likely with this group. N (Need): Co-terming and consolidating multiple licensing agreements, reducing manual overhead, right-sizing based on actual use (including downgrades for pilots), and optimizing support costs. T (Timeline): Several renewals upcoming; aiming to align/plan over “next several weeks, month really.” Azure EA integration is a 12-month future conversation. C (Competition): Direct Microsoft, other resellers, and status quo (current CSP/MPSA structure). SHI is differentiating with deeper optimization services and support options.
Opportunity 2: Support Services Optimization (Unified
Support vs SHI Support)

B: Bristow
is reluctant to add Unified Support unless offset by savings; interested in SHI’s support package if it’s more cost-effective and covers relevant OEMs.
A: IT
leadership (Marc Cougle) makes the call on support package adoption.
N: Minimize
support costs while ensuring adequate vendor coverage (Microsoft, Palo Alto, Meraki, Nutanix, etc.).
T: As
part of licensing negotiation/renewal cycle.
C: Microsoft
Unified Support, SHI multi-vendor support, possibly other third-party support vendors.

B: Bristow
is reluctant to add Unified Support unless offset by savings; interested in SHI’s support package if it’s more cost-effective and covers relevant OEMs.
A: IT
leadership (Marc Cougle) makes the call on support package adoption.
N: Minimize
support costs while ensuring adequate vendor coverage (Microsoft, Palo Alto, Meraki, Nutanix, etc.).
T: As
part of licensing negotiation/renewal cycle.
C: Microsoft
Unified Support, SHI multi-vendor support, possibly other third-party support vendors.

Initiatives

Security: Not primary focus of this call, but support services may include security vendors. Storage: Not directly discussed. Other: Microsoft Licensing Optimization (EA, CSP, MPSA), Support Services.

Security: Not primary focus of this call, but support services may include security vendors. Storage: Not directly discussed. Other: Microsoft Licensing Optimization (EA, CSP, MPSA), Support Services.

Tech Profile Updates

Licensing: Currently using Microsoft 365 E3 (3600+ users), mix of annual and monthly agreements, MPSA renewals, CSP model, planning downgrades for pilot users. Optimization Tools: SHI Insight tool (tenant-based, visual analysis); internal Excel/Power BI analysis. Support: Currently basic CSP support; evaluating need for Unified Support or SHI’s multi-OEM support. Azure: Managed separately via third party; not yet in EA, planning future consolidation. ITM Services: SHI’s deeper optimization/audit defense available, but Bristow doing much of this internally for now.

Licensing: Currently using Microsoft 365 E3 (3600+ users), mix of annual and monthly agreements, MPSA renewals, CSP model, planning downgrades for pilot users. Optimization Tools: SHI Insight tool (tenant-based, visual analysis); internal Excel/Power BI analysis. Support: Currently basic CSP support; evaluating need for Unified Support or SHI’s multi-OEM support. Azure: Managed separately via third party; not yet in EA, planning future consolidation. ITM Services: SHI’s deeper optimization/audit defense available, but Bristow doing much of this internally for now.

Meeting Notes

Environment

Bristow Group’s IT team is actively working to optimize Microsoft licensing, using SHI’s tools and internal analytics. Existing licensing is fragmented (multiple renewal dates, MPSA, CSP, annual/monthly), creating manual workload. Bristow is defining user personas to determine who needs which license level (e.g., pilots to be downgraded). Azure is currently managed outside the core licensing discussion, but future consolidation is anticipated.

Bristow Group’s IT team is actively working to optimize Microsoft licensing, using SHI’s tools and internal analytics. Existing licensing is fragmented (multiple renewal dates, MPSA, CSP, annual/monthly), creating manual workload. Bristow is defining user personas to determine who needs which license level (e.g., pilots to be downgraded). Azure is currently managed outside the core licensing discussion, but future consolidation is anticipated.

Detailed Discussion

SHI’s Insight tool is being used for high-level analysis; Bristow is supplementing with their own data (to distinguish user vs. generic/system accounts). SHI outlined their full optimization/licensing position service (including device-level discovery and audit defense), but Bristow is handling most of this internally. Bristow wants a side-by-side cost comparison of EA vs. CSP, including the impact of downgrades and co-terming. SHI clarified EA requirements (minimum license quantities, Software Assurance SKUs), and the process for adding future renewals (via supplemental CPS). Unified Support is an additional cost under EA; CSP includes support by default. SHI can offer a multi-vendor support package as an alternative. Azure integration and support is a future topic, not immediate. SHI to provide final pricing for both EA and CSP (including flexible billing options and “no Teams” SKUs if relevant).

SHI’s Insight tool is being used for high-level analysis; Bristow is supplementing with their own data (to distinguish user vs. generic/system accounts). SHI outlined their full optimization/licensing position service (including device-level discovery and audit defense), but Bristow is handling most of this internally. Bristow wants a side-by-side cost comparison of EA vs. CSP, including the impact of downgrades and co-terming. SHI clarified EA requirements (minimum license quantities, Software Assurance SKUs), and the process for adding future renewals (via supplemental CPS). Unified Support is an additional cost under EA; CSP includes support by default. SHI can offer a multi-vendor support package as an alternative. Azure integration and support is a future topic, not immediate. SHI to provide final pricing for both EA and CSP (including flexible billing options and “no Teams” SKUs if relevant).

Technical Notes

Bristow’s internal analysis uses Excel/Power BI to marry licensing data with user account status. EA minimum for Level B pricing is 2400 enterprise licenses (up to 6000), all annual commitment. Co-terming in EA requires manual addition at anniversary; CSP via SHI portal can co-term in advance. Pilots and other roles to be downgraded, which may drop Bristow to Level A pricing if user counts change. Azure spend currently managed outside EA; will consider adding after 12 months. EA requires at least one qualifying license with Software Assurance (e.g., RDS CAL) to start. SHI to quote both monthly and annual billing options for CSP; E3 “no Teams” SKU available for flexibility. SHI’s ITM services provide audit defense, device-level discovery, and can justify licensing positions to Microsoft during audits.

Bristow’s internal analysis uses Excel/Power BI to marry licensing data with user account status. EA minimum for Level B pricing is 2400 enterprise licenses (up to 6000), all annual commitment. Co-terming in EA requires manual addition at anniversary; CSP via SHI portal can co-term in advance. Pilots and other roles to be downgraded, which may drop Bristow to Level A pricing if user counts change. Azure spend currently managed outside EA; will consider adding after 12 months. EA requires at least one qualifying license with Software Assurance (e.g., RDS CAL) to start. SHI to quote both monthly and annual billing options for CSP; E3 “no Teams” SKU available for flexibility. SHI’s ITM services provide audit defense, device-level discovery, and can justify licensing positions to Microsoft during audits. List all speakers/Participants of Transcript:

Nicole Agoncillo (SHI) Marc Cougle (Bristow Group) Susie Oberpriller (SHI) Adil Ahmed (Bristow Group) Stephen Drake (SHI) Joey Clevenger (SHI, Microsoft Licensing Specialist) Daniel Moran (SHI) Carl Heasman (Bristow Group) Manuel Zelaya (SHI)

Nicole Agoncillo (SHI) Marc Cougle (Bristow Group) Susie Oberpriller (SHI) Adil Ahmed (Bristow Group) Stephen Drake (SHI) Joey Clevenger (SHI, Microsoft Licensing Specialist) Daniel Moran (SHI) Carl Heasman (Bristow Group) Manuel Zelaya (SHI)

Potential Next steps

Cost Comparison & Final Pricing

Cost Comparison & Final Pricing

SHI (Daniel Moran, Joey Clevenger) to send final side-by-side pricing for EA and CSP, including flexible billing options, annual/monthly commitments, and “no Teams” E3 SKUs as relevant. Action: SHI → Bristow Group (Marc Cougle, Adil Ahmed, Carl Heasman) Timeline: As soon as internal discounting is finalized.

SHI (Daniel Moran, Joey Clevenger) to send final side-by-side pricing for EA and CSP, including flexible billing options, annual/monthly commitments, and “no Teams” E3 SKUs as relevant. Action: SHI → Bristow Group (Marc Cougle, Adil Ahmed, Carl Heasman) Timeline: As soon as internal discounting is finalized.

Internal Analysis Completion

Internal Analysis Completion

Bristow to continue refining user personas and right-sizing license needs, particularly for pilot downgrades. Action: Bristow IT (Adil Ahmed, Marc Cougle, Carl Heasman)

Bristow to continue refining user personas and right-sizing license needs, particularly for pilot downgrades. Action: Bristow IT (Adil Ahmed, Marc Cougle, Carl Heasman)

EA Migration Planning

EA Migration Planning

SHI to outline process for migrating MPSA renewals to EA (using supplemental CPS) and co-terming. Action: SHI → Bristow Group

SHI to outline process for migrating MPSA renewals to EA (using supplemental CPS) and co-terming. Action: SHI → Bristow Group

Support Package Evaluation

Support Package Evaluation

Bristow to consider SHI’s multi-OEM support package as alternative to Microsoft Unified Support. SHI to provide more information as needed. Action: SHI → Bristow Group

Bristow to consider SHI’s multi-OEM support package as alternative to Microsoft Unified Support. SHI to provide more information as needed. Action: SHI → Bristow Group

Azure Integration Future Planning

Azure Integration Future Planning

Schedule follow-up in ~12 months to discuss Azure consolidation into EA. Action: Bristow IT (Marc Cougle) to revisit with SHI

Schedule follow-up in ~12 months to discuss Azure consolidation into EA. Action: Bristow IT (Marc Cougle) to revisit with SHI

Questions/Additional Requests

Questions/Additional Requests

Bristow to review SHI’s final pricing and provide feedback or further questions (e.g., cherry-picking support OEMs, deeper licensing analytics). Action: Bristow → SHI

Bristow to review SHI’s final pricing and provide feedback or further questions (e.g., cherry-picking support OEMs, deeper licensing analytics). Action: Bristow → SHI
