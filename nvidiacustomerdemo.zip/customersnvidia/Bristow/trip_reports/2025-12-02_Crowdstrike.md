Trip Report | Crowdstrike | Bristow

Customer: Bristow
AE: Jax M
Topic: Crowdstrike
Meeting Date 12/02/2025

*Internal notes – Please read and edit before sending externally*

Summary

• The customer
team led by Michael May outlined their 2026 security posture: endpoint volumes were increased this year, with limited or slightly shrinking growth anticipated next year due to expanded Azure VDI; CrowdStrike agents remain required on VDI. The team is satisfied with Falcon Complete and expects continuity through most of 2026 under a new CIO, Mark Google. They flagged an immediate need to ingest third‑party firewall telemetry (Versa) into CrowdStrike’s Next‑Gen SIEM so Falcon Complete can act on network indicators earlier, plus a comprehensive policy review across servers and endpoints aligned to Windows 11 24H2. Executive reporting cadence (quarterly “what was detected and what actions were taken”) must be surfaced consistently to support board‑level value demonstration. Longer‑term topics included DLP strategy (currently leaning Microsoft for M365, but recognizing the need for endpoint controls), and potential adoption of Exposure Management integrated with Falcon for IT to enable real‑time patching. A QBR-style on‑site session in Houston was proposed (with SE support) to roadmap futures and execute the policy review; a quick PoV

Agenda

• Introductions
and account alignment (CrowdStrike: Andy Wittner as Regional Director; Brandon Reyes as dedicated Account Rep).
• Customer 2026
outlook: asset count trend, Azure VDI expansion, Falcon Complete satisfaction, new CIO governance.
• Next‑Gen SIEM:
ingest Versa firewall logs, pricing model, data retention options, PoV approach.
• Policy review
across endpoints/servers aligned to Windows 11 24H2.
• DLP strategy:
Microsoft vs. endpoint DLP considerations.
• Quarterly
executive reporting expectations.
• Exposure
Management + Falcon for IT patching roadmap (Q1 expectation).
• Logistics:
share deck, set policy review, schedule QBR/on‑site in Houston, provide contact at prior vendor.

Opps Identified & BANTC

Opportunity 1 — Next‑Gen SIEM ingest of Versa firewall
logs
• B: Budgetary quote requested; pricing based on
third‑party daily ingest volume and retention window (minimum ~90 days).
• A: Decision influence by Michael May; ultimate
authority likely with CIO Mark Google.
• N: Close telemetry gap by ingesting firewall
logs from ~40 Versa devices so Falcon Complete can detect/respond before

endpoint impact.

• T: Near‑term; PoV suggested to estimate ingest;
retention “a couple of months” unless incidents require longer storage.
• C: Prior POCs included Microsoft SIEM;
competition includes other SIM platforms.
Opportunity 2 — Falcon policy review &
optimization
• B: Potentially covered by Falcon
Complete/implementation services.
• A: Customer operators (Michael May, Nathan
Trahan, “Carl”) with Falcon Complete team executing.
• N: Remove outdated controls; align to current
OS; ensure USB policy and server coverage best practices.
• T: ASAP; proposed to schedule quickly and also
as part of an early‑next‑year QBR/on‑site.
• C: None explicitly; internal optimization vs.
alternative EDR.
Opportunity 3 — Executive quarterly reporting
enablement
• B: Likely nil; reporting exists in console,
needs surfacing/distribution.
• A: “Carl” likely recipient/owner; Michael May
wants visibility for CIO/board.
• N: Routine incident/action summaries to
demonstrate Falcon Complete value upstairs.
• T: Ongoing; ensure inclusion in cybersecurity
meetings.
• C: None; internal cadence.
Opportunity 4 — DLP program design
• B: Undetermined; Microsoft services vs.
CrowdStrike Data Protection module/licensing.
• A: CIO governance; security team input.
• N: Prevent data exfiltration beyond M365
controls; need endpoint‑level enforcement.
• T: 2026 planning horizon; investigation and
workshops suggested.
• C: Microsoft DLP stack; other endpoint DLP
vendors.
Opportunity 5 — Exposure Management + Falcon for IT
patching
• B: To be scoped; future module(s).
• A: Customer security/IT leadership; CrowdStrike
product team guidance.
• N: Vulnerability/external attack surface
integration, attack path mapping, and real‑time patch orchestration via Falcon for IT.
• T: Anticipated Q1 release/integration (subject
to change); roadmap session proposed.
• C: Tanium, Tenable, traditional
scanners/patchers.

Initiatives

• Security — SIEM telemetry ingestion; policy
optimization; executive reporting; DLP program; exposure management & patching.

Tech Profile Updates

• Falcon Complete
in production; customer “very happy” and plans continuity through bulk of 2026.
• Spotlight
module previously dropped and now restored; working well.
• CrowdStrike
agent deployed on Azure VDI and servers.
• OS baseline:
Windows 11 24H2 globally.
• USB control in
place and working.
• Next‑Gen SIEM
currently supports first‑party data at no charge; third‑party ingestion (Versa, email) is billable by ingest volume + retention.

Meeting Notes

Environment

• Network edge:
~40 Versa firewalls across bases; typical sites at 100 Mbps Internet; some at 500 Mbps. Larger bases (Lake Charles, Aberdeen) host ~300 people; SAR bases have crews of ~18.
• Workforce:
~3,000 employees; ~900 pilots with half rotating every two weeks.
• Public
exposure: minimal; ~3–4 external websites/FTP.
• Cloud posture:
significant Azure presence; increased Azure VDI adoption.

Detailed Discussion

• Account
alignment & intros: Brandon Reyes introduced himself as dedicated CrowdStrike account rep under Andy Wittner (Regional Director, South Texas).
• 2026 asset
outlook: Michael May increased per‑asset counts this year; anticipates flat to slightly down in 2026 with Azure VDI growth; agents remain on VDI.
• CIO &
service stability: New CIO (Mark Google) sets priorities; Falcon Complete stays in place through bulk of 2026 unless directed otherwise.
• Next‑Gen SIEM:
endpoint DLP is needed to block non‑M365 exfil vectors (e.g., Google Drive).
• Exposure
Management roadmap: CrowdStrike’s integration (Exposure Management + Falcon for IT) to support scanning of non‑agent devices and real‑time patching; agent can function as a scanner. Q1 expectation flagged with caveats.
• Operations
& integrations: Next‑Gen SIEM can take first‑party action on ~14–15 partner integrations today, scaling toward 25–35 by end of 2026; custom connectors possible, scoped with an implementation fee.
• Closeout &
logistics: Agreement to set policy review ASAP and schedule a full QBR in early next year, potentially on‑site in Houston with SE lead.

Technical Notes

• Next‑Gen SIEM
economics: First‑party CrowdStrike data is included; third‑party logs (Versa, email) are billed by daily ingest + retention duration; minimum retention discussed around 90 days.
• PoV path: Tech

ROLES

• Andy Wittner —
Regional Director, CrowdStrike (South Texas).
• Brandon Reyes —
Dedicated Account Representative, CrowdStrike.
• Michael May —
Customer security/IT leader (Bristow).
• Nathan Trahan —
Customer IT/security contributor (Bristow).
• Jax Miley —
Account team host/facilitator.

Potential Next steps

• Set Falcon policy review (servers + endpoints)
— Michael May requested Falcon Complete to review/remove legacy policies and
apply recommended settings for Windows 11 24H2; Andy Wittner/Brandon Reyes to coordinate and schedule.
• Provide budgetary quote for Versa log ingestion
— Michael May asked Andy Wittner/Brandon Reyes for a pricing model based on
daily ingest and retention; option to spin up PoV and point Versa logs to CrowdStrike.
• Estimate daily ingest via Speedcast dashboard —
Michael May to coordinate pulling ingest estimates; Speedcast maintains the relevant dashboards.
• Quarterly incident/action reporting cadence —
Michael May asked to ensure “detections + actions” reports are routinely captured and presented in CIO/board meetings; “Carl likely has them” in the console.
• Share one‑slide deck — Brandon Reyes to email
the slide; Andy Wittner shared it live when screen‑sharing issues occurred.
• Schedule QBR/on‑site in Houston (early next year)
— Andy Wittner proposed a full QBR with a technical engineer for
roadmap/futures; on‑site with catering offered; include “Carl” when he is in Houston in March.
• Provide contact at prior vendor — Michael May
asked Brandon Reyes to share the contact “back at Data Price”; Brandon agreed to “pull some strings.”
