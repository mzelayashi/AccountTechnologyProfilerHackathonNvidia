Trip Report | Email Security | Pinnergy

Customer: Pinnergy
AE: Jax M
Topic: Email Security
Meeting Date 03/29/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

provide detailed datasheets and proposals to Josh Hayes by end of business Monday

04/20

2

Jax M

coordinate a meeting with Abnormal Security for email security evaluation, targeted for April 2025, involving Josh Hayes.

04/20

Item Owner Next Steps/Detail Due Date 1 Manuel Z provide detailed datasheets and proposals to Josh Hayes by end of business Monday 04/20 2 Jax M coordinate a meeting with Abnormal Security for email security evaluation, targeted for April 2025, involving Josh Hayes. 04/20

Summary

second part of the Security Posture Review (SPR) between Pinnergy and SHI. The meeting focused on evaluating Pinnergy's current security infrastructure and providing recommendations to enhance security, streamline operations, and ensure comprehensive protection. The conversation involved reviewing findings from a previous session, discussing strategic priorities, and agreeing on actionable steps. Participants emphasized the importance of balancing immediate needs with long-term goals while considering budget and resource constraints.

Agenda

Introduction and participant check-in Review of previous findings and objectives Detailed discussion of recommendations and priorities Agreement on action items and timelines Closing remarks and appreciation

Introduction and participant check-in Review of previous findings and objectives Detailed discussion of recommendations and priorities Agreement on action items and timelines Closing remarks and appreciation

Opps Identified & BANTC

Opportunity 1: Identity Management & Endpoint
Protection n • B: Need for enhanced identity management and endpoint protection due to security concerns. • A: Josh Hayes has the authority to prioritize and implement these changes. • N: Urgent, with focus on immediate improvements to prevent unauthorized access. • T: Targeted for implementation by Q3 2025. • C: Budget will be allocated for necessary tools and services.
Opportunity 2: Integrated Cloud Email Solution
• B: Need for robust email security given the high
volume of external communication. • A: Josh Hayes and IT team to evaluate and implement solutions. • N: Priority for Q2 2025 to address vulnerabilities in email systems. • T: Decision and implementation by end of April 2025. • C: Consideration for cost of premium solutions like Abnormal Security.
Opportunity 3: Data Security and Management • B:
Importance of data protection to secure sensitive information. • A: Josh Hayes to lead initiatives with SHI support. • N: Medium-term priority, scheduled for Q3 2025. • T: Initial briefing and planning in Q3 2025. • C: Budget allocated for data protection tools and briefings.

Initiatives

Security

Focus on identity management, endpoint protection, and email security. Storage: Addressing data security and backup processes.

Security

Focus on identity management, endpoint protection, and email security. Storage: Addressing data security and backup processes. Tech Profile Updates: Pinnergy operates within a hybrid IT environment, utilizing Microsoft products for identity and endpoint management. Gaps were identified in email security and data protection, with a reliance on Azure for cloud services and SolarWinds for systems management. Meeting Notes: Environment: The company uses a mix of on-premises and cloud-based solutions, with current challenges in maintaining a robust security posture and managing data efficiently. Detailed Discussion: The meeting explored specific areas for improvement, including replacing Carbon Black for endpoint protection, enhancing email security with integrated solutions like Abnormal Security, and focusing on data security practices. The team discussed potential vendors and the importance of aligning security measures with business objectives.

Technical Notes

Endpoint

protection: Consider alternatives to Carbon Black due to Broadcom's lack of investment. Email security: Evaluate integrated solutions focusing on social engineering and business email compromise. Data security: Explore options like Microsoft Purview or Varonis for comprehensive data management and classification.

Endpoint

protection: Consider alternatives to Carbon Black due to Broadcom's lack of investment. Email security: Evaluate integrated solutions focusing on social engineering and business email compromise. Data security: Explore options like Microsoft Purview or Varonis for comprehensive data management and classification. List all speakers/Participants of Transcript:

Manuel Zelaya (Vendor, SHI) Jax Miley (Vendor, SHI) Luz Angeles (Vendor, SHI) Josh Hayes (Customer, Pinnergy)

Manuel Zelaya (Vendor, SHI) Jax Miley (Vendor, SHI) Luz Angeles (Vendor, SHI) Josh Hayes (Customer, Pinnergy)

Potential Next steps

Manuel Zelaya to provide detailed datasheets and proposals to Josh Hayes by end of business Monday, April 7,
2025.
Schedule a briefing on data security options for mid to late April 2025. Jax Miley to coordinate a meeting with Abnormal Security for email security evaluation, targeted for April 2025, involving Josh Hayes. Luz Angeles to follow up with Josh Hayes on the well-architected review and backup processes, providing additional information by April 15, 2025. Josh Hayes to review current contracts and evaluate endpoint protection alternatives by Q3 2025, involving IT team and SHI support.

Manuel Zelaya to provide detailed datasheets and proposals to Josh Hayes by end of business Monday, April 7,
2025.
Schedule a briefing on data security options for mid to late April 2025. Jax Miley to coordinate a meeting with Abnormal Security for email security evaluation, targeted for April 2025, involving Josh Hayes. Luz Angeles to follow up with Josh Hayes on the well-architected review and backup processes, providing additional information by April 15, 2025. Josh Hayes to review current contracts and evaluate endpoint protection alternatives by Q3 2025, involving IT team and SHI support.
