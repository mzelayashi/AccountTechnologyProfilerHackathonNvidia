Trip Report | Barracuda | Pro Petro

Customer: Pro Petro
AE: Tony V
Topic: Barracuda
Meeting Date 01/08/2026

*Internal notes – Please read and edit before sending externally*

Summary

This working session between SHI, ProPetro Services, and Barracuda centered on performing a Barracuda Email Security Gateway health check, reviewing current configurations, identifying security gaps, and outlining post‑holiday remediation work. The purpose was to help ProPetro ensure their environment is aligned to best practices, reduce unnecessary email noise for end‑users, tighten security controls, and simplify ongoing management. The discussion focused heavily on:

Misalignment between global vs. domain-level sender policies, causing unpredictable mail handling. Excessive exemption policies, particularly for high-risk domains and “no-reply” senders. Improper IP address policy configuration, including invalid subnet masks and overly broad ranges. Need to fix Direct Send issues and ensure all inbound mail routes through Barracuda before Microsoft to prevent bypass.

Opportunities to reduce

end‑user burden by tuning spam vs. quarantine thresholds, especially for bulk and marketing email. Regional policy use, and GeoIP filtering optimizations. Recommendation to consolidate policies, create a consistent global approach, and take pre‑change snapshots.

Misalignment between global vs. domain-level sender policies, causing unpredictable mail handling. Excessive exemption policies, particularly for high-risk domains and “no-reply” senders. Improper IP address policy configuration, including invalid subnet masks and overly broad ranges. Need to fix Direct Send issues and ensure all inbound mail routes through Barracuda before Microsoft to prevent bypass.

Opportunities to reduce

end‑user burden by tuning spam vs. quarantine thresholds, especially for bulk and marketing email. Regional policy use, and GeoIP filtering optimizations. Recommendation to consolidate policies, create a consistent global approach, and take pre‑change snapshots. The call concluded with alignment on generating a punch list, sharing a detailed health check report, combining policies, and scheduling a technical working session in early January. The intent is to enhance ProPetro’s security posture, consolidate configuration management, and reduce user‑introduced risks.

Agenda

• Introductions
between SHI, ProPetro, and Barracuda parties
• Explanation of
meeting purpose (health check + review of Barracuda configuration)
• Review of
report findings (reds, yellows, greens)
• Deep dive into
inbound settings, sender policies, IP policies, regional policies, and authentication
• Discussion of
Direct Send, Microsoft quarantine behavior, and mail routing
• Agreement on
punch list creation and next steps after holidays

Opportunities Identified & BANTC

Opportunity 1: Consolidation of Global and
Domain-Level Email Security Policies Type: Security
B – Budget:
ProPetro already owns Barracuda solutions; budget impact is minimal. Effort is primarily configuration and services support.
A – Authority:
Morgan (Senior SysAdmin) and Mark (IT Supervisor) manage implementation; Alex (IT Manager) approves direction. Barracuda (Patrick) provides SME recommendations.
N – Need:

Misaligned policies between global and domain levels. Exemptions overriding critical security features. Inconsistent sender policy behavior causing false positives/negatives. Opportunity to refine bulk mail and marketing filtering.

Misaligned policies between global and domain levels. Exemptions overriding critical security features. Inconsistent sender policy behavior causing false positives/negatives. Opportunity to refine bulk mail and marketing filtering.
T – Timeline:
Work to begin after holidays, with targeted working session around January 6th.
C – Competition / Alternatives:
Competes with status quo + internal configuration practices. No alternative email security vendor discussed.
Opportunity 2: Correcting Direct Send & Routing
All Mail Through Barracuda Type: Security
B – Budget:
No additional spend; requires configuration change and possible connector updates in Microsoft.
A – Authority:
Morgan and Mark execute changes; Alex oversees; Patrick provides guidance.
N – Need:

Direct Send enabled in Microsoft allows attackers to bypass Barracuda. Users must currently check both Barracuda and Microsoft quarantine. Causes operational inefficiency and increases phishing exposure.

Direct Send enabled in Microsoft allows attackers to bypass Barracuda. Users must currently check both Barracuda and Microsoft quarantine. Causes operational inefficiency and increases phishing exposure.
T – Timeline:
Addressed during the January working session. C: Internal Microsoft features; risk of staying with current mixed‑path routing.
Opportunity 3: Sender Policy Cleanup & Reduction
of User-Controlled Exemptions Type: Security B: Same Barracuda environment; only labor needed. A: Morgan/Mark with Patrick’s guidance. N:

End‑users currently exempt malicious senders. High‑risk domains (DocuSign, QuickBooks, LinkedIn, Microsoft “no-reply” senders) are whitelisted globally or per domain. Need to align DMARC-based recommendations.

End‑users currently exempt malicious senders. High‑risk domains (DocuSign, QuickBooks, LinkedIn, Microsoft “no-reply” senders) are whitelisted globally or per domain. Need to align DMARC-based recommendations. T: Pending log report, delivered near holiday timeframe; execution in January. C: Competes with legacy habits and user-driven exemptions.

Initiatives (Security / Storage)

All initiatives in this call are Security-focused.
• Sender policy
rationalization (Security)
• Global vs
domain policy consolidation (Security)
• IP policy
cleanup (Security)
• Direct Send
remediation & connector configuration (Security)
• Quarantine
tuning and bulk/marketing mail handling improvements (Security)
• GeoIP policy
refinement (Security)

Tech Profile Updates

• ProPetro
environment has multiple domains with inconsistent policy inheritance.
• Heavy use of
sender policy exemptions historically, some justified by acquisitions.
• Quarantine
digest frequently overloaded for end‑users.
• Microsoft
quarantine enabled due to Direct Send misconfiguration.
• Regional policy
blocks nearly all countries except those manually exempted for business needs.
• Large
differences between global and domain‑level inbound settings.
• New UI is being
used in Barracuda Gateway (important for feature availability).

Meeting Notes

Environment

• Multidomain
Barracuda Email Security Gateway deployment.
• Microsoft 365
tenant with Direct Send still active.
• Users empowered
to deliver/block messages, creating security gaps.
• Quarantine
volume is high; bulk and marketing settings are causing false positives.

Detailed Discussion

1. Introductions & Meeting Setup
Parties introduced roles and clarified the meeting purpose: perform a health check, review findings, and prepare post‑holiday remediation plans.
2. Sender Policies (Most Critical Area)
Key problems identified:

Massive use of exemptions, including full domains. Global vs. domain policy mismatch leading to inconsistent mail handling. Some exemptions override spoofing checks, URL wrapping, spam scoring, etc. High-risk services (DocuSign, QuickBooks, Microsoft no‑reply) are whitelisted without verifying DMARC.

Massive use of exemptions, including full domains. Global vs. domain policy mismatch leading to inconsistent mail handling. Some exemptions override spoofing checks, URL wrapping, spam scoring, etc. High-risk services (DocuSign, QuickBooks, Microsoft no‑reply) are whitelisted without verifying DMARC. Patrick recommended:

Moving to a global policy model where possible. Removing domain-level exemptions and using IP-based allow-listing when appropriate. Using MX Toolbox to inspect DMARC records when assessing full-domain exemptions. Awaiting log report from engineering to identify all problematic exemptions across global/domain/user level.

Moving to a global policy model where possible. Removing domain-level exemptions and using IP-based allow-listing when appropriate. Using MX Toolbox to inspect DMARC records when assessing full-domain exemptions. Awaiting log report from engineering to identify all problematic exemptions across global/domain/user level.
3. IP Address Policies
Issues discovered:

Subnet masks that do not match IP ranges (ignored by Barracuda). Overly broad ranges (e.g., TransUnion example). IPs that provide no functional value because of mask mismatch.

Subnet masks that do not match IP ranges (ignored by Barracuda). Overly broad ranges (e.g., TransUnion example). IPs that provide no functional value because of mask mismatch. Fixes:

Use Bulk Edit to mass-correct via CSV. Validate correct addressing structure before applying ranges.

Use Bulk Edit to mass-correct via CSV. Validate correct addressing structure before applying ranges.
4. Regional Policies
Current configuration:

Nearly all countries blocked except those manually exempted. Possible risk: legitimate Microsoft traffic sometimes originates from European relay centers. No strong pain point reported, but may cause intermittent mail failures.

Nearly all countries blocked except those manually exempted. Possible risk: legitimate Microsoft traffic sometimes originates from European relay centers. No strong pain point reported, but may cause intermittent mail failures. Recommendation:

Use GeoIP filtering data in Incident Response to refine country blocks. Monitor traffic to identify top spam-sending countries.

Use GeoIP filtering data in Incident Response to refine country blocks. Monitor traffic to identify top spam-sending countries.
5. Anti-Spam / Anti-Virus Settings
Findings:

Spam score thresholds acceptable. Bulk and marketing emails currently quarantined, causing unnecessary digest noise. Patrick recommended setting bulk email to block and using specific exemptions instead.

Spam score thresholds acceptable. Bulk and marketing emails currently quarantined, causing unnecessary digest noise. Patrick recommended setting bulk email to block and using specific exemptions instead.
6. Direct Send & Microsoft Quarantine Handling
Critical gap:

Direct Send is still enabled in Microsoft, enabling attackers to bypass Barracuda. Mixed routing creates dual quarantine locations for admins.

Direct Send is still enabled in Microsoft, enabling attackers to bypass Barracuda. Mixed routing creates dual quarantine locations for admins. Proposed solution:

Disable Direct Send. Ensure all MX-bound mail routes through Barracuda first. Adjust connectors in Microsoft to maintain legitimate mail flow for systems like Diligent notifications.

Disable Direct Send. Ensure all MX-bound mail routes through Barracuda first. Adjust connectors in Microsoft to maintain legitimate mail flow for systems like Diligent notifications.
7. End-User Permissions
End users can:

Exempt senders Deliver block messages

Exempt senders Deliver block messages Problem:

Users unintentionally allow malicious messages.

Users unintentionally allow malicious messages. Recommendation:

Remove ability to deliver blocked messages. Reassess permissions after receiving log report.

Remove ability to deliver blocked messages. Reassess permissions after receiving log report.

Technical Notes (Granular)

• Sender policies
at domain level override global-level settings, causing inconsistency.
• Exemption
policies on the domain level ignore spoofing, link protection, spam checks.
• IP address
policy mismatches: incorrect subnet masks cause entries to be ignored entirely.
• TransUnion IP
range too broad; likely missing the first IP that matches subnet.
• Log report in
XML will display domains with valid DMARC that are currently exempted.
• Bulk mail
should be set to block, with exemptions handled individually.
• User privileges
are causing malicious email deliverability due to manual overrides.
• Enhanced
filtering was adjusted earlier by Barracuda support but didn’t fix root issue.
• Inbound
connectors not forcing mail to Barracuda—must be corrected.
• High-confidence
phishing messages will always remain in Microsoft quarantine; cannot disable.
• New UI required
for new features rolling out in future gateway updates.
• Global-level
backups via “Save and apply account configuration settings” before changes.

ROLES (Speakers / Participants)

Patrick Yount – Senior Solutions Engineer / Technical Architect, Barracuda Jeff Atkinson – Account Executive, Barracuda (Texas Region) Tony Villalanti – SHI AE supporting ProPetro Manuel Zelaya – SHI Security Engineer (Core SE) Greg Miller – (Mentioned, SHI Leadership – not present in transcript dialogue) Alex Padron – IT Manager, ProPetro Mark Stevenson – IT Supervisor, Infrastructure, ProPetro Morgan Grimes – Senior Systems Administrator, ProPetro Unknown Speaker – Unidentified participant with minor contributions

Potential Next Steps

1. Patrick → Morgan & Mark (ProPetro)
Action: Deliver full health check document + log report identifying problematic sender policies and DMARC conflicts. Purpose: Provide punch list for January working session.
2. Patrick → Entire ProPetro Team
Action: Perform policy consolidation (global + domain) after holidays. Triggered by: Patrick stating he will combine and present recommendations. Participants: Patrick, Morgan, Mark.
3. Tony → All Attendees
Action: Reuse existing meeting invite and schedule the January 6th, 2 PM Central working session. Participants: Tony (organizer), Patrick, Morgan, Mark, optionally Alex.
4. Morgan → Patrick
Action: Provide examples or background of domain‑specific needs (e.g., Silvertip acquisition). Purpose: Inform policy combination decisions.
5. ProPetro IT Team → Internal Ticketing System
Action: Create documented change requests ahead of working session (requested by Alex). Purpose: Ensure change control & approval for configuration updates.
6. Patrick → ProPetro Team
Action: Take global-level snapshot before applying changes. Purpose: Enable rollback if needed.
7. Joint Work Session (After Jan 6)

Agenda

Disable Direct Send Update Microsoft connectors Clean sender policies Fix IP policies Adjust bulk/marketing email handling Apply GeoIP refinements Remove user permission to deliver blocked messages Confirm routing: all inbound mail → Barracuda → Microsoft

Disable Direct Send Update Microsoft connectors Clean sender policies Fix IP policies Adjust bulk/marketing email handling Apply GeoIP refinements Remove user permission to deliver blocked messages Confirm routing: all inbound mail → Barracuda → Microsoft
