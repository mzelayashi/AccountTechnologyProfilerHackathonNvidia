Trip Report | Beyond Trust | Pro Petro

Customer: Pro Petro
AE: Tony V
Topic: Beyond Trust
Meeting Date 03/06/2026

*Internal notes – Please read and edit before sending externally*

Summary

This meeting was a deep technical and business working session between SHI, BeyondTrust, and ProPetro stakeholders focused on solving a high‑impact operational and security problem affecting field operations, compliance posture, and productivity. The core challenge discussed is how ProPetro can secure, rotate, and manage privileged and shared credentials across remote, operationally critical environments (fracturing fleets, Pro Power sites, data vans, and the Remote Operations Center) without disrupting uptime, where downtime can cost approximately $125,000 per hour. The discussion highlighted a three‑way tension between:

Operational continuity (field users must always be able to log in),

Security

and compliance requirements (password rotation, least privilege, auditability for a public company), and Usability for non‑technical field personnel (shared accounts, rotating shifts, low tolerance for friction).

Operational continuity (field users must always be able to log in),

Security

and compliance requirements (password rotation, least privilege, auditability for a public company), and Usability for non‑technical field personnel (shared accounts, rotating shifts, low tolerance for friction). BeyondTrust demonstrated how Endpoint Privilege Management (EPM), Password Safe, and Privileged Remote Access (PRA) could be combined to remove standing admin rights, vault and rotate credentials, inject credentials into sessions, and record/audit activity. The conversation evolved from a product demo into a workflow‑level architecture discussion, including the need for single sign‑on (SSO) and self‑service password reset (via identity platforms such as Okta/Duo) to fully solve the “can’t log in” problem that currently drives insecure workarounds like shared static passwords. The outcome of the call was alignment on:

Proceeding with a Proof of Concept (POC), Establishing initial sizing assumptions (EPM devices, PRA/users or assets), Treating Pro Power as the crawl phase and Frac operations as a future run phase, and Continuing cross‑vendor collaboration to finalize a secure, compliant, and user‑friendly end‑state architecture.

Proceeding with a Proof of Concept (POC), Establishing initial sizing assumptions (EPM devices, PRA/users or assets), Treating Pro Power as the crawl phase and Frac operations as a future run phase, and Continuing cross‑vendor collaboration to finalize a secure, compliant, and user‑friendly end‑state architecture.

Agenda

Recap of prior BeyondTrust demo and EPM concepts Deep dive into Password Safe (credential vaulting and rotation) Discussion of shared vs non‑human vs user accounts Privileged Remote Access session management and auditing Operational workflows for Pro Power and Frac environments Licensing models (user‑based vs asset‑based) Compliance, cybersecurity, and productivity constraints Definition of end‑state workflow and next steps (POC)

Recap of prior BeyondTrust demo and EPM concepts Deep dive into Password Safe (credential vaulting and rotation) Discussion of shared vs non‑human vs user accounts Privileged Remote Access session management and auditing Operational workflows for Pro Power and Frac environments Licensing models (user‑based vs asset‑based) Compliance, cybersecurity, and productivity constraints Definition of end‑state workflow and next steps (POC)

Opps Identified & BANTC

Opportunity 1: Endpoint Privilege Management (EPM)
Description: Remove local admin rights from endpoints while allowing users to elevate only approved applications or tasks, reducing security risk without disrupting operations.

BANTC

B (Budget): Budget sensitivity acknowledged, but leadership emphasized solving the problem first. Budget expected if solution prevents downtime and compliance risk. A (Authority): Morgan Grimes (IT leadership) with strong influence from Mark Stevenson; budget visibility via Alex Padron. N (Need): Critical need to eliminate standing admin rights while maintaining uptime in field and remote environments. T (Timeline): Immediate POC; phased rollout starting with Pro Power. C (Competition): Status quo (local admin rights, shared passwords). No direct competing vendor named.

B (Budget): Budget sensitivity acknowledged, but leadership emphasized solving the problem first. Budget expected if solution prevents downtime and compliance risk. A (Authority): Morgan Grimes (IT leadership) with strong influence from Mark Stevenson; budget visibility via Alex Padron. N (Need): Critical need to eliminate standing admin rights while maintaining uptime in field and remote environments. T (Timeline): Immediate POC; phased rollout starting with Pro Power. C (Competition): Status quo (local admin rights, shared passwords). No direct competing vendor named.
Opportunity 2: Password Safe (Enterprise Password
Management) Description: Vault, rotate, and inject shared and privileged credentials without exposing passwords to users; enforce approval workflows and auditing.

BANTC

B (Budget): Justified by security, compliance, and operational risk reduction. A (Authority): Morgan Grimes with strong operational backing from Shane Wright and Mark Stevenson. N (Need): Shared accounts with static passwords represent a major cybersecurity and compliance gap. T (Timeline): Near‑term POC aligned with EPM. C (Competition): None explicitly stated; alternative is insecure shared credentials.

B (Budget): Justified by security, compliance, and operational risk reduction. A (Authority): Morgan Grimes with strong operational backing from Shane Wright and Mark Stevenson. N (Need): Shared accounts with static passwords represent a major cybersecurity and compliance gap. T (Timeline): Near‑term POC aligned with EPM. C (Competition): None explicitly stated; alternative is insecure shared credentials.
Opportunity 3: Privileged Remote Access (PRA)
Description: Enable credential injection, RDP/SSH session brokering, session recording, and audit trails without installing agents everywhere.

BANTC

B (Budget): Tied to asset/user counts; flexible licensing options discussed. A (Authority): Same decision group as EPM and Password Safe. N (Need): Remote access into geographically isolated sites with full auditing and control. T (Timeline): Included in POC. C (Competition): Existing tools like LogMeIn (view‑only, limited security controls).

B (Budget): Tied to asset/user counts; flexible licensing options discussed. A (Authority): Same decision group as EPM and Password Safe. N (Need): Remote access into geographically isolated sites with full auditing and control. T (Timeline): Included in POC. C (Competition): Existing tools like LogMeIn (view‑only, limited security controls).

Initiatives

Security

Privileged access management Password rotation and vaulting Session auditing and compliance

Operational Enablement:

Secure remote access Reduced downtime in field operations

Security

Privileged access management Password rotation and vaulting Session auditing and compliance

Privileged access management Password rotation and vaulting Session auditing and compliance Operational Enablement:

Secure remote access Reduced downtime in field operations

Secure remote access Reduced downtime in field operations

Tech Profile Updates

Identity platform: Microsoft Entra ID Existing remote access tooling: LogMeIn (limited capability) Shared local accounts in Frac environments Standard accounts with local admin elevation in Pro Power Starlink connectivity for remote sites OT‑adjacent environments with serial connections and specialized software

Identity platform: Microsoft Entra ID Existing remote access tooling: LogMeIn (limited capability) Shared local accounts in Frac environments Standard accounts with local admin elevation in Pro Power Starlink connectivity for remote sites OT‑adjacent environments with serial connections and specialized software

Meeting Notes

Environment

Highly distributed, remote field sites Data Vans on drilling sites Remote Operations Center (“The Rock”) in Midland Mixed IT/OT environment Intermittent connectivity constraints Public company compliance requirements

Highly distributed, remote field sites Data Vans on drilling sites Remote Operations Center (“The Rock”) in Midland Mixed IT/OT environment Intermittent connectivity constraints Public company compliance requirements

Detailed Discussion

Password Safe can manage Entra‑based credentials and rotate them on schedules without user visibility. Discovery scans identify local users, domain users, services, databases, and running software. Smart Rules automatically group assets and assign RBAC controls. PRA enables RDP/SSH via jump points or jump clients with full session recording. Approval workflows can enforce just‑in‑time access. Users authenticate once (SSO), then credentials are injected automatically. EPM enforces least privilege at the application level, not by granting admin rights. Frac environments currently rely on a single shared password across ~150 machines due to operational constraints. This workaround is acknowledged as non‑compliant and insecure. The proposed end‑state removes password knowledge from users entirely.

Password Safe can manage Entra‑based credentials and rotate them on schedules without user visibility. Discovery scans identify local users, domain users, services, databases, and running software. Smart Rules automatically group assets and assign RBAC controls. PRA enables RDP/SSH via jump points or jump clients with full session recording. Approval workflows can enforce just‑in‑time access. Users authenticate once (SSO), then credentials are injected automatically. EPM enforces least privilege at the application level, not by granting admin rights. Frac environments currently rely on a single shared password across ~150 machines due to operational constraints. This workaround is acknowledged as non‑compliant and insecure. The proposed end‑state removes password knowledge from users entirely.

Technical Notes

Appliance‑based Password Safe hosted in Azure (single tenant). Outbound 443 only; no inbound firewall exposure. Resource Broker used for credential discovery and management. Jump Point architecture avoids agent sprawl.https://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=a1246b75-0fc3-e611-80f6-0050569574e0 Session recordings retained ~90 days. Credential injection removes need for copy/paste. PRA supports web and thick‑client access. Licensing can be asset‑based or user‑based; flexibility discussed. Integration potential with Entra ID, Okta, Duo, Ping. MFA challenges exist for shared accounts, reinforcing need for vaulted credentials. EPM policies enforce app‑level elevation instead of account‑level admin.

Appliance‑based Password Safe hosted in Azure (single tenant). Outbound 443 only; no inbound firewall exposure. Resource Broker used for credential discovery and management. Jump Point architecture avoids agent sprawl.https://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=a1246b75-0fc3-e611-80f6-0050569574e0 Session recordings retained ~90 days. Credential injection removes need for copy/paste. PRA supports web and thick‑client access. Licensing can be asset‑based or user‑based; flexibility discussed. Integration potential with Entra ID, Okta, Duo, Ping. MFA challenges exist for shared accounts, reinforcing need for vaulted credentials. EPM policies enforce app‑level elevation instead of account‑level admin. List all speakers / Participants (Roles Only)

Mark Stevenson – ProPetro, Senior IT / Operations Leader Morgan Grimes – ProPetro, IT Decision Maker Shane Wright – ProPetro, Field / Operations IT Lead Tony Villalanti – SHI, Account Executive John Marsh – BeyondTrust, Sales Leadership Al Bridges – BeyondTrust, Sales Engineer Alex Padron – ProPetro, Executive Stakeholder (partial attendance)

Mark Stevenson – ProPetro, Senior IT / Operations Leader Morgan Grimes – ProPetro, IT Decision Maker Shane Wright – ProPetro, Field / Operations IT Lead Tony Villalanti – SHI, Account Executive John Marsh – BeyondTrust, Sales Leadership Al Bridges – BeyondTrust, Sales Engineer Alex Padron – ProPetro, Executive Stakeholder (partial attendance)

Potential Next Steps

Initiate BeyondTrust POC

Who: Tony Villalanti → John Marsh / Al Bridges Involved: ProPetro IT (Morgan, Shane), BeyondTrust SE team

Define Success Criteria for POC

Who: Mark Stevenson & Morgan Grimes Involved: SHI, BeyondTrust

Validate Identity Integration Path (SSO / Self‑Service Reset)

Who: Tony Villalanti Involved: SHI identity SME, ProPetro IT, Okta/Duo stakeholders

Confirm Licensing Model (Asset vs User)

Who: Morgan Grimes with BeyondTrust Involved: Finance / Executive visibility

Phased Rollout Strategy

Who: ProPetro IT Plan: Pro Power first (crawl), Frac later (run)

Initiate BeyondTrust POC

Who: Tony Villalanti → John Marsh / Al Bridges Involved: ProPetro IT (Morgan, Shane), BeyondTrust SE team

Who: Tony Villalanti → John Marsh / Al Bridges Involved: ProPetro IT (Morgan, Shane), BeyondTrust SE team Define Success Criteria for POC

Who: Mark Stevenson & Morgan Grimes Involved: SHI, BeyondTrust

Who: Mark Stevenson & Morgan Grimes Involved: SHI, BeyondTrust Validate Identity Integration Path (SSO / Self‑Service Reset)

Who: Tony Villalanti Involved: SHI identity SME, ProPetro IT, Okta/Duo stakeholders

Who: Tony Villalanti Involved: SHI identity SME, ProPetro IT, Okta/Duo stakeholders Confirm Licensing Model (Asset vs User)

Who: Morgan Grimes with BeyondTrust Involved: Finance / Executive visibility

Who: Morgan Grimes with BeyondTrust Involved: Finance / Executive visibility Phased Rollout Strategy

Who: ProPetro IT Plan: Pro Power first (crawl), Frac later (run)

Who: ProPetro IT Plan: Pro Power first (crawl), Frac later (run)
