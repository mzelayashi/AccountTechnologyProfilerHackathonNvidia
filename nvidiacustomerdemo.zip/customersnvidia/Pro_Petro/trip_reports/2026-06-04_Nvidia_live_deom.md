Trip Report | Nvidia live deom | Pro Petro

Customer: Pro Petro
AE: Tony V
Topic: Nvidia live deom
Meeting Date 06/04/2026

*Internal notes – Please read and edit before sending externally*

Summary

SHI and NVIDIA met with ProPetro to demonstrate an AI-assisted operations center / predictive maintenance concept for oilfield operations and to test whether there is a credible path to applying AI beyond desktop productivity into real operational workflows. The customer’s core business objectives were clearly stated as reducing human exposure in the field, improving safety, keeping pace with larger competitors such as Halliburton, and identifying AI use cases that create measurable operational value rather than generic “AI marketing.” ProPetro’s IT leadership made it clear that they are already active in AI at the enterprise level, with an AI committee, tools such as Copilot and Claude, note-taking assistants, and ongoing attempts to place AI-enabled tools in employees’ hands. However, the more important strategic interest is operational AI: AI that can ingest telemetry, monitor equipment, support real-time decision-making, and potentially guide or automate field operations. The demo showed a generalized AI workflow using simulated telemetry, alerts, risk scoring, pending approvals, and a chatbot for summarization and diagnostics. SHI positioned this as “art of the possible”, not a finished product or off-the-shelf solution. That distinction became the central theme of the call: ProPetro wants to see real proof of delivery, working examples, highlight reels, and evidence of business outcomes before committing executive time, travel, or political capital internally. ProPetro confirmed they are already rolling out an equipment health monitoring system with IoT devices, data collectors, and a platform that analyzes equipment

Agenda

Introductions across SHI, NVIDIA, and ProPetro Demo of an AI-assisted operations center concept for field/oil-and-gas style workflows Discussion of how AI recommendations would be trained, grounded, and governed Discussion of telemetry ingestion, IoT/sensor architecture, and cloud/data platform patterns Comparison of the demo against ProPetro’s existing equipment health monitoring efforts Exploration of broader AI

opportunities beyond predictive maintenance

Discussion of engagement model, workshops, prototypes, visits to SHI / NVIDIA facilities, and next steps

Introductions across SHI, NVIDIA, and ProPetro Demo of an AI-assisted operations center concept for field/oil-and-gas style workflows Discussion of how AI recommendations would be trained, grounded, and governed Discussion of telemetry ingestion, IoT/sensor architecture, and cloud/data platform patterns Comparison of the demo against ProPetro’s existing equipment health monitoring efforts Exploration of broader AI

opportunities beyond predictive maintenance

Discussion of engagement model, workshops, prototypes, visits to SHI / NVIDIA facilities, and next steps

Opps Identified & BANTC

Opportunity 1: AI-Assisted Predictive Maintenance /
Operations Monitoring for Field Equipment

Opportunity Description: Build or prototype a ProPetro-specific AI layer that ingests field telemetry, identifies anomalies, summarizes operational conditions, recommends next actions, and supports human approval workflows for maintenance or safety-related events. B: Budget was not explicitly confirmed. SHI raised concerns around AI compute cost, token consumption, and the tradeoff between using hosted models versus custom/on-prem/cloud AI infrastructure. This indicates budget sensitivity exists, but no funding commitment was made. A: Alex Padron (IT Manager, ProPetro) is a key technical and internal influencer, but not the final economic buyer. He stated he would need to socialize outcomes with his boss, additional managers/directors, and potentially a VP. Cory and operations stakeholders were referenced as likely decision participants. N: The need is real but nuanced. ProPetro wants AI for operational value, especially to reduce human exposure, improve safety, and stay competitive. However, Alex indicated ProPetro already has a related equipment health monitoring initiative in progress, so the need is not for generic predictive maintenance alone, but for a more differentiated and operationally relevant AI outcome. T: No hard timeline was committed. Immediate next step is internal review of the recording and discussion with stakeholders. Timing appears exploratory but active. C: Competition includes:

Internal ProPetro development and existing data/equipment health monitoring efforts Existing or previous vendor-led solutions, including prior AI camera/safety work Large AI vendors / platforms already in the enterprise toolset The customer’s internal skepticism toward AI marketing claims, which is a major credibility barrier

Opportunity Description: Build or prototype a ProPetro-specific AI layer that ingests field telemetry, identifies anomalies, summarizes operational conditions, recommends next actions, and supports human approval workflows for maintenance or safety-related events. B: Budget was not explicitly confirmed. SHI raised concerns around AI compute cost, token consumption, and the tradeoff between using hosted models versus custom/on-prem/cloud AI infrastructure. This indicates budget sensitivity exists, but no funding commitment was made. A: Alex Padron (IT Manager, ProPetro) is a key technical and internal influencer, but not the final economic buyer. He stated he would need to socialize outcomes with his boss, additional managers/directors, and potentially a VP. Cory and operations stakeholders were referenced as likely decision participants. N: The need is real but nuanced. ProPetro wants AI for operational value, especially to reduce human exposure, improve safety, and stay competitive. However, Alex indicated ProPetro already has a related equipment health monitoring initiative in progress, so the need is not for generic predictive maintenance alone, but for a more differentiated and operationally relevant AI outcome. T: No hard timeline was committed. Immediate next step is internal review of the recording and discussion with stakeholders. Timing appears exploratory but active. C: Competition includes:

Internal ProPetro development and existing data/equipment health monitoring efforts Existing or previous vendor-led solutions, including prior AI camera/safety work Large AI vendors / platforms already in the enterprise toolset The customer’s internal skepticism toward AI marketing claims, which is a major credibility barrier

Internal ProPetro development and existing data/equipment health monitoring efforts Existing or previous vendor-led solutions, including prior AI camera/safety work Large AI vendors / platforms already in the enterprise toolset The customer’s internal skepticism toward AI marketing claims, which is a major credibility barrier
Opportunity 2: Broader Operational AI Platform for
ProPetro (Subsurface Modeling, Safety, Robotics, Workflow AI, Real-Time Advisory)

Opportunity Description: Position SHI/NVIDIA as the design/build partner for a longer-term operational AI strategy that could include subsurface modeling, multi-agent workflows, field safety analysis, robotics integration, operational copilots, and custom AI applications driven by ProPetro telemetry and business logic. B: No approved budget. SHI framed this as likely requiring phased services, prototypes, infrastructure decisions, and AI compute planning. There is no visible committed spend yet. A: Alex can sponsor technical exploration and bring ideas to the AI committee and broader leadership, but authority likely extends to operations leaders, directors, VP-level stakeholders, and possibly business-side subject matter experts. N: Strong strategic need exists. Alex explicitly asked what AI can do beyond desktop productivity and routine predictive maintenance. ProPetro wants to connect AI directly to operations and create real-time consultative or action-oriented systems that improve efficiency, safety, and business performance. T: Medium-term

Initiatives

Operational AI for field operations and equipment monitoring

Type: Neither Security nor Storage (primary) Focus: telemetry analysis, anomaly detection, AI-assisted decisioning, approvals, field summaries

Reduce human exposure in the field

Type: Security Focus: safety improvement, fewer people exposed to dangerous zones, better remote insight and intervention

AI-enabled safety monitoring / PPE / red-zone / fire detection use cases

Type: Security Focus: computer vision, safety alerts, non-compliance detection, possible fire detection scenarios

Enterprise AI enablement for employee productivity

Type: Neither Security nor Storage Focus: Copilot, Claude, note-taking, meeting recap, email assistance, employee efficiency

Exploration of subsurface modeling / advanced operational modeling

Type: Neither Security nor Storage Focus: operations optimization, simulation, real-time analysis, potentially production improvements

AI workflow automation for repetitive business processes

Type: Neither Security nor Storage Focus: automation of repetitive communications and business workflows

Operational AI for field operations and equipment monitoring

Type: Neither Security nor Storage (primary) Focus: telemetry analysis, anomaly detection, AI-assisted decisioning, approvals, field summaries

Type: Neither Security nor Storage (primary) Focus: telemetry analysis, anomaly detection, AI-assisted decisioning, approvals, field summaries Reduce human exposure in the field

Type: Security Focus: safety improvement, fewer people exposed to dangerous zones, better remote insight and intervention

Type: Security Focus: safety improvement, fewer people exposed to dangerous zones, better remote insight and intervention AI-enabled safety monitoring / PPE / red-zone / fire detection use cases

Type: Security Focus: computer vision, safety alerts, non-compliance detection, possible fire detection scenarios

Type: Security Focus: computer vision, safety alerts, non-compliance detection, possible fire detection scenarios Enterprise AI enablement for employee productivity

Type: Neither Security nor Storage Focus: Copilot, Claude, note-taking, meeting recap, email assistance, employee efficiency

Type: Neither Security nor Storage Focus: Copilot, Claude, note-taking, meeting recap, email assistance, employee efficiency Exploration of subsurface modeling / advanced operational modeling

Type: Neither Security nor Storage Focus: operations optimization, simulation, real-time analysis, potentially production improvements

Type: Neither Security nor Storage Focus: operations optimization, simulation, real-time analysis, potentially production improvements AI workflow automation for repetitive business processes

Type: Neither Security nor Storage Focus: automation of repetitive communications and business workflows

Type: Neither Security nor Storage Focus: automation of repetitive communications and business workflows

Tech Profile Updates

ProPetro currently appears to have:

An AI committee Enterprise AI tools deployed or being tested, including Copilot and Claude Note-taking / meeting summarization tools An existing or ongoing equipment health monitoring rollout with IoT devices, collectors, and a backend analysis platform Existing telemetry/data collection in operational environments Prior attempts at AI camera monitoring for safety protocol enforcement (PPE / red-zone awareness), but it did not stick Exposure to prior custom AI efforts such as PumpGPT Azure cloud mentioned as a likely telemetry collection environment or relevant cloud context

SHI/NVIDIA positioned:

Multi-agent AI architectures RAG / prompt-grounded AI workflows Cloud or on-prem AI deployment options NVIDIA-backed AI solution design and infrastructure alignment Robotics / quadruped inspection concepts AI workshops, prototype engagements, and executive lab/center visits

ProPetro currently appears to have:

An AI committee Enterprise AI tools deployed or being tested, including Copilot and Claude Note-taking / meeting summarization tools An existing or ongoing equipment health monitoring rollout with IoT devices, collectors, and a backend analysis platform Existing telemetry/data collection in operational environments Prior attempts at AI camera monitoring for safety protocol enforcement (PPE / red-zone awareness), but it did not stick Exposure to prior custom AI efforts such as PumpGPT Azure cloud mentioned as a likely telemetry collection environment or relevant cloud context

An AI committee Enterprise AI tools deployed or being tested, including Copilot and Claude Note-taking / meeting summarization tools An existing or ongoing equipment health monitoring rollout with IoT devices, collectors, and a backend analysis platform Existing telemetry/data collection in operational environments Prior attempts at AI camera monitoring for safety protocol enforcement (PPE / red-zone awareness), but it did not stick Exposure to prior custom AI efforts such as PumpGPT Azure cloud mentioned as a likely telemetry collection environment or relevant cloud context SHI/NVIDIA positioned:

Multi-agent AI architectures RAG / prompt-grounded AI workflows Cloud or on-prem AI deployment options NVIDIA-backed AI solution design and infrastructure alignment Robotics / quadruped inspection concepts AI workshops, prototype engagements, and executive lab/center visits

Multi-agent AI architectures RAG / prompt-grounded AI workflows Cloud or on-prem AI deployment options NVIDIA-backed AI solution design and infrastructure alignment Robotics / quadruped inspection concepts AI workshops, prototype engagements, and executive lab/center visits

Meeting Notes

Environment

Meeting type: Microsoft Teams Participants included SHI, NVIDIA, and ProPetro Demo environment:

Simulated AI operations dashboard Simulated telemetry feeds Risk scoring, alerts, asset status, live data feeds Chat interface for situational summaries and diagnostics

Technical Notes

Demo was described as an AI-assisted operations center for gas/oilfield-style workflows. Dashboard capabilities included:

map-based unit visibility risk indicators compressor issue visibility gas leak/explosion-style detection events AI confidence scoring estimated intervention windows pending approval workflows action logs operational constraints display live streaming data panels asset status overview chatbot-based summarization and troubleshooting

Data in the demo was explicitly stated to be 100% simulated. AI recommendation methods discussed:

fine-tuned model RAG approach using manuals / documentation / reference content direct prompting with job/response instructions multi-agent system where agents validate or distribute analytical work human approval loops and thumbs-up / thumbs-down feedback as knowledge refinement

Alex’s technical concern:

AI will not inherently understand domain-specific meaning unless grounded in rules, reference data, or SME-supplied context example given: high RPMs in a car do not inherently mean something without thresholds, operating context, and expected action definitions

Jeff’s response:

some telemetry systems already flag conditions in structured ways AI can layer workflow orchestration and contextual response on top for more nuanced conditions, SMEs must define what constitutes a problem and which actions should follow

Data ingestion architecture discussed:

field equipment generates telemetry IoT devices/sensors collect data data collector / upstream pattern sends telemetry to a cloud platform possible destinations include storage account, database, or message queue streaming data processing is a common pattern

Manuel’s specific field architecture suggestion:

LoRa / long-range wide area network sensors for open-field deployments LoRa gateway gathering sensor traffic without each sensor needing direct internet access gateway connected via cellular or WAN to push data upstream

environment disclosed

ProPetro already has an equipment health monitoring project uses IoT devices and a collector data is pushed to a platform for analysis architecture is conceptually similar to demoed predictive maintenance flow

Additional advanced technical themes mentioned:

autonomous drilling downhole plus surface sensor correlation subsurface modeling / digital twin concepts robotic quadrupeds for inspection or leak/safety use cases computer vision for PPE / red-zone / safety enforcement fire detection using cameras

AI infrastructure / economics discussion:

concern raised around token consumption if relying heavily on hosted model APIs suggestion that larger organizations may consider building/hosting their own models in cloud or on-prem environments NVIDIA relevance positioned around GPU-backed AI compute and architecture choices

Business-process AI discussion:

AI can be effective in repetitive, scalable workflow automation, such as high-volume email or low-complexity business interactions SHI positioned this as an area of strong ROI based on internal experience

Demo was described as an AI-assisted operations center for gas/oilfield-style workflows. Dashboard capabilities included:

map-based unit visibility risk indicators compressor issue visibility gas leak/explosion-style detection events AI confidence scoring estimated intervention windows pending approval workflows action logs operational constraints display live streaming data panels asset status overview chatbot-based summarization and troubleshooting

map-based unit visibility risk indicators compressor issue visibility gas leak/explosion-style detection events AI confidence scoring estimated intervention windows pending approval workflows action logs operational constraints display live streaming data panels asset status overview chatbot-based summarization and troubleshooting Data in the demo was explicitly stated to be 100% simulated. AI recommendation methods discussed:

fine-tuned model RAG approach using manuals / documentation / reference content direct prompting with job/response instructions multi-agent system where agents validate or distribute analytical work human approval loops and thumbs-up / thumbs-down feedback as knowledge refinement

fine-tuned model RAG approach using manuals / documentation / reference content direct prompting with job/response instructions multi-agent system where agents validate or distribute analytical work human approval loops and thumbs-up / thumbs-down feedback as knowledge refinement Alex’s technical concern:

AI will not inherently understand domain-specific meaning unless grounded in rules, reference data, or SME-supplied context example given: high RPMs in a car do not inherently mean something without thresholds, operating context, and expected action definitions

AI will not inherently understand domain-specific meaning unless grounded in rules, reference data, or SME-supplied context example given: high RPMs in a car do not inherently mean something without thresholds, operating context, and expected action definitions Jeff’s response:

some telemetry systems already flag conditions in structured ways AI can layer workflow orchestration and contextual response on top for more nuanced conditions, SMEs must define what constitutes a problem and which actions should follow

some telemetry systems already flag conditions in structured ways AI can layer workflow orchestration and contextual response on top for more nuanced conditions, SMEs must define what constitutes a problem and which actions should follow Data ingestion architecture discussed:

field equipment generates telemetry IoT devices/sensors collect data data collector / upstream pattern sends telemetry to a cloud platform possible destinations include storage account, database, or message queue streaming data processing is a common pattern

field equipment generates telemetry IoT devices/sensors collect data data collector / upstream pattern sends telemetry to a cloud platform possible destinations include storage account, database, or message queue streaming data processing is a common pattern Manuel’s specific field architecture suggestion:

LoRa / long-range wide area network sensors for open-field deployments LoRa gateway gathering sensor traffic without each sensor needing direct internet access gateway connected via cellular or WAN to push data upstream

LoRa / long-range wide area network sensors for open-field deployments LoRa gateway gathering sensor traffic without each sensor needing direct internet access gateway connected via cellular or WAN to push data upstream

environment disclosed

ProPetro already has an equipment health monitoring project uses IoT devices and a collector data is pushed to a platform for analysis architecture is conceptually similar to demoed predictive maintenance flow

ProPetro already has an equipment health monitoring project uses IoT devices and a collector data is pushed to a platform for analysis architecture is conceptually similar to demoed predictive maintenance flow Additional advanced technical themes mentioned:

autonomous drilling downhole plus surface sensor correlation subsurface modeling / digital twin concepts robotic quadrupeds for inspection or leak/safety use cases computer vision for PPE / red-zone / safety enforcement fire detection using cameras

autonomous drilling downhole plus surface sensor correlation subsurface modeling / digital twin concepts robotic quadrupeds for inspection or leak/safety use cases computer vision for PPE / red-zone / safety enforcement fire detection using cameras AI infrastructure / economics discussion:

concern raised around token consumption if relying heavily on hosted model APIs suggestion that larger organizations may consider building/hosting their own models in cloud or on-prem environments NVIDIA relevance positioned around GPU-backed AI compute and architecture choices

concern raised around token consumption if relying heavily on hosted model APIs suggestion that larger organizations may consider building/hosting their own models in cloud or on-prem environments NVIDIA relevance positioned around GPU-backed AI compute and architecture choices Business-process AI discussion:

AI can be effective in repetitive, scalable workflow automation, such as high-volume email or low-complexity business interactions SHI positioned this as an area of strong ROI based on internal experience

AI can be effective in repetitive, scalable workflow automation, such as high-volume email or low-complexity business interactions SHI positioned this as an area of strong ROI based on internal experience

ROLES

Alex Padron — IT Manager, ProPetro Services

Covers desktop support, infrastructure, cybersecurity, compliance, and operational technology Primary customer technical stakeholder and internal influencer for AI conversations

Tony Villalanti — Account Executive, SHI

Customer-facing sales lead/account owner for ProPetro Coordinated the meeting and positioned SHI resources

Manuel Zelaya — Solutions Engineer / Core SE, SHI

Primary technical support resource aligned to the account Contributed architecture ideas around telemetry collection, LoRa, and AI strategy

Jeff Schedin — Lead, Applied AI Practice, SHI

Presented the demo Spoke to AI app development, multi-agent design, data/AI integration, and prototype methodology

John Lefeber — AI Pursuit / Advanced Growth Technologies (AGT), SHI

AI-focused resource helping sales teams navigate AI opportunities and bring in specialized support

Greg Miller — Solutions Director, SHI

Leader over SHI generalist engineers in the regional organization Present as leadership/engineering support

Sirisha Rella — Solutions Architect, NVIDIA

Covers GenAI and Agent AI technologies Works with partners to enable and create services using NVIDIA technologies

Stephen Drake — SHI team member / sales leadership support

Participated heavily in positioning and framing the engagement Exact formal title was not explicitly stated in the transcript

Alex Padron — IT Manager, ProPetro Services

Covers desktop support, infrastructure, cybersecurity, compliance, and operational technology Primary customer technical stakeholder and internal influencer for AI conversations

Covers desktop support, infrastructure, cybersecurity, compliance, and operational technology Primary customer technical stakeholder and internal influencer for AI conversations Tony Villalanti — Account Executive, SHI

Customer-facing sales lead/account owner for ProPetro Coordinated the meeting and positioned SHI resources

Customer-facing sales lead/account owner for ProPetro Coordinated the meeting and positioned SHI resources Manuel Zelaya — Solutions Engineer / Core SE, SHI

Primary technical support resource aligned to the account Contributed architecture ideas around telemetry collection, LoRa, and AI strategy

Primary technical support resource aligned to the account Contributed architecture ideas around telemetry collection, LoRa, and AI strategy Jeff Schedin — Lead, Applied AI Practice, SHI

Presented the demo Spoke to AI app development, multi-agent design, data/AI integration, and prototype methodology

Presented the demo Spoke to AI app development, multi-agent design, data/AI integration, and prototype methodology John Lefeber — AI Pursuit / Advanced Growth Technologies (AGT), SHI

AI-focused resource helping sales teams navigate AI opportunities and bring in specialized support

AI-focused resource helping sales teams navigate AI opportunities and bring in specialized support Greg Miller — Solutions Director, SHI

Leader over SHI generalist engineers in the regional organization Present as leadership/engineering support

Leader over SHI generalist engineers in the regional organization Present as leadership/engineering support Sirisha Rella — Solutions Architect, NVIDIA

Covers GenAI and Agent AI technologies Works with partners to enable and create services using NVIDIA technologies

Covers GenAI and Agent AI technologies Works with partners to enable and create services using NVIDIA technologies Stephen Drake — SHI team member / sales leadership support

Participated heavily in positioning and framing the engagement Exact formal title was not explicitly stated in the transcript

Participated heavily in positioning and framing the engagement Exact formal title was not explicitly stated in the transcript

Potential Next steps

Alex Padron → internal ProPetro stakeholders (including boss/Cory/operations leadership as applicable)

Review and share the meeting recording internally Determine whether stakeholders are receptive to deeper AI discussions Use the recording as an internal awareness/qualification asset

Tony Villalanti ↔ Alex Padron

Discuss next steps during their next touchpoint Decide whether to schedule a follow-up meeting with better alignment to ProPetro priorities Participants: Tony, Alex

SHI team → ProPetro

Provide more concrete examples of past AI work, preferably anonymized but outcome-oriented Focus on problem solved, approach used, and business deliverable, since Alex explicitly asked for proof points and “highlight reel” style evidence Participants: Tony, Jeff, John, Stephen, Manuel, Alex

Potential follow-up workshop

SHI proposed a free use-case workshop to identify and define ProPetro-specific AI use cases This would likely involve ProPetro SMEs from IT, operations, and possibly safety/data teams Participants: Jeff, Tony, Manuel, Alex, ProPetro SMEs, possibly NVIDIA

More tailored virtual session before any travel

Tony suggested additional virtual discussions rather than jumping straight to an on-site visit Objective would be to refine the use case and reduce risk before asking executives to travel Participants: Tony, Alex, relevant SHI/NVIDIA technical leads

Potential NVIDIA follow-up call

John offered a separate conversation with NVIDIA partner managers/resources who could explain what visiting NVIDIA HQ would involve and how those engagements are customized Participants mentioned: John, NVIDIA resources, Alex, possibly Tony

Customer

environment alignment session

Alex suggested Tony should see the existing ProPetro equipment health monitoring platform/demo because it is similar in concept to what was shown This would help SHI avoid overlapping with what ProPetro already has and instead identify unmet needs Participants: Alex, Tony, possibly Manuel / Jeff

Refine opportunity toward higher-value use cases

Based on customer feedback, SHI should shift the conversation beyond generic predictive maintenance and toward:

operational AI advisory subsurface modeling concepts safety/computer vision robotics/inspection workflow automation

Participants: SHI AI team, Alex, ProPetro operations/safety/data stakeholders

Alex Padron → internal ProPetro stakeholders (including boss/Cory/operations leadership as applicable)

Review and share the meeting recording internally Determine whether stakeholders are receptive to deeper AI discussions Use the recording as an internal awareness/qualification asset

Review and share the meeting recording internally Determine whether stakeholders are receptive to deeper AI discussions Use the recording as an internal awareness/qualification asset Tony Villalanti ↔ Alex Padron

Discuss next steps during their next touchpoint Decide whether to schedule a follow-up meeting with better alignment to ProPetro priorities Participants: Tony, Alex

Discuss next steps during their next touchpoint Decide whether to schedule a follow-up meeting with better alignment to ProPetro priorities Participants: Tony, Alex SHI team → ProPetro

Provide more concrete examples of past AI work, preferably anonymized but outcome-oriented Focus on problem solved, approach used, and business deliverable, since Alex explicitly asked for proof points and “highlight reel” style evidence Participants: Tony, Jeff, John, Stephen, Manuel, Alex

Provide more concrete examples of past AI work, preferably anonymized but outcome-oriented Focus on problem solved, approach used, and business deliverable, since Alex explicitly asked for proof points and “highlight reel” style evidence Participants: Tony, Jeff, John, Stephen, Manuel, Alex Potential follow-up workshop

SHI proposed a free use-case workshop to identify and define ProPetro-specific AI use cases This would likely involve ProPetro SMEs from IT, operations, and possibly safety/data teams Participants: Jeff, Tony, Manuel, Alex, ProPetro SMEs, possibly NVIDIA

SHI proposed a free use-case workshop to identify and define ProPetro-specific AI use cases This would likely involve ProPetro SMEs from IT, operations, and possibly safety/data teams Participants: Jeff, Tony, Manuel, Alex, ProPetro SMEs, possibly NVIDIA More tailored virtual session before any travel

Tony suggested additional virtual discussions rather than jumping straight to an on-site visit Objective would be to refine the use case and reduce risk before asking executives to travel Participants: Tony, Alex, relevant SHI/NVIDIA technical leads

Tony suggested additional virtual discussions rather than jumping straight to an on-site visit Objective would be to refine the use case and reduce risk before asking executives to travel Participants: Tony, Alex, relevant SHI/NVIDIA technical leads Potential NVIDIA follow-up call

John offered a separate conversation with NVIDIA partner managers/resources who could explain what visiting NVIDIA HQ would involve and how those engagements are customized Participants mentioned: John, NVIDIA resources, Alex, possibly Tony

John offered a separate conversation with NVIDIA partner managers/resources who could explain what visiting NVIDIA HQ would involve and how those engagements are customized Participants mentioned: John, NVIDIA resources, Alex, possibly Tony Customer

environment alignment session

Alex suggested Tony should see the existing ProPetro equipment health monitoring platform/demo because it is similar in concept to what was shown This would help SHI avoid overlapping with what ProPetro already has and instead identify unmet needs Participants: Alex, Tony, possibly Manuel / Jeff

Alex suggested Tony should see the existing ProPetro equipment health monitoring platform/demo because it is similar in concept to what was shown This would help SHI avoid overlapping with what ProPetro already has and instead identify unmet needs Participants: Alex, Tony, possibly Manuel / Jeff Refine opportunity toward higher-value use cases

Based on customer feedback, SHI should shift the conversation beyond generic predictive maintenance and toward:

operational AI advisory subsurface modeling concepts safety/computer vision robotics/inspection workflow automation

Participants: SHI AI team, Alex, ProPetro operations/safety/data stakeholders

Based on customer feedback, SHI should shift the conversation beyond generic predictive maintenance and toward:

operational AI advisory subsurface modeling concepts safety/computer vision robotics/inspection workflow automation

operational AI advisory subsurface modeling concepts safety/computer vision robotics/inspection workflow automation Participants: SHI AI team, Alex, ProPetro operations/safety/data stakeholders
