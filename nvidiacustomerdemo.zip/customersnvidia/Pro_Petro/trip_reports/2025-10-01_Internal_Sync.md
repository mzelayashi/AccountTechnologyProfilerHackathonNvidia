Trip Report | Internal Sync | Pro Petro

Customer: Pro Petro
AE: Tony V
Topic: Internal Sync
Meeting Date 10/01/2025

*Internal notes – Please read and edit before sending externally*

Summary

Summary

• The meeting focused on a customer’s need to replace
their outdated proprietary AI system (“pump GPT”) with a more modern solution, evaluating options such as Microsoft Copilot, Glean, and custom LLM builds. The customer is a Microsoft-centric organization, interested in leveraging Copilot for its integration with their existing tools (SharePoint, Teams, etc.), but remains open to other solutions if they provide greater value. Key business drivers include improving data management, enabling advanced chatbot functionality (especially for HR and internal use), and reducing the maintenance burden of their current system. The discussion covered engagement models, cost structures, technical hosting options (cloud vs. on-prem), and the importance of flexibility due to a volatile workforce. The vendor outlined their process for prototyping and deploying AI solutions, including timelines, pricing, and post-deployment considerations. Action items were identified around scheduling a technical deep-dive, clarifying licensing, and gathering

infrastructure cost estimates.

Agenda

• Review customer’s current AI system and pain points
• Discuss requirements for new AI/chatbot solution
• Evaluate Copilot, Glean, and custom LLM options
• Explore engagement models, pricing, and technical
hosting
• Identify next steps and action items

Opps Identified & BANTC

Opportunity 1: Rip-and-replace of
proprietary AI system (pump GPT) with modern AI/chatbot solution
• B: Customer (Microsoft shop, using SharePoint,
Teams, NetSuite, Workday)
• A: Decision-makers present; open to Copilot, Glean,
or custom LLM; want improved integration and reduced maintenance
• N: Outdated model, limited knowledge base, need for
better data management and chatbot capabilities
• T: Flexible; initial 2-week to 6-week engagement for
prototyping, with longer-term adoption possible
• C: Budget discussed ($60K per 2 weeks, $180-200K for
6 weeks for custom build; Glean as a leasing model; infrastructure costs TBD)

Initiatives

• Security: Considered due to cloud hosting, data
access, and integration with HR systems
• Storage: Discussed in context of data lakes,
categorization, and integration with cloud platforms (Azure, AWS)

Tech Profile Updates

• Customer is cloud-based (Azure, AWS), no on-prem
data center
• Heavy Microsoft 365 usage (E3/E5 licenses, piloting
higher licenses, but not full Copilot deployment)
• Uses NetSuite and Workday for HR and finance
• Existing AI system is proprietary, on-prem, and
outdated

Meeting Notes

Environment

• All systems are cloud-hosted (Azure, AWS)
• No on-premises data center
• Volatile workforce; preference for flexible,
scalable solutions

Detailed Discussion

• Customer’s current AI (pump GPT) is outdated,
trained on old data, and not maintained
• Interest in Copilot due to Microsoft integration,
but open to alternatives (Glean, custom LLM)
• Glean offers a leasing model with many integrations,
less maintenance, but higher long-term cost
• Custom LLM build via vendor’s Cyber Labs offers
ownership, flexibility, and lower long-term cost, but requires internal support
• Engagement models: 2-week (simple RAG/chatbot),
6-week (full build/training), up to 12 weeks for complex data scenarios
• Pricing: $60K per 2 weeks; $180-200K for 6-week
engagement; Glean is a leasing model
• Post-deployment: Customer must host solution (cloud
or on-prem); vendor does not provide ongoing hosting
• Data management and categorization are key
requirements; engagement includes data review and organization
• Integration with HR systems (Workday, NetSuite) is
important for chatbot use cases
• Licensing: Need to confirm Copilot and M365 license
status
• Action items: Schedule technical call with Microsoft
Copilot expert (Zach Shelton), gather infrastructure cost estimates, clarify licensing

Technical Notes

• Current AI model is proprietary, on-prem, trained on
data up to 2022/2023, not updated
• Customer uses cloud (Azure, AWS), no on-prem DC
• Chatbot use cases are primarily internal (HR,
document management)
• Glean: SaaS, many integrations, leasing model, less
maintenance
• Custom LLM: Built/tested in vendor’s Cyber Labs, can
be hosted on customer’s cloud, requires customer support post-deployment
• Engagement includes data review, organization, and
integration
• Pricing: $60K per 2 weeks, $180-200K for 6 weeks;
Glean is a leasing model

ROLES

• John Lefeber – SHI, AI solutions/engagement lead
• Tony Villalanti –
• Manuel Zelaya –
• Zach Shelton – SHI Microsoft Copilot expert (to be
invited for technical deep-dive)
• James Moody – SHI Glean specialist/BDM (potential
resource for deeper Glean discussion)

Potential Next steps

• Tony to schedule a 30-minute technical call with
John and Zach Shelton to discuss Copilot and integration options
• Tony to gather and provide details on customer’s
current Microsoft 365 and Copilot licensing status
• John to check with internal resources for
post-deployment infrastructure cost estimates (cloud/on-prem)
• Tony to gauge customer’s interest in Glean before
involving James Moody for a deeper discussion
• Manuel to request redacted build-out/pricing
examples for small-scale deployment from John
• John to provide any available documentation or
examples on post-deployment infrastructure r
