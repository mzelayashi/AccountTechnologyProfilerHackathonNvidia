Trip Report | AI security | Pro Petro

Customer: Pro Petro
AE: Tony V
Topic: AI security
Meeting Date 05/05/2026

*Internal notes – Please read and edit before sending externally*

Summary

Summary

• This session
was a deep technical and strategic discovery focused on helping ProPetro rapidly establish AI security guardrails and governance in response to uncontrolled AI adoption across the organization.
• ProPetro is
currently experiencing AI sprawl, driven by executive demand, employee curiosity, and decentralized purchasing (users buying tools independently), resulting in limited visibility, no centralized control, and growing security risk.
• The
organization is using a mix of Microsoft Copilot, multiple third-party LLMs (Claude, ChatGPT, Perplexity, Gemini), and an internal LLM (PumpGPT), but there is no standardized approach or enforcement of approved tools.
• A major
business risk identified is data leakage, especially around financial data due to ProPetro being publicly traded, raising concerns around insider trading exposure and compliance violations.
• The security
team is severely constrained (1 internal resource + Arctic Wolf SOC) and lacks AI-specific monitoring, prompt visibility, and DLP enforcement.
• An AI governance committee exists but is immature,
with unclear ownership, minimal participation, and no defined policies or standards.
• SHI (Tony,
Manuel) and Marcel (AI Security SME) are positioning to help ProPetro define a phased approach:

Immediate: Implement basic guardrails (browser-only, tool restriction, prompt controls) Mid-term: Standardize tools and implement monitoring/DLP Long-term: Mature governance and AI security architecture
• Key technical tension: balancing security control vs business
flexibility, especially with leadership pushing multiple AI tools simultaneously.

Immediate: Implement basic guardrails (browser-only, tool restriction, prompt controls) Mid-term: Standardize tools and implement monitoring/DLP Long-term: Mature governance and AI security architecture
• Key technical tension: balancing security control vs business
flexibility, especially with leadership pushing multiple AI tools simultaneously.

Agenda

• Introductions
and roles
• Review of
current AI usage (Copilot, PumpGPT, third-party tools)
• Identification
of risks (shadow AI, data leakage, lack of visibility)
• Discussion on
AI governance committee and policy gaps
• Exploration of

security guardrails and control mechanisms

• Initial
vendor/tool discussion and approach to selection

Opps Identified & BANTC

Opportunity 1: AI Security Platform (Prompt
Monitoring, Control, Visibility)
• B: Budget not
confirmed; concern raised about high-cost solutions (~$300K reference)
• A: Alex
(primary), Mark (security), Morgan (infra), CEO influence high
• N: Critical
need for visibility into prompts, control of AI usage, and prevention of data leakage
• T: Immediate
urgency due to rapid uncontrolled adoption
• C: Competing
solutions include Area, Zenity, Ricco AI, Prisma AIRS; Arctic Wolf potential consideration
Opportunity 2: AI Governance Framework & Policy
Development
• B:
Advisory-driven; tied to future tooling decisions
• A: Alex
(current sole committee member), Mark (policy), leadership oversight
• N: Define
approved tools, acceptable use policies, governance structure
• T: Immediate
need to prevent further sprawl
• C:
SHI/Stratascale positioned as trusted advisor
Opportunity 3: Data Protection / DLP / Microsoft
Purview Integration
• B: Implied
future investment (Purview mentioned as upcoming initiative)
• A: Mark
(security), Morgan (infra), Alex (strategy)
• N: Prevent
leakage of PII, financials, and sensitive corporate data into AI tools
• T: Near-term as
part of security baseline
• C:
Microsoft-native + overlay AI security tools

Initiatives

• Security: AI
governance, prompt monitoring, shadow AI control, DLP enforcement
• Storage: N/A
(data handling discussed but not storage modernization)

Tech Profile Updates

• Fully
SaaS-based environment (no on-prem workloads)
• Meraki for
networking/firewalls
• Arctic Wolf SOC
(handles low/medium/high alerts, but not AI-specific)
• Microsoft
stack: Azure, Copilot, SharePoint, Power Platform, Fabric, Power BI
• Internal LLM:
PumpGPT (limited usage, unclear long-term viability)
• Azure consent
process used for SaaS visibility (partial control)

Meeting Notes

Environment

• ~1,600 users
• ~50–60 Copilot
users
• ~30–40 PumpGPT
users
• Multiple
third-party AI tools in pilot
• 1 internal

security resource + external SOC

• No centralized
AI monitoring or enforcement

Detailed Discussion

• Marcel
validated current state and highlighted lack of governance and visibility.
• Strong emphasis
on shadow AI risk and inability to track what tools users are accessing.
• ProPetro
acknowledged no clear AI strategy yet and reliance on partners for guidance.
• Manuel
introduced ideas around:

Sandbox environments for AI-generated outputs Enterprise vs public AI access control
• Marcel recommended:
Start simple with browser-only AI usage Block local agent installations Restrict to approved tools via governance
• Discussion on tool standardization vs flexibility:
Manuel: standardize to simplify control Tony: must accommodate CEO-driven tool diversity
• Mark emphasized foundational security configuration and
monitoring, not relying on assumptions.
• Key risk highlighted:
Financial data leakage = potential insider trading implications
• PumpGPT concerns:
Low usage Not fully secured or validated No red teaming completed
• Vendor discussion initiated but deferred pending clarification on
internal LLM strategy

Sandbox environments for AI-generated outputs Enterprise vs public AI access control
• Marcel recommended:
Start simple with browser-only AI usage Block local agent installations Restrict to approved tools via governance
• Discussion on tool standardization vs flexibility:
Manuel: standardize to simplify control Tony: must accommodate CEO-driven tool diversity
• Mark emphasized foundational security configuration and
monitoring, not relying on assumptions.
• Key risk highlighted:
Financial data leakage = potential insider trading implications
• PumpGPT concerns:
Low usage Not fully secured or validated No red teaming completed
• Vendor discussion initiated but deferred pending clarification on
internal LLM strategy

Technical Notes

• No current
prompt-level logging or visibility
• No enforcement
of AI tool restrictions beyond basic firewall capability
• Recommended
controls:

URL blocking of non-approved AI tools Browser-only access No local AI agent installs Block sensitive inputs (PII, financials, source code)
• PumpGPT:
Separate subscription deployment Limited SharePoint integration (manual upload + sync) Controlled via Entra group Not red-teamed or fully validated
• Arctic Wolf:
Monitors general alerts but not AI-specific behavior
• SaaS sprawl:
Users purchasing tools independently via corporate cards
• Data protection gap:
No confirmed DLP enforcement today
• Agentic AI:
Not actively pursued yet Potential future via Power Platform

URL blocking of non-approved AI tools Browser-only access No local AI agent installs Block sensitive inputs (PII, financials, source code)
• PumpGPT:
Separate subscription deployment Limited SharePoint integration (manual upload + sync) Controlled via Entra group Not red-teamed or fully validated
• Arctic Wolf:
Monitors general alerts but not AI-specific behavior
• SaaS sprawl:
Users purchasing tools independently via corporate cards
• Data protection gap:
No confirmed DLP enforcement today
• Agentic AI:
Not actively pursued yet Potential future via Power Platform List all speakers/Participants of Transcript (titles and companies for the folks in the meeting please, should display as just ROLES):
• Manuel Zelaya –
Solutions Architect, SHI
• Tony Villalanti
– Account Executive, SHI
• Marcel Murry –
AI Security / Network Security Specialist, SHI
• Alex Padron –
IT Leadership / AI Governance Lead, ProPetro
• Mark Stevenson
– Cybersecurity Governance, ProPetro
• Morgan Grimes –
Network & Infrastructure Supervisor, ProPetro

Potential Next steps

• Marcel →
ProPetro (Mark, Morgan, Alex)

Deliver 1–2 vetted AI

security platform recommendations

Align options based on prompt monitoring vs full LLM coverage

Deliver 1–2 vetted AI

security platform recommendations

Align options based on prompt monitoring vs full LLM coverage
• ProPetro (Mark
/ Morgan) → Alex

Confirm whether PumpGPT will be retained or sunset Determine if internal LLM must be included in security tooling scope

Confirm whether PumpGPT will be retained or sunset Determine if internal LLM must be included in security tooling scope
• SHI (Tony /
Manuel) → ProPetro

Coordinate follow-up vendor demos based on recommendations Guide phased approach (quick guardrails → long-term architecture)

Coordinate follow-up vendor demos based on recommendations Guide phased approach (quick guardrails → long-term architecture)
• ProPetro
Internal (Alex + Committee)

Expand AI governance committee membership Define approved AI tools list Begin drafting acceptable use policies

Expand AI governance committee membership Define approved AI tools list Begin drafting acceptable use policies
• Joint (SHI +
ProPetro)

Implement initial guardrails:

Browser-only AI usage Restrict to approved tools Block sensitive prompt inputs

Explore DLP / Purview integration

Implement initial guardrails:

Browser-only AI usage Restrict to approved tools Block sensitive prompt inputs

Browser-only AI usage Restrict to approved tools Block sensitive prompt inputs Explore DLP / Purview integration
• Mark → Arctic
Wolf / SHI

Evaluate AI-specific monitoring capabilities Determine need for supplemental tooling

Evaluate AI-specific monitoring capabilities Determine need for supplemental tooling
• Tony ↔ Marcel

Align internally at SHI on recommended vendors and positioning Prepare for next customer-facing session with demos

Align internally at SHI on recommended vendors and positioning Prepare for next customer-facing session with demos
