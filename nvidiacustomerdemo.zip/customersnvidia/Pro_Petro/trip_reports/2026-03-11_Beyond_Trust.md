Trip Report | Beyond Trust | Pro Petro

Customer: Pro Petro
AE: Tony V
Topic: Beyond Trust
Meeting Date 03/11/2026

*Internal notes – Please read and edit before sending externally*

Summary

This call was a deep technical and business-working session between SHI, ProPetro Services, and BeyondTrust focused on solving mission‑critical access, security, and operational continuity challenges across ProPetro’s field and remote operations. The discussion centered on how ProPetro’s end‑users (field technicians, ROC engineers, vendors, and internal IT staff) authenticate, access, and manage systems that directly impact oilfield operations where downtime can exceed $125,000 per hour. The business challenge is a three‑way tension between:

Operational uptime and ease of access for non‑technical field users

Security

and compliance requirements for a public company (credential rotation, auditability, least privilege) IT manageability and accountability, avoiding manual password resets and shared credentials

Operational uptime and ease of access for non‑technical field users

Security

and compliance requirements for a public company (credential rotation, auditability, least privilege) IT manageability and accountability, avoiding manual password resets and shared credentials The technical conversation explored BeyondTrust’s Endpoint Privilege Management (EPM), Password Safe, and Privileged Remote Access (PRA) as a foundation for eliminating shared passwords, enforcing just‑in‑time access, recording sessions, and reducing IT intervention. However, the group also identified a missing identity and authentication layer (SSO, MFA, biometric, or token-based access) needed to complete the end‑to‑end workflow. The meeting concluded with alignment to move forward with a Proof of Concept (POC) focused first on Pro Power (crawl phase), with pricing deferred until functional validation is achieved, and with follow‑up coordination expected across SHI, BeyondTrust, and identity vendors.

Agenda

Review BeyondTrust capabilities from prior demo Deep dive into Endpoint Privilege Management (EPM) and Password Safe Discuss shared accounts, credential rotation, and audit requirements Examine field operations (ROC, Data Vans, Frac fleets, Pro Power) Identify gaps in authentication, SSO, and password reset workflows Define POC scope, success criteria, and next steps

Review BeyondTrust capabilities from prior demo Deep dive into Endpoint Privilege Management (EPM) and Password Safe Discuss shared accounts, credential rotation, and audit requirements Examine field operations (ROC, Data Vans, Frac fleets, Pro Power) Identify gaps in authentication, SSO, and password reset workflows Define POC scope, success criteria, and next steps

Opportunities Identified & BANTC

Opportunity 1: Endpoint Privilege Management (EPM)
Description: Remove local admin rights from ~1050 endpoints while still allowing users to elevate only approved applications and tasks.
B – Budget:
Budget not environment.
C – Competition:
Implicit alternatives include maintaining current local admin model or non‑integrated privilege tools; BeyondTrust positioned as a comprehensive solution.
Opportunity 2: Password Safe + Privileged Remote
Access (PRA) Description: Replace shared credentials and static passwords with vaulted, rotated credentials and recorded remote sessions.
B – Budget:
Deferred; customer explicitly stated not to anchor on pricing yet.
A – Authority:
Same authority group as EPM; decision driven by operational and compliance risk.
N – Need:

Shared accounts currently violate compliance requirements Password changes break productivity No audit trail of who accessed systems and when

Shared accounts currently violate compliance requirements Password changes break productivity No audit trail of who accessed systems and when
T – Timeline:
Aligned with EPM POC; phased approach starting with Pro Power before Frac fleets.
C – Competition:
Current workaround is static shared passwords and manual resets; no effective competing PAM solution identified in use.
Opportunity 3: Identity, SSO, and Self‑Service Access
(Complementary) Description: Introduce SSO, MFA, biometric, or token-based access to prevent login failures when passwords rotate.
B – Budget:
Unknown; outside BeyondTrust scope but acknowledged as necessary.
A – Authority:
IT leadership with cross‑vendor coordination required.
N – Need:

Users must always be able to log in even when passwords rotate Shared accounts cannot support traditional MFA Field users cannot troubleshoot identity failures

Users must always be able to log in even when passwords rotate Shared accounts cannot support traditional MFA Field users cannot troubleshoot identity failures
T – Timeline:
Parallel exploration during BeyondTrust POC.
C – Competition:
Existing Entra self‑service password reset; potential identity vendors include Okta, Duo, Ping.

Initiatives

Security

✅ Storage: ❌ Primary Focus: Security, Identity, Privileged Access, Compliance

Security

✅ Storage: ❌ Primary Focus: Security, Identity, Privileged Access, Compliance

Tech Profile Updates

Heavy use of local shared accounts across field systems Minimal credential rotation due to fear of downtime Reliance on manual IT intervention for password resets Existing Entra ID in place, but insufficient for shared accounts Remote access currently handled via basic screen‑view tools

Heavy use of local shared accounts across field systems Minimal credential rotation due to fear of downtime Reliance on manual IT intervention for password resets Existing Entra ID in place, but insufficient for shared accounts Remote access currently handled via basic screen‑view tools

Meeting Notes

Environment

Oilfield operations with Starlink connectivity Remote Operations Center (ROC) located in Midland, TX Data Vans on‑site at drilling locations Multiple user groups accessing the same machines:

Field technicians (I&E) ROC engineers Pro Power engineers Vendors (limited access)

Oilfield operations with Starlink connectivity Remote Operations Center (ROC) located in Midland, TX Data Vans on‑site at drilling locations Multiple user groups accessing the same machines:

Field technicians (I&E) ROC engineers Pro Power engineers Vendors (limited access)

Field technicians (I&E) ROC engineers Pro Power engineers Vendors (limited access)

Detailed Discussion

Password Safe presented as an appliance‑based, single‑tenant vault, hosted in Azure Only outbound port 443 required Resource Broker deployed in-domain or cloud-based PRA supports Jump Clients and Jump Points for RDP/SSH Session recording retained (video + audit logs) Smart Rules used to auto‑classify assets and accounts Discovery scans identify:

Local users Domain users Services Applications

Approval workflows configurable for credential access PIM comparison discussed but clarified as endpoint vs role-based Key concern: What happens when a user cannot log into the machine at all? Conclusion: PAM alone is insufficient without SSO / identity layer

Password Safe presented as an appliance‑based, single‑tenant vault, hosted in Azure Only outbound port 443 required Resource Broker deployed in-domain or cloud-based PRA supports Jump Clients and Jump Points for RDP/SSH Session recording retained (video + audit logs) Smart Rules used to auto‑classify assets and accounts Discovery scans identify:

Local users Domain users Services Applications

Local users Domain users Services Applications Approval workflows configurable for credential access PIM comparison discussed but clarified as endpoint vs role-based Key concern: What happens when a user cannot log into the machine at all? Conclusion: PAM alone is insufficient without SSO / identity layer

Technical Notes

EPM allows task-based elevation, not full admin access Password Safe rotates credentials automatically and invalidates copied passwords post‑access window PRA injects credentials without exposing passwords to users Supports RDP, SSH, remote sessions with audit trails Shared accounts cannot support standard MFA Vault access requires some initial authentication path Suggested solutions:

Windows Hello (biometric) YubiKey or physical token SSO with MFA tied to personal identity

Field systems often lack redundancy; login failure halts operations Compliance requires password rotation even when productivity suffers POC to be hosted in sandbox (Skytap) to avoid production risk

EPM allows task-based elevation, not full admin access Password Safe rotates credentials automatically and invalidates copied passwords post‑access window PRA injects credentials without exposing passwords to users Supports RDP, SSH, remote sessions with audit trails Shared accounts cannot support standard MFA Vault access requires some initial authentication path Suggested solutions:

Windows Hello (biometric) YubiKey or physical token SSO with MFA tied to personal identity

Windows Hello (biometric) YubiKey or physical token SSO with MFA tied to personal identity Field systems often lack redundancy; login failure halts operations Compliance requires password rotation even when productivity suffers POC to be hosted in sandbox (Skytap) to avoid production risk List all speakers / Participants (Roles Only)

Commercial Solutions Engineer – SHI Commercial Inside Account Executive – SHI IT Leadership / Security Stakeholder – ProPetro Services IT Operations Manager – ProPetro Services Field Operations / Engineering Lead – ProPetro Services Privileged Access Management Specialist – BeyondTrust Sales Engineer – BeyondTrust

Commercial Solutions Engineer – SHI Commercial Inside Account Executive – SHI IT Leadership / Security Stakeholder – ProPetro Services IT Operations Manager – ProPetro Services Field Operations / Engineering Lead – ProPetro Services Privileged Access Management Specialist – BeyondTrust Sales Engineer – BeyondTrust

Potential Next Steps

POC Initiation

Who: SHI (Tony), BeyondTrust (John, Al), ProPetro IT Action: Launch POC for EPM + Password Safe + PRA Scope: Pro Power environment first

Identity Workflow Validation

Who: SHI + ProPetro IT Action: Review SSO, MFA, biometric, and token-based access options Goal: Ensure users can always authenticate regardless of password rotation

Architecture Mapping

Who: BeyondTrust + SHI Action: Diagram end‑to‑end workflow from login → elevation → audit

Operational Impact Assessment

Who: ProPetro IT + Field Ops Action: Define success criteria tied to uptime and reduced IT calls

Deferred Pricing Discussion

Who: BeyondTrust + SHI + ProPetro leadership Trigger: Only after POC proves functional success

POC Initiation

Who: SHI (Tony), BeyondTrust (John, Al), ProPetro IT Action: Launch POC for EPM + Password Safe + PRA Scope: Pro Power environment first

Who: SHI (Tony), BeyondTrust (John, Al), ProPetro IT Action: Launch POC for EPM + Password Safe + PRA Scope: Pro Power environment first Identity Workflow Validation

Who: SHI + ProPetro IT Action: Review SSO, MFA, biometric, and token-based access options Goal: Ensure users can always authenticate regardless of password rotation

Who: SHI + ProPetro IT Action: Review SSO, MFA, biometric, and token-based access options Goal: Ensure users can always authenticate regardless of password rotation Architecture Mapping

Who: BeyondTrust + SHI Action: Diagram end‑to‑end workflow from login → elevation → audit

Who: BeyondTrust + SHI Action: Diagram end‑to‑end workflow from login → elevation → audit Operational Impact Assessment

Who: ProPetro IT + Field Ops Action: Define success criteria tied to uptime and reduced IT calls

Who: ProPetro IT + Field Ops Action: Define success criteria tied to uptime and reduced IT calls Deferred Pricing Discussion

Who: BeyondTrust + SHI + ProPetro leadership Trigger: Only after POC proves functional success

Who: BeyondTrust + SHI + ProPetro leadership Trigger: Only after POC proves functional success
