Trip Report | Tailored SPR Review | Pro Petro

Customer: Pro Petro
AE: Tony V
Topic: Tailored SPR Review
Meeting Date 12/23/2025

*Internal notes – Please read and edit before sending externally*

Summary

This call brought together SHI (as the technology partner/vendor) and ProPetro (the customer) to collaboratively review, validate, and tailor the Security Posture Review (SPR) previously delivered. The conversation covered all critical components of ProPetro’s environment—from endpoint protection to data protection, network security, DLP, cloud tools, PAM, phishing training, asset management, backup immutability, and their highly specialized drilling‑site “data van” infrastructure. From a business standpoint, the objective was to help ProPetro align their security program with NIST‑based recommendations, identify gaps, validate existing tooling, reduce costs where possible, and prepare leadership-ready documentation that justifies future investments. The ProPetro team provided detailed operational and security requirements, especially around field operations, network reliability, and remote‑operations transformation. SHI's team aimed to refine risk scoring (green/yellow/red), provide context, offer options (e.g., Barracuda vs. Microsoft vs. KnowBe4, DNS, CASB, PAM), and drive next steps that would convert into actionable initiatives in 2026.

Agenda

• Review and
tailor the previously delivered Security Posture Review (SPR)
• Validate color
coding (red/yellow/green) for all security and infrastructure categories
• Discuss tooling
changes around phishing training, EDR/endpoint protection, and cloud security
• Explore PAM,
DNS, CASB, DLP, asset management, network design, and “data van” architecture
• Identify areas
requiring additional meetings, POCs, or engineering resources
• Prepare for
leadership‑ready SPR updates after the holidays

Opportunities Identified & BANTC

Opportunity 1: Phishing Training & Security
Awareness Platform (KnowBe4 Evaluation)
B – Budget: ProPetro prefers cost‑neutral
solutions; KnowBe4 estimated around the “teens” (approx. 15k/yr). Barracuda is already paid for through 2027.
A – Authority: Alex Padron (IT Manager) with
support from Morgan (SysAdmin).
N – Need: More realistic phishing simulations;
Microsoft licensing restrictions; Barracuda emails too simplistic.
T – Timeline: After the New Year; pending
Morgan’s POC evaluation.
C – Competition: Barracuda (current), Microsoft
(feature access), KnowBe4 (potential).
Opportunity 2: Privileged Access Management (PAM)
B: Cost sensitivity noted; no numbers provided.
A: Alex, supported by Morgan and Mark. SHI to
bring in Identity SME Josh Gold.
N: Need granular application‑level elevation
for field technicians who require admin rights to run COM‑port‑based tooling.
T: Post‑holiday follow‑up.
C: ThreatLocker, Delinea, CyberArk, SailPoint,
CrowdStrike; uncertain whether Arctic Wolf offers a PAM module.
Opportunity 3: Network Assessment for Data Vans
B: Mission‑critical infrastructure; budget
likely available with justification.
A: Alex owns decision‑making; Mark provides
operational guidance.
N: Assessment, design refinement, redundancy
improvements, security hardening, remote operations support.
T: Intended as a major 2026 initiative.
C: Other vendors internally already being
evaluated; SHI will add perspective.
Opportunity 4: DNS Protection Solution
B: Unknown at this time.
A: Alex, Mark, Morgan.
N: Recent DNS issues; need enhanced protection,
filtering, and reliability.
T: To be evaluated after inclusion in tailored
documentation.
C: Zscaler, Cisco Umbrella, CrowdStrike,
DNSFilter.
Opportunity 5: CASB Solution
B: Likely significant; customer cost‑conscious.
A: Alex; SHI to involve licensing/Microsoft
specialists.
N: No CASB in place; marked red in SPR.
T: Evaluation recommended in 2026.
C: Microsoft Defender CASB, Palo Alto, Zscaler,
Cloudflare, Netskope, Proofpoint.
Opportunity 6: Backup & Immutability Enhancement

security needs.

A: Alex and Mark.
N: Lack of immutability; inadequate protection
against ransomware wiping backups.
T: Follow‑up recommended early 2026.
C: Barracuda, Rubrik, Commvault, others.

Initiatives

Security: Phishing training, PAM, DNS protection, CASB, DLP tuning, network security, backup immutability. Storage: Backup/DR improvements and immutability. Both: Asset management, data van architecture

security and lifecycle support.

Tech Profile Updates

• Arctic Wolf
fully deployed for EDR, vulnerability management, and EPP.
• Barracuda
provides phishing campaigns and O365 backups.
• Microsoft PIM
is used for privileged identity management.
• Azure native
tools provide CSPM and Web App Firewall.
• DLP policies
operational but relaxed due to end‑user friction.
• USB devices
allowed but scanned.
• Starlink used
for remote site WAN.
• Meraki used for
network core functions.
• No CASB
deployed.
• No immutability
on backups.
• Lansweeper is
under serious consideration for asset management.

Meeting Notes

The meeting focused on reviewing the SPR line‑by‑line and realigning risk categories based on updated understanding of ProPetro’s environment. Color changes were agreed for numerous categories (notably upgrading endpoint, email, CSPM, WAF, and DLP to green). Much of the discussion revolved around usability tradeoffs, licensing restrictions, and field operations realities that directly impact security posture. Architectural deep dives were conducted on the data vans, which are central to drilling-site telemetry and safety. Cost sensitivity, given current industry conditions, shaped discussions around KnowBe4, CASB, PAM, and other tooling. SHI committed to delivering a tailored SPR document after the holiday break, along with follow‑up meetings on multiple tracks: PAM, DNS, data vans, DLP, and phishing training improvements.

Environment

• Azure-first
cloud strategy
• Arctic Wolf

security stack

• Meraki
networking
• Starlink WAN
• Barracuda for
phishing and backups
• No CASB;
limited DNS security
• Field
technicians requiring elevated software permissions
• High‑risk
remote environments inside drilling operations
•
Telemetry-sensitive data van architecture powering real-time drilling oversight

Detailed Discussion

• Endpoint Security: Arctic Wolf provides
multi-layered EDR/EPP; team confident marking as green.
• Email Security: Microsoft phishing utility
liked but improperly licensed; Barracuda adequate; KnowBe4 POC to evaluate realism and automation.
• PAM: Microsoft PIM is insufficient for endpoint
elevation; need external PAM for granular controls. Field tools require admin rights, creating risk.
• Network/Data Vans: Highly critical environment
requiring redundancy, real-time telemetry, and preventing local technicians from circumventing updates/security.
• Asset Management: Previously evaluated
solutions too costly (~90k); current leaning toward Lansweeper due to pricing and functionality.
• CASB: Lacking; discussion included Microsoft,
Netskope, Palo Alto, Zscaler. Future evaluation required.
• DNS: Recent problems point to need for robust
DNS filtering/protection.
• Azure Security Controls: CSPM/WAF suitable for
Azure-only footprint; marked green.
• DLP: Policies exist but were toned down due to
blocking legitimate traffic; USB device allowances remain business‑driven.
• Backup & Immutability: No immutability in
place; major risk highlighted and recommended as yellow pending evaluation.

Technical Notes

• Arctic Wolf
integrates with Defender to provide layered endpoint protection.
• Barracuda
phishing templates lack realism; Microsoft templates highly realistic.
• Microsoft
exposes features even without proper licensing, causing compliance backtracking.
• PIM handles
Azure RBAC only, cannot solve local endpoint privilege management.
• ThreatLocker
highlighted for application-level privilege control for techs running COMport software.
• Data vans use
collectors to transmit sensor data to the Remote Operations Center; safety risk if telemetry fails.
• Need robust WAN
redundancy due to remote locations (Starlink primary).
• Internal
technicians sometimes bypass controls; necessitates PAM and enforcement mechanisms.
• Zscaler seen as
a strong DNS/CASB choice in this market segment.
• USB device
policy driven by business pushback; scanning currently implemented.
• Backup
immutability critical to prevent backup destruction during ransomware attacks.
• Lansweeper
pricing favorable relative to competitors. ROLES: Participants (Titles & Companies) SHI (Vendor):
• Tony Villalanti
— SHI, Security/SPR Lead
• Greg Miller —
Director of Engineering, Advanced Solutions Group (TOLA)
• Manuel Zelaya —
Commercial Solutions Engineer
• Josh Gold — SHI
Identity SME (not on call; to be engaged) ProPetro (Customer):
• Alex Padron —
IT Manager
• Mark Stevenson
— Infrastructure Supervisor
• Morgan Grimes —
Systems Administrator

Potential Next Steps

1. Tailored Updated SPR Document
Owner: Tony Recipients: Entire ProPetro Team Deliver updated color coding, context, and recommendations after the holiday.
2. KnowBe4 POC Setup
Owner: Tony Participants: Morgan (requested), Alex Morgan will evaluate KnowBe4’s realism and automation to determine value vs. Barracuda.
3. PAM Deep Dive with SME
Owners: Tony, Greg, Manuel Participants: Alex, Mark, Morgan Introduce SHI SME Josh Gold to evaluate PAM platforms for endpoint-level elevation.
4. Network/Data Van Assessment Meeting
Owner: Tony Participants: Mark (primary), Morgan SHI network team to assess architecture, redundancy, telemetry pathways, and security posture.
5. DNS Protection Follow-Up
Owner: Tony Participants: Mark Provide recommendations for DNS filtering platform.
6. CASB Evaluation
Owners: Tony + SHI Security Team Participants: Alex, Mark Review Microsoft licensing, evaluate CASB vendors, and prepare recommendation set.
7. DLP Deep-Dive Meeting
Owner: Tony Participants: Alex, Morgan Review DLP policy tuning after holiday; address past friction points.
8. Backup Immutability Review
Owners: Tony, Manuel Participants: Alex, Mark Discuss adding immutability to O365 backups and third-party app data; explore Barracuda, Rubrik, Commvault.
