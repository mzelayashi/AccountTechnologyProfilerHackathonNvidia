Trip Report | Data security compliance | Newpark Resources, Inc

Customer: Newpark Resources, Inc
AE: David A
Topic: Data security compliance
Meeting Date 10/23/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

David A

Gather initial pricing and present to Brad

11/1

2

Brad R

Send environment backup size for Druva quote

11/1

3

Rob C

Provide data encryption and certification documentation

11/03

Item Owner Next Steps/Detail Due Date 1 David A Gather initial pricing and present to Brad 11/1 2 Brad R Send environment backup size for Druva quote 11/1 3 Rob C Provide data encryption and certification documentation 11/03

Summary

The meeting between SHI, Druva, and Newpark Resources, Inc. focused on exploring Druva's capabilities to enhance backup solutions and data management. SHI introduced Druva's SaaS model, which operates on a credit-based system, allowing flexible workload management without AWS egress/ingress costs. The potential switch from Veeam to Druva was discussed, with Newpark expressing interest due to their current challenges with incomplete Veeam utilization and the need for a robust multi-solution backup strategy. Druva's ability to handle Oracle Virtual Manager and customize policies by VM and region was highlighted. Concerns about historical data ingestion from Veeam and the necessity for a DPIA were noted, alongside a proposal for a small-scale POC to showcase Druva's capabilities. Discussions also covered O365 backup specifics and security compliance, with actions set for data encryption documentation and initial pricing. Customer Technical Environment Notes:

Incomplete utilization of current Veeam setup Interest in multi-solution backup strategy Need for robust, immutable backup solutions Data retention policy for seven years Use of AWS S3 for data security

Incomplete utilization of current Veeam setup Interest in multi-solution backup strategy Need for robust, immutable backup solutions Data retention policy for seven years Use of AWS S3 for data security

Agenda

Introduction and participant confirmation Overview of Druva and its capabilities Discussion on current challenges and solutions POC setup and timing Cost considerations for Druva implementation

Security

and compliance requirements

Introduction and participant confirmation Overview of Druva and its capabilities Discussion on current challenges and solutions POC setup and timing Cost considerations for Druva implementation

Security

and compliance requirements Opps Identified & BANTC: Opportunity 1: Druva Implementation

B: Interest
expressed by Newpark's security team
A: Brad
Redfearn and James Parks
N: Need
for a robust backup solution and multi-solution strategy
T: Aim
for POC by next week and quotation by week’s end
C: Cost
analysis required for long-term expenses

B: Interest
expressed by Newpark's security team
A: Brad
Redfearn and James Parks
N: Need
for a robust backup solution and multi-solution strategy
T: Aim
for POC by next week and quotation by week’s end
C: Cost
analysis required for long-term expenses

Initiatives

(Security or Storage or both):

Both: Enhancing backup solutions and data security compliance

Both: Enhancing backup solutions and data security compliance Tech Profile Updates:

Druva's credit-based SaaS model Oracle Virtual Manager support with proxy processes Customizable policies by VM and region

Druva's credit-based SaaS model Oracle Virtual Manager support with proxy processes Customizable policies by VM and region Meeting Notes:

Alfie initiated the meeting and outlined required information Manuel introduced as SHI's new technical resource Discussions on Druva's workload handling and SaaS benefits Brad's concerns about changing backup solutions Proposal of a small-scale POC to demonstrate capabilities

Alfie initiated the meeting and outlined required information Manuel introduced as SHI's new technical resource Discussions on Druva's workload handling and SaaS benefits Brad's concerns about changing backup solutions Proposal of a small-scale POC to demonstrate capabilities Detailed Discussion Notes:

Roberto confirmed quick POC setup capabilities Brad noted the security team's interest in Druva James emphasized the need for a robust backup solution Discussions on O365 backup specifics and additional storage

Roberto confirmed quick POC setup capabilities Brad noted the security team's interest in Druva James emphasized the need for a robust backup solution Discussions on O365 backup specifics and additional storage List all speakers/Participants of Transcript:

Brad Redfearn, Newpark James Parks, Newpark Daniele Boi, Newpark Drilling Fluids Vladislav Iliev, Newpark Drilling Fluids Roberto Ciccateri, Druva Alfie Hansard-Scales, SHI UK Tom Wellman, SHI UK Manuel Zelaya, SHI David Atkinson, SHI

Brad Redfearn, Newpark James Parks, Newpark Daniele Boi, Newpark Drilling Fluids Vladislav Iliev, Newpark Drilling Fluids Roberto Ciccateri, Druva Alfie Hansard-Scales, SHI UK Tom Wellman, SHI UK Manuel Zelaya, SHI David Atkinson, SHI
