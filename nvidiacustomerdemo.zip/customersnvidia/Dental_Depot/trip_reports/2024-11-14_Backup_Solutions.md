Trip Report | Backup Solutions | Dental Depot

Customer: Dental Depot
AE: David H
Topic: Backup Solutions
Meeting Date 11/14/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

David H

Discuss Exagrid Expansion

11/22

2

Kevin K

Align with other storage upgrades by February 2025. To streamline AWS backups and integrate with existing infrastructure.

11/22

Item Owner Next Steps/Detail Due Date 1 David H Discuss Exagrid Expansion 11/22 2 Kevin K Align with other storage upgrades by February 2025. To streamline AWS backups and integrate with existing infrastructure. 11/22

Summary

The discussion primarily focused on Ryan J. Martin's current backup strategy and infrastructure, which involves an Exagrid appliance for deduplication and storage, with data backed up from multiple remote dental offices over a VPN. Their current challenge is managing storage capacity due to encrypted data that Exagrid cannot deduplicate. They are considering adding more storage or potentially revamping their backup solution. Options include maintaining their current Veeam-based setup or exploring alternatives like Rubrik, though cost is a concern. Ryan is also exploring using Linux-based hardened repositories for local backups at remote sites to improve speed and efficiency while considering the introduction of tape drives for long-term archival storage. Exagrid's recent developments for compatibility with M365 and AWS backups were discussed as potential enhancements to their backup strategy.

Agenda

Introduction and roles Current backup strategy and infrastructure overview Challenges with current setup, particularly storage issues Exploration of potential solutions, including local storage, Linux servers, and alternatives to Veeam Discussion on Exagrid and cloud integration Next steps and timelines

Introduction and roles Current backup strategy and infrastructure overview Challenges with current setup, particularly storage issues Exploration of potential solutions, including local storage, Linux servers, and alternatives to Veeam Discussion on Exagrid and cloud integration Next steps and timelines

Opps Identified & BANTC

Opportunity: Additional Exagrid Storage

Opportunity: Additional Exagrid Storage

B: Ryan
needs more storage capacity due to encrypted data issues.
A: Ryan
and Casey are responsible for backup infrastructure decisions.
N: Immediate
need to avoid exceeding current storage capacity.
T: Required
by January-February 2025.
C: Budget
constraints are a consideration.

B: Ryan
needs more storage capacity due to encrypted data issues.
A: Ryan
and Casey are responsible for backup infrastructure decisions.
N: Immediate
need to avoid exceeding current storage capacity.
T: Required
by January-February 2025.
C: Budget
constraints are a consideration.

Opportunity: Linux-based Local Repositories

Opportunity: Linux-based Local Repositories

B: Improve
backup efficiency and speed for remote sites.
A: Ryan
and Casey will manage the implementation.
N: Testing
by the end of 2024.
T: Implement
by early 2025.
C: Cost-effective
solution using existing hardware if possible.

B: Improve
backup efficiency and speed for remote sites.
A: Ryan
and Casey will manage the implementation.
N: Testing
by the end of 2024.
T: Implement
by early 2025.
C: Cost-effective
solution using existing hardware if possible.

Opportunity: Veeam for AWS Backups

Opportunity: Veeam for AWS Backups

B: Enhance
AWS backup efficiency.
A: Ryan
manages AWS backups.
N: Integration
needed to streamline backup processes.
T: Align
with other storage upgrades by February 2025.
C: Licensing
and setup costs must be considered.

B: Enhance
AWS backup efficiency.
A: Ryan
manages AWS backups.
N: Integration
needed to streamline backup processes.
T: Align
with other storage upgrades by February 2025.
C: Licensing
and setup costs must be considered.

Initiatives

Storage: Exploring additional Exagrid storage and Linux-based local repositories to manage data growth.

Storage: Exploring additional Exagrid storage and Linux-based local repositories to manage data growth.

Tech Profile Updates

Exagrid appliance in use, considering expansion. Veeam is the primary backup software, with potential integration of AWS backup solutions. Considering Linux-based hardened repositories for local backups at remote sites.

Exagrid appliance in use, considering expansion. Veeam is the primary backup software, with potential integration of AWS backup solutions. Considering Linux-based hardened repositories for local backups at remote sites.

Meeting Notes

Environment: Ryan's company operates a centralized Exagrid system with remote dental offices connected via a Meraki VPN. They rely heavily on Veeam for backup processes. Detailed Discussion: Key concerns include managing storage growth due to encrypted data, potential inefficiencies with Veeam, and exploring cost-effective solutions. Technical Notes: Discussed Exagrid’s limitations with encrypted data, potential for using Linux servers for local backups, and Veeam's capabilities and limitations.

Environment: Ryan's company operates a centralized Exagrid system with remote dental offices connected via a Meraki VPN. They rely heavily on Veeam for backup processes. Detailed Discussion: Key concerns include managing storage growth due to encrypted data, potential inefficiencies with Veeam, and exploring cost-effective solutions. Technical Notes: Discussed Exagrid’s limitations with encrypted data, potential for using Linux servers for local backups, and Veeam's capabilities and limitations. List all speakers/Participants of Transcript:

David Hamilton Kevin Kehoe Casey Redmon Ryan J. Martin Stephen Drake

David Hamilton Kevin Kehoe Casey Redmon Ryan J. Martin Stephen Drake
