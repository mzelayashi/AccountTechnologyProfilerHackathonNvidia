Trip Report | Logicmonitor | Dental Depot

Customer: Dental Depot
AE: David H
Topic: Logicmonitor
Meeting Date 10/28/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Brandon

Send a resource count sheet for estimating endpoint numbers.

11/05

2

Ryan

Consider a white-glove POC with LogicMonitor to evaluate the solution.

11/05

3

Casey

Provide Jason with endpoint counts for pricing estimates.

11/05

4

Brandon

Follow up with an email containing resources and next steps for trial and pricing.

11/05

Item Owner Next Steps/Detail Due Date 1 Brandon Send a resource count sheet for estimating endpoint numbers. 11/05 2 Ryan Consider a white-glove POC with LogicMonitor to evaluate the solution. 11/05 3 Casey Provide Jason with endpoint counts for pricing estimates. 11/05 4 Brandon Follow up with an email containing resources and next steps for trial and pricing. 11/05

Summary

The meeting involved a discussion between LogicMonitor representatives and Dental Depot's IT team to explore potential solutions for server and network monitoring. Dental Depot is transitioning from their current monitoring solution and seeks improved visualization, alerting, and integration capabilities. LogicMonitor presented its cloud-based SaaS monitoring solution that offers comprehensive observability, including server, network, and application monitoring. Key features discussed included alerting via SMS, integration with AWS, monitoring of Veeam backups, and the potential to extend monitoring to cameras and custom applications.

Technical Notes

LogicMonitor supports WMI for Windows servers and provides metrics without needing agents. Collectors can be deployed per office for localized monitoring. Integration with ConnectWise Manage for ticketing via webhooks. Capacity guidelines for collectors based on server count.

LogicMonitor supports WMI for Windows servers and provides metrics without needing agents. Collectors can be deployed per office for localized monitoring. Integration with ConnectWise Manage for ticketing via webhooks. Capacity guidelines for collectors based on server count.

Agenda

Introductions Current challenges and requirements Overview of LogicMonitor's architecture and capabilities Discussion on specific needs (e.g., server types, network monitoring) Potential

next steps and trial options

Introductions Current challenges and requirements Overview of LogicMonitor's architecture and capabilities Discussion on specific needs (e.g., server types, network monitoring) Potential

next steps and trial options

Opps Identified & BANTC [NEW]

Opportunity: Transition to LogicMonitor for Enhanced Monitoring

Opportunity: Transition to LogicMonitor for Enhanced Monitoring

B: Dental
Depot's need to replace existing monitoring with a more comprehensive solution.
A: Ryan
Martin, Director of IT, is the key decision-maker expressing interest in moving forward.
N: Immediate
need for improved server and network monitoring across remote offices.
T: As
soon as possible, with consideration of upcoming holidays.
C: LogicMonitor's
solution aligns with Dental Depot's requirements for SaaS monitoring, alerting, and integration capabilities.

B: Dental
Depot's need to replace existing monitoring with a more comprehensive solution.
A: Ryan
Martin, Director of IT, is the key decision-maker expressing interest in moving forward.
N: Immediate
need for improved server and network monitoring across remote offices.
T: As
soon as possible, with consideration of upcoming holidays.
C: LogicMonitor's
solution aligns with Dental Depot's requirements for SaaS monitoring, alerting, and integration capabilities.

Initiatives

Storage: Monitoring of Veeam backup statuses and integration with AWS.

Storage: Monitoring of Veeam backup statuses and integration with AWS.

Tech Profile Updates

Current use of Meraki dashboard and Netgear switches. Servers primarily Windows, with some Linux and AWS applications. Use of APC and Cyber Power UPS systems. Interest in monitoring Ubiquiti cameras and custom data transfers to Snowflake.

Current use of Meraki dashboard and Netgear switches. Servers primarily Windows, with some Linux and AWS applications. Use of APC and Cyber Power UPS systems. Interest in monitoring Ubiquiti cameras and custom data transfers to Snowflake.

Meeting Notes

Environment

Remote branch offices with servers needing monitoring. Existing infrastructure includes Windows and Linux servers, AWS applications, Meraki and Netgear network devices, and UPS systems.

Remote branch offices with servers needing monitoring. Existing infrastructure includes Windows and Linux servers, AWS applications, Meraki and Netgear network devices, and UPS systems.

Detailed Discussion

LogicMonitor's agentless architecture and data streaming to the cloud. Integration with various systems, including Meraki, AWS, and Veeam. Granular alerting and notification system to reduce noise and improve response times. Potential for creating custom integrations for unique needs like Snowflake data transfers.

LogicMonitor's agentless architecture and data streaming to the cloud. Integration with various systems, including Meraki, AWS, and Veeam. Granular alerting and notification system to reduce noise and improve response times. Potential for creating custom integrations for unique needs like Snowflake data transfers. List of Speakers/Participants of Transcript:

Brandon Rech (LogicMonitor) Jason Roeber (LogicMonitor) Ryan Martin (Dental Depot) Casey (Dental Depot) Manuel Zelaya (SHI) Gramirez-Sandoval Credmon

Brandon Rech (LogicMonitor) Jason Roeber (LogicMonitor) Ryan Martin (Dental Depot) Casey (Dental Depot) Manuel Zelaya (SHI) Gramirez-Sandoval Credmon
