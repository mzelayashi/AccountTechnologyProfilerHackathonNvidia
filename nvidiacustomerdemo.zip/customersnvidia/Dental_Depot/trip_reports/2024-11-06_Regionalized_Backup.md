Trip Report | Regionalized Backup | Dental Depot

Customer: Dental Depot
AE: David H
Topic: Regionalized Backup
Meeting Date 11/06/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

David H

schedule a meeting with the customer to replicate the discussion and explore solutions in detail.

11/14

2

Kevin K

prepare a detailed technical overview for the customer on Veeam's capabilities and potential cloud solutions.

11/14

3

Manuel Z

Strategic planning  consider regional backup strategies and potential managed service provider (MSP) offerings if applicable.

11/14

Item Owner Next Steps/Detail Due Date 1 David H schedule a meeting with the customer to replicate the discussion and explore solutions in detail. 11/14 2 Kevin K prepare a detailed technical overview for the customer on Veeam's capabilities and potential cloud solutions. 11/14 3 Manuel Z Strategic planning  consider regional backup strategies and potential managed service provider (MSP) offerings if applicable. 11/14

Summary

The conversation involved a detailed discussion about a customer's data backup and disaster recovery strategy. The customer, with a large number of locations, is currently using ExaGrid and Veeam for backups and is considering alternatives like Druva or Rubrik due to a recent disaster event (flooding) that compromised their systems. The challenge lies in balancing the need for local backups and exploring cloud-based solutions while considering their IT infrastructure, which includes Cisco Firewalls, Dell servers, and Hyper-V systems. The customer's small IT team is looking for expert advice on optimizing their backup strategy considering cost, security, and operational efficiency.

Agenda

Discuss current backup strategy and infrastructure. Explore potential improvements or changes in backup solutions. Address disaster recovery concerns following a recent flood incident. Consider the feasibility of cloud-based backups versus on-premises solutions. Plan for future engagements and further discussions with the customer.

Discuss current backup strategy and infrastructure. Explore potential improvements or changes in backup solutions. Address disaster recovery concerns following a recent flood incident. Consider the feasibility of cloud-based backups versus on-premises solutions. Plan for future engagements and further discussions with the customer.

Opportunities

Identified & BANTC:
Opportunity 1: Backup Solution Optimization

B:

Initiatives

Security

Enhancing data protection and disaster recovery through potentially immutable storage options. Storage: Evaluating the shift from Veeam and ExaGrid to other storage solutions like Druva or Rubrik, focusing on cloud integration.

Security

Enhancing data protection and disaster recovery through potentially immutable storage options. Storage: Evaluating the shift from Veeam and ExaGrid to other storage solutions like Druva or Rubrik, focusing on cloud integration. Tech Profile Updates:

Current infrastructure includes Cisco Firewalls, Dell servers, Hyper-V systems, and ExaGrid for centralized backup. Exploring potential replacements or augmentations to Veeam with Druva or Rubrik. Concerns about immutability and local vs. cloud storage.

Current infrastructure includes Cisco Firewalls, Dell servers, Hyper-V systems, and ExaGrid for centralized backup. Exploring potential replacements or augmentations to Veeam with Druva or Rubrik. Concerns about immutability and local vs. cloud storage. Meeting Notes:

The customer operates over 40 dental sites with centralized ExaGrid backups. A recent flood highlighted vulnerabilities in their disaster recovery strategy. They are exploring both local and cloud-based backup options, considering cost, scalability, and regulatory compliance.

The customer operates over 40 dental sites with centralized ExaGrid backups. A recent flood highlighted vulnerabilities in their disaster recovery strategy. They are exploring both local and cloud-based backup options, considering cost, scalability, and regulatory compliance.

Environment

Multi-state operation with sites in Arkansas, Oklahoma, and other neighboring states. Good network connectivity across locations. Predominantly physical server infrastructure with some Hyper-V usage in centralized data centers.

Multi-state operation with sites in Arkansas, Oklahoma, and other neighboring states. Good network connectivity across locations. Predominantly physical server infrastructure with some Hyper-V usage in centralized data centers. Detailed Discussion:

Backup Strategy: Focus on immutability and secure backups, possibly leveraging ExaGrid's capabilities. Cloud Solutions: Evaluation of Druva and Rubrik, considering data recovery times and regulatory compliance for healthcare data. Disaster Recovery: Need for a robust plan to mitigate risks from environmental disasters like floods.

Backup Strategy: Focus on immutability and secure backups, possibly leveraging ExaGrid's capabilities. Cloud Solutions: Evaluation of Druva and Rubrik, considering data recovery times and regulatory compliance for healthcare data. Disaster Recovery: Need for a robust plan to mitigate risks from environmental disasters like floods. Technical Notes:

Consideration of hardened repositories for cost-effective immutability in Veeam solutions. Potential for using Linux-based systems for cost-effective storage. Discussion on the viability of using cloud solutions like Wasabi for data storage.

Consideration of hardened repositories for cost-effective immutability in Veeam solutions. Potential for using Linux-based systems for cost-effective storage. Discussion on the viability of using cloud solutions like Wasabi for data storage. List of Speakers/Participants:

David Hamilton Kevin Kehoe Manuel Zelaya Stephen Drake

David Hamilton Kevin Kehoe Manuel Zelaya Stephen Drake
