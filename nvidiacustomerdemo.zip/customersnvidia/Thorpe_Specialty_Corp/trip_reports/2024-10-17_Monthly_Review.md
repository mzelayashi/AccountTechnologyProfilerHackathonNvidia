Trip Report | Monthly Review | Thorpe Specialty Corp

Customer: Thorpe Specialty Corp
AE: Felix M
Topic: Monthly Review
Meeting Date 10/17/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Felix M

Verify license consolidation and send renewal quote. And Provide details on SHI's managed services offerings.

10/23

Item Owner Next Steps/Detail Due Date 1 Felix M Verify license consolidation and send renewal quote. And Provide details on SHI's managed services offerings. 10/23

Summary

The conversation primarily focused on proactive renewal management and managed services offered by SHI. Felix Menchaca from SHI engaged with Tim Thompson to discuss current renewal processes, the benefits of managed services, and specific vendor relationships, including Sophos and Webroot for endpoint protection. They explored the potential for managed Microsoft solutions and discussed existing multi-year contracts. Felix also inquired about the status of a $100 gift card and renewal details for a Cisco license. The dialogue ended with discussions about future engagements and a side conversation on potential business interests.

Technical Notes

Sophos used for endpoint and email security. Webroot for internet security. Existing contracts are long-term, typically three years. Upcoming Cisco license renewal needs confirmation on consolidation.

Sophos used for endpoint and email security. Webroot for internet security. Existing contracts are long-term, typically three years. Upcoming Cisco license renewal needs confirmation on consolidation.

Agenda

Discuss proactive renewal management. Explore managed services offerings by SHI. Review current endpoint protection vendors. Address outstanding $100 gift card issue. Plan for upcoming Cisco license renewal. Identify potential future solutions and partnerships.

Discuss proactive renewal management. Explore managed services offerings by SHI. Review current endpoint protection vendors. Address outstanding $100 gift card issue. Plan for upcoming Cisco license renewal. Identify potential future solutions and partnerships.

Opps Identified & BANTC

Managed Services Expansion with SHI:

Managed Services Expansion with SHI:

B: Tim
Thompson expressed interest in managed services.
A: Tim
Thompson, decision-maker for technology management.
N: Need
for efficient management solutions for existing software.
T: Potential
timing aligned with current contracts ending in three years.
C: Open
to receiving information for future consideration.

B: Tim
Thompson expressed interest in managed services.
A: Tim
Thompson, decision-maker for technology management.
N: Need
for efficient management solutions for existing software.
T: Potential
timing aligned with current contracts ending in three years.
C: Open
to receiving information for future consideration.

Cisco License Renewal:

Cisco License Renewal:

B: One
Cisco license renewal due October 28th.
A: Tim
Thompson, overseeing renewals.
N: Ensure
all licenses are consolidated for ease.
T: Immediate,
as the renewal is due soon.
C: Felix
to send a quote and verify consolidation.

B: One
Cisco license renewal due October 28th.
A: Tim
Thompson, overseeing renewals.
N: Ensure
all licenses are consolidated for ease.
T: Immediate,
as the renewal is due soon.
C: Felix
to send a quote and verify consolidation.

Initiatives

Security: Discussed

endpoint protection with Sophos and Webroot.

Storage: No specific storage initiatives discussed.

Security: Discussed

endpoint protection with Sophos and Webroot.

Storage: No specific storage initiatives discussed.

Tech Profile Updates

Current

endpoint protection: Sophos and Webroot.

Previous use of Proofpoint, now fully transitioned to Sophos. Existing three-year contracts for various services.

Current

endpoint protection: Sophos and Webroot.

Previous use of Proofpoint, now fully transitioned to Sophos. Existing three-year contracts for various services.

Meeting Notes

Environment

SHI providing managed services and renewal management. Customer currently using Sophos for endpoint and email security.

SHI providing managed services and renewal management. Customer currently using Sophos for endpoint and email security.

Detailed Discussion

Tim finds current renewal management satisfactory but is open to exploring SHI's managed services. Discussed potential interest in Rubrik, but decided to table for now. Felix offered to send information proactively for future renewals. Tim prefers three-year contracts for services, consolidating renewals where possible.

Tim finds current renewal management satisfactory but is open to exploring SHI's managed services. Discussed potential interest in Rubrik, but decided to table for now. Felix offered to send information proactively for future renewals. Tim prefers three-year contracts for services, consolidating renewals where possible. List all speakers/Participants of Transcript:

Felix Menchaca (SHI) Tim Thompson (Customer)

Felix Menchaca (SHI) Tim Thompson (Customer)
