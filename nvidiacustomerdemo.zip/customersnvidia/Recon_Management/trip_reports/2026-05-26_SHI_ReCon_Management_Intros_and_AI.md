Trip Report | SHI & ReCon Management | Intros and AI | Recon Management

Customer: Recon Management
AE: Tony V
Topic: SHI & ReCon Management | Intros and AI
Meeting Date 05/26/2026

*Internal notes – Please read and edit before sending externally*

Summary

• Introductory
discovery call between SHI and ReCon Management focused on establishing AI strategy, with primary emphasis on security, data governance, and infrastructure readiness. ReCon is early in their AI journey, driven by executive pressure to adopt AI for competitiveness (especially in engineering workflows and bid efficiency), but is constrained by strict data security requirements and inability to expose client data to public AI models. SHI positioned itself as a strategic advisor offering readiness workshops, security tooling (prompt security / SaaS security), and longer-term private AI infrastructure (on-prem/self-hosted models). Key business drivers include risk of falling behind competitors, efficiency gains in engineering workflows, and compliance protection, while key blockers include poor data organization (rated 2/10), lack of enforcement tooling, and small IT team dependency on MSP. The conversation aligned on starting with security enforcement and AI governance before broader AI transformation.

Agenda

• Introductions
and roles alignment
• Overview of SHI
AI capabilities and approach
• Customer
current-state assessment (infrastructure, data, security)
• Discussion of
AI use cases (internal efficiency vs customer-facing innovation)
• Identification
of constraints (security, compliance, data structure)
• Discussion of
AI security controls (prompt security, SaaS control)
• Alignment on

next steps and workshops

Opps Identified & BANTC

Opportunity 1: AI Security Enforcement (Prompt

Security / SaaS Control)

• B: Funding not
explicitly confirmed, but urgency indicates likely near-term budget alignment
• A: IT
leadership (Mike Nelson) with influence from CEO-driven AI mandate
• N: Critical
need to prevent sensitive client data leakage into public AI tools; enforce policy vs relying on trust
• T: Immediate /
near-term priority
• C: Compliance
restrictions, existing MSP-managed environment, need for integration with current stack
Opportunity 2: AI Readiness & Data Governance
(Workshops + Tooling)
• B: Not defined;
value-based engagement initially (workshops free)
• A: IT
leadership and visioneering group (Stephen Pinnick)
• N: Data
organization maturity extremely low (self-rated 2/10); foundational requirement for AI
• T: Mid-term
(after security controls in place)
• C:
Distributed/unstructured data, reliance on MSP, limited internal IT bandwidth
Opportunity 3: Private AI / On-Prem PCAI Deployment
(Long-term)
• B: Future
capital investment (hardware + infrastructure)
• A: IT
leadership with executive sponsorship
• N: Ability to
safely process proprietary proposals and engineering data internally without violating agreements
• T: Long-term
strategic direction
• C:
Infrastructure cost, deployment complexity, need for GPU-enabled hardware, integration with workflows

Initiatives

• AI Security
Enforcement – Security
• AI Readiness
& Data Governance – Security + Storage
• Private On-Prem
AI (PCAI) – Security + Storage

Tech Profile Updates

• Microsoft 365 +
Azure tenant in use
• ERP systems:
Paylocity (HR), Unanet (accounting)
• Heavy on-prem
data storage (large engineering/media datasets, e.g., 3D scans)
• MSP-managed

infrastructure (servers, EDR/MDR, networking)

• Security stack
includes Sophos MDR and Nebula firewall OS
• Limited AI
usage: ad hoc usage of ChatGPT, Copilot, Gemini under policy limitation
• No current AI
governance or enforcement tools deployed

Meeting Notes

Environment

• Hybrid
environment: Azure cloud services + heavy on-prem infrastructure
• No ability to
move sensitive client data to public cloud AI environments
• MSP manages
most infrastructure, IT team (4 people) sets policy/direction
• Large
unstructured datasets (engineering, CAD, media files)

Detailed Discussion

Technical Notes

• Prompt security
capabilities:

Detect and block sensitive data submissions into AI tools Categorization rules for allowed vs restricted content Audit logging of user activity and attempted data exfiltration

Detect and block sensitive data submissions into AI tools Categorization rules for allowed vs restricted content Audit logging of user activity and attempted data exfiltration
• SaaS security
capabilities:

Identify AI tools accessed across environment Block unauthorized AI tools (e.g., Gemini, Claude) Redirect users to approved enterprise tenants

Identify AI tools accessed across environment Block unauthorized AI tools (e.g., Gemini, Claude) Redirect users to approved enterprise tenants
• AI deployment
models discussed:

Public AI (ChatGPT, Gemini, Copilot) → compliance risk Enterprise AI (Copilot in Azure tenant) → secure but still cloud-hosted Private AI (PCAI) → fully on-prem, no data leaves environment

Public AI (ChatGPT, Gemini, Copilot) → compliance risk Enterprise AI (Copilot in Azure tenant) → secure but still cloud-hosted Private AI (PCAI) → fully on-prem, no data leaves environment
• Data
challenges:

Unstructured formats (PNG, JPEG, PDF duplicates) Lack of classification and taxonomy No centralized governance model

Unstructured formats (PNG, JPEG, PDF duplicates) Lack of classification and taxonomy No centralized governance model
• Infrastructure
notes:

On-prem storage is large-scale and growing rapidly MSP handles server provisioning and operational tasks IT team defines naming conventions and metadata structures

On-prem storage is large-scale and growing rapidly MSP handles server provisioning and operational tasks IT team defines naming conventions and metadata structures
• Security stack:

Sophos MDR (managed detection response) Nebula firewall OS (standardized across sites) Internet filtering in place No AI-specific security tools deployed yet

Sophos MDR (managed detection response) Nebula firewall OS (standardized across sites) Internet filtering in place No AI-specific security tools deployed yet
• Copilot
functionality discussed:

Ability to toggle between internal data (OneDrive/SharePoint) and web Data in tenant not used to train external models Not suitable for restricted client data under strict contracts

Ability to toggle between internal data (OneDrive/SharePoint) and web Data in tenant not used to train external models Not suitable for restricted client data under strict contracts

ROLES

• Tony Villalanti
– Account Executive, SHI
• Manuel Zelaya –
Solutions Engineer, SHI
• Christian
Sparks – Commercial Development, SHI
• Mike Nelson –
IT Leadership, ReCon Management
• Stephen Pinnick
– Engineering / Project Management (Visioneering Team), ReCon

Potential Next Steps

• Tony Villalanti
to schedule AI security workshop with SHI AI security expert for Mike Nelson and team
• Mike Nelson to
include MSP security representative in next session
• SHI to perform
discovery on current security stack before recommending tools
• Follow-up
engagement to evaluate prompt security and SaaS control solutions
• After security
workshop, conduct full AI readiness workshop (data, infrastructure, business alignment)
• Potential
future exploration of private AI deployment aligned with compliance requirements
• Stephen Pinnick
to optionally participate and evaluate involvement depending on relevance
• Timeline
constraint noted: scheduling to occur after customer availability opens (post early June window
