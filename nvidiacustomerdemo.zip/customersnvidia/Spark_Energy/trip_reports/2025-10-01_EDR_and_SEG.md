Trip Report | EDR and SEG | Spark Energy

Customer: Spark Energy
AE: Jax M
Topic: EDR and SEG
Meeting Date 10/01/2025

*Internal notes – Please read and edit before sending externally*

Summary

• The meeting focused on Spark’s current security
environment, specifically their Endpoint Detection and Response (EDR) and Secure Email Gateway (SEG) solutions, with a goal to consolidate tools, reduce costs, and improve operational efficiency. Spark is using a mix of Sophos and Microsoft Defender for EDR, and Mimecast for SEG. The new Spark team (Kevin, Michael) is evaluating whether to continue with Sophos, given dissatisfaction with its device control and past reliability issues, and considering alternatives like SentinelOne and CrowdStrike. There is interest in leveraging Microsoft Defender more fully, especially since Spark already pays for E3/E5 licenses. The team also discussed Data Loss Prevention (DLP) needs, particularly for endpoint and file system monitoring, and the potential for Microsoft Purview to address these requirements. Contract terms and buyout options for switching vendors were considered, and a Sophos health check was proposed to assess current configuration and value. Action items were assigned to explore SentinelOne buyout, set up a Sophos health check, and schedule a DLP briefing.

Agenda

• Review Spark’s current EDR and SEG solutions
• Discuss cost-saving and consolidation opportunities
• Evaluate Sophos vs. Microsoft Defender, SentinelOne,
CrowdStrike
• Address device control and DLP requirements
• Plan next steps for health check, vendor buyout, and
DLP workshop

Opps Identified & BANTC

Opportunity 1: EDR Consolidation
& Replacement
• B: Spark (represented by Kevin, Michael) seeks to
consolidate EDR tools, reduce costs, and improve reliability for endpoint protection.
• A: Decision-makers are Kevin and Michael, with input
from Jimmy (for technical validation).
• N: Need to replace Sophos due to poor device
control, heavy resource usage, and past reliability issues; interest in leveraging Defender or switching to SentinelOne/CrowdStrike.
• T: Contract with Sophos runs until June 2027;
potential for buyout or transition at next renewal (May/June 2026).
• C: Cost savings are critical; any new solution must
be equal or lower in cost than Sophos, with improved features.
Opportunity 2: DLP Solution
Enhancement
• B: Spark needs robust DLP for endpoint and file
system monitoring, with interest in Microsoft Purview’s capabilities.
• A: Kevin, Michael, and Jimmy (technical lead for
Mimecast and DLP).
• N: Current solutions lack comprehensive DLP; need to
monitor data leaving servers, file sharing, and bulk data transfers.
• T: Workshop to be scheduled; evaluation of Purview
and comparison to legacy DLP solutions.
• C: Must integrate with existing Microsoft stack and
provide advanced monitoring without increasing costs.

Initiatives

• Security: EDR consolidation, Sophos health check,
SentinelOne/CrowdStrike evaluation, DLP enhancement
• Storage: Not discussed in detail; focus was on

security and data protection

Tech Profile Updates

• Spark currently uses Sophos and Microsoft Defender
for endpoint protection, with E3/E5 licensing in place.
• Mimecast is used for secure email gateway.
• ManageEngine is present for endpoint management and
device control.
• Interest in SentinelOne and CrowdStrike as
alternative EDRs.
• Considering Microsoft Purview for DLP.

Meeting Notes

Environment

• Approximately 120 endpoints managed, with Sophos
licensed for 450 endpoints under a three-year contract (expires June 2027).
• E3/E5 Microsoft licenses in use; ManageEngine for

endpoint management.

• Mimecast for email security; device control via
Sophos and ManageEngine.

Detailed Discussion

• Dissatisfaction with Sophos due to unreliable device
control (USB lockdown not working), heavy CPU usage, and past incidents (file deletion).
• Microsoft Defender is seen as a viable alternative,
especially with E3/E5 licensing; P1/P2 plans now include device control.
• SentinelOne and CrowdStrike discussed as market
leaders, with SentinelOne preferred for its lighter agent and advanced features.
• CrowdStrike’s recent kernel update issue noted as a
risk.
• DLP requirements clarified: focus on endpoint/file
system monitoring, not email DLP.
• Microsoft Purview identified as a potential solution
for DLP, with a workshop proposed to explore its capabilities.
• Sophos health check suggested to assess current
configuration and value, especially given the long contract term.
• Contract buyout options for SentinelOne to replace
Sophos discussed; pricing and cost savings are key decision factors.

Technical Notes

• Sophos device control (USB lockdown) is unreliable;
users can still save data to USB despite policies.
• Microsoft Defender P1 (included with E3) now
supports device control, making Sophos potentially redundant.
• ManageEngine can manage Defender and device control
policies.
• SentinelOne offers behavioral detection, machine
learning, AI-driven playbooks, rollback, device control, and endpoint firewall.
• CrowdStrike and SentinelOne are competitive in price
with Sophos; SentinelOne may offer contract buyout.
• Microsoft Defender P2 provides full enterprise-grade
protection, automated investigation, threat intelligence, and advanced hunting.
• DLP via Microsoft Purview can monitor data leaving
servers, file sharing, and bulk transfers; workshop to be scheduled for detailed review.
• Mimecast issues to be discussed further with Jimmy,
who manages its configuration.

ROLES

• Nicole Cousins – Security Solutions Specialist, SHI
(Vendor/Consultant)
• Kevin Fung – IT Lead, Spark (Customer)
• Michael Shader – IT Lead, Spark (Customer)
• Jax Miley – Account Manager, SHI (Vendor)
• Manuel Zelaya – Spark (Customer)
• Jimmy – Spark (Customer, technical lead for Mimecast
and DLP; not present but referenced)
• Unknown Speaker – Not identified

Potential Next steps

• Nicole to reach out to Sophos and schedule a health
check for Spark’s environment (Nicole, Kevin, Michael)
• Nicole and Jax to contact SentinelOne channel reps
to explore contract buyout options and provide pricing for Spark (Nicole, Jax, Kevin, Michael)
• Nicole to set up a DLP briefing/workshop with Glen
for Spark team to review Microsoft Purview and DLP strategy (Nicole, Jax, Manuel, Glen, Kevin, Michael, Jimmy)
• Kevin to provide current Sophos cost details and
Jimmy’s contact to Jax and Nicole for further discussions (Kevin, Jax, Nicole, Jimmy)
• Follow-up meeting to discuss Mimecast issues with
Jimmy present (Nicole, Kevin, Michael, Jimmy)
