Trip Report | HPE Solution | Smart Start

Customer: Smart Start
AE: David A
Topic: HPE Solution
Meeting Date 09/19/2025

*Internal notes – Please read and edit before sending externally*

Summary

The meeting focused on reviewing HPE’s proposed hybrid storage solution (Electra 5000 series) as a replacement for the customer’s existing Dell Compellent environment. The customer, Smart Start, emphasized the need for a cost-effective, scalable, and high-performance storage solution to support global operations, with specific requirements for high IOPS, low latency, and support for Hyper-V, SQL, and VDI workloads. The discussion centered on technical feasibility, real-world performance (especially latency under peak loads), network connectivity, and migration timelines. The

Agenda

• Introductions and roles

Opps Identified & BANTC

Opportunity 1: HPE Electra 5000
Hybrid Storage Solution for Compellent Replacement
• B (Budget): Customer
wants to purchase in the current fiscal year and requires cost-effective, scalable storage with five years of support included.
• A (Authority): Dan
(IT Director) is the main decision-maker, with input from technical team (Justin, Ken) and account management (David, Manuel).
• N (Need): High-capacity,
high-IOPS, low-latency storage for global infrastructure, supporting Hyper-V, SQL, VDI, and BLOB workloads; migration by next year.
• T (Timeline): Purchase
this year; migration planned by August next year, with a 4–6 month runway preferred.
• C (Competition): Dell
(current vendor, negative experience); HPE is preferred due to better support and reliability.

Initiatives

• Storage (primary focus)
• Security (indirectly referenced via
backup/replication and integration with Veeam, but not a main topic)

Tech Profile Updates

• Current environment: Dell Compellent, mix of SSD and
spinning disks, 2–5 TB current storage, growing to 60–70 TB (non-dedupable/compressible data), high IOPS/low latency needs, global deployment.
• Target: HPE Electra 5030/5050 hybrid array, scalable
to 504–1260 TB raw, 21 spinning drives + SSD cache, iSCSI/Fibre Channel, 25/40/100 Gb network options, active/passive controllers, Veeam integration.

Meeting Notes

Environment

• Global company with distributed infrastructure
• Mix of Hyper-V, SQL, VDI, and BLOB workloads
• High morning IOPS peaks (up to 40K), concern about
latency during boot/login storms
• Current network: Each node has 4x10Gb connections,
spikes up to 2GB/s

Detailed Discussion

• Customer outlined technical requirements: high
capacity, high IOPS, low latency, support for Hyper-V/SQL/VDI, migration timeline, cost sensitivity
• HPE presented Electra 5000 series, highlighting
hybrid architecture, front-end SSD cache, 6-nines availability, InfoSight predictive analytics, and scalability
• Technical Q&A covered:

IOPS and latency under real-world workloads (customer wants sub-millisecond latency even at peak IOPS; concern about cache vs. spindle performance) Controller architecture (active/passive, failover behavior, expansion) Network connectivity (25/40/100Gb options, iSCSI/Fibre Channel, port bonding, expansion slots) Expansion shelves (direct connection, no impact on front-end networking) Backup integration (Veeam, snapshots, replication)
• Customer requested technical documentation, admin guides, and white
papers for Veeam integration

Technical Notes

• Electra 5030: 420TB raw, 236–337TB usable, 70K IOPS,
21 spinning drives + SSD cache
• Electra 5050: 1260TB raw, higher cache, double
performance of 5030
• Minimum 10% SSD cache; all writes go to cache,
prefetching, RAID in cache
• Active/passive controllers; failover designed to
avoid overload
• Network: 4x25Gb per controller, upgradable, supports
iSCSI/Fibre Channel
• Expansion shelves add capacity, connect to base
controller, no downtime
• Veeam integration for backup/snapshots/replication
• InfoSight for predictive analytics, firmware/patch
management
• POC to be run in HPE lab, remote access, customer to
provide workload specs
• Customer wants to test real-world scenarios,
including controller failures and high IOPS/latency events
• Technical documentation and admin guides to be
provided by HPE List all speakers/Participants of Transcript:
• Manuel Zelaya
• David Atkinson
• Dan Davidenko
• Ken Greene
• Justin (Speaker 1)
• Nathan Sirvent
• Tricia Beattie
• Unknown Speaker
• Garrett (invited, not confirmed present)

Potential Next steps

• Nathan to send technical documentation, admin
guides, and Veeam integration white papers to Justin and team
• Nathan to coordinate with HPE labs to schedule a
remote POC, using customer-provided workload specs (Justin to provide details)
• Justin to review pricing and provide feedback to
David and Dan
• David to ensure all relevant documentation and
