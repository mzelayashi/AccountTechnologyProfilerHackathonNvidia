Trip Report | SPR review | AWS Inc

Customer: AWS Inc
AE: Kyle G
Topic: SPR review
Meeting Date 2026

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

Kyle G

send pricing and quotes related to Azure and Aruba solutions

12/19

Kyle G

Kyle to provide updates on any new developments from vendors or service providers

12/20

Item Owner Next Steps/Detail Due Date Kyle G send pricing and quotes related to Azure and Aruba solutions 12/19 Kyle G Kyle to provide updates on any new developments from vendors or service providers 12/20

Summary

Summary: The conversation between was focused on IT infrastructure and operations, ongoing projects, and technology deployments. The primary focus was on managing Azure costs, firewall deployments, and ISP aggregation services. Discussed the need for cost-effective solutions and the importance of ensuring all technology initiatives align with business objectives. Additionally, they shared updates on security incidents and the role of CrowdStrike in mitigating threats.

Agenda

Discussion on Azure cost management and reservations. Updates on firewall deployments and site readiness. Evaluation of LogicMonitor and other infrastructure monitoring tools. ISP aggregation services and vendor experiences. Year-end reviews, bonuses, and team achievements. Planning for future IT roadmaps and security initiatives.

Discussion on Azure cost management and reservations. Updates on firewall deployments and site readiness. Evaluation of LogicMonitor and other infrastructure monitoring tools. ISP aggregation services and vendor experiences. Year-end reviews, bonuses, and team achievements. Planning for future IT roadmaps and security initiatives.

Technical Notes

Azure Reservations: Exploring cost-saving measures through reservations and efficient usage. Firewall Deployments: Ongoing installations with focus on high availability and security. ISP Aggregation: Transition from DSR to Z Link for better service and portal functionality.

Azure Reservations: Exploring cost-saving measures through reservations and efficient usage. Firewall Deployments: Ongoing installations with focus on high availability and security. ISP Aggregation: Transition from DSR to Z Link for better service and portal functionality.

Opps Identified & BANTC

Opportunity 1: Azure Cost Management • B: The need to
reduce Azure costs through reservations and efficient usage.
• A: Ashton Mellott is managing the project with input
from Chris Telstra for adoption. • N: Reduce operational costs associated with Azure services.
• T: Immediate,
with ongoing efforts to optimize costs.
• C: Other
cloud service providers and cost management tools.
Opportunity 2: Firewall Deployment and Site Readiness
• B: Budget allocated for deploying firewalls at new sites and maintaining high
availability. • A: Ashton Mellott is overseeing the deployment with support from Kyle Golden. • N: Ensure network security and availability at new and existing sites. • T: Current deployments with timelines extending into the new year. • C: Alternative firewall vendors and solutions.

Initiatives

Security

Deployment of new firewalls and enhancement of network security. Storage: Management of Azure costs and optimization of cloud resources.

Security

Deployment of new firewalls and enhancement of network security. Storage: Management of Azure costs and optimization of cloud resources.

Tech Profile Updates

Current reliance on Azure for cloud services with an emphasis on cost management. Deployment of CrowdStrike for endpoint security and threat mitigation. Use of Aruba for network infrastructure with attention to potential issues related to USB ports.

Current reliance on Azure for cloud services with an emphasis on cost management. Deployment of CrowdStrike for endpoint security and threat mitigation. Use of Aruba for network infrastructure with attention to potential issues related to USB ports.

Meeting Notes

Environment

The organization is expanding its IT infrastructure, necessitating efficient cost management and robust security measures. ISP aggregation services are being evaluated to streamline connectivity at various sites.

The organization is expanding its IT infrastructure, necessitating efficient cost management and robust security measures. ISP aggregation services are being evaluated to streamline connectivity at various sites.

Detailed Discussion

Ashton and Kyle discussed strategies to optimize Azure costs, including the use of reserved instances. Updates on firewall deployments were shared, highlighting the need for high availability and security at new sites. The effectiveness of CrowdStrike in mitigating a recent security incident was discussed, showcasing its value in preventing unauthorized access. ISP aggregation services were evaluated, with Ashton expressing dissatisfaction with DSR and preference for Z Link.

Ashton and Kyle discussed strategies to optimize Azure costs, including the use of reserved instances. Updates on firewall deployments were shared, highlighting the need for high availability and security at new sites. The effectiveness of CrowdStrike in mitigating a recent security incident was discussed, showcasing its value in preventing unauthorized access. ISP aggregation services were evaluated, with Ashton expressing dissatisfaction with DSR and preference for Z Link.
