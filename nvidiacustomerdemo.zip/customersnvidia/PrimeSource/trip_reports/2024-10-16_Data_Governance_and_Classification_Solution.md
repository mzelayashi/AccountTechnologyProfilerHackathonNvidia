Trip Report | Data Governance and Classification Solution | PrimeSource

Customer: PrimeSource
AE: Leslie S
Topic: Data Governance and Classification Solution
Meeting Date 10/16/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Richard Welsh, Anthony Quesenberry, Kyle Vogley, and Michael Nanos

Consideration of a Proof of Concept (POC) for the Netwrix Enterprise Auditor solution Primesource team to connect internally and confirm with SHI/Netwrix later today if they prefer another demo or a POC as next

10/17/24

2

Leslie Schmulson

send a follow-up email summarizing the discussion and outlining next steps.

10/23/24

Item Owner Next Steps/Detail Due Date 1 Richard Welsh, Anthony Quesenberry, Kyle Vogley, and Michael Nanos Consideration of a Proof of Concept (POC) for the Netwrix Enterprise Auditor solution Primesource team to connect internally and confirm with SHI/Netwrix later today if they prefer another demo or a POC as next 10/17/24 2 Leslie Schmulson send a follow-up email summarizing the discussion and outlining next steps. 10/23/24

Summary

The meeting focused on discussing data access, governance, discovery, and classification solutions presented by Kyle Vogley and Michael Nanos, highlighting the Netwrix Enterprise Auditor Demo. The primary aim was to address the client's challenges, including data security, regulatory compliance, and efficient data management across platforms like SharePoint, OneDrive, and file servers. The client is looking to enhance their current Microsoft E3 setup without upgrading to E5 and explore alternatives for data tagging and governance. There was significant interest in the capabilities of the proposed solutions, especially in handling large amounts of data, minimizing false positives, and supporting future growth and acquisitions.

Agenda

Introductions and meeting objectives. Current data governance challenges and goals. Presentation of Netwrix Enterprise Auditor Demo. Detailed technical discussion and Q&A. Next steps and action items.

Introductions and meeting objectives. Current data governance challenges and goals. Presentation of Netwrix Enterprise Auditor Demo. Detailed technical discussion and Q&A. Next steps and action items.

Opportunities Identified & BANTC

[NEW] Netwrix Enterprise Auditor :

[NEW] Netwrix Enterprise Auditor :
B: Client
seeks solutions to manage and classify data efficiently without upgrading to Microsoft E5.

A: Anthony
and Richard expressed interest in alternatives to Microsoft Purview.
N: Immediate
need to address data governance and compliance with potential acquisitions.
T: Q4
Implementation.
C: Current
challenges with Microsoft tools and a need for more comprehensive solutions.

A: Anthony
and Richard expressed interest in alternatives to Microsoft Purview.
N: Immediate
need to address data governance and compliance with potential acquisitions.
T: Q4
Implementation.
C: Current
challenges with Microsoft tools and a need for more comprehensive solutions.

Initiatives

Security: Enhance data security and compliance. Storage: Efficient management and classification of large data volumes.

Security: Enhance data security and compliance. Storage: Efficient management and classification of large data volumes.

Tech Profile Updates

Current reliance on Microsoft E3 licenses. Interest in integrating solutions that provide better data governance and classification capabilities.

Current reliance on Microsoft E3 licenses. Interest in integrating solutions that provide better data governance and classification capabilities.

Meeting Notes

Environment

Hybrid setup with Microsoft and on-premises file systems. Data stored across SharePoint, OneDrive, and file servers.

Hybrid setup with Microsoft and on-premises file systems. Data stored across SharePoint, OneDrive, and file servers.

Detailed Discussion

Technical Notes: Need for a solution that can handle both structured and unstructured data. Options for data tagging and classification without E5 license. Importance of minimizing user impact and ensuring minimal false positives. Discussion on differential scanning and OCR capabilities.

Technical Notes: Need for a solution that can handle both structured and unstructured data. Options for data tagging and classification without E5 license. Importance of minimizing user impact and ensuring minimal false positives. Discussion on differential scanning and OCR capabilities. List all speakers/Participants of Transcript:

Kyle Vogley Leslie Schmulson Paul Wilhelm Quesenberry, Anthony Michael Nanos Richard Welsh Manuel Zelaya

Kyle Vogley Leslie Schmulson Paul Wilhelm Quesenberry, Anthony Michael Nanos Richard Welsh Manuel Zelaya
