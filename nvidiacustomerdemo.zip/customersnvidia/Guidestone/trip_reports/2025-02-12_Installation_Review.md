Trip Report | Installation Review | Guidestone

Customer: Guidestone
AE: Felix M
Topic: Installation Review
Meeting Date 02/12/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Felix

Schedule a follow-up meeting to assess the progress on resolving installation issues and the RMA process.

02/28

Item Owner Next Steps/Detail Due Date 1 Felix Schedule a follow-up meeting to assess the progress on resolving installation issues and the RMA process. 02/28

Summary

The conversation is centered around addressing complications in the installation process of technology solutions provided by SHI to Guidestone. The key issue is the incorrect installation of equipment by the installer, Okos, which has led to significant operational challenges and potential financial losses. Stephen Drake and Felix Menchaca from SHI are collaborating with John Majors from Guidestone to resolve these issues. They are working on identifying unused equipment for return, managing change orders, and ensuring that Felix is not unfairly blamed for issues arising from past project management. The focus is on minimizing negative financial impacts on Guidestone and restoring effective service delivery.

Agenda

Address installation issues and errors Discuss the role and responsibility of Okos Identify unused or incorrectly installed equipment Outline steps for possible RMA and resolution Protect Felix Menchaca from unwarranted blame

Address installation issues and errors Discuss the role and responsibility of Okos Identify unused or incorrectly installed equipment Outline steps for possible RMA and resolution Protect Felix Menchaca from unwarranted blame

Opps Identified & BANTC

Opportunity for Improving Vendor Management and Installation Processes

Opportunity for Improving Vendor Management and Installation Processes

B: Guidestone
is dissatisfied with current vendor Okos due to installation errors.
A: Stephen
Drake and Felix Menchaca are responsible for managing this resolution.
N: Immediate
need to rectify installation errors and manage change orders.
T: Urgent,
as ongoing issues could lead to operational downtime and financial losses.
C: Relationship
and trust with Guidestone at risk, potential financial implications from incorrect installations.

B: Guidestone
is dissatisfied with current vendor Okos due to installation errors.
A: Stephen
Drake and Felix Menchaca are responsible for managing this resolution.
N: Immediate
need to rectify installation errors and manage change orders.
T: Urgent,
as ongoing issues could lead to operational downtime and financial losses.
C: Relationship
and trust with Guidestone at risk, potential financial implications from incorrect installations.

Initiatives

Security

Security

Tech Profile Updates

Review and update on the installation process and vendor selection criteria.

Review and update on the installation process and vendor selection criteria.

Meeting Notes

Environment

SHI is providing technology solutions to Guidestone, but installation issues with Okos have disrupted operations.

SHI is providing technology solutions to Guidestone, but installation issues with Okos have disrupted operations.

Detailed Discussion

The discussion revolved around resolving the installation issues caused by Okos. Stephen Drake emphasized the need to protect Felix Menchaca from taking the blame for issues he wasn't involved in. John Majors expressed dissatisfaction with Okos and advised against using them in the future. They discussed identifying and tagging unused equipment for potential return and credit. The importance of written communication and documentation was stressed for managing approvals and cancellations. John Majors agreed to provide a list of inventory and a breakdown of costs related to installations and equipment.

The discussion revolved around resolving the installation issues caused by Okos. Stephen Drake emphasized the need to protect Felix Menchaca from taking the blame for issues he wasn't involved in. John Majors expressed dissatisfaction with Okos and advised against using them in the future. They discussed identifying and tagging unused equipment for potential return and credit. The importance of written communication and documentation was stressed for managing approvals and cancellations. John Majors agreed to provide a list of inventory and a breakdown of costs related to installations and equipment.

Technical Notes

Discussion on the incorrect installation of maglocks and other equipment. Issues with change orders and approval processes. Mention of hot wiring and potential hazards posed by incorrect installations.

Discussion on the incorrect installation of maglocks and other equipment. Issues with change orders and approval processes. Mention of hot wiring and potential hazards posed by incorrect installations. List all speakers/Participants of Transcript:

John Majors (Guidestone) Stephen Drake (SHI) Felix Menchaca (SHI)

John Majors (Guidestone) Stephen Drake (SHI) Felix Menchaca (SHI)

Potential Next steps

Inventory and Documentation:

Inventory and Documentation:

John Majors to compile a list of inventory that was never received and items that can be sent back for RMA. (Action by John Majors, to be reviewed by Stephen Drake and Felix Menchaca)

John Majors to compile a list of inventory that was never received and items that can be sent back for RMA. (Action by John Majors, to be reviewed by Stephen Drake and Felix Menchaca)

Installation Error Review:

Installation Error Review:

John Majors to provide photographs and documentation of incorrectly installed equipment to SHI. (Action by John Majors, reviewed by Stephen Drake and Felix Menchaca)

John Majors to provide photographs and documentation of incorrectly installed equipment to SHI. (Action by John Majors, reviewed by Stephen Drake and Felix Menchaca)

Vendor Evaluation:

Vendor Evaluation:

Evaluate and possibly replace Okos as an installation partner for future projects. (Action suggested by Stephen Drake, to be discussed with SHI management)

Evaluate and possibly replace Okos as an installation partner for future projects. (Action suggested by Stephen Drake, to be discussed with SHI management)

Resolution Process:

Resolution Process:

Stephen Drake to initiate discussions with Okos for a resolution based on the documentation provided by Guidestone. (Action by Stephen Drake, supported by Felix Menchaca)

Stephen Drake to initiate discussions with Okos for a resolution based on the documentation provided by Guidestone. (Action by Stephen Drake, supported by Felix Menchaca)

Follow-up Meeting:

Follow-up Meeting:

Schedule a follow-up meeting to assess the progress on resolving installation issues and the RMA process. (Action by Felix Menchaca, involving all parties)

Schedule a follow-up meeting to assess the progress on resolving installation issues and the RMA process. (Action by Felix Menchaca, involving all parties)
