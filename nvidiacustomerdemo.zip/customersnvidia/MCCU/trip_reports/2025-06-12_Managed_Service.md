Trip Report | Managed Service | MCCU

Customer: MCCU
AE: Nicole A
Topic: Managed Service
Meeting Date 06/12/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Nicole A

contact SHI MSP presales (Robert McCoy) with opportunity details

07/05

2

Manuel Z

collect technical/environment details from MCCU (firewall platform, locations, current MSP, etc.).

07/05

Item Owner Next Steps/Detail Due Date 1 Nicole A contact SHI MSP presales (Robert McCoy) with opportunity details 07/05 2 Manuel Z collect technical/environment details from MCCU (firewall platform, locations, current MSP, etc.). 07/05

Summary

This call involved a discussion between Nicole Agoncillo, Manuel Zelaya (Solutions Engineer, SHI), and Matthew Bracy (Service Providers Team, SHI) regarding a request from Members Choice Credit Union (MCCU) for managed network services. The opportunity originated from a

Agenda

• Confirm details and origin of MCCU’s managed network
services request • Clarify whether the request is a formal RFP or an informal inquiry • Review SHI’s managed services engagement process (in-house vs. third-party MSPs) • Discuss MCCU’s technical environment and prior engagements (MFA, PAM) • Identify next steps and action items for internal coordination and customer follow-up

Opps Identified & BANTC

Opportunity 1: Managed Network Services for MCCU
(Networking/Security)
• B: Budget: ~$5,000/month ($60,000/year) confirmed by
customer • A: Authority: MCCU’s IT/Network decision-makers (Nathan mentioned as a point of contact) • N: Need: Managed network services (firewall management, VPNs, monitoring, etc.), desire for multiple options, high selectivity in vendor selection • T: Timeline: 2-3 months for project start • C: Competition: SHI in-house (SHI Connect) preferred to be considered first; third-party MSPs to be considered if SHI Connect is not a fit or for competitive comparison

Initiatives

• Security & Networking (managed firewalls, VPN,
monitoring, potential managed SOC) • Previous initiatives with MFA and PAM (security-focused)

Tech Profile Updates

• MCCU evaluated MFA (Cisco Duo, Keeper, others) and
PAM solutions recently • Existing network environment details (platforms, number of locations, etc.) still to be confirmed • Opening a new branch in Q3 (expansion plans) • Interest in managed network services, possibly including NOC, firewall, and VPN

Meeting Notes

Environment: • MCCU is exploring managed network services, seeking both in-house and third-party options • Budget is defined, but technical requirements and environment specifics need clarification (firewall platforms, current MSP involvement, device/user counts, etc.) • SHI Connect (in-house) may be a fit if MCCU’s platforms align; if not, third-party MSPs are available Detailed Discussion: • The customer’s request was informal, not a formal RFP, but included detailed requirements and a contact for questions, making it RFP-like. • SHI’s standard process is to engage in-house managed services teams first (SHI Connect), offering better margin control and contract terms for SHI, before involving third-party MSPs. • Nicole and Manuel have not yet reached out to other vendors; Matt suggested engaging SHI’s MSP presales alias (Robert McCoy) and CC’ing him. • Matt provided information about a potential third-party MSP (CIS) with a flexible pricing model based on number of locations and service tiers (hardware monitoring, patching, firewall management, remote/on-site support). • MCCU has a history of being highly selective with solutions, requiring multiple rounds of demos and evaluations (notably for MFA). Technical Notes: • Managed network services request: initiatives with MFA (Cisco Duo, Keeper) and PAM; customer is “picky” and evaluates solutions thoroughly • SHI Connect is a subset of SHI Complete, focused on networking; SHI Complete includes managed service desk, IAM, etc. • SHI’s in-house managed services have preferred vendors; areas not covered are referred to third parties List all speakers/Participants of Transcript:  Nicole Agoncillo (SHI) • Manuel Zelaya (SHI Solutions Engineer) • Matthew Bracy (SHI Service Providers Team) • Members Choice Credit Union – not present, but referenced (“Nathan” as decision maker/contact)

Potential Next steps

Nicole/Manuel to reach out to SHIs MSP presales alias (Robert McCoy/team) regarding the MCCU opportunity, CCing Matthew Bracy for visibility and internal engagement tracking. • Assigned: Nicole Agoncillo, Manuel Zelaya (to: MSP presales, CC: Matt Bracy) SHI MSP presales team to evaluate if SHI Connect is a fit for MCCU’s requirements (platform compatibility, service scope, etc.) and prepare a proposal if appropriate. • Assigned: Robert McCoy/MSP presales team (to: Nicole/Manuel) Nicole/Manuel to collect and confirm additional technical/environmental details from MCCU (firewall platform, number of locations, current MSP status, etc.) to support scoping. • Assigned: Nicole Agoncillo, Manuel Zelaya (to: MCCU/Nathan) If SHI Connect is not a fit or MCCU requests competitive options, Matt Bracy to provide recommendations for vetted third-party MSPs (e.g., CIS) and facilitate introductions as needed. • Assigned: Matt Bracy (to: Nicole/Manuel) Schedule follow-up call(s) with MCCU to clarify requirements, present solutions, and address technical/selection criteria. • Assigned: Nicole/Manuel/SHI MSP presales (to: MCCU/Nathan) All parties to maintain internal communication and transparency regarding process (funneling through correct internal teams, building rapport, documenting origin of engagement). • Assigned: Nicole/Manuel (to: SHI internal stakeholders, including Matt Bracy)

Nicole/Manuel to reach out to SHIs MSP presales alias (Robert McCoy/team) regarding the MCCU opportunity, CCing Matthew Bracy for visibility and internal engagement tracking. • Assigned: Nicole Agoncillo, Manuel Zelaya (to: MSP presales, CC: Matt Bracy) SHI MSP presales team to evaluate if SHI Connect is a fit for MCCU’s requirements (platform compatibility, service scope, etc.) and prepare a proposal if appropriate. • Assigned: Robert McCoy/MSP presales team (to: Nicole/Manuel) Nicole/Manuel to collect and confirm additional technical/environmental details from MCCU (firewall platform, number of locations, current MSP status, etc.) to support scoping. • Assigned: Nicole Agoncillo, Manuel Zelaya (to: MCCU/Nathan) If SHI Connect is not a fit or MCCU requests competitive options, Matt Bracy to provide recommendations for vetted third-party MSPs (e.g., CIS) and facilitate introductions as needed. • Assigned: Matt Bracy (to: Nicole/Manuel) Schedule follow-up call(s) with MCCU to clarify requirements, present solutions, and address technical/selection criteria. • Assigned: Nicole/Manuel/SHI MSP presales (to: MCCU/Nathan) All parties to maintain internal communication and transparency regarding process (funneling through correct internal teams, building rapport, documenting origin of engagement). • Assigned: Nicole/Manuel (to: SHI internal stakeholders, including Matt Bracy) ( Summary: • This internal SHI conversation centered on responding to a managed network services opportunity with Members Choice Credit Union (MCCU). The team—Nicole Agoncillo (account executive), Manuel Zelaya (solutions engineer), and Matthew Bracy (service providers)—reviewed MCCU’s requirements, including managed firewalls and VPNs, a $5K/month budget, and a 2-3 month timeline. The team confirmed the opportunity originated from a direct email (not a formal RFP), and discussed SHI's process to first engage their in-house managed services (SHI Connect) before considering third-party MSPs. The team also referenced MCCU’s history of rigorous vendor evaluations (notably for MFA and PAM) and expansion plans (opening a new branch in Q3). Action items included engaging SHI’s MSP presales team, clarifying MCCUs technical stack, and preparing backup third-party options.

Agenda

• Review MCCU’s managed network services request and
qualification details • Confirm opportunity origin and RFP status • Discuss SHI’s managed services process (in-house vs. third-party) • Review MCCU’s technical stack and previous projects • Define next steps for scoping, proposal, and internal coordination

Opps Identified & BANTC

Opportunity 1: Managed Network Services for MCCU
(Networking/Security)
• B: Budget: $5,000/month ($60,000/year), confirmed by
customer • A: Authority: Nathan at MCCU (decision-maker), not present but referenced • N: Need: Managed firewall, VPN, monitoring, patching, NOC, remote/on-site support; high selectivity, wants options • T: Timeline: 2-3 months to start; opening a new branch in Q3 • C: Competition: SHI Connect to be considered first, then third-party MSPs (e.g., CIS) if needed

Initiatives

• Security & Networking (Managed firewalls, VPN,
monitoring, NOC) • Previous security initiatives (MFA, PAM)

Tech Profile Updates

• MCCU previously evaluated MFA (Cisco Duo, Keeper)
and PAM solutions • Existing network platforms (possible Fortinet/Meraki; confirmation pending) • Opening new branch in Q3 • Scope: Managed network services, no current MSP info

Meeting Notes

Environment: • Credit union with expansion plans • $60K/year budget for managed network • High due diligence process for vendor selection Detailed Discussion: • MCCU’s request arrived via informal email, but with RFP-like detail • SHI’s process: Always try in-house managed services (SHI Connect) first for better margin/control; only then consider third-party MSPs • Matt recommended starting with SHI MSP presales (Robert McCoy) for scoping/fit • Third-party MSP option discussed (CIS, with flexible tiered pricing) • MCCU’s past security projects show a pattern of thorough selection and multiple demos Technical Notes: • Managed services scope: firewalls, VPNs, monitoring, patching, support (remote/on-site) • SHI Connect specializes in networking; SHI Complete covers broader IT services • CIS offers NOC-as-a-Service, by location count, with hardware monitoring, patching, and support • Need details on MCCU’s firewall platform, number of locations, current MSP status • MCCU is expanding with a new branch (timing affects rollout) List all speakers/Participants of Transcript:  Nicole Agoncillo (SHI) • Manuel Zelaya (SHI) • Matthew Bracy (SHI) • Reference: Nathan (MCCU)

Potential Next steps

Nicole and Manuel to contact SHI MSP presales (Robert McCoy) with opportunity details; CC Matt Bracy.

Nicole and Manuel to contact SHI MSP presales (Robert McCoy) with opportunity details; CC Matt Bracy.

Responsible: Nicole Agoncillo, Manuel Zelaya (to: SHI MSP presales, CC: Matt Bracy)

Responsible: Nicole Agoncillo, Manuel Zelaya (to: SHI MSP presales, CC: Matt Bracy)

SHI MSP presales to determine if SHI Connect is a fit for MCCU’s stack and requirements.

SHI MSP presales to determine if SHI Connect is a fit for MCCU’s stack and requirements.

Responsible: SHI MSP presales (to: Nicole, Manuel)

Responsible: SHI MSP presales (to: Nicole, Manuel)

Nicole/Manuel to collect technical/environment details from MCCU (firewall platform, locations, current MSP, etc.).

Nicole/Manuel to collect technical/environment details from MCCU (firewall platform, locations, current MSP, etc.).

Responsible: Nicole Agoncillo, Manuel Zelaya (to: MCCU/Nathan)

Responsible: Nicole Agoncillo, Manuel Zelaya (to: MCCU/Nathan)

If SHI Connect not a fit or for competitive comparison, Matt to provide third-party MSP options (e.g., CIS).

If SHI Connect not a fit or for competitive comparison, Matt to provide third-party MSP options (e.g., CIS).

Responsible: Matt Bracy (to: Nicole, Manuel)

Responsible: Matt Bracy (to: Nicole, Manuel)
