Trip Report | SHI ONE Platform Demo | MCCU

Customer: MCCU
AE: Nicole A
Topic: SHI ONE Platform Demo
Meeting Date 04/02/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Nicole A

reach out to Nathan Turner to reschedule the demo and ensure full participation

04/25

2

Manuel Z

o provide detailed information about SHI's CSP offerings for Azure and AWS support options

04/25

Item Owner Next Steps/Detail Due Date 1 Nicole A reach out to Nathan Turner to reschedule the demo and ensure full participation 04/25 2 Manuel Z o provide detailed information about SHI's CSP offerings for Azure and AWS support options 04/25

Summary

he SHIOne Platform Demo meeting was intended to showcase SHI's capabilities and offerings to MCCU team, particularly focusing on AWS and Azure support. Participants included representatives from SHI, including Manuel Zelaya and Thomas Loupe, and Hoang Cao, a representative from the client side. The discussion revolved around SHI's role as a value-added reseller and its partnership with AWS, highlighting the benefits of working with SHI for cloud services. Due to scheduling conflicts, Nathan from the client's side was unable to attend, leading to considerations about rescheduling the demo for a comprehensive presentation.

Agenda

Introductions and setting expectations for the meeting. Discussion about SHI's role as a Premier Consulting Partner with AWS. Overview of SHI's capabilities and offerings, including technical support tiers. Exploration of SHIOne Platform's features for monitoring and cost optimization. Potential collaboration on CSP offerings for Azure.

Next steps and

rescheduling the demo for full participation.

Introductions and setting expectations for the meeting. Discussion about SHI's role as a Premier Consulting Partner with AWS. Overview of SHI's capabilities and offerings, including technical support tiers. Exploration of SHIOne Platform's features for monitoring and cost optimization. Potential collaboration on CSP offerings for Azure.

Next steps and

rescheduling the demo for full participation. Opps Identified & BANTC Opportunity 1: Augmented Monitoring and Support for AWS • B: The client requires 24/7 monitoring support and recommendations for AWS services. • A: Nathan Turner (absent), Hoang Cao as backup for decision-making. • N: Immediate need to augment internal monitoring capabilities. • T: Potential collaboration timeline dependent on further discussions. • C: Open for discussion, fact-finding mission regarding costs and support options. Opportunity 2: CSP Offerings for Azure • B: Exploration of CSP offerings for Azure to enhance current infrastructure. • A: Nathan Turner and Hoang Cao involved in decision-making. • N: Need to assess CSP options as part of strategic IT planning. • T: Dependent on further discussions and RFP process. • C: Budget considerations for CSP transition and optimization.

Initiatives

Security

Monitoring and support for AWS infrastructure. Storage: CSP offerings for Azure to optimize existing solutions.

Security

Monitoring and support for AWS infrastructure. Storage: CSP offerings for Azure to optimize existing solutions. Tech Profile Updates:

Client's infrastructure includes a significant Azure footprint with a smaller AWS component. SHI's capabilities as a Premier Consulting Partner for AWS and CSP offerings for Azure.

Client's infrastructure includes a significant Azure footprint with a smaller AWS component. SHI's capabilities as a Premier Consulting Partner for AWS and CSP offerings for Azure. Meeting Notes: Environment:

Client operates primarily on Azure with some AWS components. SHI offers extensive support and monitoring capabilities for both AWS and Azure.

Client operates primarily on Azure with some AWS components. SHI offers extensive support and monitoring capabilities for both AWS and Azure. Detailed Discussion:

SHI's role as a value-added reseller and Premier Consulting Partner with AWS. Exploration of SHIOne Platform's features for monitoring and cost optimization. Discussion about CSP offerings for Azure and potential collaboration.

SHI's role as a value-added reseller and Premier Consulting Partner with AWS. Exploration of SHIOne Platform's features for monitoring and cost optimization. Discussion about CSP offerings for Azure and potential collaboration. Technical Notes:

SHIOne Platform offers customizable dashboards for monitoring and asset tracking. SHI's support includes recommendations for cost savings, security, and compliance. Discussion on technical support tiers available through SHI and AWS.

SHIOne Platform offers customizable dashboards for monitoring and asset tracking. SHI's support includes recommendations for cost savings, security, and compliance. Discussion on technical support tiers available through SHI and AWS. List all speakers/Participants of Transcript:

Nicole Agoncillo (SHI) Thomas Loupe (SHI) Manuel Zelaya (SHI) Hoang Cao (Client representative) Nathan Turner (MCCU)

Nicole Agoncillo (SHI) Thomas Loupe (SHI) Manuel Zelaya (SHI) Hoang Cao (Client representative) Nathan Turner (MCCU) Potential

Next steps

Nicole Agoncillo to reach out to Nathan Turner to reschedule the demo and ensure full participation reach out to Nathan Turner to reschedule the demo and ensure full participation (Action by Nicole Agoncillo, Nathan Turner). Thomas Loupe to provide detailed information about SHI's CSP offerings for Azure and AWS support options (Action by Thomas Loupe, Hoang Cao). Hoang Cao to discuss internally with Nathan Turner and evaluate CSP options for Azure (Action by Hoang Cao, Nathan Turner). Schedule a follow-up meeting for a comprehensive SHIOne Platform demo and discussion of CSP offerings (Action by Nicole Agoncillo, Thomas Loupe, Nathan Turner, Hoang Cao).

Nicole Agoncillo to reach out to Nathan Turner to reschedule the demo and ensure full participation reach out to Nathan Turner to reschedule the demo and ensure full participation (Action by Nicole Agoncillo, Nathan Turner). Thomas Loupe to provide detailed information about SHI's CSP offerings for Azure and AWS support options (Action by Thomas Loupe, Hoang Cao). Hoang Cao to discuss internally with Nathan Turner and evaluate CSP options for Azure (Action by Hoang Cao, Nathan Turner). Schedule a follow-up meeting for a comprehensive SHIOne Platform demo and discussion of CSP offerings (Action by Nicole Agoncillo, Thomas Loupe, Nathan Turner, Hoang Cao).
