Trip Report | SilverFort | MCCU

Customer: MCCU
AE: Nicole A
Topic: SilverFort
Meeting Date 05/14/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Nicole

Send official Silverfort quote (including a la carte pricing for admin/service accounts; optional pricing for cloud NHI module if requested

05/25

2

Manuel Z

escalate technical questions about coverage for remote/off-network/cached authentication to Silverfort engineering and report back if clarification is required.

05/25

Item Owner Next Steps/Detail Due Date 1 Nicole Send official Silverfort quote (including a la carte pricing for admin/service accounts; optional pricing for cloud NHI module if requested 05/25 2 Manuel Z escalate technical questions about coverage for remote/off-network/cached authentication to Silverfort engineering and report back if clarification is required. 05/25

Summary

This call was a follow-up quote review and technical Q&A between SHI, Silverfort, and MCCU. The focus was on Silverfort’s MFA and service account protection capabilities for MCCU’s admin and service accounts, a project prompted by audit requirements. MCCU needs MFA for about 10 admin accounts and protection for approximately 50 service accounts, with a strong interest in understanding coverage for both on-premises Active Directory (AD) and cloud (Microsoft Entra/Azure AD) non-human identities (NHIs), such as managed identities and service principals. The team clarified the technical scope of Silverfort’s base offering (primarily on-prem AD) and discussed the new module for cloud NHIs, which adds visibility but not (yet) active controls. MCCU also asked about coverage for non-domain joined and remote devices, with Silverfort confirming that visibility/control is limited to systems with a line of sight to AD or Entra. MCCU is aiming for a July deployment and will review the quote and technical fit internally before responding to SHI/Silverfort, with a follow-up planned for early next week.

Agenda

• Introductions
• Confirmation of attendee list
• Review of project scope and requirements
• Technical Q&A: Silverfort’s support for
admin/service accounts, cloud NHIs, and device scenarios
• Quote review (a la carte pricing for specified use
cases)
• Discussion of deployment timelines and next steps
• Closing and scheduling of follow-up actions

Opps Identified & BANTC

Opportunity 1: Silverfort MFA & Service Account
Protection for MCCU

B (Budget): Not explicitly discussed, but MCCU is cost-conscious and considering fit/value for 10 admin and ~50 service accounts; a la carte pricing model under review. A (Authority): Nathan Turner is the primary MCCU technical decision-maker, with input from Henry Huff, West Williams, and Devon Wolf. N (Need): Audit-driven requirement to implement MFA for admin accounts and protect service accounts (on-prem AD), with a secondary interest in extending protection and visibility to cloud NHIs (managed identities/service principals in Entra/Azure AD). T (Timeline): Deployment needed by end of July (audit-driven deadline). C (Competition): No specific competitors mentioned, but MCCU is reviewing the value proposition versus “four spot solutions” and wants a unified pane of glass.

B (Budget): Not explicitly discussed, but MCCU is cost-conscious and considering fit/value for 10 admin and ~50 service accounts; a la carte pricing model under review. A (Authority): Nathan Turner is the primary MCCU technical decision-maker, with input from Henry Huff, West Williams, and Devon Wolf. N (Need): Audit-driven requirement to implement MFA for admin accounts and protect service accounts (on-prem AD), with a secondary interest in extending protection and visibility to cloud NHIs (managed identities/service principals in Entra/Azure AD). T (Timeline): Deployment needed by end of July (audit-driven deadline). C (Competition): No specific competitors mentioned, but MCCU is reviewing the value proposition versus “four spot solutions” and wants a unified pane of glass.

Initiatives

Security: (Primary) Multi-factor authentication for admin accounts Service account protection/on-prem AD (Emerging) Cloud NHI/Entra managed identities visibility Storage: Not discussed

Security: (Primary) Multi-factor authentication for admin accounts Service account protection/on-prem AD (Emerging) Cloud NHI/Entra managed identities visibility Storage: Not discussed

Tech Profile Updates

MCCU uses on-prem Active Directory and Microsoft Entra (Azure AD) for identity management. Needs MFA coverage for on-prem admin accounts and service accounts. Cloud automation/service principal identities (NHIs) are in use; interest in protecting these as well.

Environment

includes domain-joined and non-domain-joined devices, some remote/off-network. Silverfort’s base offering covers AD and can bridge to Entra for certain scenarios; newly released module for cloud NHIs offers visibility, with controls coming soon. Current workflow: Admin access via RDP, PowerShell, PSEEXEC, WMI, SSH, etc.

MCCU uses on-prem Active Directory and Microsoft Entra (Azure AD) for identity management. Needs MFA coverage for on-prem admin accounts and service accounts. Cloud automation/service principal identities (NHIs) are in use; interest in protecting these as well.

Environment

includes domain-joined and non-domain-joined devices, some remote/off-network. Silverfort’s base offering covers AD and can bridge to Entra for certain scenarios; newly released module for cloud NHIs offers visibility, with controls coming soon. Current workflow: Admin access via RDP, PowerShell, PSEEXEC, WMI, SSH, etc.

Meeting Notes

Environment

MCCU is a credit union with compliance-driven security projects. Project is prompted by audit findings. Team is moderately technical and detail-oriented, with a focus on practical coverage for both legacy and cloud environments.

MCCU is a credit union with compliance-driven security projects. Project is prompted by audit findings. Team is moderately technical and detail-oriented, with a focus on practical coverage for both legacy and cloud environments.

Detailed Discussion

Scope: 10 admin accounts for on-prem MFA, 50 service accounts to be protected. Silverfort can provide coverage for AD-joined resources and extend conditional access/MFA from Entra to on-prem systems. Cloud NHIs (managed identities/service principals) are supported with a new module (visibility only for now; controls coming). Non-domain joined and remote devices are only covered if they have a line of sight to AD or Entra; otherwise, authentication events are not visible to Silverfort. Silverfort’s value is in unifying security controls, reducing the need for multiple spot solutions. MCCU will review the quote and technical fit internally and follow up with SHI/Silverfort. SHI to send the official quote; follow-up planned for early next week after MCCU’s internal review.

Scope: 10 admin accounts for on-prem MFA, 50 service accounts to be protected. Silverfort can provide coverage for AD-joined resources and extend conditional access/MFA from Entra to on-prem systems. Cloud NHIs (managed identities/service principals) are supported with a new module (visibility only for now; controls coming). Non-domain joined and remote devices are only covered if they have a line of sight to AD or Entra; otherwise, authentication events are not visible to Silverfort. Silverfort’s value is in unifying security controls, reducing the need for multiple spot solutions. MCCU will review the quote and technical fit internally and follow up with SHI/Silverfort. SHI to send the official quote; follow-up planned for early next week after MCCU’s internal review.

Technical Notes

Silverfort’s base platform integrates with on-prem AD, providing visibility and MFA controls for admin/service accounts (PowerShell, PSEEXEC, RDP, WMI, SSH, etc.). Cloud NHIs (non-human identities like managed identities/service principals in Entra/Azure AD) are supported in a new module—currently visibility only, no active controls. Pricing for this module is separate. Silverfort can bridge Entra conditional access policies to on-prem systems. If a device is not domain-joined or is off-network (e.g., a remote user not on VPN), Silverfort cannot see authentication events unless AD/Entra is in the path. Cached credentials used off-network (e.g., remote PowerShell with no DC contact) cannot be intercepted by Silverfort. The solution is designed for quick deployment (hours, not days). Quote is a la carte based on specified user/service account counts; can be adjusted for additional modules/features.

Silverfort’s base platform integrates with on-prem AD, providing visibility and MFA controls for admin/service accounts (PowerShell, PSEEXEC, RDP, WMI, SSH, etc.). Cloud NHIs (non-human identities like managed identities/service principals in Entra/Azure AD) are supported in a new module—currently visibility only, no active controls. Pricing for this module is separate. Silverfort can bridge Entra conditional access policies to on-prem systems. If a device is not domain-joined or is off-network (e.g., a remote user not on VPN), Silverfort cannot see authentication events unless AD/Entra is in the path. Cached credentials used off-network (e.g., remote PowerShell with no DC contact) cannot be intercepted by Silverfort. The solution is designed for quick deployment (hours, not days). Quote is a la carte based on specified user/service account counts; can be adjusted for additional modules/features. List all speakers/Participants of Transcript:

Nicole Agoncillo (SHI) Stephan Hinojos (Silverfort) Manuel Zelaya (SHI, Solutions Engineer) Nathan Turner (MCCU) Henry Huff (MCCU) West Williams (MCCU) Devon Wolf (MCCU)

Nicole Agoncillo (SHI) Stephan Hinojos (Silverfort) Manuel Zelaya (SHI, Solutions Engineer) Nathan Turner (MCCU) Henry Huff (MCCU) West Williams (MCCU) Devon Wolf (MCCU)

Potential Next steps

SHI/Silverfort (Nicole/Stephan) to MCCU (Nathan):

SHI/Silverfort (Nicole/Stephan) to MCCU (Nathan):

Send official Silverfort quote (including a la carte pricing for admin/service accounts; optional pricing for cloud NHI module if requested). Action: Nicole to send quote and supporting docs.

Send official Silverfort quote (including a la carte pricing for admin/service accounts; optional pricing for cloud NHI module if requested). Action: Nicole to send quote and supporting docs.

MCCU (Nathan, Henry, West, Devon):

MCCU (Nathan, Henry, West, Devon):

Meet internally (target: tomorrow/Friday) to review technical fit and pricing. Action: Nathan to coordinate internal review.

Meet internally (target: tomorrow/Friday) to review technical fit and pricing. Action: Nathan to coordinate internal review.

MCCU (Nathan) to SHI/Silverfort:

MCCU (Nathan) to SHI/Silverfort:

Provide feedback on decision/next steps by early next week (Monday at latest). Action: Nathan to email outcome/thoughts after internal meeting.

Provide feedback on decision/next steps by early next week (Monday at latest). Action: Nathan to email outcome/thoughts after internal meeting.

SHI/Silverfort (Stephan):

SHI/Silverfort (Stephan):

If no response by Friday, follow up with Nathan via email midday Friday. Action: Stephan to send follow-up email if needed.

If no response by Friday, follow up with Nathan via email midday Friday. Action: Stephan to send follow-up email if needed.

Silverfort (Stephan):

Silverfort (Stephan):

Optionally, escalate technical questions about coverage for remote/off-network/cached authentication to Silverfort engineering and report back if clarification is required. Action: Stephan to clarify and respond if MCCU requests.

Optionally, escalate technical questions about coverage for remote/off-network/cached authentication to Silverfort engineering and report back if clarification is required. Action: Stephan to clarify and respond if MCCU requests.

Optional—Schedule 15-min Sync (Next Week):

Optional—Schedule 15-min Sync (Next Week):

If MCCU desires, schedule a 15-min call for live feedback/decision post-internal review. Action: To be coordinated based on MCCU response.

If MCCU desires, schedule a 15-min call for live feedback/decision post-internal review. Action: To be coordinated based on MCCU response.
