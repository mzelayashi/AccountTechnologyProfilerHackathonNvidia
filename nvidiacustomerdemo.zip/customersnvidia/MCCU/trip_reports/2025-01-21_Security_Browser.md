Trip Report | Security Browser | MCCU

Customer: MCCU
AE: Tony V
Topic: Security Browser
Meeting Date 01/21/2025

*Internal notes – Please read and edit before sending externally*

Security Browser

TOLA1 01/21
*Internal
notes – Please read and edit before sending externally*

Summary

This meeting brought together stakeholders from MCCU’s IT leadership team and vendor partners SHI and their extended ecosystem. The objective was to review MCCU’s 2026 technology roadmap, surface high‑impact projects, evaluate dependencies, prioritize Q1 deliverables, and ensure vendor alignment. The customer’s environment is experiencing significant modernization pressures across networking, identity, DR, help desk operations, browser security, procurement consolidation, AI adoption, hardware lifecycle management, physical security, and project coordination tools. MCCU’s IT Director (Nathan) emphasized time constraints, competing priorities, limited engineering bandwidth, and the need to balance legacy systems with modernization efforts. SHI positioned themselves as a strategic partner capable of reducing operational friction through procurement simplification, asset management tools, AI advisory, infrastructure refresh planning, and vendor coordination. A large portion of the meeting involved reviewing MCCU’s infrastructure spreadsheet, identifying high-risk and high-effort projects, coordinating timelines around networking refreshes, DR preparations, service desk transitions, branch build-outs, and browser hardening. SHI demonstrated SHI One enhancements such as Roadmaps, Lifecycle Management, Procurement History, and Asset tools to provide MCCU better planning visibility. The customer presented strong interest in selective assistance across hardware procurement, networking refresh, DR verification, vulnerability management (Rapid7), branch buildouts, and potential future browser security evaluations. However, many initiatives are gated by MCCU’s limited time, vendor dependencies, and the need for sequential decision-making.

Agenda

• Review of
MCCU’s 2026 infrastructure roadmap
• Q1 priority
evaluation (Fortinet renewal, network refresh, Lake Jackson branch, DR landing zone, Rapid7, help desk replacement)
• SHI One
platform walkthrough (Roadmaps, Assets, Renewals, Procurement)
• Browser

security and enterprise browser discussion

• AI chatbot vs.
service desk AI functionality evaluation
• Support
expectations and Microsoft/Azure support alignment
• Physical

security and branch buildout coordination

• Procurement
consolidation into a single vendor stream
• Upcoming
timelines and required inter-vendor introductions

OPPORTUNITIES

IDENTIFIED & BANTC
Opportunity 1:
Network Infrastructure Refresh (Fortinet or Alternative)
B: MCCU’s
Fortinet hardware is reaching end of life; a major refresh is required and is one of the largest projects of 2026. Customer is open to vendor guidance.
A: Authority sits
with Nathan, with support from Henry and MCCU’s network engineering team.
N: The need is
immediate due to end‑of‑support timelines, dependency on new MSP (Emesis), and strategic planning for future security posture.
T: Target is
Q1/Q2 for final vendor decision.
C: Cost not yet
defined, but highly significant given firewall, VPN, branch connectivity, and configuration scope.
Opportunity 2:
Enterprise Browser Hardening / Browser Security Evaluation
B: CIS hardening
requirements, audit findings, and operational risk drive the need for enterprise-grade controls.
A: Shared between
Nathan and Henry; internal security team may be involved later.
N: MCCU needs
simplified deployment and reduced manual configuration overhead.
T: Evaluation
likely Q2 or later due to bandwidth limitations.
C: Cost unknown;
potential bundling discounts if aligned with firewall vendor selection.
Opportunity 3:
Service Desk Replacement (Fresh Service vs. Atomic Work)
B: MCCU is
committed to moving away from ServiceDesk Plus.
A: Nathan and his
IT support leaders.
N: The need is
high — legacy ticketing is insufficient and audit gaps exist.
T: Active
evaluations underway. Vendor decision expected early 2026.
C: Cost dependent
on seat count and AI features.
Opportunity 4:
Rapid7 Vulnerability Management Migration (Away from Tenable)
B: MCCU
evaluating dropping Tenable in favor of Rapid7, already in progress.
A: Nathan; SHI
assisting on quote creation and evaluation.
N: Strong need
for better alignment with existing tools and reduced spend.
T: Meeting
scheduled the same day; decision expected soon.
C: Pricing
available via SHI; customer requires more details to finalize.
Opportunity 5:
Disaster Recovery in Azure (Landing Zone, ASR, Backup, Testing)
B: MCCU needs a
full DR design implemented before April/May DR testing window.
A: Nathan with
cloud engineering team.
N: Critical need
for compliance, recovery objectives, and audit readiness.
T: Implementation
must begin immediately; design nearly complete.
C: Azure
consumption + potential SHI service engagements.
Opportunity 6:
Asset Lifecycle & Procurement Consolidation through SHI One
B: MCCU desires
centralized procurement visibility and vendor consolidation.
A: Nathan, with
procurement and finance teams.
N: Needed for
operational efficiency and spend tracking.
T: Immediate
onboarding; SHI to assist this week.
C: No additional
cost; included with SHI partnership.
Opportunity 7:
Physical Security & Branch Technology Build-Out Support
B: MCCU
renovating a new branch requiring cabling, networking, cameras, alarms, and A/V.
A: Nathan
coordinating with construction and vendors.
N: Need to
fast-track diagrams, equipment, and cabling.
T: Must deliver
diagrams by early February to support construction deadlines.
C: Equipment +
integration partner costs.

Initiatives

(Categorized by Security / Storage / Other)

Security

• Network refresh
(Fortinet or alternative)
• Vulnerability
management (Rapid7)
• Browser
hardening & enterprise browser evaluation
• Help desk AI
chatbot & security implications
• CIS hardening
standards across browsers and endpoints
• DR posture
validation (ASR, Azure Backup)
• Physical
security systems for new branch (cameras, alarms)
• Firewall vendor
alignment with MSP Emesis Storage
• Azure backup
strategy tied to DR
• Backups
retention & RPO/RTO mapping Other
• SHI One
adoption
• Procurement
vendor consolidation
• Service desk
replacement
• Branch

infrastructure rollout

• Lifecycle and
asset management improvements
• AI enablement
(general, not custom model training) Tech Profile Updates
• MCCU moving
toward full Azure cloud for DR and backup.
• Network
operations undergoing MSP transition to Emesis.
• Hardware
lifecycle managed with a 4‑year refresh for end‑user devices.
• Vulnerability
management likely shifting from Tenable to Rapid7.
• Service desk
transitioning away from ServiceDesk Plus; Fresh Service and Atomic Work are finalists.
• Moving toward
enterprise browser security controls aligned with CIS benchmarks.
• Physical
security uses New Source, cameras appear to be AVIX brand.
• AI initiatives
led by applications team under Ralph, not infrastructure.

Meeting Notes

(High‑Level)
• New MSP Emesis
will take over infrastructure operations and influence firewall vendor selection.
• Fortinet estate
is at EOL and must be refreshed.
• MCCU intends to
centralize procurement through SHI to simplify tracking and oversight.
• SHI One
Roadmaps, Procurement History, Lifecycle Management, and Asset views were demonstrated.
• Branch buildout
requires urgent network diagrams before Feb 6 for construction.
• Azure DR design
is almost complete; implementation targeted before April/May DR tests.
• Rapid7 quotes
prepared; customer meeting scheduled immediately after this call.
• Browser
security evaluation likely Q2-Q3 due to bandwidth constraints.
• AI chatbot
usage undecided; depends on service desk vendor capabilities.

Environment

• Heavy
dependency on Azure for DR and cloud backups.
• Fortinet used
for firewalls, VPN (including 40/40 client VPN), and security edge.
• ServiceDesk
Plus currently used but slated for replacement.
• Monitoring via
PRTG; customer must reduce sensors below licensed count (500).
• Physical

security via New Source, AVIX cameras.

• Construction
deadlines influencing project dependencies for Lake Jackson branch. Detailed Discussion
• Networking
& MSP Transition: Emesis becomes the extension of MCCU’s network team; they will help decide whether to remain with Fortinet or switch vendors. Firewall refresh will be one of the years most complex projects.
• Fortinet &
Vendor Replacement: No major complaints with Fortinet, but NCCU open to Emesis-led vendor evaluation. SHI to be involved heavily in procurement regardless of vendor selected.
• Help Desk
Replacement: Fresh Service and Atomic Work in evaluation; decision impacts whether Copilot or a built-in chatbot handles enterprise support.
• DR Program:
Azure landing zones complete; ASR + Azure Backup heavily used. Testing must be ready by spring. Design near completion; implementation is the next Big Lift.
• Browser
Hardening: CIS level 1

Technical Notes

(Granular Details)
• Emesis will
have direct keyboard access to Fortinet VPN, configs, and firewall stack.

ROLES (Speakers

& Their Roles) (Roles inferred based on transcript context)
• Nathan Turner –
Director of IT Infrastructure, Members Choice Credit Union (Customer)
• Tony Villalanti
– SHI Account Executive / Technology Advisor (Vendor)
• Manuel Zelaya –
SHI Solutions Engineer (Vendor)
• Henry Huff –
MCCU IT Team Member / Infrastructure Engineering (Customer)
• Unknown Speaker
– MCCU participant (Customer)
• Wes / Devon /
Lewis – Not speaking extensively but referenced as MCCU team members or partners Potential Next Steps (with attribution)
1.
Emesis–SHI–MCCU Introduction Meeting Said by: Nathan & Tony Action: Schedule introduction next week after Nathan’s Friday onboarding meeting with Emesis. Involved: Nathan, Emesis, Tony, Manuel.
2. Branch Network
Diagram Fast‑Tracking Said by: Tony to Lewis and integration partner; Nathan to verify dates. Action: SHI must push integration partner to produce diagrams by Feb 6 (or earlier). Involved: Tony, Lewis, Nathan, integration partner.
3. Rapid7
Follow‑Up Said by: Tony Action: SHI to present Rapid7 quotes later today at scheduled meeting. Involved: Tony, Nathan, MCCU security team.
4. PRTG Sensor
Cleanup Said by: Nathan Action: MCCU to reduce sensors below 500, potentially this Friday. SHI to provide overage cost estimate. Involved: Nathan, MCCU IT team, Tony (for pricing).
5. SHI One Full
Onboarding Said by: Tony Action: SHI to onboard Nathan, Wes, Devon, Henry; MCCU to provide any additional user info. Involved: Tony, Nathan, MCCU staff.
6. Browser

Security Evaluation (Future)

Said by: Nathan Action: Consider scheduling evaluation in Q2/Q3 once bandwidth allows. Involved: Nathan, Henry, SHI security team.
7. DR
Implementation Said by: Nathan Action: Complete DR design and move to implementation phase before April/May DR tests. Involved: MCCU cloud engineering, SHI (if support requested).
8. Service Desk
Final Vendor Selection Said by: Nathan Action: Continue vetting Fresh Service and Atomic Work; determine AI chatbot direction afterwards. Involved: MCCU support team, SHI advisory as needed.
