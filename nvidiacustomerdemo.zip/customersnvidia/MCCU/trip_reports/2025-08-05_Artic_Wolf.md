Trip Report | Artic Wolf | MCCU

Customer: MCCU
AE: Nicole
Topic: Artic Wolf
Meeting Date 08/05/2025

*Internal notes – Please read and edit before sending externally*

Summary

This internal sync between SHI and Arctic Wolf centered on Members Choice Credit Union’s (MCCU) need for a managed network service provider, including an NDR (Network Detection and Response) tool and the ability to manage and monitor a large inventory of Fortinet devices and switches. The team clarified that Arctic Wolf’s managed services do not extend to direct network device (firewall, switch) management but rather focus on managed detection and response (MDR) and security monitoring. Arctic Wolf does offer an add-on, Data Explorer, for customer visibility, but does not sell standalone tools. The credit union’s current environment uses Rapid7 and Fortinet for security and is evaluating DLP via Microsoft Purview. The team also discussed MCCU's upcoming branch expansion and equipment needs. Arctic Wolf will provide recommendations for trusted network managed service providers and share updated information on their security platform for future reference or potential shifts from Rapid7. No immediate opportunity for Arctic Wolf, but potential for future collaboration if security focus shifts.

Agenda

• Confirm receipt of SHI Connects information for MCCU
• Review MCCU’s requirements for managed network
services and security
• Clarify Arctic Wolf’s service offerings relative to
MCCU’s needs
• Discuss equipment inventory and upcoming branch
expansion
• Establish next steps and recommendations

Opps Identified & BANTC

Opportunity 1: Managed Network Services for MCCU
• B (Budget): Not discussed; need likely
funded due to upcoming branch expansion and infrastructure refresh.
• A (Authority): Nathan (MCCU contact, not
present) and new CIO are primary decision-makers. Nicole Agoncillo is AE at SHI, Manuel Zelaya handling technical.
• N (Need): MCCU requires a provider for
managed network services, particularly management and monitoring of firewalls, switches, and access points across an expanding network.
• T (Timeline): Immediate, with an upcoming
branch scheduled to open in Q3 and corresponding equipment requirements.
• C (Competition): Arctic Wolf not a fit for
direct network management; SHI to provide alternate provider recommendations. Rapid7 currently in use for security, but Arctic Wolf is positioned for future consideration.
Opportunity 2: Security Monitoring/Visibility Add-ons
• B (Budget): Not discussed.
• A (Authority): Nathan and CIO at MCCU.
• N (Need): Potential future interest in
enhanced visibility/security monitoring if MCCU moves away from Rapid7 or requires more integrated MDR.
• T (Timeline): Not immediate; future
opportunity as IT/security landscape evolves.
• C (Competition): Rapid7 is current
solution; Arctic Wolf can provide Data Explorer as an add-on for MDR customers.

Initiatives

• Security: Current security stack includes
Rapid7, Fortinet; evaluating Microsoft Purview DLP. Arctic Wolf’s MDR and Data Explorer considered for future needs.
• Networking: Managed network service for
extensive Fortinet firewall/switch environment; expansion needs for new branch.

Tech Profile Updates

• MCCU’s device inventory: 96 items, primarily
FortiGate firewalls and FortiSwitches.
• New branch opening in Q3; significant equipment
procurement anticipated.
• Current security tools: Rapid7
(monitoring/visibility), Fortinet (firewall/switching), evaluating Microsoft Purview (DLP).
• Arctic Wolf MDR not a fit for direct device
management but can partner with network MSPs and offers Data Explorer for MDR customers.

Meeting Notes

Environment

• MCCU is expanding (new branch, Q3)
• Network stack: Large Fortinet footprint, many
switches/firewalls
• Security: Rapid7, Fortinet, exploring Microsoft
Purview DLP
• New leadership (Nathan, new CIO)
Discussion Highlights:
• SHI confirmed receipt of device inventory and
discussed managed network requirements with Arctic Wolf
• Arctic Wolf clarified they do not provide direct
management for network devices (i.e., firewalls, switches), focusing instead on

security monitoring

• Arctic Wolf offers Data Explorer for enhanced
visibility but only as an MDR add-on
• Nicole and Manuel to follow up with MCCU regarding
their Rapid7 use and security needs
• Arctic Wolf to recommend reputable managed network
service providers
• Opportunity to re-engage if MCCU’s security needs
evolve

Technical Notes

• Device inventory: 96+ Fortinet devices; current
configuration/monitoring managed in-house or through Rapid7
• Arctic Wolf MDR does not cover hands-on device
management (firewalls/switches); strictly monitoring/response
• Data Explorer SKU provides dashboard/visibility for
MDR customers, not a standalone tool
• Arctic Wolf can partner with MSPs for layered

security monitoring

• SHI to facilitate introduction to trusted network
MSPs List all speakers/Participants of Transcript:
• Nicole Agoncillo (SHI, AE)
• Manuel Zelaya (SHI, technical)
• Drew (Arctic Wolf, AE)
• Nathan (MCCU, mentioned, not present)
• CIO (MCCU, mentioned, not present)

Potential Next steps

SHI to recommend managed network service providers for MCCU’s Fortinet environment

SHI to recommend managed network service providers for MCCU’s Fortinet environment

Action: Drew to email Manuel trusted MSP recommendations Who: Drew → Manuel Zelaya, Nicole Agoncillo

Action: Drew to email Manuel trusted MSP recommendations Who: Drew → Manuel Zelaya, Nicole Agoncillo

Arctic Wolf to send summary of Data Explorer and MDR capabilities for future reference

Arctic Wolf to send summary of Data Explorer and MDR capabilities for future reference

Action: Drew to provide latest Arctic Wolf platform/capability overview, including Data Explorer Who: Drew → Nicole Agoncillo, Manuel Zelaya

Action: Drew to provide latest Arctic Wolf platform/capability overview, including Data Explorer Who: Drew → Nicole Agoncillo, Manuel Zelaya

SHI to follow up with MCCU on current Rapid7 usage and explore future security needs

SHI to follow up with MCCU on current Rapid7 usage and explore future security needs

Action: Nicole/Manuel to check with Nathan/CIO about Rapid7 and security roadmap Who: Nicole Agoncillo, Manuel Zelaya → Nathan, CIO (MCCU)

Action: Nicole/Manuel to check with Nathan/CIO about Rapid7 and security roadmap Who: Nicole Agoncillo, Manuel Zelaya → Nathan, CIO (MCCU)

Monitor MCCU’s branch expansion and equipment procurement for potential SHI engagement

Monitor MCCU’s branch expansion and equipment procurement for potential SHI engagement

Action: Nicole/Manuel to stay close to MCCU for Q3 branch project and upcoming needs Who: Nicole Agoncillo, Manuel Zelaya → MCCU Team

Action: Nicole/Manuel to stay close to MCCU for Q3 branch project and upcoming needs Who: Nicole Agoncillo, Manuel Zelaya → MCCU Team

Re-engage Arctic Wolf if MCCU’s needs shift from network management to MDR/security monitoring

Re-engage Arctic Wolf if MCCU’s needs shift from network management to MDR/security monitoring

Action: SHI to keep Arctic Wolf in loop for future security-focused opportunities Who: Nicole Agoncillo, Manuel Zelaya → Drew (Arctic Wolf)

Action: SHI to keep Arctic Wolf in loop for future security-focused opportunities Who: Nicole Agoncillo, Manuel Zelaya → Drew (Arctic Wolf)
