Trip Report | Keep Security | MCCU

Customer: MCCU
AE: Nicole A
Topic: Keep Security
Meeting Date 06/18/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

MCCU to complete testing within 2-week trial period; raise any questions/issues to Keeper team

07/05

2

West Williams

finish spinning up the Docker container with provided files from Devon Wolf

07/05

Item Owner Next Steps/Detail Due Date 1 Manuel Z MCCU to complete testing within 2-week trial period; raise any questions/issues to Keeper team

07/05 2 West Williams finish spinning up the Docker container with provided files from Devon Wolf 07/05

Summary

This call involved a technical onboarding and setup session between MCCU (customer team: Nathan Turner, Devon Wolf, West Williams), SHI (Manuel Zelaya), and Keeper Security (Roy Baker, Patrick - Keeper, Jax Miley). The primary purpose was to review the Keeper Secrets Manager trial, specifically configuring and deploying a gateway container to automate credential rotation for privileged Active Directory (AD) and Azure AD accounts. The teams discussed technical requirements, deployment options (Docker, Linux, Windows), firewall and networking needs, Azure app registration, and permissions. The session included live configuration within Azure and Keeper, troubleshooting access issues, and confirming how to provision the gateway and assign necessary roles. A follow-up checkpoint was scheduled to review progress. The call focused on security (privileged access management, credential rotation), with the immediate initiative being a proof-of-concept/trial for MCCU. Key business outcomes are improved credential hygiene, automation of password rotations, and compliance with security best practices.

Agenda

• Overview of Keeper Secrets Manager trial and
objectives
• Discussion of deployment options for the Keeper
gateway utility
• Technical requirements (server/container,
networking, firewall rules)
• Walkthrough of Azure app registration and
permissions assignment
• Live demonstration: configuring the gateway and
connecting to Keeper
• Q&A and troubleshooting (access roles, policy
issues)
• Scheduling of follow-up/check-in meeting
• Next steps and documentation sharing

Opps Identified & BANTC

Opportunity 1: Keeper Privileged Access Management for AD & Azure AD

B: Medium–High.
MCCU expressed a clear need to automate privileged account password rotations for AD and Azure AD admin accounts, indicating a strong business driver around security, compliance, and operational efficiency.
A: Nathan
Turner, Devon Wolf, West Williams (MCCU) are key technical and business stakeholders. Keeper (Roy Baker, Patrick) are vendor technical contacts; SHI (Manuel Zelaya) is the partner/AM.
N: Immediate:
Secure privileged accounts, reduce manual password changes, streamline compliance. Long-term: Potential to expand to more accounts, service accounts, or other environments.
T: 2-week
trial (active now, ends in two weeks). Quick technical deployment (Docker/container, app registration, firewall changes). Potential for rapid production if trial succeeds.
C: No
explicit budget discussed, but the time and technical resource commitment to the trial is confirmed. Purchase decision likely post-trial.

B: Medium–High.
MCCU expressed a clear need to automate privileged account password rotations for AD and Azure AD admin accounts, indicating a strong business driver around security, compliance, and operational efficiency.
A: Nathan
Turner, Devon Wolf, West Williams (MCCU) are key technical and business stakeholders. Keeper (Roy Baker, Patrick) are vendor technical contacts; SHI (Manuel Zelaya) is the partner/AM.
N: Immediate:
Secure privileged accounts, reduce manual password changes, streamline compliance. Long-term: Potential to expand to more accounts, service accounts, or other environments.
T: 2-week
trial (active now, ends in two weeks). Quick technical deployment (Docker/container, app registration, firewall changes). Potential for rapid production if trial succeeds.
C: No
explicit budget discussed, but the time and technical resource commitment to the trial is confirmed. Purchase decision likely post-trial.

Initiatives

Security: Privileged Access Management, Password Rotation Automation (Keeper Secrets Manager) Storage: Not discussed/Not applicable

Security: Privileged Access Management, Password Rotation Automation (Keeper Secrets Manager) Storage: Not discussed/Not applicable

Tech Profile Updates

MCCU is using Azure (container apps), Active Directory (on-prem), Azure AD, Hyper-V, and is open to Docker/container-based deployments.

Security

initiative: Privileged access management and credential rotation. Networking: Outbound 443, 3478 TCP/UDP; internal LDAPS (636), SSH (22), WinRM (5986). Azure AD integration with Keeper; custom app registration and role-based access control.

MCCU is using Azure (container apps), Active Directory (on-prem), Azure AD, Hyper-V, and is open to Docker/container-based deployments.

Security

initiative: Privileged access management and credential rotation. Networking: Outbound 443, 3478 TCP/UDP; internal LDAPS (636), SSH (22), WinRM (5986). Azure AD integration with Keeper; custom app registration and role-based access control.

Meeting Notes

Environment

Target: AD privileged accounts (domain/local admin), Azure AD admin accounts. Deployment: Docker container (preferred), can use Linux or Windows server or Hyper-V VM. No agent required on endpoints; only the Keeper gateway utility.

Target: AD privileged accounts (domain/local admin), Azure AD admin accounts. Deployment: Docker container (preferred), can use Linux or Windows server or Hyper-V VM. No agent required on endpoints; only the Keeper gateway utility.

Detailed Discussion

Deployment: Discussed whether to use existing servers, create new VMs, or use an Azure container app (decided on container app). Networking: Outbound traffic on 443 and 3478; internal LDAPS for AD; WinRM/SSH for other servers. Azure AD: Requires app registration, client ID, directory ID, subscription ID, and appropriate admin role (privileged authentication administrator). Keeper Configuration: Walkthrough of setting up the gateway, handling trial activation issues, adjusting user roles and policies. Firewall: Need to coordinate with MSP for firewall rule implementation; documentation to be shared by Keeper. Trial: 2-week duration; initial focus on admin users, with potential expansion. Post-rotation scripting: Option to run scripts post-rotation from the gateway.

Deployment: Discussed whether to use existing servers, create new VMs, or use an Azure container app (decided on container app). Networking: Outbound traffic on 443 and 3478; internal LDAPS for AD; WinRM/SSH for other servers. Azure AD: Requires app registration, client ID, directory ID, subscription ID, and appropriate admin role (privileged authentication administrator). Keeper Configuration: Walkthrough of setting up the gateway, handling trial activation issues, adjusting user roles and policies. Firewall: Need to coordinate with MSP for firewall rule implementation; documentation to be shared by Keeper. Trial: 2-week duration; initial focus on admin users, with potential expansion. Post-rotation scripting: Option to run scripts post-rotation from the gateway.

Technical Notes

Keeper gateway requires a minimal-resource container (1 core, 1GB RAM). Outbound ports: 443 (HTTPS), 3478 TCP/UDP; no inbound public access required. Internal ports: 636 (LDAPS), 22 (SSH), 5986 (WinRM) as required for target endpoints. Azure AD integration: App registration must be single-tenant, with client/application ID, directory/tenant ID, and subscription ID. Privileged Authentication Administrator role assigned to the Keeper app in Azure for password rotation. Custom role assignment in Azure for subscription-level permissions. Keeper Vault: Users to be added as PAM users; rotation can be on-demand or scheduled. Post-rotation script support (optional), executed by gateway with required permissions. Trial activation issue resolved by refreshing, role policy adjustment, and proper assignment/removal of restrictive roles. Documentation provided for firewall and Azure app registration steps. No service account rotation in initial phase; focus on admin accounts.

Keeper gateway requires a minimal-resource container (1 core, 1GB RAM). Outbound ports: 443 (HTTPS), 3478 TCP/UDP; no inbound public access required. Internal ports: 636 (LDAPS), 22 (SSH), 5986 (WinRM) as required for target endpoints. Azure AD integration: App registration must be single-tenant, with client/application ID, directory/tenant ID, and subscription ID. Privileged Authentication Administrator role assigned to the Keeper app in Azure for password rotation. Custom role assignment in Azure for subscription-level permissions. Keeper Vault: Users to be added as PAM users; rotation can be on-demand or scheduled. Post-rotation script support (optional), executed by gateway with required permissions. Trial activation issue resolved by refreshing, role policy adjustment, and proper assignment/removal of restrictive roles. Documentation provided for firewall and Azure app registration steps. No service account rotation in initial phase; focus on admin accounts. List all speakers/Participants of Transcript:

Nathan Turner (MCCU, Customer) Devon Wolf (MCCU, Customer) West Williams (MCCU, Customer) Roy Baker (Keeper, Vendor) Patrick
- Keeper (Keeper, Vendor)
Jax Miley (Keeper, Vendor) Manuel Zelaya (SHI, Partner/Account Manager) – not speaking, but as current user

Nathan Turner (MCCU, Customer) Devon Wolf (MCCU, Customer) West Williams (MCCU, Customer) Roy Baker (Keeper, Vendor) Patrick
- Keeper (Keeper, Vendor)
Jax Miley (Keeper, Vendor) Manuel Zelaya (SHI, Partner/Account Manager) – not speaking, but as current user

Potential Next Steps

Firewall Documentation Sharing:

Firewall Documentation Sharing:

Roy Baker (Keeper) to send firewall requirements documentation to West Williams (MCCU), who will forward to their MSP. Status: In progress; link sent in chat.

Roy Baker (Keeper) to send firewall requirements documentation to West Williams (MCCU), who will forward to their MSP. Status: In progress; link sent in chat.

Azure Container App Deployment:

Azure Container App Deployment:

West Williams to finish spinning up the Docker container with provided files from Devon Wolf. Status: In progress.

West Williams to finish spinning up the Docker container with provided files from Devon Wolf. Status: In progress.

Azure App Registration:

Azure App Registration:

Devon Wolf to create a new app registration in Azure for Keeper gateway (cannot use SSO app registration). Status: Completed during call.

Devon Wolf to create a new app registration in Azure for Keeper gateway (cannot use SSO app registration). Status: Completed during call.

Custom Role Assignment in Azure:

Custom Role Assignment in Azure:

Devon Wolf to assign custom role and privileged authentication administrator role to the Keeper app registration. Status: Completed during call.

Devon Wolf to assign custom role and privileged authentication administrator role to the Keeper app registration. Status: Completed during call.

Keeper Vault Configuration:

Keeper Vault Configuration:

Devon Wolf to add test users (admin accounts) as PAM users in Keeper Vault, configure rotation settings. Status: In progress; test user to be used (demo1).

Devon Wolf to add test users (admin accounts) as PAM users in Keeper Vault, configure rotation settings. Status: In progress; test user to be used (demo1).

Post-Rotation Script:

Post-Rotation Script:

Optional: Devon Wolf or team to develop/implement post-rotation script if needed; ensure necessary permissions.

Optional: Devon Wolf or team to develop/implement post-rotation script if needed; ensure necessary permissions.

Trial Monitoring and Testing:

Trial Monitoring and Testing:

MCCU team to test credential rotation, validate functionality, and document any issues.

MCCU team to test credential rotation, validate functionality, and document any issues.

Follow-up Meeting:

Follow-up Meeting:

Patrick (Keeper) to schedule follow-up/check-in for Monday, 23rd at 11:00 AM – 12:00 PM Central. Status: To be confirmed on calendars.

Patrick (Keeper) to schedule follow-up/check-in for Monday, 23rd at 11:00 AM – 12:00 PM Central. Status: To be confirmed on calendars.

Trial Duration:

Trial Duration:

MCCU to complete testing within 2-week trial period; raise any questions/issues to Keeper team or SHI (Manuel Zelaya).

MCCU to complete testing within 2-week trial period; raise any questions/issues to Keeper team or SHI (Manuel Zelaya). If further opportunities are identified in future sessions (e.g., extending to service accounts, broader PAM, or storage/security integrations), these should be listed with their own BANTC analysis.
