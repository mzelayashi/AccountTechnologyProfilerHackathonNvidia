Trip Report | FortiSASE | MCCU

Customer: MCCU
AE: Nicole A
Topic: FortiSASE
Meeting Date 04/17/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Devon W

review FortiSASE documentation and assess its integration with MCCU's current setup.

05/15

2

Manuel Z

Work with team to provide additional documentation and support materials related to FortiSASE and its deployment.

05/15

Item Owner Next Steps/Detail Due Date 1 Devon W review FortiSASE documentation and assess its integration with MCCU's current setup. 05/15 2 Manuel Z Work with team to provide additional documentation and support materials related to FortiSASE and its deployment. 05/15

Summary

The conversation focused on the demonstration and discussion of FortiSASE, a Fortinet solution aimed at enhancing security and connectivity for remote users. The participants included representatives from SHI, Fortinet, and Members Choice Credit Union (MCCU). Key topics included the need for secure remote access, challenges with traditional VPNs, and how FortiSASE could address these issues by providing a seamless, secure service edge and SD-WAN integration. The discussion highlighted the benefits of FortiSASE, including Zero Trust Network Access (ZTNA), centralized management, and improved visibility into network traffic. The conversation concluded with plans for further review of documentation and potential integration with MCCU's existing infrastructure.

Agenda

Introductions and participant roles Overview of FortiSASE capabilities Discussion of MCCU’s current environment and needs FortiSASE demo and technical explanations Q&A and next steps

Introductions and participant roles Overview of FortiSASE capabilities Discussion of MCCU’s current environment and needs FortiSASE demo and technical explanations Q&A and next steps

Opps Identified & BANTC

Opportunity 1: Secure Remote Access for
MCCU

Opportunity 1: Secure Remote Access for
MCCU

B: MCCU
needs to enhance remote user security and streamline VPN access.
A: Nathan
Turner, Director of IT Infrastructure and Information Security, is involved in decision-making.
N: Immediate
need due to expanding remote workforce and security concerns.
T: Implementation
desired in the short term, as remote access is a current priority.
C: Budget
considerations were not explicitly mentioned but implied need for cost-effective solutions.

B: MCCU
needs to enhance remote user security and streamline VPN access.
A: Nathan
Turner, Director of IT Infrastructure and Information Security, is involved in decision-making.
N: Immediate
need due to expanding remote workforce and security concerns.
T: Implementation
desired in the short term, as remote access is a current priority.
C: Budget
considerations were not explicitly mentioned but implied need for cost-effective solutions.

Initiatives

Security: Implementation of FortiSASE for enhanced security and secure remote access.

Security: Implementation of FortiSASE for enhanced security and secure remote access.

Tech Profile Updates

FortiSASE offers integration with existing SD-WAN solutions and provides ZTNA capabilities. It provides centralized management through FortiCloud and enhanced monitoring and analytics.

FortiSASE offers integration with existing SD-WAN solutions and provides ZTNA capabilities. It provides centralized management through FortiCloud and enhanced monitoring and analytics.

Meeting Notes

Environment

MCCU is expanding its VPN user base and looking to modernize its deployment for remote access. Current setup includes traditional VPNs with challenges in user authentication and seamless access.

MCCU is expanding its VPN user base and looking to modernize its deployment for remote access. Current setup includes traditional VPNs with challenges in user authentication and seamless access.

Detailed Discussion

The demo highlighted FortiSASE’s ability to provide secure and seamless remote access using ZTNA principles. Discussion on the integration of FortiSASE with existing MCCU infrastructure, including Active Directory and VPN systems. Challenges with traditional VPNs, such as lack of control and visibility, were addressed by FortiSASE’s capabilities.

The demo highlighted FortiSASE’s ability to provide secure and seamless remote access using ZTNA principles. Discussion on the integration of FortiSASE with existing MCCU infrastructure, including Active Directory and VPN systems. Challenges with traditional VPNs, such as lack of control and visibility, were addressed by FortiSASE’s capabilities.

Technical Notes

FortiSASE integrates SD-WAN with secure service edge capabilities. ZTNA provides session-based security checks for continuous verification of user access. FortiSASE supports various operating systems and offers advanced features like secure internet access and data loss prevention.

FortiSASE integrates SD-WAN with secure service edge capabilities. ZTNA provides session-based security checks for continuous verification of user access. FortiSASE supports various operating systems and offers advanced features like secure internet access and data loss prevention. List all speakers/Participants of Transcript:

Nicole Agoncillo (SHI) Michael Batts (SHI) Marc Constantine Mediavillo (Fortinet) Nathan Turner (MCCU) Devon Wolf (MCCU) West Williams (MCCU)

Nicole Agoncillo (SHI) Michael Batts (SHI) Marc Constantine Mediavillo (Fortinet) Nathan Turner (MCCU) Devon Wolf (MCCU) West Williams (MCCU)

Potential Next steps

Action Item 1: Devon Wolf and West Williams to review FortiSASE documentation and assess its integration with MCCU's current setup.

Action Item 1: Devon Wolf and West Williams to review FortiSASE documentation and assess its integration with MCCU's current setup.

Involved: Devon Wolf, West Williams, Marc Constantine Mediavillo

Involved: Devon Wolf, West Williams, Marc Constantine Mediavillo

Action Item 2: Marc Constantine Mediavillo to provide additional documentation and support materials related to FortiSASE and its deployment.

Action Item 2: Marc Constantine Mediavillo to provide additional documentation and support materials related to FortiSASE and its deployment.

Involved: Marc Constantine Mediavillo, Nathan Turner

Involved: Marc Constantine Mediavillo, Nathan Turner

Action Item 3: Nathan Turner to coordinate internally at MCCU to evaluate the potential shift to FortiSASE for enhanced security and user experience.

Action Item 3: Nathan Turner to coordinate internally at MCCU to evaluate the potential shift to FortiSASE for enhanced security and user experience.

Involved: Nathan Turner, Devon Wolf, West Williams

Involved: Nathan Turner, Devon Wolf, West Williams These steps will help MCCU assess the feasibility and benefits of deploying FortiSASE in their environment, ensuring better security and user access management.
