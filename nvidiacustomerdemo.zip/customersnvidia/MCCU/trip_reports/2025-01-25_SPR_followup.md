Trip Report | SPR followup | MCCU

Customer: MCCU
AE: Nicole A
Topic: SPR followup
Meeting Date 01/25/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Glenn C

conduct a data protection briefing with Nathan Turner and Henry Huff, focusing on DLP and data governance and  provide alternative GRC tool recommendations to Nathan Turner for evaluation by MCCU's enterprise risk team.

02/25

2

Nicole A

to coordinate follow-up meetings to discuss deliverables and action items with MCCU stakeholders.

02/24

Item Owner Next Steps/Detail Due Date 1 Glenn C conduct a data protection briefing with Nathan Turner and Henry Huff, focusing on DLP and data governance and  provide alternative GRC tool recommendations to Nathan Turner for evaluation by MCCU's enterprise risk team. 02/25 2 Nicole A to coordinate follow-up meetings to discuss deliverables and action items with MCCU stakeholders. 02/24

Summary

The meeting involved a detailed discussion between MCCU and SHI representatives focusing on network security and data protection. The primary focus was on MCCU's current use of Fortinet products for network security, including firewalls, VPNs, and authentication tools. Earl O'Connor provided insights into security features and recommended best practices for optimizing Fortinet's security capabilities, including SSL decryption and network segmentation. Discussions also covered email phishing protection, data loss prevention (DLP), and cloud security posture management (CSPM), with recommendations for enhancing these areas. The conversation highlighted MCCU's need to improve data governance and protection strategies, as well as their interest in evaluating additional security tools like CASB and GRC solutions.

Agenda

Introduction and meeting logistics Review of previous meeting topics and follow-up Discussion on Fortinet security features and best practices Exploration of data protection and governance strategies Recommendations for cloud security management tools Evaluation of GRC tools and third-party management practices

Next steps and

closing remarks

Introduction and meeting logistics Review of previous meeting topics and follow-up Discussion on Fortinet security features and best practices Exploration of data protection and governance strategies Recommendations for cloud security management tools Evaluation of GRC tools and third-party management practices

Next steps and

closing remarks Opps Identified & BANTC:

Opportunity: Enhancing Fortinet Security Features

Opportunity: Enhancing Fortinet Security Features

B: MCCU uses
Fortinet products for network security and is interested in optimizing their capabilities.
A: Earl
O'Connor and Glenn Crist to provide recommendations and best practices.
N: Need to
improve SSL decryption and ensure management interfaces are secure.
T: Immediate
to short-term implementation.
C: Network

security and data protection enhancement.

B: MCCU uses
Fortinet products for network security and is interested in optimizing their capabilities.
A: Earl
O'Connor and Glenn Crist to provide recommendations and best practices.
N: Need to
improve SSL decryption and ensure management interfaces are secure.
T: Immediate
to short-term implementation.
C: Network

security and data protection enhancement.

Opportunity: Data Protection and Governance

Opportunity: Data Protection and Governance

B: MCCU lacks
a comprehensive data protection strategy.
A: Glenn Crist
to provide a data protection briefing and recommendations.
N: Need for a
robust data governance framework and DLP solutions.
T: Medium-term
to long-term implementation.
C: Ensuring
data security and regulatory compliance.

B: MCCU lacks
a comprehensive data protection strategy.
A: Glenn Crist
to provide a data protection briefing and recommendations.
N: Need for a
robust data governance framework and DLP solutions.
T: Medium-term
to long-term implementation.
C: Ensuring
data security and regulatory compliance.

Opportunity: Cloud Security Posture Management (CSPM)

Opportunity: Cloud Security Posture Management (CSPM)

B: Interest in
CSPM tools for better cloud security management.
A: Earl
O'Connor to recommend suitable CSPM tools.
N: Need to
manage cloud security risks effectively.
T: Short-term
exploration with potential long-term implementation.
C: Cloud

security enhancement.

B: Interest in
CSPM tools for better cloud security management.
A: Earl
O'Connor to recommend suitable CSPM tools.
N: Need to
manage cloud security risks effectively.
T: Short-term
exploration with potential long-term implementation.
C: Cloud

security enhancement.

Opportunity: Evaluating GRC Tools

Opportunity: Evaluating GRC Tools

B: Dissatisfaction
with current GRC tool, inContracts.
A: Glenn Crist
to provide recommendations for alternative GRC solutions.
N: Need to
improve compliance and risk management processes.
T: Medium-term
evaluation and potential transition.
C: Improved
compliance management.

B: Dissatisfaction
with current GRC tool, inContracts.
A: Glenn Crist
to provide recommendations for alternative GRC solutions.
N: Need to
improve compliance and risk management processes.
T: Medium-term
evaluation and potential transition.
C: Improved
compliance management.

Initiatives

Security: Enhancing Fortinet security features, SSL decryption, and network segmentation. Storage: Exploring CSPM tools for cloud security.

Security: Enhancing Fortinet security features, SSL decryption, and network segmentation. Storage: Exploring CSPM tools for cloud security. Tech Profile Updates:

Current use of Fortinet products for network security. Interest in CSPM tools and alternative GRC solutions.

Current use of Fortinet products for network security. Interest in CSPM tools and alternative GRC solutions. Meeting Notes:

Environment

MCCU utilizes Fortinet firewalls, VPNs, and authentication tools for network security. Current challenges include SSL decryption issues and limited data protection strategies.

MCCU utilizes Fortinet firewalls, VPNs, and authentication tools for network security. Current challenges include SSL decryption issues and limited data protection strategies. Detailed Discussion: Technical Notes:

Fortinet firewalls are used for client VPN and East-West traffic inspection. SSL decryption is problematic; recommendations include using an internal root certificate and phased rollout. Management interfaces are not exposed to the internet, but Azure VMs have public IP objects. BGP peers are password-protected; IPSEC tunnels use compliant algorithms. Interest in CASB and SASE solutions, as well as CSPM tools for cloud security. Current GRC tool is inContracts; alternative solutions like ServiceNow and OneTrust are considered.

Fortinet firewalls are used for client VPN and East-West traffic inspection. SSL decryption is problematic; recommendations include using an internal root certificate and phased rollout. Management interfaces are not exposed to the internet, but Azure VMs have public IP objects. BGP peers are password-protected; IPSEC tunnels use compliant algorithms. Interest in CASB and SASE solutions, as well as CSPM tools for cloud security. Current GRC tool is inContracts; alternative solutions like ServiceNow and OneTrust are considered. List all speakers/Participants of Transcript:

Nicole Agoncillo Devon Wolf Earl O'Connor Henry Huff Glenn Crist Nathan Turner

Nicole Agoncillo Devon Wolf Earl O'Connor Henry Huff Glenn Crist Nathan Turner Potential

Next Steps

Earl O'Connor to provide detailed recommendations for optimizing Fortinet security features to Nathan Turner and Devon Wolf. Glenn Crist to conduct a data protection briefing with Nathan Turner and Henry Huff, focusing on DLP and data governance. Earl O'Connor to explore CSPM tools suitable for MCCU's cloud environment and provide recommendations to Nathan Turner. Glenn Crist to provide alternative GRC tool recommendations to Nathan Turner for evaluation by MCCU's enterprise risk team. Nicole Agoncillo to coordinate follow-up meetings to discuss deliverables and action items with MCCU stakeholders.

Earl O'Connor to provide detailed recommendations for optimizing Fortinet security features to Nathan Turner and Devon Wolf. Glenn Crist to conduct a data protection briefing with Nathan Turner and Henry Huff, focusing on DLP and data governance. Earl O'Connor to explore CSPM tools suitable for MCCU's cloud environment and provide recommendations to Nathan Turner. Glenn Crist to provide alternative GRC tool recommendations to Nathan Turner for evaluation by MCCU's enterprise risk team. Nicole Agoncillo to coordinate follow-up meetings to discuss deliverables and action items with MCCU stakeholders.
