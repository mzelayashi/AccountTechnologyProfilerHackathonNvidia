Trip Report | Managed Network Services | MCCU

Customer: MCCU
AE: Nicole A
Topic: Managed Network Services
Meeting Date 06/20/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Nicole A

coordinate with MCCU for customer-facing call; Mat Seydel to join for deep-dive on services and scope.

07/05

2

Manuel Z

Assist to find if SHI solution exceeds MCCU’s budget, discuss value/benefit and compare to cost of internal staffing;

07/05

Item Owner Next Steps/Detail Due Date 1 Nicole A coordinate with MCCU for customer-facing call; Mat Seydel to join for deep-dive on services and scope. 07/05 2 Manuel Z Assist to find if SHI solution exceeds MCCU’s budget, discuss value/benefit and compare to cost of internal staffing; 07/05

Summary

This was an internal SHI sync between Nicole Agoncillo (Account Manager), Manuel Zelaya (Solutions Engineer), and Mat Seydel (Managed Services Specialist) to align on a potential managed network services (MNS) opportunity for Member Choice Credit Union (MCCU). Nicole and Manuel briefed Mat on MCCU’s needs, current budget constraints, and internal context. Mat provided an overview of SHI’s Connect managed network services offering, including pricing structure (minimum $100K/year), what’s included (device management, patching, security, remote/on-site support), and implementation approach. The team discussed the disconnect between MCCU’s budget ($60K/year) and SHI’s minimum, agreed to present the solution anyway, and will request network inventory/specs from MCCU prior to a scoping call. They reviewed MCCU’s environment (9 branches, HQ/micro data center in Katy, TX) and discussed next steps, including scheduling a customer-facing scoping call and obtaining detailed device counts for accurate pricing.

Agenda

Introductions and roles Review of MCCU’s managed services request, current budget, and context Overview of SHI Connect managed network services (scope, pricing, deliverables) Discussion of site/device counts, HQ/data center setup, and support model Considerations for MCCU’s internal IT staffing and cost/benefit Next steps: gathering inventory, scheduling customer scoping call, preparing proposal

Introductions and roles Review of MCCU’s managed services request, current budget, and context Overview of SHI Connect managed network services (scope, pricing, deliverables) Discussion of site/device counts, HQ/data center setup, and support model Considerations for MCCU’s internal IT staffing and cost/benefit Next steps: gathering inventory, scheduling customer scoping call, preparing proposal

Opps Identified & BANTC

Opportunity: Managed Network Services for Member Choice Credit Union

B (Budget): MCCU’s stated budget is $60,000/year ($5,000/month), but SHI’s minimum for managed network services is $100,000/year ($8,300/month). There is a $40K delta, but SHI will present regardless; customer is cost-sensitive and likely shopping other vendors. A (Authority): Decision-makers presumed to be MCCU IT and operations leadership. Nicole is primary contact; Mat Bracy made initial referral. N (Need): Full managed services for network (switches, firewalls, WAPs), security, patching, remote and on-site support. Trigger for project is likely new branch opening and/or offloading work from small IT staff. T (Timeline): Customer is actively exploring now, likely driven by new branch. Scoping call to be scheduled ASAP; implementation estimated at 4–6 weeks post-contract. C (Competition): MCCU is shopping other MSPs (tried Strata Skill previously); may consider smaller/cheaper providers. SHI’s solution is enterprise-grade, minimum $100K/yr.

B (Budget): MCCU’s stated budget is $60,000/year ($5,000/month), but SHI’s minimum for managed network services is $100,000/year ($8,300/month). There is a $40K delta, but SHI will present regardless; customer is cost-sensitive and likely shopping other vendors. A (Authority): Decision-makers presumed to be MCCU IT and operations leadership. Nicole is primary contact; Mat Bracy made initial referral. N (Need): Full managed services for network (switches, firewalls, WAPs), security, patching, remote and on-site support. Trigger for project is likely new branch opening and/or offloading work from small IT staff. T (Timeline): Customer is actively exploring now, likely driven by new branch. Scoping call to be scheduled ASAP; implementation estimated at 4–6 weeks post-contract. C (Competition): MCCU is shopping other MSPs (tried Strata Skill previously); may consider smaller/cheaper providers. SHI’s solution is enterprise-grade, minimum $100K/yr.

Initiatives

Security & Networking: This opportunity is

primarily Security (patching, monitoring, architecture reviews, wireless analysis) and Networking (infrastructure device management, support).

Tech Profile Updates

Branches: 9 physical branches (does not include ATMs), plus HQ/micro data center in Katy, TX. Data Center: All network ingress/egress and VPN terminated at Katy HQ data center; firewalls located here. Devices: Device counts (switches, WAPs, routers, firewalls) needed for accurate pricing. Model is per-device/per-month. Staff: IT staff size unknown, likely small (2–3 people). Current Status: No current managed services provider; services likely handled in-house. Security: Currently evaluating Keeper for password/identity security. Growth: New branch opening is likely trigger for managed services inquiry.

Branches: 9 physical branches (does not include ATMs), plus HQ/micro data center in Katy, TX. Data Center: All network ingress/egress and VPN terminated at Katy HQ data center; firewalls located here. Devices: Device counts (switches, WAPs, routers, firewalls) needed for accurate pricing. Model is per-device/per-month. Staff: IT staff size unknown, likely small (2–3 people). Current Status: No current managed services provider; services likely handled in-house. Security: Currently evaluating Keeper for password/identity security. Growth: New branch opening is likely trigger for managed services inquiry.

Meeting Notes

Environment

MCCU is Houston-based, 9 branches + HQ/data center. Network hub is Katy, TX HQ; all WAN/LAN routed through here. Seeking managed network services to support network, wireless, and security, possibly to augment a small IT team. Customer is cost-sensitive and may be comparing multiple MSPs.

MCCU is Houston-based, 9 branches + HQ/data center. Network hub is Katy, TX HQ; all WAN/LAN routed through here. Seeking managed network services to support network, wireless, and security, possibly to augment a small IT team. Customer is cost-sensitive and may be comparing multiple MSPs.

Detailed Discussion

SHI Connect minimum is $100K/year, includes device management, patching, security, remote support, and on-demand on-site smart hands (third-party partners for national dispatch). Pricing is per-device/per-month; site and device counts (core/edge switches, firewalls, WAPs) drive proposal. On-site support is time/materials, can be scheduled regularly or as-needed. Meraki environments are easier/cheaper to onboard; SHI can support any network vendor. Implementation (onboarding) for an org of this size (approx. 100 devices, 10 sites) is 4–6 weeks. Benefits highlighted: managed services provide continuous coverage, relieve IT staff, include proactive reviews, and ensure up-to-date patching/firmware. Nicole/Manuel to request device inventory/specs from MCCU before scoping call; Mat can join call with or without full inventory.

SHI Connect minimum is $100K/year, includes device management, patching, security, remote support, and on-demand on-site smart hands (third-party partners for national dispatch). Pricing is per-device/per-month; site and device counts (core/edge switches, firewalls, WAPs) drive proposal. On-site support is time/materials, can be scheduled regularly or as-needed. Meraki environments are easier/cheaper to onboard; SHI can support any network vendor. Implementation (onboarding) for an org of this size (approx. 100 devices, 10 sites) is 4–6 weeks. Benefits highlighted: managed services provide continuous coverage, relieve IT staff, include proactive reviews, and ensure up-to-date patching/firmware. Nicole/Manuel to request device inventory/specs from MCCU before scoping call; Mat can join call with or without full inventory.

Technical Notes

Service covers switches, firewalls, routers, wireless APs; can extend to server monitoring if desired. Pricing depends on device/site count (e.g., ~100 devices across 10 sites). Support model: remote-first, with on-site dispatch as needed via partners, billed in arrears. Architecture and wireless analysis, equipment age/firmware advisories, included in service. Meraki devices simplify onboarding (cloud-based). SHI managed services minimum is $100K/year; cannot offer “barebones” service below this threshold. MCCU’s current security stack known, but not network inventory.

Service covers switches, firewalls, routers, wireless APs; can extend to server monitoring if desired. Pricing depends on device/site count (e.g., ~100 devices across 10 sites). Support model: remote-first, with on-site dispatch as needed via partners, billed in arrears. Architecture and wireless analysis, equipment age/firmware advisories, included in service. Meraki devices simplify onboarding (cloud-based). SHI managed services minimum is $100K/year; cannot offer “barebones” service below this threshold. MCCU’s current security stack known, but not network inventory. List all speakers/Participants of Transcript:

Nicole Agoncillo (SHI, Account Manager) Manuel Zelaya (SHI, Core Solutions Engineer) Mat Seydel (SHI, Managed Services Specialist)

Nicole Agoncillo (SHI, Account Manager) Manuel Zelaya (SHI, Core Solutions Engineer) Mat Seydel (SHI, Managed Services Specialist)

Potential Next steps

Request Network Inventory/Specs from MCCU

Request Network Inventory/Specs from MCCU

Nicole to reach out to MCCU (contact: Nathan) to request full device and site inventory. Action: Nicole Agoncillo → MCCU

Nicole to reach out to MCCU (contact: Nathan) to request full device and site inventory. Action: Nicole Agoncillo → MCCU

Schedule Scoping Call with MCCU

Schedule Scoping Call with MCCU

Nicole to coordinate with MCCU for customer-facing call; Mat Seydel to join for deep-dive on services and scope. Action: Nicole Agoncillo → MCCU, Mat Seydel, Manuel Zelaya

Nicole to coordinate with MCCU for customer-facing call; Mat Seydel to join for deep-dive on services and scope. Action: Nicole Agoncillo → MCCU, Mat Seydel, Manuel Zelaya

Prepare Preliminary Pricing/Proposal

Prepare Preliminary Pricing/Proposal

Mat to draft preliminary pricing based on estimated device counts and update as more detail is provided. Action: Mat Seydel

Mat to draft preliminary pricing based on estimated device counts and update as more detail is provided. Action: Mat Seydel

Present Solution/Cost-Benefit

Present Solution/Cost-Benefit

SHI team to present managed services solution, highlight operational benefits (freeing up IT staff, proactive support, etc.), and address budget concerns. Action: Nicole Agoncillo, Mat Seydel, Manuel Zelaya → MCCU

SHI team to present managed services solution, highlight operational benefits (freeing up IT staff, proactive support, etc.), and address budget concerns. Action: Nicole Agoncillo, Mat Seydel, Manuel Zelaya → MCCU

Alternative Options Discussion (if Over Budget)

Alternative Options Discussion (if Over Budget)

If SHI solution exceeds MCCU’s budget, discuss value/benefit and compare to cost of internal staffing; acknowledge other providers may be less expensive but with different service levels. Action: Nicole Agoncillo, Mat Seydel

If SHI solution exceeds MCCU’s budget, discuss value/benefit and compare to cost of internal staffing; acknowledge other providers may be less expensive but with different service levels. Action: Nicole Agoncillo, Mat Seydel

Follow-up on Keeper Opportunity

Follow-up on Keeper Opportunity

Maintain engagement on separate Keeper (password/identity security) opportunity. Action: Nicole Agoncillo, Manuel Zelaya

Maintain engagement on separate Keeper (password/identity security) opportunity. Action: Nicole Agoncillo, Manuel Zelaya
