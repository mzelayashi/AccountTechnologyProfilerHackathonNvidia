Trip Report | MS Purvriew | MCCU

Customer: MCCU
AE: Nicole A
Topic: MS Purvriew
Meeting Date 04/22/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Jace Rose

Stratascale team to draft a proposal based on the discussion and MCCU's needs.

05/12

2

Nicole/Tony

coordinate the next meeting with MCCU.

05/13

3

Manuel Z

review audit findings and provide specific details to the Stratascale team

05/14

Item Owner Next Steps/Detail Due Date 1 Jace Rose Stratascale team to draft a proposal based on the discussion and MCCU's needs. 05/12 2 Nicole/Tony coordinate the next meeting with MCCU. 05/13 3 Manuel Z review audit findings and provide specific details to the Stratascale team 05/14

Summary

The call was primarily focused on the scoping of a Purview implementation for Members Choice Credit Union (MCCU). The key issues discussed included the need for a robust data protection strategy, addressing data leakage, and enhancing data classification and governance strategies. The conversation highlighted the importance of defining trusted domains and third-party risk management, as well as identifying and managing sensitive data across the organization. The participants agreed on the next steps to draft a proposal for the implementation, considering the business drivers and budgetary constraints.

Agenda

Introductions and role clarifications Discussion of current data protection challenges Exploration of Purview and data protection strategies

Next steps and

follow-up actions

Introductions and role clarifications Discussion of current data protection challenges Exploration of Purview and data protection strategies

Next steps and

follow-up actions

Opportunities

Identified & BANTC:

Opportunity 1: Data Protection and Classification Enhancement

Opportunity 1: Data Protection and Classification Enhancement

B: MCCU needs
to secure data transmission and data at rest, improve data classification, and prevent data leakage.
A: Nathan
Turner (Director of IT Infrastructure and Information Security) and other IT team members are key decision-makers.
N: Immediate
need for a data protection strategy and Purview implementation due to regulatory requirements and internal data sprawl.
T: Budget for
the project is yet to be confirmed and may require approval.
C: Compliance
with NCUA, GLBA, and PCI regulations is essential.

B: MCCU needs
to secure data transmission and data at rest, improve data classification, and prevent data leakage.
A: Nathan
Turner (Director of IT Infrastructure and Information Security) and other IT team members are key decision-makers.
N: Immediate
need for a data protection strategy and Purview implementation due to regulatory requirements and internal data sprawl.
T: Budget for
the project is yet to be confirmed and may require approval.
C: Compliance
with NCUA, GLBA, and PCI regulations is essential.

Initiatives

Security: Focus on data protection, governance policies, and regulatory compliance.

Security: Focus on data protection, governance policies, and regulatory compliance. Tech Profile Updates:

Current data governance policies are mature but not fully implemented. Data classification processes need enhancement to align with regulatory requirements.

Current data governance policies are mature but not fully implemented. Data classification processes need enhancement to align with regulatory requirements. Meeting Notes:

Environment

MCCU operates within a regulated financial sector with strict compliance needs. Current data management practices involve manual processes and lack automation.

MCCU operates within a regulated financial sector with strict compliance needs. Current data management practices involve manual processes and lack automation. Detailed Discussion:

The need for a structured data protection strategy was emphasized, focusing on endpoint DLP and data leakage prevention. Discussion on the importance of aligning data governance policies with regulatory frameworks. Identified the necessity for defining trusted domains and managing third-party risks.

The need for a structured data protection strategy was emphasized, focusing on endpoint DLP and data leakage prevention. Discussion on the importance of aligning data governance policies with regulatory frameworks. Identified the necessity for defining trusted domains and managing third-party risks. Technical Notes:

Purview implementation should consider existing data classification categories such as regulated data, member confidential data, and restricted information. Simulation policies in Purview could help in testing data classification without generating alerts or blocks. Encryption risk assessment and its configuration settings were briefly discussed.

Purview implementation should consider existing data classification categories such as regulated data, member confidential data, and restricted information. Simulation policies in Purview could help in testing data classification without generating alerts or blocks. Encryption risk assessment and its configuration settings were briefly discussed. List of Speakers/Participants of Transcript:

Nicole Agoncillo (SHI Account Executive) Manuel Zelaya (SHI Dedicated Solutions Corps SC) Jace Rose (Stratascale Cybersecurity Advisor) Daniel Shaul (Stratascale Principal Consultant) Joseph Karpenko (Stratascale CSO Executive Advisor) Nathan Turner (MCCU Director of IT Infrastructure and Information Security) Devon Wolf (MCCU Cloud and Infrastructure Administrator) Henry Huff (MCCU Junior Cyber Security Specialist)

Nicole Agoncillo (SHI Account Executive) Manuel Zelaya (SHI Dedicated Solutions Corps SC) Jace Rose (Stratascale Cybersecurity Advisor) Daniel Shaul (Stratascale Principal Consultant) Joseph Karpenko (Stratascale CSO Executive Advisor) Nathan Turner (MCCU Director of IT Infrastructure and Information Security) Devon Wolf (MCCU Cloud and Infrastructure Administrator) Henry Huff (MCCU Junior Cyber Security Specialist) Potential

Next Steps

Develop a proposal for Purview implementation:

Develop a proposal for Purview implementation:

Action Item: Stratascale team to draft a proposal based on the discussion and MCCU's needs. Responsible Parties: Jace Rose, Daniel Shaul, and the Stratascale team.

Action Item: Stratascale team to draft a proposal based on the discussion and MCCU's needs. Responsible Parties: Jace Rose, Daniel Shaul, and the Stratascale team.

Schedule a follow-up call to review the proposal:

Schedule a follow-up call to review the proposal:

Action Item: Nicole Agoncillo and Jace Rose to coordinate the next meeting with MCCU. Responsible Parties: Nicole Agoncillo, Jace Rose, Nathan Turner, and MCCU team.

Action Item: Nicole Agoncillo and Jace Rose to coordinate the next meeting with MCCU. Responsible Parties: Nicole Agoncillo, Jace Rose, Nathan Turner, and MCCU team.

Clarify encryption risk assessment requirements:

Clarify encryption risk assessment requirements:

Action Item: Nathan Turner to review audit findings and provide specific details to the Stratascale team. Responsible Parties: Nathan Turner and Joseph Karpenko.

Action Item: Nathan Turner to review audit findings and provide specific details to the Stratascale team. Responsible Parties: Nathan Turner and Joseph Karpenko.

Evaluate budget and approval process for the project:

Evaluate budget and approval process for the project:

Action Item: Nathan Turner to outline the budgetary requirements and approval process. Responsible Parties: Nathan Turner and MCCU management.

Action Item: Nathan Turner to outline the budgetary requirements and approval process. Responsible Parties: Nathan Turner and MCCU management. 🔄
