Trip Report | DataCenter | Par Pacific

Customer: Par Pacific
AE: Manuel Z
Topic: DataCenter
Meeting Date 05/01/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

David H

Follow-up call or email to finalize configuration, confirm order, and proceed with procurement after quote/lead time are reviewed.

05/25

2

Manuel Z

Assist in review Dell Native Edge information for future edge/remote management consideration.

05/25

Item Owner Next Steps/Detail Due Date 1 David H Follow-up call or email to finalize configuration, confirm order, and proceed with procurement after quote/lead time are reviewed. 05/25 2 Manuel Z Assist in review Dell Native Edge information for future edge/remote management consideration. 05/25

Summary

This call centers around Par Pacific’s need to replace SuperMicro hardware with Dell solutions for edge computing environments, specifically for refinery clusters located outside traditional data centers (e.g., in Hawaii). The customer is seeking a ruggedized, high-density, cost-effective server solution that meets both power and compute requirements, while being mindful of lead times and supply chain realities. Dell’s XR platform is discussed as a primary contender, offering up to four nodes per chassis, with strengths in integrated security, manageability, and support compared to SuperMicro. The conversation covers technical details (power supplies, networking, physical form factor), configuration questions, and logistics (shipping to Hawaii, power cord types). Dell’s Native Edge platform is introduced as a future option for automated, secure edge deployments, though Par Pacific’s current need is for isolated, on-premises clusters at refineries rather than large-scale edge rollouts. Next steps include configuration, quoting, lead time verification, and ensuring power compatibility. Agenda: • Discuss Dell server options as SuperMicro replacements for edge/refinery use • Review technical specs: power, form factor, density, networking, security • Compare costs and feature sets (Dell vs. SuperMicro) • Confirm configuration and compatibility (power, networking, physical) • Discuss logistics: shipping, power cords, delivery timelines • Share information on Dell Native Edge as a future consideration • Establish next steps for quoting and deployment

Opps Identified & BANTC

Opportunity 1: SuperMicro Replacement with Dell XR
Platform for Edge/Refinery Clusters

B: Budget
• Customer is price-sensitive and wants to compare Dell’s solution to
previously quoted SuperMicro pricing. Acknowledges that Dell is typically more expensive due to better security/support, but seeks a solution within acceptable cost parameters. A: Authority
• Decision-makers on call include Constance Rowan (likely primary
technical lead), David Hamilton (project manager/procurement), and Kaitlin Abbott (quoting/support from vendor). N: Need
• Need to replace unavailable SuperMicro edge hardware with a Dell
solution that meets compute (core count, RAM), power (120V support), and ruggedization requirements for refinery use. T: Timeline
• ASAP – Projects have been waiting on hardware, and there is urgency
to deliver. Lead time is a critical factor in selection. C: Competition
• SuperMicro is/was the incumbent. Other server vendors and form
factors (rackmount vs. modular) considered, but Dell XR is primary option due to supply chain, support, and feature set.

B: Budget
• Customer is price-sensitive and wants to compare Dell’s solution to
previously quoted SuperMicro pricing. Acknowledges that Dell is typically more expensive due to better security/support, but seeks a solution within acceptable cost parameters. A: Authority
• Decision-makers on call include Constance Rowan (likely primary
technical lead), David Hamilton (project manager/procurement), and Kaitlin Abbott (quoting/support from vendor). N: Need
• Need to replace unavailable SuperMicro edge hardware with a Dell
solution that meets compute (core count, RAM), power (120V support), and ruggedization requirements for refinery use. T: Timeline
• ASAP – Projects have been waiting on hardware, and there is urgency
to deliver. Lead time is a critical factor in selection. C: Competition
• SuperMicro is/was the incumbent. Other server vendors and form
factors (rackmount vs. modular) considered, but Dell XR is primary option due to supply chain, support, and feature set.

Initiatives

Storage: Indirectly (boot drives discussed, storage density not primary focus)

Security

Yes (integrated security, firmware lockdown, Dell Native Edge platform discussed)

Storage: Indirectly (boot drives discussed, storage density not primary focus)

Security

Yes (integrated security, firmware lockdown, Dell Native Edge platform discussed)

Tech Profile Updates

Par Pacific is migrating most infrastructure to the cloud, but maintaining small, ruggedized clusters at refineries (edge environments). Power supply requirements are stringent (120V compatibility, C19/C20 or NEMA 5/15 plugs). Networking: Needs SFP28 cables, dual-port per blade, pair of switches per chassis. Boot drive requirements: 2x480GB SSDs per node. Interested in scalable, remotely manageable solutions for future (Dell Native Edge).

Par Pacific is migrating most infrastructure to the cloud, but maintaining small, ruggedized clusters at refineries (edge environments). Power supply requirements are stringent (120V compatibility, C19/C20 or NEMA 5/15 plugs). Networking: Needs SFP28 cables, dual-port per blade, pair of switches per chassis. Boot drive requirements: 2x480GB SSDs per node. Interested in scalable, remotely manageable solutions for future (Dell Native Edge).

Meeting Notes

Environment

Edge/refinery (outside traditional data center) Power supply: 120V, standard US plugs (NEMA 5/15 or C19/C20) Shipping/logistics: Hawaii, special considerations for freight

Edge/refinery (outside traditional data center) Power supply: 120V, standard US plugs (NEMA 5/15 or C19/C20) Shipping/logistics: Hawaii, special considerations for freight

Detailed Discussion

Dell XR chassis can support 4 nodes, each up to 32 cores/512GB RAM (256 cores total per chassis). Dell’s ruggedized chassis (filtered bezel, front-facing IO) is designed for edge environments. Power supply: Typically dual 1400W, with 1800W available for higher GPU/wattage configs. Needs to be verified for 120V operation. Networking: 25/40/100/200GbE options discussed; customer may not need high-end networking. Price point: Dell is more expensive due to integrated security and support, but not prohibitive; needs quoting. Lead time: To be checked post-configuration; urgency highlighted. Management: Dell’s auto-provisioning, security lockdown, and remote management features highlighted. Dell Native Edge: Introduced as a zero-trust, automated deployment platform for future scalability.

Dell XR chassis can support 4 nodes, each up to 32 cores/512GB RAM (256 cores total per chassis). Dell’s ruggedized chassis (filtered bezel, front-facing IO) is designed for edge environments. Power supply: Typically dual 1400W, with 1800W available for higher GPU/wattage configs. Needs to be verified for 120V operation. Networking: 25/40/100/200GbE options discussed; customer may not need high-end networking. Price point: Dell is more expensive due to integrated security and support, but not prohibitive; needs quoting. Lead time: To be checked post-configuration; urgency highlighted. Management: Dell’s auto-provisioning, security lockdown, and remote management features highlighted. Dell Native Edge: Introduced as a zero-trust, automated deployment platform for future scalability.

Technical Notes

XR chassis: 4 nodes/blades, each 32-core, 512GB max RAM; supports GPUs if NICs removed (requires 1800W PSU for GPUs). Chassis uses dual 1400W power supplies (active/passive); confirm configuration for 120V compatibility. SFP28 networking cables required, 2 per blade (8 total for 4 blades). Standard boot drives: 2x480GB SSD per node. Power cord: Preference/requirement for NEMA 5/15 or C19/C20 (depends on site). Shipping: Needs to Hawaii, confirmed no free shipping. Lead time: To be provided after configuration/quote. Dell’s auto-provisioning can lock down firmware/drivers for security compliance. Dell Native Edge: Zero-trust, automated provisioning/orchestration for edge; suited for large-scale deployments, not current use.

XR chassis: 4 nodes/blades, each 32-core, 512GB max RAM; supports GPUs if NICs removed (requires 1800W PSU for GPUs). Chassis uses dual 1400W power supplies (active/passive); confirm configuration for 120V compatibility. SFP28 networking cables required, 2 per blade (8 total for 4 blades). Standard boot drives: 2x480GB SSD per node. Power cord: Preference/requirement for NEMA 5/15 or C19/C20 (depends on site). Shipping: Needs to Hawaii, confirmed no free shipping. Lead time: To be provided after configuration/quote. Dell’s auto-provisioning can lock down firmware/drivers for security compliance. Dell Native Edge: Zero-trust, automated provisioning/orchestration for edge; suited for large-scale deployments, not current use. List all speakers/Participants of Transcript:

Horne, Briggs (Dell technical/solutions expert) Rowan, Constance (Par Pacific technical lead/engineer) Abbott, Kaitlin (Vendor/solutions quoting and logistics) David Hamilton (Par Pacific project manager/procurement) Manuel Zelaya (SHI, observer/participant; current user)

Horne, Briggs (Dell technical/solutions expert) Rowan, Constance (Par Pacific technical lead/engineer) Abbott, Kaitlin (Vendor/solutions quoting and logistics) David Hamilton (Par Pacific project manager/procurement) Manuel Zelaya (SHI, observer/participant; current user)

Potential Next Steps

Action: Kaitlin Abbott to build and send quote for Dell XR configuration to David Hamilton and Constance Rowan.
• Who: Kaitlin Abbott → David Hamilton, Constance Rowan
• Status: In progress; to be completed same day.
Action: Verify power supply compatibility with 120V and correct cord type for Hawaii site.
• Who: Kaitlin Abbott (initial config), Horne Briggs (power
calculator tool)
• Status: Kaitlin to send solution ID to Briggs, who will verify with
Dell tool. Action: Confirm lead time for quoted configuration and update customer.
• Who: Kaitlin Abbott → David Hamilton, Constance Rowan
• Status: To be provided post-configuration.
Action: Customer to confirm shipping address and power cord requirements for Hawaii refinery.
• Who: Constance Rowan → Kaitlin Abbott
• Status: Awaiting customer confirmation.
Action: Provide required quantity of SFP28 cables (8 total) and confirm networking requirements in quote.
• Who: Kaitlin Abbott → David Hamilton, Constance Rowan
• Status: In progress.
Action: Constance Rowan to review Dell Native Edge information for future edge/remote management consideration.
• Who: Horne Briggs → Constance Rowan
• Status: Link shared; for future reference.
Action: Follow-up call or email to finalize configuration, confirm order, and proceed with procurement after quote/lead time are reviewed.
• Who: David Hamilton, Constance Rowan, Kaitlin Abbott
• Status: Pending after quote delivery.

Action: Kaitlin Abbott to build and send quote for Dell XR configuration to David Hamilton and Constance Rowan.
• Who: Kaitlin Abbott → David Hamilton, Constance Rowan
• Status: In progress; to be completed same day.
Action: Verify power supply compatibility with 120V and correct cord type for Hawaii site.
• Who: Kaitlin Abbott (initial config), Horne Briggs (power
calculator tool)
• Status: Kaitlin to send solution ID to Briggs, who will verify with
Dell tool. Action: Confirm lead time for quoted configuration and update customer.
• Who: Kaitlin Abbott → David Hamilton, Constance Rowan
• Status: To be provided post-configuration.
Action: Customer to confirm shipping address and power cord requirements for Hawaii refinery.
• Who: Constance Rowan → Kaitlin Abbott
• Status: Awaiting customer confirmation.
Action: Provide required quantity of SFP28 cables (8 total) and confirm networking requirements in quote.
• Who: Kaitlin Abbott → David Hamilton, Constance Rowan
• Status: In progress.
Action: Constance Rowan to review Dell Native Edge information for future edge/remote management consideration.
• Who: Horne Briggs → Constance Rowan
• Status: Link shared; for future reference.
Action: Follow-up call or email to finalize configuration, confirm order, and proceed with procurement after quote/lead time are reviewed.
• Who: David Hamilton, Constance Rowan, Kaitlin Abbott
• Status: Pending after quote delivery.
From <https://mindspark.shi.com/My_Agents>
