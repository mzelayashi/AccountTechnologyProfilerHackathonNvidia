Trip Report | SHI Internal | Par Pacific

Customer: Par Pacific
AE: David H
Topic: SHI Internal
Meeting Date 12/16/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

David H

Prepare for customer call; validate DNA licensing and explore competitive positioning for 2025 purchases.

12/19

2

Manuel Z

Coordinate with David Hamilton for weekly customer call; inquire about DNA usage and procurement plans.

12/19

3

Hannah Innis

Ensure action items are time-bound and expectations are clear

12/19

Item Owner Next Steps/Detail Due Date 1 David H Prepare for customer call; validate DNA licensing and explore competitive positioning for 2025 purchases. 12/19 2 Manuel Z Coordinate with David Hamilton for weekly customer call; inquire about DNA usage and procurement plans. 12/19 3 Hannah Innis Ensure action items are time-bound and expectations are clear 12/19

Summary

Summary

The internal discussion at SHI International focused on the Par Pacific company's technology needs, specifically concerning their

security tools include Cisco ISE and DUO.

Interest in Meraki and enterprise switching DNA licenses for Cat and Nexus. Committed to Fortinet for firewalls.

Current

security tools include Cisco ISE and DUO.

Interest in Meraki and enterprise switching DNA licenses for Cat and Nexus. Committed to Fortinet for firewalls.

Agenda

Discuss Cisco Security and Networking EA. Validate Cisco DNA usage. Review and adjust hardware list. Explore 2025 procurement plans and competitive positioning. Discuss consolidation into SHI One.

Discuss Cisco Security and Networking EA. Validate Cisco DNA usage. Review and adjust hardware list. Explore 2025 procurement plans and competitive positioning. Discuss consolidation into SHI One.

Opps Identified & BANTC

Opportunity 1: Cisco EA for Security
and Networking

Opportunity 1: Cisco EA for Security
and Networking

B: Par
Pacific is planning hardware purchases and has an interest in transitioning to an EA.
A: IT
Director seeking to educate leadership on EA benefits.
N: Need
for consolidation and efficient management of Cisco products.
T: Timeline
for decision aligns with 2025 quarterly purchases.
C: Competition
with existing Fortinet solutions; opportunity to integrate Meraki and DNA.

B: Par
Pacific is planning hardware purchases and has an interest in transitioning to an EA.
A: IT
Director seeking to educate leadership on EA benefits.
N: Need
for consolidation and efficient management of Cisco products.
T: Timeline
for decision aligns with 2025 quarterly purchases.
C: Competition
with existing Fortinet solutions; opportunity to integrate Meraki and DNA.

Initiatives (Security or Storage or both)

Security

Focus on Cisco ISE, DUO, and Meraki Security.

Security

Focus on Cisco ISE, DUO, and Meraki Security.

Tech Profile Updates

Par Pacific exploring Cisco EA options with a focus on Meraki and DNA. Committed to integrating solutions across retail, HQ, and refining environments.

Par Pacific exploring Cisco EA options with a focus on Meraki and DNA. Committed to integrating solutions across retail, HQ, and refining environments.

Meeting Notes

Discussed potential disruption of current Cisco Security products. Validated Meraki hardware; need to confirm DNA licensing. Emphasized the importance of setting clear, time-bound action items.

Discussed potential disruption of current Cisco Security products. Validated Meraki hardware; need to confirm DNA licensing. Emphasized the importance of setting clear, time-bound action items.

Detailed Discussion Notes

Initial focus on EA for both security and networking. Customer's hardware list needs adjustments; SHI to assist. Advantages of EA discussed, including price savings and true-forward renewals. Par Pacific's main production environment includes HQ and refining sites.

Initial focus on EA for both security and networking. Customer's hardware list needs adjustments; SHI to assist. Advantages of EA discussed, including price savings and true-forward renewals. Par Pacific's main production environment includes HQ and refining sites. Participants of Meetingt:

David Hamilton Leonel Marquez David Shapiro Hannah Innis Manuel Zelaya David Amon Inga Cancelli Stephen Drake Tom Conti

David Hamilton Leonel Marquez David Shapiro Hannah Innis Manuel Zelaya David Amon Inga Cancelli Stephen Drake Tom Conti
