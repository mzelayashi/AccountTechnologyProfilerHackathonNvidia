Trip Report | AI workshop | Great Plains Bank

Customer: Great Plains Bank
AE: Tony A
Topic: AI workshop
Meeting Date 06/24/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Tony V

send PDF summarizing findings, recommendations, and solution mapping.

07/12

2

Manuel Z

Assist in gather/estimate current manual time spent on account matching and insufficient funds to help justify potential ROI

07/15

Item Owner Next Steps/Detail Due Date 1 Tony V send PDF summarizing findings, recommendations, and solution mapping. 07/12 2 Manuel Z Assist in gather/estimate current manual time spent on account matching and insufficient funds to help justify potential ROI 07/15

Summary

This call was a follow-up to the AI Use Case Workshop between SHI and Great Plains Bank. The session focused on reviewing findings from the initial workshop, which centered on identifying high-impact generative AI use cases, particularly within deposit operations and insufficient funds processing. SHI presented a summary of pain points (manual effort, failed RPA attempts, cross-team communication gaps), mapped potential generative AI solutions (account matching, workflow automation, email/routing agents, alert/recommendation agents), and discussed business impact and readiness. The team reviewed next steps, including a demo of the Isara platform, and discussed how to quantify potential ROI via time-savings estimates. SHI will deliver a summary PDF of recommendations and facilitate a demo with Isara for the Great Plains Bank stakeholders.

Agenda

Recap of the AI Use Case Workshop and its objectives Executive

summary of findings and SHI recommendations

Walkthrough of identified use cases, pain points, and mapped AI solutions Discussion of potential metrics/KPIs for ROI justification Next steps: Isara demo scheduling, deliverable PDF, and action planning

Recap of the AI Use Case Workshop and its objectives Executive

summary of findings and SHI recommendations

Walkthrough of identified use cases, pain points, and mapped AI solutions Discussion of potential metrics/KPIs for ROI justification Next steps: Isara demo scheduling, deliverable PDF, and action planning

Opps Identified & BANTC

Opportunity: Generative AI Automation for Deposit Operations & Insufficiency Processing

B (Budget): No commitment to paid engagement at this stage. Stakeholders are interested in a demo and understanding ROI before moving to the paid phase. A (Authority): J.R. Mills and Holly Scott are the key business stakeholders/decision-makers; Tony Villalanti and Shawn Cox are leading from SHI. N (Need): Reduce manual account matching and communication errors, automate workflow for deposit operations and insufficient funds processing, improve operational efficiency, and reduce resolution time. T (Timeline): Near-term for decision on pilot/demo. Next steps include an Isara demo scheduled in the next 1–2 weeks. C (Competition): Isara is the leading candidate for workflow automation. SHI may recommend other platforms if Isara is not a fit. Internal RPA has failed; external AI solutions are being evaluated.

B (Budget): No commitment to paid engagement at this stage. Stakeholders are interested in a demo and understanding ROI before moving to the paid phase. A (Authority): J.R. Mills and Holly Scott are the key business stakeholders/decision-makers; Tony Villalanti and Shawn Cox are leading from SHI. N (Need): Reduce manual account matching and communication errors, automate workflow for deposit operations and insufficient funds processing, improve operational efficiency, and reduce resolution time. T (Timeline): Near-term for decision on pilot/demo. Next steps include an Isara demo scheduled in the next 1–2 weeks. C (Competition): Isara is the leading candidate for workflow automation. SHI may recommend other platforms if Isara is not a fit. Internal RPA has failed; external AI solutions are being evaluated.

Initiatives

Security: Not primary. Storage: Not primary. AI/Automation: Main focus—deposit operations, workflow automation, and process redesign using generative AI.

Tech Profile Updates

Current State: Manual deposit operations, account matching, and insufficient funds processes; RPA attempts have failed; processes are time-consuming and communication-heavy. Pain Points: Manual lookups, cross-team communication gaps, lack of automation, inconsistent workflow, no current KPIs for tracking. Data: Sufficiently structured; CRM, Horizon, and other banking data accessible for AI workflow integration. Solution Candidates: Generative AI agents for account matching, email/routing, recommendation, and alerting; Isara as a leading workflow solution.

Current State: Manual deposit operations, account matching, and insufficient funds processes; RPA attempts have failed; processes are time-consuming and communication-heavy. Pain Points: Manual lookups, cross-team communication gaps, lack of automation, inconsistent workflow, no current KPIs for tracking. Data: Sufficiently structured; CRM, Horizon, and other banking data accessible for AI workflow integration. Solution Candidates: Generative AI agents for account matching, email/routing, recommendation, and alerting; Isara as a leading workflow solution.

Meeting Notes

Environment

Great Plains Bank is seeking to modernize manual deposit and insufficient funds operations with generative AI solutions. Key pain points are manual workload, communication gaps, and failed RPA automation. Data is available and ready for AI workflows; current processes lack metrics/KPIs.

Great Plains Bank is seeking to modernize manual deposit and insufficient funds operations with generative AI solutions. Key pain points are manual workload, communication gaps, and failed RPA automation. Data is available and ready for AI workflows; current processes lack metrics/KPIs.

Detailed Discussion

SHI summarized pain points and mapped several AI solutions:

SHI summarized pain points and mapped several AI solutions:

Account Matching Agent: Automated/fuzzy look-up for manual matching tasks with human-in-the-loop. Email/Workflow Routing Agent: Automate routing and escalation of communications. Recommendation/Alert Agent: For insufficient funds, automate recommendations and escalations based on policy.

Account Matching Agent: Automated/fuzzy look-up for manual matching tasks with human-in-the-loop. Email/Workflow Routing Agent: Automate routing and escalation of communications. Recommendation/Alert Agent: For insufficient funds, automate recommendations and escalations based on policy.

SHI outlined how impact and effort should be mapped for each solution and recommended starting with account matching (quick win). KPIs discussed: time-to-resolution, manual effort reduction, error/exception rates. SHI will provide a PDF deliverable summarizing findings, recommendations, and solution mapping. Isara is suggested as a demo platform; its banking-specific workflows match Great Plains Bank’s needs. Demo to be scheduled; all current call participants will be invited.

SHI outlined how impact and effort should be mapped for each solution and recommended starting with account matching (quick win). KPIs discussed: time-to-resolution, manual effort reduction, error/exception rates. SHI will provide a PDF deliverable summarizing findings, recommendations, and solution mapping. Isara is suggested as a demo platform; its banking-specific workflows match Great Plains Bank’s needs. Demo to be scheduled; all current call participants will be invited.

Technical Notes

Solution Approach: Custom prompt-based AI (retrieval augmented generation, no custom model training required). AI agents access CRM/Horizon data securely (no external sharing). Workflows can be delivered as web-based or embedded in existing systems. KPIs to be established for time savings, match accuracy, and operational efficiency. Isara supports account setup, payment tracking, dispute management, and more. Labs/Testing: SHI offers access to AI/Cyber labs for hands-on evaluation (Isara demo will be virtual for now). Isara not yet in SHI’s lab but available for direct demo.

Solution Approach: Custom prompt-based AI (retrieval augmented generation, no custom model training required). AI agents access CRM/Horizon data securely (no external sharing). Workflows can be delivered as web-based or embedded in existing systems. KPIs to be established for time savings, match accuracy, and operational efficiency. Isara supports account setup, payment tracking, dispute management, and more. Labs/Testing: SHI offers access to AI/Cyber labs for hands-on evaluation (Isara demo will be virtual for now). Isara not yet in SHI’s lab but available for direct demo. List all speakers/Participants of Transcript:

Tony Villalanti (SHI) Shawn Cox (SHI) Aaron Richmond (SHI) Andrew Gomez (SHI) J.R. Mills (Great Plains Bank) Holly Scott (Great Plains Bank) Angel (SHI, referenced as co-lead in intro) Manuel Zelaya (SHI) Tyler (Great Plains Bank, invited but not present) Others referenced: Branch managers, internal teams (not present)

Tony Villalanti (SHI) Shawn Cox (SHI) Aaron Richmond (SHI) Andrew Gomez (SHI) J.R. Mills (Great Plains Bank) Holly Scott (Great Plains Bank) Angel (SHI, referenced as co-lead in intro) Manuel Zelaya (SHI) Tyler (Great Plains Bank, invited but not present) Others referenced: Branch managers, internal teams (not present)

Potential Next steps

Deliver AI Use Case Summary PDF

Deliver AI Use Case Summary PDF

Shawn Cox/Tony Villalanti to send PDF summarizing findings, recommendations, and solution mapping. Action: SHI (Shawn Cox/Tony Villalanti) → Great Plains Bank (J.R. Mills, Holly Scott, team)

Shawn Cox/Tony Villalanti to send PDF summarizing findings, recommendations, and solution mapping. Action: SHI (Shawn Cox/Tony Villalanti) → Great Plains Bank (J.R. Mills, Holly Scott, team)

Schedule Isara Platform Demo

Schedule Isara Platform Demo

Tony Villalanti to coordinate scheduling with Isara and all Great Plains Bank call participants. Action: Tony Villalanti → Isara/Great Plains Bank (J.R. Mills, Holly Scott, team) Timeline: Next 1–2 weeks

Tony Villalanti to coordinate scheduling with Isara and all Great Plains Bank call participants. Action: Tony Villalanti → Isara/Great Plains Bank (J.R. Mills, Holly Scott, team) Timeline: Next 1–2 weeks

Internal Metrics Review (ROI Prep)

Internal Metrics Review (ROI Prep)

Great Plains Bank (Holly Scott/J.R. Mills) to gather/estimate current manual time spent on account matching and insufficient funds to help justify potential ROI. Action: Holly Scott/J.R. Mills → SHI (optional, to share before/after demo)

Great Plains Bank (Holly Scott/J.R. Mills) to gather/estimate current manual time spent on account matching and insufficient funds to help justify potential ROI. Action: Holly Scott/J.R. Mills → SHI (optional, to share before/after demo)

Demo/Workshop Follow-Up

Demo/Workshop Follow-Up

Post-demo, SHI and Great Plains Bank to review fit, next steps, and decision on moving to a pilot or deeper paid engagement. Action: Both teams, pending demo outcome

Post-demo, SHI and Great Plains Bank to review fit, next steps, and decision on moving to a pilot or deeper paid engagement. Action: Both teams, pending demo outcome

Optional: Explore Additional AI/Cyber Labs/Platforms

Optional: Explore Additional AI/Cyber Labs/Platforms

If Isara not a fit, SHI to recommend/test other automation platforms. Action: SHI → Great Plains Bank

If Isara not a fit, SHI to recommend/test other automation platforms. Action: SHI → Great Plains Bank
