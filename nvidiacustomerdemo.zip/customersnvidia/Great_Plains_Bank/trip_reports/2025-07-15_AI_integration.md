Trip Report | AI integration | Great Plains Bank

Customer: Great Plains Bank
AE: Tony V
Topic: AI integration
Meeting Date 07/15/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Tony V

Coordinate with Great Plains Bank CIO/IT to validate FIS Horizon XE API capabilities and accessibility for Aisera integration

2

Manuel Z

Assist  Aisera team in Preparing technical demo highlighting integration with SharePoint and core banking APIs; address specific ACH use case

Item Owner Next Steps/Detail Due Date 1 Tony V Coordinate with Great Plains Bank CIO/IT to validate FIS Horizon XE API capabilities and accessibility for Aisera integration 2 Manuel Z Assist  Aisera team in Preparing technical demo highlighting integration with SharePoint and core banking APIs; address specific ACH use case

Summary

SHI met with Great Plains Bank to discuss AI-driven automation opportunities with a focus on ACH exception processing and reconciliation. The bank currently uses FIS Horizon XE as its core system, which offers APIs, though the accessibility and modernity are undetermined. Source-of-truth documentation for ACH exception procedures is centralized in SharePoint. The bank experiences a moderate daily ACH exception reconciliation load (20 cases daily, 15 minutes each), indicating significant manual effort and operational overhead. Previous attempts to automate this process using Fortra RPA were unsuccessful, primarily due to instability and inability to directly access necessary account information, resulting in frequent process interruptions. SHI identified Aisera as a recommended AI automation solution tailored to these pain points, with the objective of streamlining exception handling, reducing manual workload, and improving operational resilience. The workshop agenda included an Aisera platform overview, assessment of current state, and demonstration of relevant tools. Additional discovery around API capabilities and integration requirements was initiated to ensure compatibility and maximize automation potential. Customer Technical Environment Notes:

Core banking platform: FIS Horizon XE (with available API, accessibility/modernity uncertain) Document management: SharePoint for ACH Exception Procedure documentation Existing automation: Fortra RPA (abandoned due to access and stability issues) Manual ACH exception reconciliation: ~20 cases/day, 15 minutes per case

Core banking platform: FIS Horizon XE (with available API, accessibility/modernity uncertain) Document management: SharePoint for ACH Exception Procedure documentation Existing automation: Fortra RPA (abandoned due to access and stability issues) Manual ACH exception reconciliation: ~20 cases/day, 15 minutes per case

Agenda

• Aisera overview
• Review of Great Plains Bank’s current operational
state
• Discussion of AI automation use cases from SHI-led
workshop
• Aisera tools demonstration
• Summary and next steps

Opps Identified & BANTC

Opportunity 1: AI-driven Automation for ACH Exception
Handling with Aisera
• B: Moderate—Bank is investing time and
resources on manual reconciliation (20 cases/day at 15 min/case) and has budgeted for efficiency-improving initiatives.
• A: Decision-makers engaged (CIO,
operations leads), high authority to approve automation solutions.
• N: High—Manual process is
resource-intensive; prior RPA failed due to technical limitations.
• T: Medium—Requirements gathering and
proof-of-concept needed; integration with FIS Horizon XE APIs must be validated.
• C: Competitive landscape includes legacy
RPA (Fortra, which failed); Aisera positioned as AI-native, stable, and more robust.

Initiatives (Security or Storage or both)

Primary focus: Automation/AI for Operational Efficiency (No explicit security or storage initiative discussed, but integration and data governance implied.)

Tech Profile Updates

FIS Horizon XE is in use with available APIs (details pending) SharePoint is primary for SOPs/documentation RPA history: Fortra previously trialed and failed No current automation in place for ACH reconciliation

FIS Horizon XE is in use with available APIs (details pending) SharePoint is primary for SOPs/documentation RPA history: Fortra previously trialed and failed No current automation in place for ACH reconciliation

Meeting Notes

Great Plains Bank clarified that their core (not CRM) is FIS Horizon XE, with APIs (degree of accessibility unknown) ACH exception reconciliation is manual, time-consuming, and a clear pain point Previous RPA tool (Fortra) was unreliable and lacked necessary access, leading to abandonment Interest expressed in Aisera as a potential fit for automation goals SHI to further validate FIS Horizon XE API suitability and integration approach

Great Plains Bank clarified that their core (not CRM) is FIS Horizon XE, with APIs (degree of accessibility unknown) ACH exception reconciliation is manual, time-consuming, and a clear pain point Previous RPA tool (Fortra) was unreliable and lacked necessary access, leading to abandonment Interest expressed in Aisera as a potential fit for automation goals SHI to further validate FIS Horizon XE API suitability and integration approach

Detailed Discussion Notes

API integration is central to the automation project; need to confirm if FIS Horizon XE APIs meet Aisera’s requirements Manual reconciliation process is well-documented on SharePoint, which could streamline bot design and exception logic Prior Fortra RPA attempt failed due to inability to access unprocessed ACH account data and frequent system failures SHI and Aisera to demonstrate capabilities and map out integration steps with existing bank systems Additional questions raised regarding data flows, exception triggers, and escalation logic

API integration is central to the automation project; need to confirm if FIS Horizon XE APIs meet Aisera’s requirements Manual reconciliation process is well-documented on SharePoint, which could streamline bot design and exception logic Prior Fortra RPA attempt failed due to inability to access unprocessed ACH account data and frequent system failures SHI and Aisera to demonstrate capabilities and map out integration steps with existing bank systems Additional questions raised regarding data flows, exception triggers, and escalation logic Next Steps/detail:

Tony Villalanti (SHI): Coordinate with Great Plains Bank CIO/IT to validate FIS Horizon XE API capabilities and accessibility for Aisera integration Aisera Team: Prepare technical demo highlighting integration with SharePoint and core banking APIs; address specific ACH use case Great Plains Bank (Holly Scott, Trace Larman): Provide additional documentation on existing workflows and any available API documentation SHI (Manuel Zelaya): Aggregate responses, document technical requirements, and facilitate follow-up technical workshop

Tony Villalanti (SHI): Coordinate with Great Plains Bank CIO/IT to validate FIS Horizon XE API capabilities and accessibility for Aisera integration Aisera Team: Prepare technical demo highlighting integration with SharePoint and core banking APIs; address specific ACH use case Great Plains Bank (Holly Scott, Trace Larman): Provide additional documentation on existing workflows and any available API documentation SHI (Manuel Zelaya): Aggregate responses, document technical requirements, and facilitate follow-up technical workshop List all speakers/Participants of Transcript:

Tony Villalanti (SHI) Aaron Richmond (SHI) Shawn Cox (SHI) Andrew Gomez (SHI) Tyler Webb (SHI) James Moody (SHI) Manuel Zelaya (SHI) Stephen Drake (SHI) Holly Scott (Great Plains Bank) J.R. Mills (Great Plains Bank) Trace Larman (Great Plains Bank) Nick Lenius (Great Plains Bank) Trisha Cook (Great Plains Bank)

Tony Villalanti (SHI) Aaron Richmond (SHI) Shawn Cox (SHI) Andrew Gomez (SHI) Tyler Webb (SHI) James Moody (SHI) Manuel Zelaya (SHI) Stephen Drake (SHI) Holly Scott (Great Plains Bank) J.R. Mills (Great Plains Bank) Trace Larman (Great Plains Bank) Nick Lenius (Great Plains Bank) Trisha Cook (Great Plains Bank)
