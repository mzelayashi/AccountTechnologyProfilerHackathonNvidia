Trip Report | Solar Winds | Great Plains Bank

Customer: Great Plains Bank
AE: Tony V
Topic: Solar Winds
Meeting Date 05/02/2026

*Internal notes – Please read and edit before sending externally*

Summary

Summary

• This meeting
focused on the SolarWinds Service Desk renewal for Great Plains Bank, with discussions centered on pricing, contract length, customer experience concerns,

Agenda

• Introductions
(SolarWinds renewal rep, SHI team, customer stakeholders)
• Review of
SolarWinds renewal quote and licensing structure
• Customer
feedback on product usage and support experience
• Pricing
discussion for 3-year renewal
• Competitive
positioning vs ServiceNow
• Discussion of
additional features (asset tracking)
• Alignment on

next steps and follow-up actions [SHI

& Grea...Recording | Video]

Opps Identified

& BANTC
Opportunity 1:
SolarWinds 3-Year Renewal
• B: Target
budget expressed at ~$45,000/year
• A: CIO (J.R.
Mills) is final decision-maker; Nick supports evaluation
• N: Maintain
current Service Desk platform while reducing cost and improving support experience
• T: Immediate
renewal cycle; follow-up expected within 1–2 weeks
• C: Strong
competition from ServiceNow with comparable pricing and perceived higher functionality [SHI & Grea...Recording | Video]
Opportunity 2:
Asset Management Add-On (SolarWinds)
• B: Not yet
defined; interest in cost-effective bundling within renewal
• A: Nick (IS
Director / primary admin) leading evaluation; CIO involved in budget approval
• N: Centralized
tracking of IT assets (laptops, monitors, remote user equipment) tied to users—capability missing in current RMM
• T: Near-term
evaluation tied to renewal packaging
• C: Existing RMM
solution; resistance to paying for overlapping functionality [SHI & Grea...Recording | Video]

Initiatives

• IT Service
Management Optimization (neither Security nor Storage – Service Desk / ITSM)
• Asset Lifecycle
& Inventory Tracking (neither Security nor Storage – IT Operations) Tech Profile Updates:
• SolarWinds
Service Desk (Premier tier) actively deployed
• 50 licensed
agents with expansion expected
• Heavy usage of
workflows, automation, and cross-department processes
• Existing RMM
platform used for endpoint management (patching, remote support)
• Evaluating
SolarWinds Asset Management as complementary capability
• ServiceNow
identified as primary competitive benchmark [SHI & Grea...Recording | Video]

Meeting Notes

Environment

• SaaS-based IT
Service Management platform (SolarWinds Service Desk)
•
Multi-department usage within banking environment
• Hybrid toolset:
SolarWinds + separate RMM Detailed Discussion:
• Customer
confirmed satisfaction with SolarWinds functionality and breadth of usage, including advanced workflows and automation
• Significant
dissatisfaction raised around customer success/support experience (lack of product knowledge, reliance on KB links, poor engagement)
• Licensing
structure confirmed:

Per-agent licensing model remains unchanged Unit pricing can be locked in during a 3-year agreement Flex licensing allows limited annual reduction (approx. 5–10%)

Technical Notes

• Current
licensing: SolarWinds Premier Service Desk (50 agents)
• Unit pricing
model confirmed as stable and lockable over multi-year agreement
• Flex licensing
allows ~10% annual license reduction with notice
• No change
expected in licensing model (no additional licensing for approvers unlike ServiceNow)
• Asset
management:

Requires separate licensing or asset packs Non-licensed “manual” tracking available but limited (non-automated, spreadsheet-like) Automated asset tracking supports assignment to users and lifecycle tracking
• Customer RMM handles: patching, remote support, device
maintenance
• Gap identified: RMM lacks asset/user assignment and inventory
visibility
• Integration between service desk and asset tracking seen as
valuable
• Advanced usage: workflows, automations, multi-department expansion
already in production [SHI & Grea...Recording | Video]

Requires separate licensing or asset packs Non-licensed “manual” tracking available but limited (non-automated, spreadsheet-like) Automated asset tracking supports assignment to users and lifecycle tracking
• Customer RMM handles: patching, remote support, device
maintenance
• Gap identified: RMM lacks asset/user assignment and inventory
visibility
• Integration between service desk and asset tracking seen as
valuable
• Advanced usage: workflows, automations, multi-department expansion
already in production [SHI & Grea...Recording | Video] List all speakers/Participants of Transcript:
• Tony Villalanti
– Account Executive, SHI
• Sarah Tessier –
Renewal Representative, SolarWinds
• Sam Box –
Commercial Development Team (SHI, shadowing)
• Nick Lenius –
IS Director / Service Desk Administrator, Great Plains Bank
• J.R. Mills –
CIO, Great Plains Bank Potential Next steps:
• Sarah Tessier
(SolarWinds) → Tony Villalanti (SHI):

Align internally on pricing strategy and discounting to reach ~$45K/year target

Align internally on pricing strategy and discounting to reach ~$45K/year target
• Sarah Tessier →
Great Plains Bank (Nick & J.R.):

Deliver revised renewal pricing proposal (3-year options) Include comparison quotes: with and without asset management add-on

Deliver revised renewal pricing proposal (3-year options) Include comparison quotes: with and without asset management add-on
• Sarah Tessier →
SolarWinds Customer Success Leadership:

Escalate feedback
