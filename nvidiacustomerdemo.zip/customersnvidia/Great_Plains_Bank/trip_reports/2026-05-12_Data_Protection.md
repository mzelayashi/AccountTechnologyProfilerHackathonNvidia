Trip Report | Data Protection | Great Plains Bank

Customer: Great Plains Bank
AE: Tony B
Topic: Data Protection
Meeting Date 05/12/2026

*Internal notes – Please read and edit before sending externally*

Summary

Summary

• The call
focused on introducing Assured Data Protection (vendor) to Great Plains Bank as a potential Disaster Recovery (DR) as-a-Service solution aligned with their Nutanix and Rubrik environment. SHI facilitated the discussion (Tony) to evaluate whether outsourcing DR infrastructure could reduce total cost of ownership (TCO) ahead of an upcoming Nutanix hardware refresh in Oklahoma City.
• The customer
(JR) confirmed a mature, highly functional dual-site DR strategy using two Nutanix clusters (Tulsa and OKC) with cross-replication and Rubrik backup replication. Their environment is stable, audited, and tested regularly, with no major technical gaps.
• While Assured
proposed value in consolidating production and outsourcing DR to their managed

Agenda

• Introductions
and context setting
• Overview of
Assured Data Protection services (DRaaS for Nutanix + Rubrik environments)
• Review of Great
Plains Bank current DR architecture
• Discussion of
Nutanix refresh timeline and strategy
• Exploration of
cost optimization and DR outsourcing options
• Agreement on
next steps (budgetary pricing and follow-up meeting)

Opps Identified & BANTC

Opportunity 1: DRaaS Replacement of Secondary Data
Center

Initiatives

• Storage:
Nutanix infrastructure refresh (primary initiative driving conversation)
• Security +
Storage: Disaster Recovery strategy leveraging replication and backup (Nutanix + Rubrik)
• Cost
Optimization: Evaluate TCO reduction via DR outsourcing

Tech Profile Updates

• Dual Nutanix
clusters (Tulsa and OKC)
• Acropolis
Hypervisor (AHV) in use
• Rubrik deployed
at both sites with replication
• Active-active
DR replication strategy across sites
• Monthly DR
testing procedures in place
• Fully capable
failover between sites (100% load handling) [SHI & Grea...Recording | Video]

Meeting Notes

Environment

• Two
geographically separated data centers (Tulsa and OKC)
• Balanced
workload distribution with critical systems replicated across both sites
• Data centers
designed for extreme durability (F5 tornado-rated facilities)
• Fully in-house
managed IT (no MSP usage)
• Highly audited
and regulated banking environment [SHI & Grea...Recording | Video]

Detailed Discussion

• Assured
explained their DRaaS offering as a managed private cloud alternative leveraging Nutanix-native replication
• Customer
described current architecture as stable, efficient, and validated through real DR events
• Vendor
positioned value around:

Eliminating need for secondary site infrastructure Reducing hardware refresh costs Offloading operational management
• Customer emphasized preference for:
Maintaining control of

environment

Continuing proven DR model Leveraging internal team capabilities
• Discussion surfaced that Assured’s typical model (single production
+ cold DR site) does not align with customer’s active-active design

environment

Continuing proven DR model Leveraging internal team capabilities
• Discussion surfaced that Assured’s typical model (single production
+ cold DR site) does not align with customer’s active-active design

Technical Notes

•
Cross-replication between Nutanix clusters using native AHV capabilities
• Replication
covers ~50% critical workloads (business-critical systems prioritized)
• Rubrik deployed
at both sites with replication between appliances
• DR failover
tested monthly; proven successful in real scenarios
• Both sites
capable of running full production workloads independently
• DR sites housed
in hardened facilities designed for severe weather resilience

ROLES

• Tony Villalanti
– Account Executive, SHI
• JR Mills – IT
Infrastructure Lead / Senior Systems Engineer, Great Plains Bank
• Max Boris –
Account Executive / DR Specialist, Assured Data Protection
• Tim Bonsoe –
Sales Engineer, Assured Data Protection

Potential Next Steps

• Tony (SHI) to
gather and send updated Nutanix collector data to Max and Tim for sizing and pricing
• Max and Tim
(Assured) to produce:

Budgetary quote Architecture diagram High-level solution proposal
• JR (Customer) to review pricing before deciding on demo or further
engagement
• Follow-up meeting scheduled for early June (proposal walkthrough
with all parties)
• Potential future action:
Revisit DR outsourcing strategy during or after hardware refresh cycle Evaluate cost comparison vs maintaining dual-site infrastructure

Budgetary quote Architecture diagram High-level solution proposal
• JR (Customer) to review pricing before deciding on demo or further
engagement
• Follow-up meeting scheduled for early June (proposal walkthrough
with all parties)
• Potential future action:
Revisit DR outsourcing strategy during or after hardware refresh cycle Evaluate cost comparison vs maintaining dual-site infrastructure
