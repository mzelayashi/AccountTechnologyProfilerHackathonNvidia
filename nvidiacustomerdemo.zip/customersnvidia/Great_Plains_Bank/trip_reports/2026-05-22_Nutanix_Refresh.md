Trip Report | Nutanix Refresh | Great Plains Bank

Customer: Great Plains Bank
AE: Tony V
Topic: Nutanix Refresh
Meeting Date 05/22/2026

*Internal notes – Please read and edit before sending externally*

Summary

Summary

• This call
focused on finalizing a Nutanix refresh strategy for Great Plains, with a primary emphasis on hardware selection, pricing volatility, and procurement timing. The SHI team (Tony, Stephen, Manuel) aligned with the customer (J.R.) on the urgency created by a recent Supermicro price increase of approximately $120K–$125K. The discussion centered around balancing cost savings versus

Agenda

• Nutanix refresh
configuration review
• Pricing update
and impact from Supermicro increase
• Evaluation of
alternative OEMs (Dell, Lenovo)
• Lead time and
lifecycle alignment
• Decision path
and procurement timing
• SHI internal
alignment for execution

Opps Identified

& BANTC
Opportunity 1:
Nutanix Refresh with Supermicro (Primary Path)
• B: Customer
needs infrastructure refresh aligned with Nutanix workloads and DR requirements across OKC/Tulsa
• A: Customer
(J.R.) engaging CEO for approval; SHI coordinating internally for credit and procurement readiness
• N: Avoid $125K
price increase, maintain known platform reliability, support production workloads
• T: End-of-month
deadline (critical), ~9-month delivery timeline acceptable
• C:
High—decision nearly finalized, approval process actively underway
Opportunity 2:
Alternative OEM Evaluation (Dell)
• B: Potentially
improved lead times and competitive pricing
• A: SHI to
generate BOM and coordinate with Dell/Nutanix backend teams
• N: Validate if
better financial or operational model exists versus Supermicro
• T: 24–48 hour

Initiatives

• Nutanix
Infrastructure Refresh – Storage + Compute (Primary focus: Storage + Hyperconverged Infrastructure)
• DR Strategy
Validation (OKC/Tulsa clusters) – Storage
• Cost
Optimization / Procurement Acceleration – Both Tech Profile Updates:
• Current
environment uses Nutanix on Supermicro hardware
• Multi-site
cluster deployment (OKC and Tulsa)
• DR strategy in
place but capacity concerns exist for full workload failover
• Customer
prefers CapEx procurement (no financing models)
• Existing
lifecycle support valid through March 2027

Meeting Notes

Environment

• Nutanix HCI
deployment across multiple sites
• Supermicro
hardware baseline
• DR between OKC
and Tulsa clusters
• Tulsa cluster
insufficient for 100% workload failover; designed for critical apps only Detailed Discussion:
• Pricing
volatility introduced urgency: Supermicro hardware costs increased ~120K+ due to demand pressures
• Customer
presented with decision path: lock pricing now vs evaluate alternatives
• Lead times
extended to ~9 months, but accepted due to lifecycle alignment
• Dell introduced

Technical Notes

• Nutanix
configuration previously tuned and validated by engineering team as optimal based on hardware constraints
• Cluster design
spans two locations: OKC (primary) and Tulsa (secondary/DR)
•
Performance/capacity concern: Tulsa cannot sustain full production workload
• Workload
placement strategy expected to prioritize critical applications in DR failover scenario
• Hardware cost
increase isolated strictly to OEM layer (software licensing unchanged)
• Demand-driven
pricing pressure impacting Supermicro supply chain
• Lead time
expansion (~9 months) tied to high market demand and manufacturing backlog
• Alternative OEM
(Dell) potential advantages: shorter lead times, possible DFS financing, competitive pricing
• Deployment
timeline still aligns with support lifecycle cutoff (March 2027)
• SHI internal
processes required: credit limit validation, accounting alignment, order pre-approval List all speakers/Participants of Transcript (titles and companies for the folks in the meeting please, should display as just ROLES):
• Manuel Zelaya –
Solutions Engineer (SHI)
• Tony Villalanti
– Account Executive (SHI)
• Stephen Drake –
Field CTO / Technical Leadership (SHI)
• J.R. Mills – IT
Decision Maker / Customer Representative (Great Plains) Potential Next steps:
• J.R. → CEO:
Submit approval request to proceed with Supermicro purchase (critical path)
• Tony (SHI) →
J.R.: Provide updated pricing quote reflecting $125K delta for comparison and justification
• Tony (SHI) →
SHI Accounting: Initiate credit approval and order readiness process
• Stephen (SHI) →
Internal Team: Support escalation and backend coordination (Nutanix, OEM alignment)
• Manuel (SHI) →
Internal Engineering: Prepare Dell alternative BOM within ~24 hours (contingency path)
• SHI Team →
J.R.: Deliver optional Dell quote for validation before final commitment
• Tony/Stephen →
OEM/Distribution: Explore options for extending support coverage if delivery overlaps lifecycle
• Stephen → J.R.:
Share direct contact for ongoing technical support while AE is out This capture reflects a late-stage deal with near-term close potential, driven heavily by pricing pressure and customer confidence in existing vendor alignment.
