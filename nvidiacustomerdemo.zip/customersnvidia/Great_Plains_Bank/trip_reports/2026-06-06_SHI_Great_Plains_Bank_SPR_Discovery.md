Trip Report | & Great Plains Bank | SPR Discovery

Customer: SPR Discovery
AE: 
Topic: & Great Plains Bank
Meeting Date 06/06/2026

*Internal notes – Please read and edit before sending externally*

Summary:
This session was a structured security posture discovery meeting focused on understanding Great Plains Bank’s current security stack, operational maturity, compliance obligations, and near-term decision points so SHI could map strengths, identify gaps, and shape recommendations for future improvements. The business context was clear from the outset: the customer is generally satisfied with key incumbent platforms—especially Rapid7 and SentinelOne—but is actively pressure-testing cost, ROI, and consolidation opportunities ahead of an upcoming renewal cycle. The discussion also showed a small, lean IT/security team supporting a regulated banking environment, which means operational simplicity, automation, and tools that reduce administrative burden matter just as much as raw feature depth.
The call also revealed that the account is not in a broad rip-and-replace posture. Instead, the customer appears to be selectively optimizing around cost control, process automation, and targeted maturity improvements. Areas that stood out from a business-value standpoint were identity lifecycle automation, improved asset/CMDB formalization, stronger governance around contractor/remote access workflows, continued cloud security evaluation around Azure/OpenAI use cases, and a phased posture review across additional domains not yet covered in this session. The meeting positioned SHI less as a reseller and more as a consultative advisor helping the customer validate what is already working, protect strong existing investments, and identify where incremental changes could materially improve security operations without overburdening a six-person IT team.
The customer also demonstrated a relatively mature culture in several domains: structured phishing awareness with escalation paths, enforcement of MFA/SSO/conditional access, full endpoint protection coverage, restricted user privileges, and disciplined third-party access controls. At the same time, they openly acknowledged areas still in progress, such as identity automation, formal CMDB buildout, endpoint privilege workflow deployment through Keeper, and evaluation of how Microsoft and cloud-centric controls could be further leveraged. That combination—strong baseline hygiene with a few practical operational gaps—creates multiple concrete advisory and solution opportunities for future customer engagement.
Agenda:
Introductions and role alignment across SHI and Great Plains Bank.
Review of the updated SPR process, expected deliverables, and maturity scoring output.
Baseline business and environment questions covering compliance, branch/data center footprint, staffing, third-party contractor access, and active initiatives.
Technical discovery across host security, MDM/BYOD, email security, phishing awareness, identity, MFA/SSO, PAM, endpoint privilege management, IGA, asset management, vulnerability management, patching, endpoint firewall, and CMDB direction.
Discussion of the Rapid7 renewal/cost concern and broader platform fit.
Scheduling of the next discovery session to cover network, cloud, data, compliance, and application security topics.
Opps Identified & BANTC
Opportunity 1: Security platform cost optimization and renewal strategy around Rapid7
B: Pricing pressure was stated explicitly as the main complaint with Rapid7, and the broader business objective was to evaluate options for better ROI ahead of renewal. No exact budget number was stated.
A: J.R. Mills identified himself as CIO and spoke directly about renewal posture, vendor negotiations, and platform satisfaction; Nick Lenius also spoke as an operational decision-maker.
N: Need is to confirm whether the customer should stay with Rapid7, reduce cost, or understand any functional tradeoffs if they consider alternatives. The need is optimization rather than a dissatisfaction-driven replacement.
T: Renewal timing was called out as December, and prior pricing discussions had already occurred in the October/November timeframe.
C: The incumbent is Rapid7. No named replacement platform was selected during the call, but the customer had already expressed interest in shopping around.
Opportunity 2: Identity lifecycle automation / IGA improvement
B: No budget was stated. The discussion framed this as an operational improvement area tied to automation and risk reduction.
A: Nick Lenius described the current onboarding/offboarding process and acknowledged the current manual checklist approach; J.R. Mills participated in validating the absence of a dedicated IGA solution.
N: The customer does not currently have automatic provisioning/deprovisioning or a dedicated IGA platform, and access reviews are largely manual with attempts to improve through SolarWinds Service Desk automations. This is a clear operational and governance gap in an otherwise mature environment.
T: Active project now; they are already trying to improve the process with service desk automations rather than treating it as a distant initiative.
C: No specific competing vendor was named; SailPoint-type tooling was referenced by SHI as an example category, but the customer said they had not used such tools.
Opportunity 3: CMDB / asset ownership formalization
B: No budget was stated. The customer tied this to an existing SolarWinds renewal that will include assets.
A: Nick Lenius described the current state and target state, including using the upcoming SolarWinds asset capability to implement CMDB functions.
N: The customer does not formally track ownership to each critical asset today and does not yet have a formal CMDB in place. This creates an opportunity around governance, lifecycle, and operational visibility.
T: Target completion was stated as by end of year.
C: No active competing CMDB product was named during the meeting.
Opportunity 4: Cloud security and Azure/OpenAI posture review
B: No budget was stated.
A: Tony Villalanti explicitly raised the customer’s Azure/OpenAI activity and asked that it be included in the SPR discussion; J.R. Mills acknowledged that request.
N: Need is to better understand how OpenAI is being used in Azure, the structure of that environment, and whether current cloud security controls are sufficient.
T: Immediate, since SHI wanted it included as part of the ongoing SPR workstream.
C: Darktrace was referenced in connection with cloud security context, but no formal competitive product evaluation was completed in this specific meeting segment.
Initiatives:
Security only; no storage initiative was discussed in this session.
Security initiative 1: evaluate security posture and maturity through the SPR process, with follow-on recommendations by short-, medium-, and long-term priority.
Security initiative 2: assess ROI and renewal strategy for Rapid7.
Security initiative 3: continue discovery into network, cloud, data, compliance, and application security in the next session.
Security initiative 4: improve operational maturity around identity automation, CMDB/asset tracking, and privilege/access governance.
Security initiative 5: review Azure/OpenAI usage and associated cloud security posture.
Tech Profile Updates:
Lean IT/security team of six total staff supporting the environment.
Regulated banking environment with GLBA as the primary requirement, plus NIST best practices and PCI in scope.
Approximately two data centers and roughly 26 to 30 branches were discussed.
Around 500 workstations and roughly 44 to 50 servers in scope.
Endpoint security standard appears to center on SentinelOne across workstations and servers, with strong satisfaction from the customer.
Current security stack discussed included Rapid7, SentinelOne, KnowBe4, Egress, Jamf, Entra, Cato, Keeper, Zero Touch, SolarWinds Service Desk, Surface Command, and Microsoft 365/Office 365.
BYOD mobile access is containerized and limited to Outlook data, while corporate Apple mobile devices are managed through Jamf.
The customer is in the middle of moving from NinjaOne to Zero Touch, with Intune alignment as part of the value proposition.
Formal CMDB is not yet implemented, but SolarWinds asset functionality is expected to support this by year-end.
Meeting Notes:
The SPR was framed as a way to identify security gaps, overlap, vendor consolidation opportunities, and maturity improvements.
The customer had completed a similar process in the past and remembered it as a question-driven exercise that resulted in recommendations.
Tony Villalanti set context that the biggest near-term business issue was the Rapid7 renewal and determining whether alternative options could improve ROI.
J.R. Mills later clarified that despite cost concerns, they were likely to stay with Rapid7 because the platform performed very well.
Tony Villalanti also surfaced Azure/OpenAI activity as an area that should be included in the ongoing security review.
The group closed by scheduling the next session for June 2 at 10:00 AM Central to continue discovery.
Environment:
Industry/regulatory context: banking, GLBA, NIST-aligned practices, PCI relevance.
Infrastructure scale: two data centers and roughly mid-20s to 30 branches.
Endpoint/server profile: about 500 endpoints and 44–50 servers.
Operating systems: 99% Windows endpoints, no Mac endpoints, and only a small number of Linux/Red Hat systems.
Third-party access model: no unattended vendor access; application support providers gain access only by request and through controlled remote-session tooling rather than standing credentials.
Remote access model: Cato ZTNA tied to Entra, always-on for remote users, with MFA/conditional access controls.
Identity and access governance: currently manual in several areas, with improvement work underway via SolarWinds Service Desk automations and future CMDB/asset formalization.
Detailed Discussion:
Host security was one of the strongest areas in the meeting. SentinelOne was reported as fully deployed to workstations and servers, providing USB control and automatic isolation. The customer specifically said they liked the product and that it was working well. They also reported success with SentinelOne Prompt Security, saying it was fully deployed and simple to implement.
On mobile and device management, the customer described a split model: corporate Apple devices managed through Jamf, and BYOD access controlled through MAM tied to Azure/Entra. BYOD access appears intentionally narrow, limited to Outlook data in a containerized model that can be selectively wiped.
Email security and awareness also appeared mature. The customer uses Egress inbound and outbound with Office 365, scans attachments, supports outbound encryption, and has DMARC, DKIM, and SPF enabled. Their user-awareness program through KnowBe4 includes monthly testing, a consequence ladder for repeat failures, and a “Phishing Derby” incentive model to reward reporting behavior.
Identity and governance were materially less mature than endpoint and email controls. The customer does not have automatic provisioning/deprovisioning, does not use a dedicated IGA tool, and still relies on manual workflows with cross-checking between supervisors, HR notifications, and service desk processes. They do, however, perform daily and monthly reviews aided by Rapid7 reporting and KnowBe4 PasswordIQ.
PAM and privileged access controls were described positively. Keeper is used for password management, session monitoring/recording, and credential rotation; service account passwords are auto-generated and rotate every login according to the discussion. The team also said endpoint privilege management from Keeper was available, though not yet fully deployed.
Asset and patch management showed active change. The customer is transitioning from NinjaOne to Zero Touch, which they described as acting like a full RMM integrated with Intune. They spoke highly of the vendor’s responsiveness and said the product team was building features based on customer requests, sometimes within days.
Vulnerability management reinforced the strength of the Rapid7 relationship. The customer uses the broader managed threat stack, receives daily reports, monitors internal and external exposure, and supplements this with monthly external testing and threat monitoring. Despite cost frustration, both operational satisfaction and platform stickiness were very clear.
Technical Notes:
SentinelOne is deployed to both servers and workstations with full coverage.
Customer is on SentinelOne EDR Advanced, not using its SIEM/monitoring products because those functions are handled through Rapid7.
SentinelOne Prompt Security is in production and had been live for roughly four to five months at the time of the meeting. Deployment was described as very simple, completed in about four hours.
Endpoint mix is approximately 99% Windows, with only a few Linux devices and no Mac endpoints. Servers are mostly Windows with a very small number of Linux/Red Hat systems, including systems tied to Rapid7 and another vendor environment.
USB/removable device control is enabled in SentinelOne. Automatic isolation is also enabled.
Corporate mobile device management is done through Jamf for Apple devices, including remote wipe and encryption. BYOD uses MAM via Azure/Entra; data is containerized and only Outlook is exposed.
Full disk encryption discussion referenced BitLocker and Nutanix for servers, with keys securely stored and managed.
Email stack includes Office 365 with Egress inbound/outbound protection, attachment scanning, outbound encryption enforcement, and DMARC/DKIM/SPF enabled.
Security awareness model uses KnowBe4 with AI-driven phishing simulation logic, monthly testing, click/failure tracking, tiered remediation, and an incentive-driven phishing reporting program.
User onboarding/deprovisioning remains manual and checklist-driven, with same-day termination handling and HR cross-checking. No dedicated IGA platform is in place.
Password and access hygiene include reports from Rapid7 and KnowBe4 PasswordIQ to identify stale credentials or passwords exceeding policy tolerance.
Vendors do not receive unattended access or standing credentials. Access is via remote-session tooling such as LogMeIn/Bomgar-style workflows initiated by service desk request.
Keeper is used as password manager and for privileged session monitoring/recording. The remote access component named in the meeting was Keeper Connection Manager; another referenced component was KSM.
MFA is enabled for administrator accounts and remote access, with conditional access, impossible travel, geolocation-style controls, and IP restrictions discussed.
Remote access is provided through Cato ZTNA tied to Entra; it is described as always-on rather than user-connected on demand.
SSO is in place across core business applications, and new software appears to be expected to support SSO integration. Role-based access is described as very specific where possible.
Roughly 14 privileged/service accounts were referenced, with auto-generated passwords through Keeper and rotation every login.
Endpoint privilege management from Keeper can prompt for elevation, notify admins, allow approval by user/app policy, and audit elevated access, but it had not yet been fully deployed.
Asset management uses Zero Touch; agent installation is automated at deployment and checked at login via GPO/script logic.
Rapid7 Surface Command is used to identify devices missing required agents. Disposal is still a manual process, and formal asset ownership tracking is not yet implemented.
Vulnerability management uses the Rapid7 managed stack, with some real-time and some daily scanning/reporting. External assessments are complemented by monthly self-directed testing with another product referenced by the customer.
Patch and asset modernization is happening through a move from NinjaOne to Zero Touch, partly because of cost and partly because of its tighter Intune integration.
Endpoint firewall controls are enabled broadly through SentinelOne except on servers, where the team uses macro segmentation with another platform instead.
CMDB is not formalized today, but SolarWinds Service Desk plus future asset functionality is intended to become the foundation, with a target completion by year-end.
ROLES:
J.R. Mills — CIO, Great Plains Bank.
Nick Lenius — IT Director, Great Plains Bank.
Heath Stiles — IT officer / generalist (“jack of all trades”), Great Plains Bank.
Damian Del Signore — Security Engineer focused on cloud security and application security, SHI.
Stefon Jones — Security Solutions Engineer with specialty focus in threat and vulnerability management, SOC, threat intel, MDR, endpoint, and some risk/compliance, SHI.
Tony Villalanti — SHI meeting organizer and account lead/facilitator for the engagement; formal title was not stated in the transcript.
Manuel Zelaya — invited attendee from SHI; formal title/role was not stated in the transcript segment viewed.
Potential Next steps:
Stefon Jones told the group that the next SPR session should move into network, cloud, data, compliance, and application security, and asked Tony Villalanti to start scheduling. In response, Tony Villalanti worked calendars live with J.R. Mills, Nick Lenius, and the SHI team and booked the next meeting for June 2 at 10:00 AM Central. Involved: Tony Villalanti, Damian Del Signore, Stefon Jones, Manuel Zelaya, J.R. Mills, Nick Lenius.
Tony Villalanti said he would send the invite for the June 2 continuation session and noted that if his own schedule conflicted, the rest of the team could still proceed and record the session. Involved: Tony Villalanti, Damian Del Signore, Stefon Jones, customer attendees.
Tony Villalanti offered to introduce Stefon Jones and the engineering team to the Zero Touch team after Stefon Jones said he wanted an introduction to learn more about the platform’s Intune optimization capabilities. This sets up a possible vendor/engineering follow-up meeting. Involved: Tony Villalanti, Stefon Jones, likely Nick Lenius/Heath Stiles, and the Zero Touch team.
Tony Villalanti told Nick Lenius he would follow up again with NinjaOne after learning an offboarding/support ticket had not been answered. This could drive a smaller administrative follow-up around the transition from NinjaOne to Zero Touch. Involved: Tony Villalanti, Nick Lenius, potentially Heath Stiles.
The SPR team should carry forward the Azure/OpenAI topic that Tony Villalanti explicitly asked to include in the overall review so cloud usage and associated controls can be examined in a future session. Involved: Tony Villalanti, J.R. Mills, Damian Del Signore, Stefon Jones.

15 May
Friday
11:00 AM - 12:00 PM
T
Tony Villalanti organized this
Ask
