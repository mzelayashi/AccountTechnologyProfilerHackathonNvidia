Trip Report | password management services | Great Plains Bank

Customer: Great Plains Bank
AE: Tony C
Topic: password management services
Meeting Date 04/01/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Tony V

create a detailed quote for Keeper services, ensuring it is competitive with Bitwarden.

04/24

2

Tony V

Organize a follow-up meeting to discuss the quote and next steps for the transition.

04/21

Item Owner Next Steps/Detail Due Date 1 Tony V create a detailed quote for Keeper services, ensuring it is competitive with Bitwarden. 04/24 2 Tony V Organize a follow-up meeting to discuss the quote and next steps for the transition. 04/21

Summary

The meeting involved a discussion between SHI and Great Plains Bank representatives about transitioning from Bitwarden to Keeper for password management services. The primary focus was to ensure that Keeper could match the services provided by Bitwarden at a competitive price. The key participants aimed to establish clear understanding of the services required and to prepare for the proposal of a quote that aligns with the customer's budget and needs.

Agenda

• Discuss current use of Bitwarden by Great Plains
Bank. • Explore Keeper as an alternative for password management. • Ensure competitive pricing between Bitwarden and Keeper. • Plan for the submission of a detailed proposal and quote.

Opps Identified & BANTC

Opportunity: Transition to Keeper Password Manager
• B: Great Plains Bank seeks to replace
Bitwarden with Keeper for password management. • A: J.R. Mills indicated the need for a seamless transition that maintains current functionalities. • N: The requirement is specifically for end-user password management. • T: The transition should happen in a timely manner to avoid service disruption. • C: Pricing is a significant factor, with a need to ensure cost-effectiveness.

Initiatives

• Security: Transition to a new password management
solution.

Tech Profile Updates

• Current use of Bitwarden for password management. •
Evaluation of Keeper to ensure feature parity and cost-effectiveness.

Meeting Notes

Environment

• Great Plains Bank is currently using Bitwarden for
password management. • The transition aims to maintain or improve current service levels without increasing costs.

Detailed Discussion

• Password Management Needs: J.R. Mills
clarified that the only service being replaced is the password manager for end users, stressing the need for simplicity and user-friendliness. • Price Comparison: Jimmie Welch emphasized the importance of providing a competitive quote that matches the current Bitwarden pricing to ensure a smooth transition.

Technical Notes

• There was a need to confirm if Keeper supports
password sharing and other functionalities provided by Bitwarden. List all speakers/Participants of Transcript:
• Tony Villalanti (SHI) • Manuel Zelaya (SHI) • J.R.
Mills (Great Plains Bank) • Jimmie Welch (Keeper)

Potential Next steps

Quote Preparation:

Quote Preparation:

Action Item: Jimmie Welch to create a detailed quote for Keeper services, ensuring it is competitive with Bitwarden. Involved: Jimmie Welch, Tony Villalanti

Action Item: Jimmie Welch to create a detailed quote for Keeper services, ensuring it is competitive with Bitwarden. Involved: Jimmie Welch, Tony Villalanti

Price Comparison:

Price Comparison:

Action Item: Tony Villalanti to share the full-year pricing comparison with J.R. Mills once the quote is ready. Involved: Tony Villalanti, J.R. Mills

Action Item: Tony Villalanti to share the full-year pricing comparison with J.R. Mills once the quote is ready. Involved: Tony Villalanti, J.R. Mills

Follow-up Meeting:

Follow-up Meeting:

Action Item: Organize a follow-up meeting to discuss the quote and next steps for the transition. Involved: Manuel Zelaya, J.R. Mills, Jimmie Welch

Action Item: Organize a follow-up meeting to discuss the quote and next steps for the transition. Involved: Manuel Zelaya, J.R. Mills, Jimmie Welch
