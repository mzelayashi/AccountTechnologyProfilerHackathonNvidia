Trip Report | Email Secuirty | Great Plains Bank

Customer: Great Plains Bank
AE: Tony V
Topic: Email Secuirty
Meeting Date 05/06/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Tony V

Maintain contact with Great Plains Bank to provide updates on other solutions or changes in vendor landscape.

05/25

2

Manuel Z

Assist in Great Plains finding alternative no outbound currently provided by Abnormal

05/25

Item Owner Next Steps/Detail Due Date 1 Tony V Maintain contact with Great Plains Bank to provide updates on other solutions or changes in vendor landscape. 05/25 2 Manuel Z Assist in Great Plains finding alternative no outbound currently provided by Abnormal 05/25

Summary

This meeting between SHI, Great Plains Bank, and Abnormal Security focused on the evaluation of Abnormal’s email security solution. Abnormal presented its behavioral AI-based approach to email security, emphasizing its ease of deployment and unique detection capabilities, specifically around business email compromise and advanced phishing attacks. Great Plains Bank currently uses Darktrace (for inbound) and Egress (for outbound) and is seeking to consolidate both inbound and outbound filtering—including DLP (Data Loss Prevention) and encryption—into a single solution with unified management (“one pane of glass”). Abnormal clarified that while they excel at inbound email security and recently introduced limited DLP features (focused on misdirected emails), they do not currently offer outbound filtering, DLP, or encryption robust enough to replace Egress or consolidate both functions. The customer ultimately decided that, while Abnormal’s approach is promising, it does not meet their consolidation requirements at this time. Both parties agreed to stay in touch for future developments, especially if Abnormal expands its outbound and DLP capabilities.

Agenda

• Abnormal Security’s approach, architecture, and
evaluation process
• Comparison with existing solutions (Darktrace,
Egress, Mimecast)
• Technical Q&A (deployment, integration, policy
compatibility, DLP, encryption)
• Discussion of customer’s consolidation goal
• Alignment on next steps or disqualification
• Closing remarks and future touchpoints

Opps Identified & BANTC

Opportunity 1: Consolidated Email Security Platform
(Inbound & Outbound, DLP, Encryption)

B: Budget Not specifically discussed, but implied importance due to the desire to consolidate vendors and reduce operational overhead. A: Authority Decision-makers and key influencers present: Nick Lenius, J.R. Mills, Tony Villalanti (SHI), with input from Cole Cunningham and Hunter Artmann (Abnormal). N: Need A single solution that provides both inbound and outbound email filtering, robust DLP, and encryption, all manageable via a unified portal. T: Timeline Actively evaluating; decision likely in the near term as part of a broader vendor consolidation initiative. C: Competition Current stack: Darktrace (inbound), Egress (outbound). Also considering Mimecast and others. Microsoft 365 native tools are an option but seen as complex and less user-friendly.

B: Budget Not specifically discussed, but implied importance due to the desire to consolidate vendors and reduce operational overhead. A: Authority Decision-makers and key influencers present: Nick Lenius, J.R. Mills, Tony Villalanti (SHI), with input from Cole Cunningham and Hunter Artmann (Abnormal). N: Need A single solution that provides both inbound and outbound email filtering, robust DLP, and encryption, all manageable via a unified portal. T: Timeline Actively evaluating; decision likely in the near term as part of a broader vendor consolidation initiative. C: Competition Current stack: Darktrace (inbound), Egress (outbound). Also considering Mimecast and others. Microsoft 365 native tools are an option but seen as complex and less user-friendly. Status: Disqualified for now—Abnormal cannot provide outbound filtering and full DLP/encryption at this time.

Initiatives

Security

(Email Security, DLP, Encryption, Vendor Consolidation)

Security

(Email Security, DLP, Encryption, Vendor Consolidation)

Tech Profile Updates

Current Solutions: Inbound: Darktrace Outbound: Egress

Security

Awareness: KnowBe4 Considering: Mimecast, Microsoft 365 native security features (not preferred due to complexity) Priorities: Consolidation of inbound/outbound filtering, DLP, encryption into one vendor/portal Preference for easy integration, minimal management overhead, visibility, and automation via AI Limitations: Abnormal currently only addresses inbound security, with limited DLP (misdirected email) and no outbound filtering or encryption

Current Solutions: Inbound: Darktrace Outbound: Egress

Security

Awareness: KnowBe4 Considering: Mimecast, Microsoft 365 native security features (not preferred due to complexity) Priorities: Consolidation of inbound/outbound filtering, DLP, encryption into one vendor/portal Preference for easy integration, minimal management overhead, visibility, and automation via AI Limitations: Abnormal currently only addresses inbound security, with limited DLP (misdirected email) and no outbound filtering or encryption

Meeting Notes

Environment

Microsoft 365 with external security layers (Darktrace, Egress) Seeking to reduce complexity and vendor count Preference for a modern, AI-driven, behavior-based approach Need for robust, easy-to-manage DLP and encryption, especially for regulatory compliance

Microsoft 365 with external security layers (Darktrace, Egress) Seeking to reduce complexity and vendor count Preference for a modern, AI-driven, behavior-based approach Need for robust, easy-to-manage DLP and encryption, especially for regulatory compliance

Detailed Discussion

Abnormal’s API-based integration (read-only risk assessment first; minimal disruption, no MX changes required) Behavioral detection leverages 80,000+ signals, including communication patterns, device ID, geo, tonality, etc. Specific advantages over Darktrace: no journaling required, metadata-driven detection, flexibility with URL rewriting Works in parallel with Microsoft policies (does not overwrite Defender/Safelinks unless customer chooses) DLP is limited to misdirected email; no dictionary-based DLP or comprehensive outbound protection Outbound encryption must be handled via Microsoft; Abnormal has no native outbound encryption Customer’s main driver: eliminate the need to manage separate portals for inbound/outbound and consolidate to one solution—Abnormal’s current limitations disqualify them Customer would reconsider if Abnormal expands outbound/DLP capabilities

Abnormal’s API-based integration (read-only risk assessment first; minimal disruption, no MX changes required) Behavioral detection leverages 80,000+ signals, including communication patterns, device ID, geo, tonality, etc. Specific advantages over Darktrace: no journaling required, metadata-driven detection, flexibility with URL rewriting Works in parallel with Microsoft policies (does not overwrite Defender/Safelinks unless customer chooses) DLP is limited to misdirected email; no dictionary-based DLP or comprehensive outbound protection Outbound encryption must be handled via Microsoft; Abnormal has no native outbound encryption Customer’s main driver: eliminate the need to manage separate portals for inbound/outbound and consolidate to one solution—Abnormal’s current limitations disqualify them Customer would reconsider if Abnormal expands outbound/DLP capabilities

Technical Notes

Abnormal plugs into Microsoft Graph API for integration Baseline assessment takes 7-10 days (analyzes up to 60 days’ historical data) No impact on mail flow during evaluation (read-only) Can rewrite suspicious URLs if configured, but does not replace all URLs by default (unlike Darktrace) DLP features are limited; primarily for accidental/misdirected emails, not compliance scanning Outbound filtering and encryption deferred to Microsoft or third-party (Egress) No near-term roadmap for full outbound DLP/encryption

Abnormal plugs into Microsoft Graph API for integration Baseline assessment takes 7-10 days (analyzes up to 60 days’ historical data) No impact on mail flow during evaluation (read-only) Can rewrite suspicious URLs if configured, but does not replace all URLs by default (unlike Darktrace) DLP features are limited; primarily for accidental/misdirected emails, not compliance scanning Outbound filtering and encryption deferred to Microsoft or third-party (Egress) No near-term roadmap for full outbound DLP/encryption List all speakers/Participants of Transcript:

Tony Villalanti (SHI) Cole Cunningham (Abnormal Security) Nick Lenius (Great Plains Bank) J.R. Mills (Great Plains Bank) Hunter Artmann (Abnormal Security, filling in for Parrish) Parrish (Abnormal Security, referenced as main contact) [Mention of “Jaron” by Tony at the end, unclear if present or referenced]

Tony Villalanti (SHI) Cole Cunningham (Abnormal Security) Nick Lenius (Great Plains Bank) J.R. Mills (Great Plains Bank) Hunter Artmann (Abnormal Security, filling in for Parrish) Parrish (Abnormal Security, referenced as main contact) [Mention of “Jaron” by Tony at the end, unclear if present or referenced]

Potential Next Steps

Track Product Roadmap:

Track Product Roadmap:

Who: Cole Cunningham/Hunter Artmann (Abnormal) Action: Notify Nick Lenius and J.R. Mills (Great Plains Bank), and Tony Villalanti (SHI) when Abnormal releases outbound filtering, full DLP, and encryption capabilities. Status: Open; revisit when product matures.

Who: Cole Cunningham/Hunter Artmann (Abnormal) Action: Notify Nick Lenius and J.R. Mills (Great Plains Bank), and Tony Villalanti (SHI) when Abnormal releases outbound filtering, full DLP, and encryption capabilities. Status: Open; revisit when product matures.

Event Follow-up:

Event Follow-up:

Who: Cole Cunningham (Abnormal) Action: Invite Nick and J.R. to local Abnormal events for ongoing engagement. Status: Ongoing.

Who: Cole Cunningham (Abnormal) Action: Invite Nick and J.R. to local Abnormal events for ongoing engagement. Status: Ongoing.

Internal Feedback:

Internal Feedback:

Who: Cole Cunningham (Abnormal) Action: Relay feedback to Abnormal product management that loss of business was due to lack of outbound filtering/consolidation. Status: Open.

Who: Cole Cunningham (Abnormal) Action: Relay feedback to Abnormal product management that loss of business was due to lack of outbound filtering/consolidation. Status: Open.

Customer Monitoring:

Customer Monitoring:

Who: Tony Villalanti (SHI) Action: Maintain contact with Great Plains Bank to provide updates on other solutions or changes in vendor landscape. Status: Ongoing.

Who: Tony Villalanti (SHI) Action: Maintain contact with Great Plains Bank to provide updates on other solutions or changes in vendor landscape. Status: Ongoing.
