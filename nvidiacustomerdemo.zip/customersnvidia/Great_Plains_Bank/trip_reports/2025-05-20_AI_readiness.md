Trip Report | AI readiness | Great Plains Bank

Customer: Great Plains Bank
AE: Tony V
Topic: AI readiness
Meeting Date 05/20/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

Assist in initiating organization-wide AI readiness assessment and enablement after initial pilot(s) success

06/25

2

Tony V

review workshop options, pricing, and materials to decide on the preferred engagement model (free vs. paid workshop).

06/25

Item Owner Next Steps/Detail Due Date 1 Manuel Z Assist in initiating organization-wide AI readiness assessment and enablement after initial pilot(s) success 06/25 2 Tony V review workshop options, pricing, and materials to decide on the preferred engagement model (free vs. paid workshop). 06/25

Summary

This meeting between SHI and Great Plains was an introductory session focused on AI adoption strategy, with an emphasis on specific use cases, particularly in loan operations. SHI’s AI architects, Fabian Lago and Brian O’Connor, introduced themselves and outlined SHI’s experience in AI adoption both internally and with clients, referencing their own AI platform (MindSpark) and structured approach to organizational AI enablement. Great Plains (represented by CIO J.R. Mills and Director of Information Security Nick Lenius) described their current challenges with disparate banking platforms, inefficiencies in loan processing, and past limitations with RPA (Robotic Process Automation). They highlighted a specific use case: streamlining and automating small loan processing using AI, while remaining compliant with strict regulatory requirements (PII protection, FFIEC standards, etc.). The meeting concluded with SHI offering two levels of AI Use Case Workshops (introductory and paid deep-dive), the sharing of supporting materials, and a commitment to provide pricing for further engagements.

Agenda

Introductions of SHI and Great Plains AI/IT stakeholders Overview of Great Plains’ current AI exploration and pain points in loan operations Discussion

Opps Identified & BANTC

1.
Opportunity: AI-Driven Process Automation for Loan Operations
B: Budget
No explicit budget stated, but Great Plains requested quotes for SHI’s paid Use Case Workshop before proceeding. They are cost-conscious, especially given previous RPA investment issues.
A: Authority
J.R. Mills (CIO) and Nick Lenius (Director of Information Security) are leading the project and have authority to recommend initiatives, but likely require executive or board approval for spend.
N: Need

Automate and streamline manual processes in loan operations (especially for small loans) Reduce double entry, manual calculations, and error-prone processes Achieve regulatory compliance (PII protection, FFIEC standards) Evaluate if AI can address inefficiencies where RPA failed

Automate and streamline manual processes in loan operations (especially for small loans) Reduce double entry, manual calculations, and error-prone processes Achieve regulatory compliance (PII protection, FFIEC standards) Evaluate if AI can address inefficiencies where RPA failed
T: Timeline
Not specified, but there is urgency to improve efficiency and a desire to move soon enough to inform budgeting and planning.
C: Competition/Current Solution

Existing RPA (Fortra) had limited success; UiPath rejected due to high cost Multiple banking platforms (FIS, LaserPro, Teslar, DepositPro, etc.)—integration complexity is a factor Some ad hoc use of ChatGPT (with manual PII redaction) SHI’s workshop is positioned against “build vs. buy” and other consultancies

Existing RPA (Fortra) had limited success; UiPath rejected due to high cost Multiple banking platforms (FIS, LaserPro, Teslar, DepositPro, etc.)—integration complexity is a factor Some ad hoc use of ChatGPT (with manual PII redaction) SHI’s workshop is positioned against “build vs. buy” and other consultancies
2.
Opportunity: Organization-Wide AI Readiness & Use Case Factory
B: Budget
Not defined; likely a phased approach. SHI positions this as a follow-on to initial successful pilots.
A: Authority
Same as above; would likely require broader executive sponsorship for company-wide AI enablement.
N: Need

Assess overall AI readiness Develop a prioritized roadmap of AI use cases for broader business optimization Train and enable staff for sustainable AI adoption

Assess overall AI readiness Develop a prioritized roadmap of AI use cases for broader business optimization Train and enable staff for sustainable AI adoption
T: Timeline
Longer-term, after initial pilot(s) and use case validation.
C: Competition/Current Solution
Currently no formal, organization-wide AI strategy or enablement. RPA experience has set some expectations.

Initiatives

AI/Automation: Focused on workflow optimization, efficiency, and compliance within loan operations (with an eye to broader applicability).

Security

PII protection, regulatory compliance (FFIEC), security in AI data processing. Both: Workshops and enablement extend to secure, compliant AI adoption across the organization.

AI/Automation: Focused on workflow optimization, efficiency, and compliance within loan operations (with an eye to broader applicability).

Security

PII protection, regulatory compliance (FFIEC), security in AI data processing. Both: Workshops and enablement extend to secure, compliant AI adoption across the organization.

Tech Profile Updates

Core banking: FIS with XE; Image Center for documents Loan platforms: LaserPro, Teslar, DepositPro Online banking: Multiple platforms (commercial, consumer) RPA: Fortra (limited success); UiPath evaluated but cost-prohibitive ChatGPT: Used ad hoc with manual PII stripping AI/automation: No in-house development; integration with COTS banking systems required

Security

PII redaction required before external AI use; InfoSec heavily involved

Core banking: FIS with XE; Image Center for documents Loan platforms: LaserPro, Teslar, DepositPro Online banking: Multiple platforms (commercial, consumer) RPA: Fortra (limited success); UiPath evaluated but cost-prohibitive ChatGPT: Used ad hoc with manual PII stripping AI/automation: No in-house development; integration with COTS banking systems required

Security

PII redaction required before external AI use; InfoSec heavily involved

Meeting Notes

Environment

Multi-platform banking environment with disparate systems for loans, deposits, imaging, and online banking. IT and InfoSec leading digital transformation/AI exploration.

Multi-platform banking environment with disparate systems for loans, deposits, imaging, and online banking. IT and InfoSec leading digital transformation/AI exploration.

Detailed Discussion

The loan operations department is the main area of inefficiency; much manual data entry and double work. Small loan processing (<$10k) is especially time-consuming due to manual calculations and compliance checks. Previous RPA initiative for deposit-side exceptions (ACH) failed to deliver; RPA may not be the right fit for all areas. Ad hoc ChatGPT use is limited by compliance concerns (no PII). SHI described their internal AI journey (MindSpark platform, 75% adoption, 6000 seats) and services: free/paid use case workshops, proof of concept, and AI enablement. SHI offers to share materials and pricing for workshops.

The loan operations department is the main area of inefficiency; much manual data entry and double work. Small loan processing (<$10k) is especially time-consuming due to manual calculations and compliance checks. Previous RPA initiative for deposit-side exceptions (ACH) failed to deliver; RPA may not be the right fit for all areas. Ad hoc ChatGPT use is limited by compliance concerns (no PII). SHI described their internal AI journey (MindSpark platform, 75% adoption, 6000 seats) and services: free/paid use case workshops, proof of concept, and AI enablement. SHI offers to share materials and pricing for workshops.

Technical Notes

Fortra RPA used; UiPath evaluated (high cost). Loan operations: Manual calculation, data entry, double posting; platforms include LaserPro, Teslar, DepositPro. ChatGPT in use, but only with manual PII removal. SHI’s MindSpark: Internal AI platform with 300+ “agents” (departmental use cases). SHI can run transcripts through their AI to generate meeting summaries/action items. SHI AI Use Case Workshop: Free (1 hour, high-level), Paid (multi-week, deep-dive, includes deliverables and possible proof of concept).

Security

and compliance are key: FFIEC, PII, risk management, data residency. No in-house development team; most systems are COTS and rely on vendor-provided integrations/APIs.

Fortra RPA used; UiPath evaluated (high cost). Loan operations: Manual calculation, data entry, double posting; platforms include LaserPro, Teslar, DepositPro. ChatGPT in use, but only with manual PII removal. SHI’s MindSpark: Internal AI platform with 300+ “agents” (departmental use cases). SHI can run transcripts through their AI to generate meeting summaries/action items. SHI AI Use Case Workshop: Free (1 hour, high-level), Paid (multi-week, deep-dive, includes deliverables and possible proof of concept).

Security

and compliance are key: FFIEC, PII, risk management, data residency. No in-house development team; most systems are COTS and rely on vendor-provided integrations/APIs. List all speakers/Participants of Transcript:

Tony Villalanti (SHI, Account Executive/Facilitator) Fabian Lago (SHI, Solutions Architect, AI/Cloud) Brian O’Connor (SHI, Solutions Architect, AI/Cloud) J.R. Mills (Great Plains, CIO) Nick Lenius (Great Plains, Director of Information Security)

Tony Villalanti (SHI, Account Executive/Facilitator) Fabian Lago (SHI, Solutions Architect, AI/Cloud) Brian O’Connor (SHI, Solutions Architect, AI/Cloud) J.R. Mills (Great Plains, CIO) Nick Lenius (Great Plains, Director of Information Security)

Potential Next Steps

Provide Workshop Pricing & Materials

Provide Workshop Pricing & Materials

Action: Fabian Lago and Brian O’Connor (SHI) to send J.R. Mills and Nick Lenius pricing for the paid Use Case Workshop and slides/materials for both workshop options. Who: Fabian Lago, Brian O’Connor → J.R. Mills, Nick Lenius

Action: Fabian Lago and Brian O’Connor (SHI) to send J.R. Mills and Nick Lenius pricing for the paid Use Case Workshop and slides/materials for both workshop options. Who: Fabian Lago, Brian O’Connor → J.R. Mills, Nick Lenius

Internal Review at Great Plains

Internal Review at Great Plains

Action: J.R. Mills and Nick Lenius to review workshop options, pricing, and materials to decide on the preferred engagement model (free vs. paid workshop). Who: J.R. Mills, Nick Lenius (Great Plains)

Action: J.R. Mills and Nick Lenius to review workshop options, pricing, and materials to decide on the preferred engagement model (free vs. paid workshop). Who: J.R. Mills, Nick Lenius (Great Plains)

Decision on Workshop Engagement

Decision on Workshop Engagement

Action: Great Plains to communicate their decision to SHI, indicating whether to proceed with the free initial workshop or the more detailed paid workshop. Who: J.R. Mills/Nick Lenius → Tony Villalanti, Fabian Lago, Brian O’Connor

Action: Great Plains to communicate their decision to SHI, indicating whether to proceed with the free initial workshop or the more detailed paid workshop. Who: J.R. Mills/Nick Lenius → Tony Villalanti, Fabian Lago, Brian O’Connor

(Optional) Schedule Use Case Workshop

(Optional) Schedule Use Case Workshop

Action: If proceeding, schedule and prepare for the selected workshop (involving appropriate stakeholders, gathering necessary technical/process information). Who: SHI & Great Plains project teams

Action: If proceeding, schedule and prepare for the selected workshop (involving appropriate stakeholders, gathering necessary technical/process information). Who: SHI & Great Plains project teams

(Optional) Prepare for Proof of Concept

(Optional) Prepare for Proof of Concept

Action: If paid workshop leads to viable AI use case, scope and initiate proof of concept engagement (including integration with core banking platforms as needed). Who: SHI AI team & Great Plains IT/Operations

Action: If paid workshop leads to viable AI use case, scope and initiate proof of concept engagement (including integration with core banking platforms as needed). Who: SHI AI team & Great Plains IT/Operations

(Optional) Explore Broader AI Enablement (Use Case Factory/Training)

(Optional) Explore Broader AI Enablement (Use Case Factory/Training)

Action: Consider organization-wide AI readiness assessment and enablement after initial pilot(s) success. Who: SHI AI team & Great Plains leadership

Action: Consider organization-wide AI readiness assessment and enablement after initial pilot(s) success. Who: SHI AI team & Great Plains leadership
