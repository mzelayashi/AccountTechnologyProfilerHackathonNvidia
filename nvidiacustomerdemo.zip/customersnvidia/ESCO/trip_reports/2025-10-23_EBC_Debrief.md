Trip Report | EBC Debrief | ESCO

Customer: ESCO
AE: Jax M
Topic: EBC Debrief
Meeting Date 10/23/2025

*Internal notes – Please read and edit before sending externally*

Summary

Summary

The discussion centered on ESCO’s IT strategy across its 10–15 subsidiary companies, which operate semi-independently. The corporate IT leader outlined priorities: cybersecurity standardization, vendor alignment, and consolidation of licenses and tools where practical. EO’s environment includes manufacturing sites, aerospace/defense, utilities, and maritime organizations, with varying IT maturity levels. Key challenges include tool sprawl, inconsistent execution, legacy infrastructure, and acquisition-driven complexity. The corporate office focuses on governance, strategy, and vendor partnerships rather than deep technical execution. Security remains the top priority, followed by software/hardware standardization and gap analysis. The conversation explored SHI’s capabilities for security posture reviews (SPR), technology mapping, and lab environments for tool evaluation, as well as potential engagement models for consolidation and onboarding during acquisitions.

Agenda

Introductions and role alignment Overview of SCEO’s organizational structure and IT governance model Current cybersecurity standards and compliance posture Vendor strategy and consolidation opportunities Acquisition onboarding challenges and timelines Discussion of SHI services: Security Posture Review, technology diagramming, lab environment Identification of ESCOs top goals for the next 12 months Exploration of partnership

opportunities and next steps

Introductions and role alignment Overview of SCEO’s organizational structure and IT governance model Current cybersecurity standards and compliance posture Vendor strategy and consolidation opportunities Acquisition onboarding challenges and timelines Discussion of SHI services: Security Posture Review, technology diagramming, lab environment Identification of ESCOs top goals for the next 12 months Exploration of partnership

opportunities and next steps

Opportunities Identified & BANTC

Opportunity 1: Security Posture Review (SPR) Across
Subsidiaries

B (Budget): Corporate willing to invest in SPR as value-add; cost-neutral if positioned as partnership. A (Authority): Corporate IT leader drives strategy; subs have autonomy but follow corporate guidance. N (Need): Lack of standardized visibility into security tools and deployment maturity. T (Timeline): Start with ESCO corporate immediately; expand to subs over 8–9 weeks (Dec–Feb). C (Competition): Microsoft offers similar reviews; SHI differentiates with lab environment and consolidated reporting.

B (Budget): Corporate willing to invest in SPR as value-add; cost-neutral if positioned as partnership. A (Authority): Corporate IT leader drives strategy; subs have autonomy but follow corporate guidance. N (Need): Lack of standardized visibility into security tools and deployment maturity. T (Timeline): Start with ESCO corporate immediately; expand to subs over 8–9 weeks (Dec–Feb). C (Competition): Microsoft offers similar reviews; SHI differentiates with lab environment and consolidated reporting.
Opportunity 2: License & Tool Consolidation

B: Potential savings via volume
discounts; corporate can cross-charge subs.
A: Corporate influences
decisions; subs retain operational control.
N: Tool sprawl (email security,
endpoint, Adobe, Microsoft CSP vs EA).
T: Ongoing; initial focus on
Adobe and Microsoft stack.
C: Competing vendors for
EA/CSP; current EA partner underperforming.

B: Potential savings via volume
discounts; corporate can cross-charge subs.
A: Corporate influences
decisions; subs retain operational control.
N: Tool sprawl (email security,
endpoint, Adobe, Microsoft CSP vs EA).
T: Ongoing; initial focus on
Adobe and Microsoft stack.
C: Competing vendors for
EA/CSP; current EA partner underperforming.
Opportunity 3: Acquisition Onboarding &

Infrastructure Refresh

B: High variability; urgent
spend during 30-day transition windows.
A: Corporate leads onboarding;
partners execute technical work.
N: Legacy systems,
under-maintained servers, compliance gaps.
T: Immediate for pending
acquisitions; roadmap for maritime org already in motion.
C: Existing preferred vendor;
SHI can position as secondary trusted partner.

B: High variability; urgent
spend during 30-day transition windows.
A: Corporate leads onboarding;
partners execute technical work.
N: Legacy systems,
under-maintained servers, compliance gaps.
T: Immediate for pending
acquisitions; roadmap for maritime org already in motion.
C: Existing preferred vendor;
SHI can position as secondary trusted partner.

Initiatives

Security: Cybersecurity posture standardization, tool rationalization, disaster recovery exercises, penetration testing. Storage: Infrastructure refresh for acquired companies; potential cloud migration evaluation. Both: Consolidation of licensing and hardware procurement.

Security: Cybersecurity posture standardization, tool rationalization, disaster recovery exercises, penetration testing. Storage: Infrastructure refresh for acquired companies; potential cloud migration evaluation. Both: Consolidation of licensing and hardware procurement.

Tech Profile Updates

Current standards: KnowBe4 (training/phishing), SecureWorks, Sophos endpoint, B-Site scorecard. Email: Microsoft 365 (70% adoption), mixed use of Defender, Proofpoint, Mimecast. Endpoint: Dell/Lenovo hardware; CrowdStrike in some subs. Compliance: CMMC, ISO 27001 for regulated sectors. EA with Microsoft in place; CSP usage by some subs.

Current standards: KnowBe4 (training/phishing), SecureWorks, Sophos endpoint, B-Site scorecard. Email: Microsoft 365 (70% adoption), mixed use of Defender, Proofpoint, Mimecast. Endpoint: Dell/Lenovo hardware; CrowdStrike in some subs. Compliance: CMMC, ISO 27001 for regulated sectors. EA with Microsoft in place; CSP usage by some subs.

Meeting Notes

EO corporate IT team is small (~50 people, non-manufacturing). Subsidiaries range from 1–20 IT staff; operate independently. Corporate role: strategy, vendor alignment, escalation support. Pain points: delayed deployments, inconsistent execution, lack of roadmap discipline. Acquisition complexity: variable IT maturity, short transition timelines, offshore support issues.

EO corporate IT team is small (~50 people, non-manufacturing). Subsidiaries range from 1–20 IT staff; operate independently. Corporate role: strategy, vendor alignment, escalation support. Pain points: delayed deployments, inconsistent execution, lack of roadmap discipline. Acquisition complexity: variable IT maturity, short transition timelines, offshore support issues.

Environment

10–15 subsidiaries, 3–4K end users. Industries: manufacturing, aerospace/defense, utilities, maritime. Mixed IT maturity; some highly regulated, others minimal controls. Semi-independent IT governance; corporate provides standards and oversight.

10–15 subsidiaries, 3–4K end users. Industries: manufacturing, aerospace/defense, utilities, maritime. Mixed IT maturity; some highly regulated, others minimal controls. Semi-independent IT governance; corporate provides standards and oversight.

Detailed Discussion

Cybersecurity is top priority; EO wants robust posture across all subs. Consolidation opportunities for email security, endpoint tools, Adobe, Microsoft licensing. Acquisition onboarding requires rapid evaluation and remediation; current vendor struggles with execution. SHI presented SPR and lab environment for tool evaluation; potential for technology diagramming service. Corporate IT leader emphasized cultural sensitivity when introducing initiatives to subs. EA strategy under review; dissatisfaction with current vendor performance.

Cybersecurity is top priority; EO wants robust posture across all subs. Consolidation opportunities for email security, endpoint tools, Adobe, Microsoft licensing. Acquisition onboarding requires rapid evaluation and remediation; current vendor struggles with execution. SHI presented SPR and lab environment for tool evaluation; potential for technology diagramming service. Corporate IT leader emphasized cultural sensitivity when introducing initiatives to subs. EA strategy under review; dissatisfaction with current vendor performance.

Technical Notes

Mentioned tools: KnowBe4, SecureWorks, Sophos, CrowdStrike, Defender, Proofpoint, Mimecast. EA vs CSP licensing challenges; subs using E3/E5/F1/F3 licenses. Backup issues: servers backing up within same building (risk). Maritime org: 52 servers, likely only 10 active; needs cleanup and roadmap. Compliance frameworks: CMMC, ISO 27001; internal audits for user/admin access. SHI1 portal: license management, multi-cloud cost center segregation, SPR integration. Lab environment: 100–150 tools for on-demand demos/testing.

Mentioned tools: KnowBe4, SecureWorks, Sophos, CrowdStrike, Defender, Proofpoint, Mimecast. EA vs CSP licensing challenges; subs using E3/E5/F1/F3 licenses. Backup issues: servers backing up within same building (risk). Maritime org: 52 servers, likely only 10 active; needs cleanup and roadmap. Compliance frameworks: CMMC, ISO 27001; internal audits for user/admin access. SHI1 portal: license management, multi-cloud cost center segregation, SPR integration. Lab environment: 100–150 tools for on-demand demos/testing.

Roles

Corporate IT Leader: Amy Sawvell Strategy & vendor alignment (EO Corporate) Director (Greg): Oversight (SHI) Solutions Engineer (Manuel Z): Technical support (SHI) Jax Miley AE SHI

Corporate IT Leader: Amy Sawvell Strategy & vendor alignment (EO Corporate) Director (Greg): Oversight (SHI) Solutions Engineer (Manuel Z): Technical support (SHI) Jax Miley AE SHI

Potential Next Steps

Action: Schedule ESCO Corporate SPR as pilot.

Owner: SHI team (Jax, Manuel) er

Action: Provide SPR deliverable and roadmap for subs rollout.

Owner: SHI security team Stakeholder: ESCO Corporate IT Leader

Action: Initiate discussion on Microsoft EA strategy and alternatives.

Owner: SHI licensing specialist Stakeholder: ESCO Corporate IT Leader

Action: Explore Adobe consolidation quote for all subs.

Owner: SHI account team Stakeholder: ESCO Corporate IT Leader

Action: Position SHI for acquisition onboarding support.

Owner: SHI services team Stakeholder: ESCO Corporate IT Leader

Action: Schedule ESCO Corporate SPR as pilot.

Owner: SHI team (Jax, Manuel) er

Owner: SHI team (Jax, Manuel) er Action: Provide SPR deliverable and roadmap for subs rollout.

Owner: SHI security team Stakeholder: ESCO Corporate IT Leader

Owner: SHI security team Stakeholder: ESCO Corporate IT Leader Action: Initiate discussion on Microsoft EA strategy and alternatives.

Owner: SHI licensing specialist Stakeholder: ESCO Corporate IT Leader

Owner: SHI licensing specialist Stakeholder: ESCO Corporate IT Leader Action: Explore Adobe consolidation quote for all subs.

Owner: SHI account team Stakeholder: ESCO Corporate IT Leader

Owner: SHI account team Stakeholder: ESCO Corporate IT Leader Action: Position SHI for acquisition onboarding support.

Owner: SHI services team Stakeholder: ESCO Corporate IT Leader

Owner: SHI services team Stakeholder: ESCO Corporate IT Leader
