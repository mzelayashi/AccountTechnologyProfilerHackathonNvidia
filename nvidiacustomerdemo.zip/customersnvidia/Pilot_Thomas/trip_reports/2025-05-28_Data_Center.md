Trip Report | Data Center | Pilot Thomas

Customer: Pilot Thomas
AE: Leslie S
Topic: Data Center
Meeting Date 05/28/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z /Tony A

Gain Assess Cohesity performance and Tierpoint/vmware , file analytics needs, alternatives for file storageTo resolve performance/analytics gaps and align storage with business growth/compliance requirements

06/15

2

Leslie S

Clarify VMware licensing coverage for both TierPoint and PTL-owned UCS hardware; review contract terms/penalties

06/15

3

Tony A

Develop “good/better/best” architecture scenarios (on-prem, hybrid, cloud), taking into account business, technical, and contractual constraintsTo inform architecture recommendations, support migration/consolidation, and uncover hidden risk/cost

06/15

Item Owner Next Steps/Detail Due Date 1 Manuel Z /Tony A Gain Assess Cohesity performance and Tierpoint/vmware , file analytics needs, alternatives for file storageTo resolve performance/analytics gaps and align storage with business growth/compliance requirements 06/15 2 Leslie S Clarify VMware licensing coverage for both TierPoint and PTL-owned UCS hardware; review contract terms/penalties 06/15 3 Tony A Develop “good/better/best” architecture scenarios (on-prem, hybrid, cloud), taking into account business, technical, and contractual constraintsTo inform architecture recommendations, support migration/consolidation, and uncover hidden risk/cost 06/15

Summary

Summary

This call brought together key stakeholders from PTL (Pilot Thomas Logistics) and SHI to review the current state of PTL’s data center infrastructure, discuss business objectives, and establish a roadmap for future improvements. The discussion spanned infrastructure consolidation, contract obligations (notably with TierPoint), hybrid cloud strategy, storage and backup architecture, application modernization, and the need for documentation and analytics to support future growth. PTL is undergoing a leadership and technology approach shift, emphasizing smarter decision-making, scalability, automation, and cost optimization. Key technical pain points include VM licensing clarity, storage/backup performance and analytics, and legacy infrastructure limitations. SHI’s team presented initial findings from CloudPhysics and Live Optics assessments and began outlining next steps for architecture recommendations, application mapping, and vendor engagement.

Agenda

• Introductions of new SHI team members (Tony Ashby,
CJ Jones)
• Review of meeting objectives: establish current
state, clarify infrastructure, use CloudPhysics/Live Optics data, and set up for future architecture conversation
• PTL leadership’s historical context and business
drivers for change
• Hardware/contract review: TierPoint relationship,
hardware as a service, VMware licensing
• Application and infrastructure mapping
(hybrid/cloud, ERP migration, automation)
• Storage/backup strategy review (Pure, Cohesity, file
shares, backup/DR, analytics needs)
• Discussion of pain points, technical challenges, and
requirements for future state
• Next steps/action items

Opportunities Identified & BANTC

Opportunity 1: Data Center Infrastructure Consolidation & Modernization B:

PTL needs to consolidate and modernize infrastructure, optimize spend (locked into TierPoint contract through 2028), and address end-of-life hardware and licensing challenges (UCS, VMware).

PTL needs to consolidate and modernize infrastructure, optimize spend (locked into TierPoint contract through 2028), and address end-of-life hardware and licensing challenges (UCS, VMware). A:

Key decision makers: Matt Morris, Steve Silkaitis, Rob Stephens, Stephen Drake Technical input from SHI (Tony Ashby, CJ Jones, Leslie Schmulson, Manuel Zelaya)

Key decision makers: Matt Morris, Steve Silkaitis, Rob Stephens, Stephen Drake Technical input from SHI (Tony Ashby, CJ Jones, Leslie Schmulson, Manuel Zelaya) N:

Critical to business operations (ERP, dispatch, image retention, integration layer); must support future growth (double/triple volume), minimize manual effort, and facilitate automation.

Critical to business operations (ERP, dispatch, image retention, integration layer); must support future growth (double/triple volume), minimize manual effort, and facilitate automation. T:

Timeline governed by: TierPoint contract (till 2028, with penalties for early exit) ERP system end-of-life (end of next year); Immediate need for mapping and architecture recommendations

Timeline governed by: TierPoint contract (till 2028, with penalties for early exit) ERP system end-of-life (end of next year); Immediate need for mapping and architecture recommendations C:

Constraints: Existing contract (TierPoint: hardware as a service, unclear VMware licensing) Small IT team, need for external expertise Avoiding vendor lock-in for cloud/automation solutions

Constraints: Existing contract (TierPoint: hardware as a service, unclear VMware licensing) Small IT team, need for external expertise Avoiding vendor lock-in for cloud/automation solutions Opportunity 2: Storage & Backup Optimization (Cohesity, Pure, Analytics) B:

Slow file shares, lack of analytics, unclear backup/DR strategy, and cost overruns (snapshots/overages) require a re-evaluation of storage architecture and tools.

Slow file shares, lack of analytics, unclear backup/DR strategy, and cost overruns (snapshots/overages) require a re-evaluation of storage architecture and tools. A:

Same as above; additional input from Ernoel Bardaje (analytics need), Rob Stephens (storage/backup admin)

Same as above; additional input from Ernoel Bardaje (analytics need), Rob Stephens (storage/backup admin) N:

Need to improve file access for distributed users, enhance retention/analytics, reduce costs, and support regulatory requirements (e.g., mailbox retention).

Need to improve file access for distributed users, enhance retention/analytics, reduce costs, and support regulatory requirements (e.g., mailbox retention). T:

Ongoing Cohesity review/proposal; need to align with overall infrastructure modernization timeline

Ongoing Cohesity review/proposal; need to align with overall infrastructure modernization timeline C:

Current Cohesity setup was a consolidation effort (replaced NetApp/Symantec); Performance issues (old C2505s), lack of cloud-friendly features Exploring alternatives (Nasuni, Pure Unified, NetApp, etc.)

Current Cohesity setup was a consolidation effort (replaced NetApp/Symantec); Performance issues (old C2505s), lack of cloud-friendly features Exploring alternatives (Nasuni, Pure Unified, NetApp, etc.) Opportunity 3: Application Modernization & Cloud Strategy B:

Application sprawl, multiple providers for same services, cloud readiness, and ERP migration open up a need for an integration layer and thoughtful cloud/hybrid application placement.

Application sprawl, multiple providers for same services, cloud readiness, and ERP migration open up a need for an integration layer and thoughtful cloud/hybrid application placement. A:

Matt Morris, Steve Silkaitis, Rob Stephens (business/IT), SHI architects (Tony, CJ)

Matt Morris, Steve Silkaitis, Rob Stephens (business/IT), SHI architects (Tony, CJ) N:

Must support business integration, automation, and future ERP migration; avoid cloud lock-in, enable multi-cloud/hybrid flexibility.

Must support business integration, automation, and future ERP migration; avoid cloud lock-in, enable multi-cloud/hybrid flexibility. T:

ERP end-of-life (end of next year); Application mapping needed ASAP to inform next steps

ERP end-of-life (end of next year); Application mapping needed ASAP to inform next steps C:

Multiple legacy/third-party apps; Small team; Need for external development/integration partners

Multiple legacy/third-party apps; Small team; Need for external development/integration partners

Initiatives

Storage: Storage and backup optimization (Cohesity, Pure, file shares, analytics, cloud file services)

Security

Data retention, regulatory compliance (mailbox/user data retention), backup immutability Both: DR strategy, backup replication, analytics/dashboarding

Storage: Storage and backup optimization (Cohesity, Pure, file shares, analytics, cloud file services)

Security

Data retention, regulatory compliance (mailbox/user data retention), backup immutability Both: DR strategy, backup replication, analytics/dashboarding

Tech Profile Updates

On-prem VMware hosts (UCS, Dell hardware), mixed ownership (PTL-owned UCS, TierPoint-provided Dell PureStack), VMware licensing unclear Storage: Pure Storage (primary), Cohesity (backup, file shares), legacy NetApp replaced Cloud: Google Cloud (backups), Azure (AD), potential for AWS/Azure/agnostic cloud in future Citrix and VPN for distributed user access Pain points: storage speed, backup overages, application sprawl, lack of analytics

On-prem VMware hosts (UCS, Dell hardware), mixed ownership (PTL-owned UCS, TierPoint-provided Dell PureStack), VMware licensing unclear Storage: Pure Storage (primary), Cohesity (backup, file shares), legacy NetApp replaced Cloud: Google Cloud (backups), Azure (AD), potential for AWS/Azure/agnostic cloud in future Citrix and VPN for distributed user access Pain points: storage speed, backup overages, application sprawl, lack of analytics

Meeting Notes

Environment

Hybrid environment: on-prem UCS blades, TierPoint hosted Dell stack, multi-cloud potential Distributed workforce: warehouses nationwide, remote and data center access, Citrix/VPN Core business apps (ERP, dispatch, image retention) are all on-prem Backup/DR: Pure snapshots, Cohesity backups, Google Cloud for immutable backup storage

Hybrid environment: on-prem UCS blades, TierPoint hosted Dell stack, multi-cloud potential Distributed workforce: warehouses nationwide, remote and data center access, Citrix/VPN Core business apps (ERP, dispatch, image retention) are all on-prem Backup/DR: Pure snapshots, Cohesity backups, Google Cloud for immutable backup storage

Detailed Discussion

PTL is seeking to modernize and consolidate its data center environment, reduce costs, and prepare for business growth. The current contract with TierPoint dictates hardware as a service; the contract runs through 2028 and includes VMware as a service. However, VMware licensing ownership and coverage are unclear, especially for customer-owned UCS hardware. There is a lack of clarity and documentation regarding application placement, infrastructure mapping, and the status of legacy systems. Storage and backup are currently handled by Pure and Cohesity, but performance and analytics are lacking. Cohesity was originally brought in to replace NetApp and Symantec, but now also hosts file shares, which are slow and lack analytics. There is a need for analytics/dashboards for file usage, retention, and storage cost management. Alternatives to Cohesity are being considered, including Nasuni and Pure Unified. The business is preparing for an ERP migration (current system EOL end of next year). There is a desire to build an integration layer that is cloud-agnostic and facilitates automation (RPA, AI, microservices). The team needs to document the current environment, including application mapping and data flows, to inform architecture recommendations and identify legacy/unused processes. Security, compliance, and retention (including mailbox data for ex-employees) are also priorities. There is openness to outside help for mapping and diagramming the environment.

PTL is seeking to modernize and consolidate its data center environment, reduce costs, and prepare for business growth. The current contract with TierPoint dictates hardware as a service; the contract runs through 2028 and includes VMware as a service. However, VMware licensing ownership and coverage are unclear, especially for customer-owned UCS hardware. There is a lack of clarity and documentation regarding application placement, infrastructure mapping, and the status of legacy systems. Storage and backup are currently handled by Pure and Cohesity, but performance and analytics are lacking. Cohesity was originally brought in to replace NetApp and Symantec, but now also hosts file shares, which are slow and lack analytics. There is a need for analytics/dashboards for file usage, retention, and storage cost management. Alternatives to Cohesity are being considered, including Nasuni and Pure Unified. The business is preparing for an ERP migration (current system EOL end of next year). There is a desire to build an integration layer that is cloud-agnostic and facilitates automation (RPA, AI, microservices). The team needs to document the current environment, including application mapping and data flows, to inform architecture recommendations and identify legacy/unused processes. Security, compliance, and retention (including mailbox data for ex-employees) are also priorities. There is openness to outside help for mapping and diagramming the environment.

Technical Notes

VMware

Environment

Unclear licensing split between PTL-owned UCS and TierPoint-provided Dell stack UCS hardware is aging and not compatible with newer VMware versions CloudPhysics: 14 VMware hosts (UCS); Live Optics: 6 hosts (TierPoint) UCS: two chassis, 6 blades each; some legacy C220/C2505 servers (possibly unused) VMware version: 6.5 on UCS Storage & Backup: Pure Storage: primary storage, healthy performance, used for snapshots/replication Cohesity: replaced NetApp for file shares & backups; performance is slow, limited analytics, issues with old hardware kicking out SSDs File shares: mostly user data, HR, legal, some application backups, mail PSTs for retention Cohesity backs up to Google Cloud for immutable storage TierPoint was taking Pure snapshots, causing overage charges; now handled by Cohesity No application data on file shares (as per current knowledge); mostly user and department data Application & Cloud: ERP system is core; EOL at end of next year; future migration required Multiple third-party apps with redundancy (40/60% split across providers); plan to consolidate Integration layer planned for automation (Python, RPA, AI, microservices) Cloud: Google Cloud for backup, Azure AD for identity, potential for AWS/Azure for future apps Avoiding vendor lock-in is a priority; desire for cloud-agnostic solutions User Access: Users geographically distributed; warehouses connect directly to data center Citrix and VPN provide remote access Pain Points: Storage performance (file shares slow) Lack of analytics for file usage, retention, and cost Unclear VMware licensing Lack of documentation/diagrams for current environment Legacy hardware/software, potential for hidden legacy processes

VMware

Environment

Unclear licensing split between PTL-owned UCS and TierPoint-provided Dell stack UCS hardware is aging and not compatible with newer VMware versions CloudPhysics: 14 VMware hosts (UCS); Live Optics: 6 hosts (TierPoint) UCS: two chassis, 6 blades each; some legacy C220/C2505 servers (possibly unused) VMware version: 6.5 on UCS Storage & Backup: Pure Storage: primary storage, healthy performance, used for snapshots/replication Cohesity: replaced NetApp for file shares & backups; performance is slow, limited analytics, issues with old hardware kicking out SSDs File shares: mostly user data, HR, legal, some application backups, mail PSTs for retention Cohesity backs up to Google Cloud for immutable storage TierPoint was taking Pure snapshots, causing overage charges; now handled by Cohesity No application data on file shares (as per current knowledge); mostly user and department data Application & Cloud: ERP system is core; EOL at end of next year; future migration required Multiple third-party apps with redundancy (40/60% split across providers); plan to consolidate Integration layer planned for automation (Python, RPA, AI, microservices) Cloud: Google Cloud for backup, Azure AD for identity, potential for AWS/Azure for future apps Avoiding vendor lock-in is a priority; desire for cloud-agnostic solutions User Access: Users geographically distributed; warehouses connect directly to data center Citrix and VPN provide remote access Pain Points: Storage performance (file shares slow) Lack of analytics for file usage, retention, and cost Unclear VMware licensing Lack of documentation/diagrams for current environment Legacy hardware/software, potential for hidden legacy processes List of Speakers/Participants:

Tony Ashby (SHI, Solution Architect) CJ Jones (SHI, Data Protection/DR Specialist) Leslie Schmulson (SHI) Manuel Zelaya (SHI, Analyst/Facilitator) Stephen Drake (PTL) Matt Morris (PTL, Technology Leadership) Steve Silkaitis (PTL) Rob Stephens (PTL, Storage/Backup) Brandon Brown (PTL, Infrastructure) Ernoel Bardaje (PTL, File/Analytics)

Tony Ashby (SHI, Solution Architect) CJ Jones (SHI, Data Protection/DR Specialist) Leslie Schmulson (SHI) Manuel Zelaya (SHI, Analyst/Facilitator) Stephen Drake (PTL) Matt Morris (PTL, Technology Leadership) Steve Silkaitis (PTL) Rob Stephens (PTL, Storage/Backup) Brandon Brown (PTL, Infrastructure) Ernoel Bardaje (PTL, File/Analytics)

Potential Next Steps

Application Mapping and Documentation

Application Mapping and Documentation

Who: PTL (Matt Morris, Steve Silkaitis, Rob Stephens) with support from SHI (Tony Ashby, Manuel Zelaya, Leslie Schmulson) What: Inventory and map all on-prem applications, data flows, and dependencies; identify legacy/unused processes Why: To inform architecture recommendations, support migration/consolidation, and uncover hidden risk/cost Action Item: Matt and Steve to provide app list; SHI to assist with mapping/diagramming Timeline: Immediate/ASAP

Who: PTL (Matt Morris, Steve Silkaitis, Rob Stephens) with support from SHI (Tony Ashby, Manuel Zelaya, Leslie Schmulson) What: Inventory and map all on-prem applications, data flows, and dependencies; identify legacy/unused processes Why: To inform architecture recommendations, support migration/consolidation, and uncover hidden risk/cost Action Item: Matt and Steve to provide app list; SHI to assist with mapping/diagramming Timeline: Immediate/ASAP

TierPoint Contract & VMware Licensing Review

TierPoint Contract & VMware Licensing Review

Who: PTL (Steve Silkaitis, Stephen Drake, Rob Stephens), SHI (Tony Ashby, Leslie Schmulson) What: Clarify VMware licensing coverage for both TierPoint and PTL-owned UCS hardware; review contract terms/penalties Why: To determine licensing/cost obligations and inform consolidation decisions Action Item: PTL to press TierPoint for details; SHI to review provided serial numbers and advise Timeline: Immediate/ASAP

Who: PTL (Steve Silkaitis, Stephen Drake, Rob Stephens), SHI (Tony Ashby, Leslie Schmulson) What: Clarify VMware licensing coverage for both TierPoint and PTL-owned UCS hardware; review contract terms/penalties Why: To determine licensing/cost obligations and inform consolidation decisions Action Item: PTL to press TierPoint for details; SHI to review provided serial numbers and advise Timeline: Immediate/ASAP

Storage & Backup Architecture Review

Storage & Backup Architecture Review

Who: PTL (Rob Stephens, Ernoel Bardaje), SHI (Tony Ashby, CJ Jones, Leslie Schmulson) What: Assess Cohesity performance, file analytics needs, alternatives for file storage (Nasuni, Pure Unified, etc.) Why: To resolve performance/analytics gaps and align storage with business growth/compliance requirements Action Item: SHI to propose options; PTL to provide usage details and feedback on current pain points Timeline: Next 1-2 weeks, in parallel with ongoing Cohesity discussions

Who: PTL (Rob Stephens, Ernoel Bardaje), SHI (Tony Ashby, CJ Jones, Leslie Schmulson) What: Assess Cohesity performance, file analytics needs, alternatives for file storage (Nasuni, Pure Unified, etc.) Why: To resolve performance/analytics gaps and align storage with business growth/compliance requirements Action Item: SHI to propose options; PTL to provide usage details and feedback on current pain points Timeline: Next 1-2 weeks, in parallel with ongoing Cohesity discussions

Future State Architecture Recommendations

Future State Architecture Recommendations

Who: SHI (Tony Ashby, CJ Jones, Leslie Schmulson, Manuel Zelaya), PTL (All IT stakeholders) What: Develop “good/better/best” architecture scenarios (on-prem, hybrid, cloud), taking into account business, technical, and contractual constraints Why: To enable informed decision-making and set roadmap for modernization Action Item: SHI to prepare draft recommendations post-application mapping and contract/licensing clarification Timeline: After completion of above steps

Who: SHI (Tony Ashby, CJ Jones, Leslie Schmulson, Manuel Zelaya), PTL (All IT stakeholders) What: Develop “good/better/best” architecture scenarios (on-prem, hybrid, cloud), taking into account business, technical, and contractual constraints Why: To enable informed decision-making and set roadmap for modernization Action Item: SHI to prepare draft recommendations post-application mapping and contract/licensing clarification Timeline: After completion of above steps

Akamai Engagement (Parallel Initiative)

Akamai Engagement (Parallel Initiative)

Who: PTL (Stephen Drake), SHI What: Engage with Akamai to evaluate their solution(s) as part of the broader architecture strategy Why: To ensure all options are considered in parallel Action Item: PTL to coordinate parallel engagement; SHI to keep updated Timeline: In parallel with above items

Who: PTL (Stephen Drake), SHI What: Engage with Akamai to evaluate their solution(s) as part of the broader architecture strategy Why: To ensure all options are considered in parallel Action Item: PTL to coordinate parallel engagement; SHI to keep updated Timeline: In parallel with above items

Follow-up Meetings

Follow-up Meetings

Who: All What: Regular check-ins to review progress on mapping, licensing, storage/backup, and architecture recommendations Why: Ensure alignment and momentum Action Item: Leslie Schmulson to coordinate scheduling; all to provide updates Timeline: Weekly or as determined by project milestones

Who: All What: Regular check-ins to review progress on mapping, licensing, storage/backup, and architecture recommendations Why: Ensure alignment and momentum Action Item: Leslie Schmulson to coordinate scheduling; all to provide updates Timeline: Weekly or as determined by project milestones From <https://mindspark.shi.com/My_Agents>

Trip Report | Tierpoint| Pilot Thomas

CRM Link:  h ttps://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=a9c7b36a-e597-de11-8392-005056ae0ffb

Customer

AE

Topic

District

Meeting Date

Pilot Thomas

Leslie S

Tierpoint

TOLA1

05/28/25

*Internal notes – Please read and edit before sending
externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Melanie

to provide recap of current issues, send any new updates, and share a detailed agenda before the next meeting.

06/15

2

Leslie/Manuel

come prepared to discuss the paused migration plan and identify requirements to re-enable the projec

06/15

Summary

Summary: • This call centered on critical issues impacting Pilot Thomas Logistics’ backup, storage, and overall IT management in their partnership with TierPoint and SHI. The Pilot Thomas team flagged transparency and communications problems, notably around unexpected data overages caused by misunderstood or miscommunicated backup and snapshot configurations. There was frustration over lack of clarity regarding backup policies (rolling snapshots vs. full backups), Cohesity backup network routing (leading to overages), and VMware licensing metrics. The technical team has taken stopgap measures (reducing snapshot retention, adjusting backups), but customer trust has been impacted, leading to a freeze on further migrations and a demand for remediation. The group agreed to set a follow-up meeting to resolve outstanding issues, clarify contract terms, and regain momentum on stalled migration projects.

Agenda: • Review of current backup and snapshot configurations and related data overages • Discussion of Cohesity backup routing and cross-connect issues • Review of VMware licensing and contract specifics • Addressing communication and transparency concerns • Planning for remediation, next steps, and follow-up meeting scheduling

Opps Identified & BANTC

Opportunity 1: Backup/Storage Overages &
Miscommunication Remediation
• B: Pilot
Thomas is incurring unplanned costs (data overages) due to misunderstood backup and snapshot policies and Cohesity backup routing.
• A: Steve Silkaitis (Pilot Thomas) is the primary
stakeholder, with input from Matt Morris and IT team.
• N: High — dget impact, operational risk, and
customer trust are all affected; migration project is on hold until resolved.
• T: Immediate (action required before migrations
resume); next steps scheduled for Monday at 10:30 Central. • C: TierPoint (service provider), SHI (partner/advisor), Pilot Thomas (customer).

Tech Profile Updates: • Storage: Use of TierPoint for snapshots (reduced from 7 to 3-day retention), Cohesity for backups (external routing now identified as a problem, cross-connect needed). • Security: Backup integrity a concern after recent intrusion and recovery event; communication lapses could create xposure. • VMware licensing: Currently under review for metric accuracy (RAM, cores, contract quantity).

Meeting Notes

Environment: • Pilot Thomas leveraging TierPoint for primary infrastructure and SHI as partner/advisor. • Backups handled via Cohesity; initial configuration routed through external address, causing overages. • Snapshots on TierPoint were rolling 7-day, now reduced to 3-day to control costs. • Migration to new servers/VMs paused due to unresolved issues.

Detailed Discussion

• Steve
Silkaitis detailed recent backup/reovery experience post-intrusion, discovering undocumented 7-day rolling snapshots contributing to overages.
• Backup process via Cohesity initially used external
(Internet) routing, not cross-connect, further adding to data transfer costs.
• Immediate
technical adjustments made (snapshot retention, Cohesity routing), but customer confidence shaken due to poor communication/transparency.
• Migration of VMs/public IPs on hold pending
resolution and trust rebuild.
• VMware
licensing count (RAM vs. cores vs. contract) unclear; requires clarification.
• SHI/TierPoint expressed commitment to remediation
and scheduled follow-up with clear agenda.

Technical Notes

• TierPoint snapshots were set to a rolling 7-day
retention, which were not communicated to the customer; now reduced to 3-day.
• Cohesity backup initially mapped via external
address, consuming bandwidth and incurring data overages; cross-connect now being considered.
• Backup and
recovery solution currently split between Cohesity (Pilot Thomas) and TierPoint (snapshots).
• VMware
licensing discussed: 13196 cores noted, but confusion persists about what the count represents (RAM, cores, etc.), requiring breakdown.
• Contract renegotiation midterm is a question; need
to review TierPoint’s flexibility and T&Cs. • No technical changes confirmed yet for the cross-connect or backup architecture — planning for next call. List all speakers/Participants of Transcript:  Steve Silkaitis (Pilot Thomas) • Stephen Drake (Pilot Thomas) • Matt Morris (Pilot Thomas) • Melanie Sunahara (SHI/TierPoint) • Leslie Schmulson (SHI/TierPoint) • Colleen Corey (SHI/TierPoint) • (Jeremiah and Ben referenced but not directly present)

Potential Next steps

Colleen Corey (SHI/TierPoint) to send calendar invite for follow-up meeting on Monday at 10:30 Central to all participants. (Action Owner: Colleen Corey) Melanie Sunahara (SHI/TierPoint) to provide recap of current issues, send any new updates, and share a detailed agenda before the next meeting. (Action Owner: Melanie Sunahara) SHI/TierPoint to clarify VMware licensing count/metrics and provide a clear breakdown for Pilot Thomas (Action Owner: Melanie Sunahara/Leslie Schmulson to coordinate with Heath). TierPoint to review and propose remediation for data overages caused by snapshots and Cohesity routing (Action Owner: Melanie Sunahara, with input from technical contacts at TierPoint). SHI/TierPoint/Pilot Thomas to discuss contract renegotiation options and flexibility during the next call (Action Owner: Stephen Drake to prepare questions, Melanie Sunahara to provide answers/resources). Technical teams to review and potentially implement cross-connect for Cohesity backup to avoid future data overages (Action Owner: Steve Silkaitis/Matt Morris to coordinate with TierPoint technical team). All participants to come prepared to discuss the paused migration plan and identify requirements to re-enable the project (Action Owner: Steve Silkaitis to outline Pilot Thomas’ position; SHI/TierPoint to suggest solutions).

Trip Report | Tierpoint| Pilot Thomas

CRM Link:  h ttps://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=a9c7b36a-e597-de11-8392-005056ae0ffb

Customer

AE

Topic

District

Meeting Date

Pilot Thomas

Leslie S

Tierpoint

TOLA1

05/28/25

*Internal notes – Please read and edit before sending
externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Melanie

to provide recap of current issues, send any new updates, and share a detailed agenda before the next meeting.

06/15

2

Leslie/Manuel

come prepared to discuss the paused migration plan and identify requirements to re-enable the projec

06/15

Summary

Summary: • This call centered on critical issues impacting Pilot Thomas Logistics’ backup, storage, and overall IT management in their partnership with TierPoint and SHI. The Pilot Thomas team flagged transparency and communications problems, notably around unexpected data overages caused by misunderstood or miscommunicated backup and snapshot configurations. There was frustration over lack of clarity regarding backup policies (rolling snapshots vs. full backups), Cohesity backup network routing (leading to overages), and VMware licensing metrics. The technical team has taken stopgap measures (reducing snapshot retention, adjusting backups), but customer trust has been impacted, leading to a freeze on further migrations and a demand for remediation. The group agreed to set a follow-up meeting to resolve outstanding issues, clarify contract terms, and regain momentum on stalled migration projects.

Agenda: • Review of current backup and snapshot configurations and related data overages • Discussion of Cohesity backup routing and cross-connect issues • Review of VMware licensing and contract specifics • Addressing communication and transparency concerns • Planning for remediation, next steps, and follow-up meeting scheduling

Opps Identified & BANTC

Opportunity 1: Backup/Storage Overages &
Miscommunication Remediation
• B: Pilot
Thomas is incurring unplanned costs (data overages) due to misunderstood backup and snapshot policies and Cohesity backup routing.
• A: Steve Silkaitis (Pilot Thomas) is the primary
stakeholder, with input from Matt Morris and IT team.
• N: High — dget impact, operational risk, and
customer trust are all affected; migration project is on hold until resolved.
• T: Immediate (action required before migrations
resume); next steps scheduled for Monday at 10:30 Central. • C: TierPoint (service provider), SHI (partner/advisor), Pilot Thomas (customer).

Tech Profile Updates: • Storage: Use of TierPoint for snapshots (reduced from 7 to 3-day retention), Cohesity for backups (external routing now identified as a problem, cross-connect needed). • Security: Backup integrity a concern after recent intrusion and recovery event; communication lapses could create xposure. • VMware licensing: Currently under review for metric accuracy (RAM, cores, contract quantity).

Meeting Notes

Environment: • Pilot Thomas leveraging TierPoint for primary infrastructure and SHI as partner/advisor. • Backups handled via Cohesity; initial configuration routed through external address, causing overages. • Snapshots on TierPoint were rolling 7-day, now reduced to 3-day to control costs. • Migration to new servers/VMs paused due to unresolved issues.

Detailed Discussion

• Steve
Silkaitis detailed recent backup/reovery experience post-intrusion, discovering undocumented 7-day rolling snapshots contributing to overages.
• Backup process via Cohesity initially used external
(Internet) routing, not cross-connect, further adding to data transfer costs.
• Immediate
technical adjustments made (snapshot retention, Cohesity routing), but customer confidence shaken due to poor communication/transparency.
• Migration of VMs/public IPs on hold pending
resolution and trust rebuild.
• VMware
licensing count (RAM vs. cores vs. contract) unclear; requires clarification.
• SHI/TierPoint expressed commitment to remediation
and scheduled follow-up with clear agenda.

Technical Notes

• TierPoint snapshots were set to a rolling 7-day
retention, which were not communicated to the customer; now reduced to 3-day.
• Cohesity backup initially mapped via external
address, consuming bandwidth and incurring data overages; cross-connect now being considered.
• Backup and
recovery solution currently split between Cohesity (Pilot Thomas) and TierPoint (snapshots).
• VMware
licensing discussed: 13196 cores noted, but confusion persists about what the count represents (RAM, cores, etc.), requiring breakdown.
• Contract renegotiation midterm is a question; need
to review TierPoint’s flexibility and T&Cs. • No technical changes confirmed yet for the cross-connect or backup architecture — planning for next call. List all speakers/Participants of Transcript:  Steve Silkaitis (Pilot Thomas) • Stephen Drake (Pilot Thomas) • Matt Morris (Pilot Thomas) • Melanie Sunahara (SHI/TierPoint) • Leslie Schmulson (SHI/TierPoint) • Colleen Corey (SHI/TierPoint) • (Jeremiah and Ben referenced but not directly present)

Potential Next steps

Colleen Corey (SHI/TierPoint) to send calendar invite for follow-up meeting on Monday at 10:30 Central to all participants. (Action Owner: Colleen Corey) Melanie Sunahara (SHI/TierPoint) to provide recap of current issues, send any new updates, and share a detailed agenda before the next meeting. (Action Owner: Melanie Sunahara) SHI/TierPoint to clarify VMware licensing count/metrics and provide a clear breakdown for Pilot Thomas (Action Owner: Melanie Sunahara/Leslie Schmulson to coordinate with Heath). TierPoint to review and propose remediation for data overages caused by snapshots and Cohesity routing (Action Owner: Melanie Sunahara, with input from technical contacts at TierPoint). SHI/TierPoint/Pilot Thomas to discuss contract renegotiation options and flexibility during the next call (Action Owner: Stephen Drake to prepare questions, Melanie Sunahara to provide answers/resources). Technical teams to review and potentially implement cross-connect for Cohesity backup to avoid future data overages (Action Owner: Steve Silkaitis/Matt Morris to coordinate with TierPoint technical team). All participants to come prepared to discuss the paused migration plan and identify requirements to re-enable the project (Action Owner: Steve Silkaitis to outline Pilot Thomas’ position; SHI/TierPoint to suggest solutions).

Trip Report | Tierpoint| Pilot Thomas

Trip Report | Tierpoint| Pilot Thomas

CRM Link:  h ttps://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=a9c7b36a-e597-de11-8392-005056ae0ffb

Customer

AE

Topic

District

Meeting Date

Pilot Thomas

Leslie S

Tierpoint

TOLA1

05/28/25

*Internal notes – Please read and edit before sending
externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Melanie

to provide recap of current issues, send any new updates, and share a detailed agenda before the next meeting.

06/15

2

Leslie/Manuel

come prepared to discuss the paused migration plan and identify requirements to re-enable the projec

06/15

Summary

Summary: • This call centered on critical issues impacting Pilot Thomas Logistics’ backup, storage, and overall IT management in their partnership with TierPoint and SHI. The Pilot Thomas team flagged transparency and communications problems, notably around unexpected data overages caused by misunderstood or miscommunicated backup and snapshot configurations. There was frustration over lack of clarity regarding backup policies (rolling snapshots vs. full backups), Cohesity backup network routing (leading to overages), and VMware licensing metrics. The technical team has taken stopgap measures (reducing snapshot retention, adjusting backups), but customer trust has been impacted, leading to a freeze on further migrations and a demand for remediation. The group agreed to set a follow-up meeting to resolve outstanding issues, clarify contract terms, and regain momentum on stalled migration projects.

Agenda: • Review of current backup and snapshot configurations and related data overages • Discussion of Cohesity backup routing and cross-connect issues • Review of VMware licensing and contract specifics • Addressing communication and transparency concerns • Planning for remediation, next steps, and follow-up meeting scheduling

Opps Identified & BANTC

Opportunity 1: Backup/Storage Overages &
Miscommunication Remediation
• B: Pilot
Thomas is incurring unplanned costs (data overages) due to misunderstood backup and snapshot policies and Cohesity backup routing.
• A: Steve Silkaitis (Pilot Thomas) is the primary
stakeholder, with input from Matt Morris and IT team.
• N: High — dget impact, operational risk, and
customer trust are all affected; migration project is on hold until resolved.
• T: Immediate (action required before migrations
resume); next steps scheduled for Monday at 10:30 Central. • C: TierPoint (service provider), SHI (partner/advisor), Pilot Thomas (customer).

Tech Profile Updates: • Storage: Use of TierPoint for snapshots (reduced from 7 to 3-day retention), Cohesity for backups (external routing now identified as a problem, cross-connect needed). • Security: Backup integrity a concern after recent intrusion and recovery event; communication lapses could create xposure. • VMware licensing: Currently under review for metric accuracy (RAM, cores, contract quantity).

Meeting Notes

Environment: • Pilot Thomas leveraging TierPoint for primary infrastructure and SHI as partner/advisor. • Backups handled via Cohesity; initial configuration routed through external address, causing overages. • Snapshots on TierPoint were rolling 7-day, now reduced to 3-day to control costs. • Migration to new servers/VMs paused due to unresolved issues.

Detailed Discussion

• Steve
Silkaitis detailed recent backup/reovery experience post-intrusion, discovering undocumented 7-day rolling snapshots contributing to overages.
• Backup process via Cohesity initially used external
(Internet) routing, not cross-connect, further adding to data transfer costs.
• Immediate
technical adjustments made (snapshot retention, Cohesity routing), but customer confidence shaken due to poor communication/transparency.
• Migration of VMs/public IPs on hold pending
resolution and trust rebuild.
• VMware
licensing count (RAM vs. cores vs. contract) unclear; requires clarification.
• SHI/TierPoint expressed commitment to remediation
and scheduled follow-up with clear agenda.

Technical Notes

• TierPoint snapshots were set to a rolling 7-day
retention, which were not communicated to the customer; now reduced to 3-day.
• Cohesity backup initially mapped via external
address, consuming bandwidth and incurring data overages; cross-connect now being considered.
• Backup and
recovery solution currently split between Cohesity (Pilot Thomas) and TierPoint (snapshots).
• VMware
licensing discussed: 13196 cores noted, but confusion persists about what the count represents (RAM, cores, etc.), requiring breakdown.
• Contract renegotiation midterm is a question; need
to review TierPoint’s flexibility and T&Cs. • No technical changes confirmed yet for the cross-connect or backup architecture — planning for next call. List all speakers/Participants of Transcript:  Steve Silkaitis (Pilot Thomas) • Stephen Drake (Pilot Thomas) • Matt Morris (Pilot Thomas) • Melanie Sunahara (SHI/TierPoint) • Leslie Schmulson (SHI/TierPoint) • Colleen Corey (SHI/TierPoint) • (Jeremiah and Ben referenced but not directly present)

Potential Next steps

Colleen Corey (SHI/TierPoint) to send calendar invite for follow-up meeting on Monday at 10:30 Central to all participants. (Action Owner: Colleen Corey) Melanie Sunahara (SHI/TierPoint) to provide recap of current issues, send any new updates, and share a detailed agenda before the next meeting. (Action Owner: Melanie Sunahara) SHI/TierPoint to clarify VMware licensing count/metrics and provide a clear breakdown for Pilot Thomas (Action Owner: Melanie Sunahara/Leslie Schmulson to coordinate with Heath). TierPoint to review and propose remediation for data overages caused by snapshots and Cohesity routing (Action Owner: Melanie Sunahara, with input from technical contacts at TierPoint). SHI/TierPoint/Pilot Thomas to discuss contract renegotiation options and flexibility during the next call (Action Owner: Stephen Drake to prepare questions, Melanie Sunahara to provide answers/resources). Technical teams to review and potentially implement cross-connect for Cohesity backup to avoid future data overages (Action Owner: Steve Silkaitis/Matt Morris to coordinate with TierPoint technical team). All participants to come prepared to discuss the paused migration plan and identify requirements to re-enable the project (Action Owner: Steve Silkaitis to outline Pilot Thomas’ position; SHI/TierPoint to suggest solutions).

CRM Link:  h ttps://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=a9c7b36a-e597-de11-8392-005056ae0ffb

Customer

AE

Topic

District

Meeting Date

Pilot Thomas

Leslie S

Tierpoint

TOLA1

05/28/25
