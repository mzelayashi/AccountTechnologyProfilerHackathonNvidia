Trip Report | Backup Recovery | Pilot Thomas

Customer: Pilot Thomas
AE: Leslie S
Topic: Backup Recovery
Meeting Date 04/28/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Keo Sounthavin

provide a renewal quote for existing nodes and explore options for extending support until 2027.

05/15

2

Manuel Z

Once decision is made prepare a proposal for upgrading to newer models with enhanced features.

05/15

Item Owner Next Steps/Detail Due Date 1 Keo Sounthavin provide a renewal quote for existing nodes and explore options for extending support until 2027. 05/15 2 Manuel Z Once decision is made prepare a proposal for upgrading to newer models with enhanced features. 05/15

Summary

The meeting involves a detailed discussion about the renewal of maintenance contracts for Pilot Thomas Logistics' existing infrastructure, particularly focusing on AC 4600 nodes, which are set to go end of life by February 2027. The team, consisting of representatives from SHI and Cohesity, is strategizing to support Pilot Thomas Logistics in making informed decisions regarding their technology upgrades. There is a focus on whether to renew existing nodes or upgrade to newer models such as the 5000 or 6000 series. The conversation also touches on potential growth, the need for enhanced performance, and the integration of new features such as threat protection and data classification. Budget constraints and strategic planning for future growth are significant considerations.

Agenda

Review current infrastructure and maintenance contracts Discuss potential upgrades and renewals Explore

next steps and action items

Review current infrastructure and maintenance contracts Discuss potential upgrades and renewals Explore

next steps and action items

Opps Identified & BANTC

Opportunity 1: Infrastructure Renewal and Upgrade

B: Pilot
Thomas Logistics needs to decide between renewing existing infrastructure or upgrading to newer models due to impending end-of-life dates.
A: Decision-makers
include Leslie Schmulson and Keo Sounthavin, with input from Jean Mombrun and Sam Johnson.
N: The
need is urgent as some nodes are already out of support, impacting performance.
T: The
timeline for decision and action is within the next few months, with renewals due in July and end of support by February 2027.
C: Budget
considerations are crucial, with discussions around the cost of renewals versus upgrades.

B: Pilot
Thomas Logistics needs to decide between renewing existing infrastructure or upgrading to newer models due to impending end-of-life dates.
A: Decision-makers
include Leslie Schmulson and Keo Sounthavin, with input from Jean Mombrun and Sam Johnson.
N: The
need is urgent as some nodes are already out of support, impacting performance.
T: The
timeline for decision and action is within the next few months, with renewals due in July and end of support by February 2027.
C: Budget
considerations are crucial, with discussions around the cost of renewals versus upgrades.

Initiatives

Both Security and Storage: Implementing upgrades to enhance performance and security features, including threat protection and ransomware protection.

Both Security and Storage: Implementing upgrades to enhance performance and security features, including threat protection and ransomware protection.

Tech Profile Updates

Current nodes (C 2000s) are out of support, and AC 4600 will soon be end-of-life. Consideration of upgrades to 5000 or 6000 series for better performance and new features. Integration with existing systems and software updates are essential.

Current nodes (C 2000s) are out of support, and AC 4600 will soon be end-of-life. Consideration of upgrades to 5000 or 6000 series for better performance and new features. Integration with existing systems and software updates are essential.

Meeting Notes

Environment

Pilot Thomas Logistics is operating with an aging infrastructure nearing end-of-life. The company is experiencing 100% usage on existing systems, indicating a need for expansion and upgrades.

Pilot Thomas Logistics is operating with an aging infrastructure nearing end-of-life. The company is experiencing 100% usage on existing systems, indicating a need for expansion and upgrades.

Detailed Discussion

Renewal vs. Upgrade: The team discussed the benefits and drawbacks of renewing existing nodes versus upgrading to newer models. The newer models offer enhanced features and better performance. Growth Considerations: The need for scalability to accommodate company growth, including hiring and potential mergers and acquisitions, was emphasized. Technical Needs: Discussion around integrating new features like threat protection and data classification into their systems.

Renewal vs. Upgrade: The team discussed the benefits and drawbacks of renewing existing nodes versus upgrading to newer models. The newer models offer enhanced features and better performance. Growth Considerations: The need for scalability to accommodate company growth, including hiring and potential mergers and acquisitions, was emphasized. Technical Needs: Discussion around integrating new features like threat protection and data classification into their systems.

Technical Notes

End-of-life for AC 4600 is February 2027. C 2000 nodes are already out of support. No buyback program for old hardware, but potential for streamlined upgrades. The importance of aligning hardware upgrades with software updates for improved performance.

End-of-life for AC 4600 is February 2027. C 2000 nodes are already out of support. No buyback program for old hardware, but potential for streamlined upgrades. The importance of aligning hardware upgrades with software updates for improved performance. List all speakers/Participants of Transcript:

Leslie Schmulson Keo Sounthavin Jean Mombrun Flaminio Guerrero Barb Kiernan Sam Johnson

Leslie Schmulson Keo Sounthavin Jean Mombrun Flaminio Guerrero Barb Kiernan Sam Johnson

Potential Next steps

Renewal Quote Preparation:

Renewal Quote Preparation:

Keo Sounthavin to provide a renewal quote for existing nodes and explore options for extending support until 2027. Involves Leslie Schmulson for review and customer presentation.

Keo Sounthavin to provide a renewal quote for existing nodes and explore options for extending support until 2027. Involves Leslie Schmulson for review and customer presentation.

Upgrade Proposal:

Upgrade Proposal:

Prepare a proposal for upgrading to newer models with enhanced features. Action item for Jean Mombrun to coordinate with the AE and SE teams for customer discussions.

Prepare a proposal for upgrading to newer models with enhanced features. Action item for Jean Mombrun to coordinate with the AE and SE teams for customer discussions.

Customer Meeting Coordination:

Customer Meeting Coordination:

Leslie Schmulson to reach out to Pilot Thomas Logistics to schedule a follow-up meeting. Coordinate with Barb Kiernan and Sam Johnson for potential in-person interactions.

Leslie Schmulson to reach out to Pilot Thomas Logistics to schedule a follow-up meeting. Coordinate with Barb Kiernan and Sam Johnson for potential in-person interactions.
