Trip Report | Assessing the business | Pilot Thomas

Customer: Pilot Thomas
AE: Leslie S
Topic: Assessing the business
Meeting Date 02/05/2026

*Internal notes – Please read and edit before sending externally*

Summary

This meeting was a strategic business and technical alignment session between PTL customer) and SHI (vendor/partner) focused on establishing a stronger partnership model for 2026. The discussion centered on understanding PTL’s current technology environment, identifying operational gaps, improving visibility into assets and renewals, and aligning future initiatives across endpoint management, licensing, infrastructure documentation, and communications. Key business themes included:

Establishing clarity and trust in the SHI–PTL partnership Improving lifecycle and asset visibility (hardware, software, renewals) Addressing Microsoft licensing complexity and renewal planning Advancing endpoint deployment via Intune and Autopilot Exploring centralized, auditable SMS/group messaging for dispatch operations Introducing complimentary SHI services such as technology diagrams and labs Identifying future modernization opportunities without forcing near‑term commitments

Establishing clarity and trust in the SHI–PTL partnership Improving lifecycle and asset visibility (hardware, software, renewals) Addressing Microsoft licensing complexity and renewal planning Advancing endpoint deployment via Intune and Autopilot Exploring centralized, auditable SMS/group messaging for dispatch operations Introducing complimentary SHI services such as technology diagrams and labs Identifying future modernization opportunities without forcing near‑term commitments The call also served as a discovery forum to surface pain points, validate current tools, and identify follow‑up actions requiring deeper technical and vendor engagement.

Agenda

Introductions and partnership alignment Review of SHI One portal capabilities Asset lifecycle and renewal visibility Microsoft licensing challenges and renewal timing

Endpoint deployment and

Intune Autopilot discussion Asset management and patching considerations SHI Labs and technology evaluation capabilities SHI Technology Diagram offering Centralized SMS/group messaging for dispatch Future roadmap and operational modernization topics Identification of next steps and follow‑up meetings

Introductions and partnership alignment Review of SHI One portal capabilities Asset lifecycle and renewal visibility Microsoft licensing challenges and renewal timing

Endpoint deployment and

Intune Autopilot discussion Asset management and patching considerations SHI Labs and technology evaluation capabilities SHI Technology Diagram offering Centralized SMS/group messaging for dispatch Future roadmap and operational modernization topics Identification of next steps and follow‑up meetings

Opportunities Identified & BANTC

Opportunity 1: Endpoint Deployment Modernization
(Intune + Autopilot) B (Budget): Implied existing Microsoft licensing spend; optimization rather than net‑new budget discussed. A (Authority): IT leadership and engineering team at PTL (Ailyn, Cristina, Brandon). N (Need): Reduce manual imaging, accelerate laptop deployment, improve end‑user onboarding, and minimize first‑login delays caused by application installs. T (Timeline): Near‑term; active testing already underway with urgency to finalize configuration. C (Competition): Current manual enrollment and imaging processes; internal workflows.
Opportunity 2: Asset Visibility & Lifecycle
Management B (Budget): No immediate spend identified; leveraging existing SHI tools and complimentary services. A (Authority): PTL IT leadership and operations. N (Need): Centralized view of hardware, serial numbers, warranties, renewals, and ownership across the environment. T (Timeline): Ongoing; visibility needed to support planning and renewals. C (Competition): Manual spreadsheets, fragmented vendor portals, lack of unified inventory system.
Opportunity 3: Centralized SMS / Dispatch
Communications Platform B (Budget): Undetermined; exploratory stage. A (Authority): PTL IT and Operations leadership. N (Need): Enable centralized, auditable, group‑based SMS communication between dispatchers, drivers, and sales without reliance on individual iPhones. T (Timeline): Mid‑term; requires discovery with Microsoft and unified communications specialists. C (Competition): iMessage on shared phones, Vonage SMS limitations, fragmented communication history.
Opportunity 4: Infrastructure Documentation &
Visibility (Technology Diagrams) B (Budget): No cost; complimentary SHI service. A (Authority): PTL IT leadership. N (Need): Lack of documented infrastructure diagrams across sites, data centers, and endpoints. T (Timeline): Near‑term; intake session requested. C (Competition): No existing diagrams; informal tribal knowledge.

Initiatives

Endpoint Management

Modernization – Security Asset Lifecycle & Inventory Visibility – Security Centralized SMS / Communications Platform – Security

Infrastructure

Documentation (Technology Diagrams) – Both Security and

Infrastructure

Microsoft Licensing Optimization & Renewal Planning – Security

Endpoint Management

Modernization – Security Asset Lifecycle & Inventory Visibility – Security Centralized SMS / Communications Platform – Security

Infrastructure

Documentation (Technology Diagrams) – Both Security and

Infrastructure

Microsoft Licensing Optimization & Renewal Planning – Security

Tech Profile Updates

Endpoint management

transitioning toward Microsoft Intune and Autopilot Dell laptops standardizing

endpoint hardware

Cisco UCS legacy components still partially present Adobe licensing consolidated under anniversary‑based agreements Vonage used for voice with limited SMS capabilities Jira used for project and task tracking Samsara used for ELD logging (operations)

Endpoint management

transitioning toward Microsoft Intune and Autopilot Dell laptops standardizing

endpoint hardware

Cisco UCS legacy components still partially present Adobe licensing consolidated under anniversary‑based agreements Vonage used for voice with limited SMS capabilities Jira used for project and task tracking Samsara used for ELD logging (operations)

Meeting Notes

SHI emphasized partnership transparency and expectation setting PTL highlighted frustration with licensing complexity and asset visibility SHI One portal reviewed for renewals, assets, warehouse inventory, and projects Gaps identified in serial number visibility for non‑Cisco hardware Adobe licensing structure explained and clarified Warehouse‑stored, pre‑imaged laptops discussed Intune Autopilot enrollment challenges surfaced SHI Labs introduced for tool evaluation without vendor pressure Technology diagram offering introduced and positively received SMS dispatch challenge clearly articulated by PTL operations

SHI emphasized partnership transparency and expectation setting PTL highlighted frustration with licensing complexity and asset visibility SHI One portal reviewed for renewals, assets, warehouse inventory, and projects Gaps identified in serial number visibility for non‑Cisco hardware Adobe licensing structure explained and clarified Warehouse‑stored, pre‑imaged laptops discussed Intune Autopilot enrollment challenges surfaced SHI Labs introduced for tool evaluation without vendor pressure Technology diagram offering introduced and positively received SMS dispatch challenge clearly articulated by PTL operations

Environment

Microsoft 365 tenant with Intune Dell endpoint fleet Cisco UCS (partial/legacy) Adobe subscription licensing Vonage voice services iPhone‑based dispatch communications Mixed on‑prem and hosted

infrastructure (TierPoint)

Microsoft 365 tenant with Intune Dell endpoint fleet Cisco UCS (partial/legacy) Adobe subscription licensing Vonage voice services iPhone‑based dispatch communications Mixed on‑prem and hosted

infrastructure (TierPoint)

Detailed Discussion

The conversation progressed from relationship alignment into deep operational and technical exploration. PTL expressed appreciation for responsiveness but emphasized the need for clarity, visibility, and realistic delivery. Asset lifecycle management became a focal point, revealing gaps in serial‑number tracking and renewal attribution.

Endpoint

deployment challenges revealed that while Intune is in place, manual enrollment causes delays in application provisioning, impacting user experience. This led to agreement on a deeper Autopilot and Intune configuration review. The dispatch SMS issue emerged as a significant operational blocker, with strong business impact. The need for continuity across shifts, locations, and roles was clearly articulated, driving agreement to explore Microsoft and alternative unified communications options.

Technical Notes

Intune enrollment currently performed manually on some devices Autopilot hash IDs required for vendor‑side enrollment Application install latency during first login is a major concern SHI warehouse supports pre‑imaged Dell devices SHI One portal pulls asset data from order history Serial numbers currently visible primarily for Cisco assets Adobe licenses are prorated to a fixed anniversary date Discovered assets differ from purchased assets in data completeness Vonage supports SMS broadcasts but not conversational group threads Teams currently not deployed to drivers SMS requirement is account‑based, not device‑based

Infrastructure diagrams

produced via structured intake and Visio SHI Labs support ondemand and engineer‑assisted evaluations

Intune enrollment currently performed manually on some devices Autopilot hash IDs required for vendor‑side enrollment Application install latency during first login is a major concern SHI warehouse supports pre‑imaged Dell devices SHI One portal pulls asset data from order history Serial numbers currently visible primarily for Cisco assets Adobe licenses are prorated to a fixed anniversary date Discovered assets differ from purchased assets in data completeness Vonage supports SMS broadcasts but not conversational group threads Teams currently not deployed to drivers SMS requirement is account‑based, not device‑based

Infrastructure diagrams

produced via structured intake and Visio SHI Labs support ondemand and engineer‑assisted evaluations Speakers / Participants (ROLES)

Leslie Schmulson – Strategic Account Manager, SHI Manuel Zelaya – Commercial Solutions Engineer, SHI Ailyn Gonzalez – IT Leadership / Engineering, PTL Cristina Saucedo – IT Operations / Procurement, PTL Rook Watson – PTL Team Member Unknown Speaker – PTL Participant

Leslie Schmulson – Strategic Account Manager, SHI Manuel Zelaya – Commercial Solutions Engineer, SHI Ailyn Gonzalez – IT Leadership / Engineering, PTL Cristina Saucedo – IT Operations / Procurement, PTL Rook Watson – PTL Team Member Unknown Speaker – PTL Participant

Potential Next Steps

Schedule Intune & Autopilot Deep Dive

Initiated by: Leslie Involves: Manuel, Derek (SHI), Ailyn, PTL engineering Purpose: Finalize enrollment model and application deployment behavior

Engage Microsoft & Unified Communications Specialists on SMS

Initiated by: Manuel Involves: SHI Microsoft specialists, PTL IT and Operations Purpose: Assess feasibility of centralized SMS via Teams or alternative platforms

Technology Diagram Intake Session

Initiated by: Manuel Involves: Ailyn, Brandon (PTL), SHI infrastructure engineer Purpose: Build initial

infrastructure diagram

Microsoft Licensing Renewal Planning Call

Initiated by: Leslie Involves: SHI Microsoft team, PTL stakeholders Purpose: Early visibility into promotions and renewal timing

Re‑establish Recurring Monthly Syncs

Initiated by: Leslie Involves: SHI and PTL core stakeholders Purpose: Track initiatives, updates, and new priorities

Schedule Intune & Autopilot Deep Dive

Initiated by: Leslie Involves: Manuel, Derek (SHI), Ailyn, PTL engineering Purpose: Finalize enrollment model and application deployment behavior

Initiated by: Leslie Involves: Manuel, Derek (SHI), Ailyn, PTL engineering Purpose: Finalize enrollment model and application deployment behavior Engage Microsoft & Unified Communications Specialists on SMS

Initiated by: Manuel Involves: SHI Microsoft specialists, PTL IT and Operations Purpose: Assess feasibility of centralized SMS via Teams or alternative platforms

Initiated by: Manuel Involves: SHI Microsoft specialists, PTL IT and Operations Purpose: Assess feasibility of centralized SMS via Teams or alternative platforms Technology Diagram Intake Session

Initiated by: Manuel Involves: Ailyn, Brandon (PTL), SHI infrastructure engineer Purpose: Build initial

infrastructure diagram

Initiated by: Manuel Involves: Ailyn, Brandon (PTL), SHI infrastructure engineer Purpose: Build initial

infrastructure diagram

Microsoft Licensing Renewal Planning Call

Initiated by: Leslie Involves: SHI Microsoft team, PTL stakeholders Purpose: Early visibility into promotions and renewal timing

Initiated by: Leslie Involves: SHI Microsoft team, PTL stakeholders Purpose: Early visibility into promotions and renewal timing Re‑establish Recurring Monthly Syncs

Initiated by: Leslie Involves: SHI and PTL core stakeholders Purpose: Track initiatives, updates, and new priorities

Initiated by: Leslie Involves: SHI and PTL core stakeholders Purpose: Track initiatives, updates, and new priorities
