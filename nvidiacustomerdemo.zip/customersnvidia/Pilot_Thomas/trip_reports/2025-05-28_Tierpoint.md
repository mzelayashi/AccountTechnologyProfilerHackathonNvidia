Trip Report | Tierpoint | Pilot Thomas

Customer: Pilot Thomas
AE: Leslie S
Topic: Tierpoint
Meeting Date 05/28/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Melanie

to provide recap of current issues, send any new updates, and share a detailed agenda before the next meeting.

06/15

2

Leslie/Manuel

come prepared to discuss the paused migration plan and identify requirements to re-enable the projec

06/15

Item Owner Next Steps/Detail Due Date 1 Melanie to provide recap of current issues, send any new updates, and share a detailed agenda before the next meeting. 06/15 2 Leslie/Manuel come prepared to discuss the paused migration plan and identify requirements to re-enable the projec 06/15

Summary

Summary: • This call centered on critical issues impacting Pilot Thomas Logistics’ backup, storage, and overall IT management in their partnership with TierPoint and SHI. The Pilot Thomas team flagged transparency and communications problems, notably around unexpected data overages caused by misunderstood or miscommunicated backup and snapshot configurations. There was frustration over lack of clarity regarding backup policies (rolling snapshots vs. full backups), Cohesity backup network routing (leading to overages), and VMware licensing metrics. The technical team has taken stopgap measures (reducing snapshot retention, adjusting backups), but customer trust has been impacted, leading to a freeze on further migrations and a demand for remediation. The group agreed to set a follow-up meeting to resolve outstanding issues, clarify contract terms, and regain momentum on stalled migration projects. Agenda: • Review of current backup and snapshot configurations and related data overages • Discussion of Cohesity backup routing and cross-connect issues • Review of VMware licensing and contract specifics • Addressing communication and transparency concerns • Planning for remediation, next steps, and follow-up meeting scheduling

Opps Identified & BANTC

Opportunity 1: Backup/Storage Overages &
Miscommunication Remediation
• B: Pilot
Thomas is incurring unplanned costs (data overages) due to misunderstood backup and snapshot policies and Cohesity backup routing.
• A: Steve Silkaitis (Pilot Thomas) is the primary
stakeholder, with input from Matt Morris and IT team.
• N: High — dget impact, operational risk, and
customer trust are all affected; migration project is on hold until resolved.
• T: Immediate (action required before migrations
resume); next steps scheduled for Monday at 10:30 Central. • C: TierPoint (service provider), SHI (partner/advisor), Pilot Thomas (customer). Tech Profile Updates: • Storage: Use of TierPoint for snapshots (reduced from 7 to 3-day retention), Cohesity for backups (external routing now identified as a problem, cross-connect needed). • Security: Backup integrity a concern after recent intrusion and recovery event; communication lapses could create xposure. • VMware licensing: Currently under review for metric accuracy (RAM, cores, contract quantity).

Meeting Notes

Environment: • Pilot Thomas leveraging TierPoint for primary infrastructure and SHI as partner/advisor. • Backups handled via Cohesity; initial configuration routed through external address, causing overages. • Snapshots on TierPoint were rolling 7-day, now reduced to 3-day to control costs. • Migration to new servers/VMs paused due to unresolved issues.

Detailed Discussion

• Steve
Silkaitis detailed recent backup/reovery experience post-intrusion, discovering undocumented 7-day rolling snapshots contributing to overages.
• Backup process via Cohesity initially used external
(Internet) routing, not cross-connect, further adding to data transfer costs.
• Immediate
technical adjustments made (snapshot retention, Cohesity routing), but customer confidence shaken due to poor communication/transparency.
• Migration of VMs/public IPs on hold pending
resolution and trust rebuild.
• VMware
licensing count (RAM vs. cores vs. contract) unclear; requires clarification.
• SHI/TierPoint expressed commitment to remediation
and scheduled follow-up with clear agenda.

Technical Notes

• TierPoint snapshots were set to a rolling 7-day
retention, which were not communicated to the customer; now reduced to 3-day.
• Cohesity backup initially mapped via external
address, consuming bandwidth and incurring data overages; cross-connect now being considered.
• Backup and
recovery solution currently split between Cohesity (Pilot Thomas) and TierPoint (snapshots).
• VMware
licensing discussed: 13196 cores noted, but confusion persists about what the count represents (RAM, cores, etc.), requiring breakdown.
• Contract renegotiation midterm is a question; need
to review TierPoint’s flexibility and T&Cs. • No technical changes confirmed yet for the cross-connect or backup architecture — planning for next call. List all speakers/Participants of Transcript:  Steve Silkaitis (Pilot Thomas) • Stephen Drake (Pilot Thomas) • Matt Morris (Pilot Thomas) • Melanie Sunahara (SHI/TierPoint) • Leslie Schmulson (SHI/TierPoint) • Colleen Corey (SHI/TierPoint) • (Jeremiah and Ben referenced but not directly present)

Potential Next steps

Colleen Corey (SHI/TierPoint) to send calendar invite for follow-up meeting on Monday at 10:30 Central to all participants. (Action Owner: Colleen Corey) Melanie Sunahara (SHI/TierPoint) to provide recap of current issues, send any new updates, and share a detailed agenda before the next meeting. (Action Owner: Melanie Sunahara) SHI/TierPoint to clarify VMware licensing count/metrics and provide a clear breakdown for Pilot Thomas (Action Owner: Melanie Sunahara/Leslie Schmulson to coordinate with Heath). TierPoint to review and propose remediation for data overages caused by snapshots and Cohesity routing (Action Owner: Melanie Sunahara, with input from technical contacts at TierPoint). SHI/TierPoint/Pilot Thomas to discuss contract renegotiation options and flexibility during the next call (Action Owner: Stephen Drake to prepare questions, Melanie Sunahara to provide answers/resources). Technical teams to review and potentially implement cross-connect for Cohesity backup to avoid future data overages (Action Owner: Steve Silkaitis/Matt Morris to coordinate with TierPoint technical team). All participants to come prepared to discuss the paused migration plan and identify requirements to re-enable the project (Action Owner: Steve Silkaitis to outline Pilot Thomas’ position; SHI/TierPoint to suggest solutions).

Colleen Corey (SHI/TierPoint) to send calendar invite for follow-up meeting on Monday at 10:30 Central to all participants. (Action Owner: Colleen Corey) Melanie Sunahara (SHI/TierPoint) to provide recap of current issues, send any new updates, and share a detailed agenda before the next meeting. (Action Owner: Melanie Sunahara) SHI/TierPoint to clarify VMware licensing count/metrics and provide a clear breakdown for Pilot Thomas (Action Owner: Melanie Sunahara/Leslie Schmulson to coordinate with Heath). TierPoint to review and propose remediation for data overages caused by snapshots and Cohesity routing (Action Owner: Melanie Sunahara, with input from technical contacts at TierPoint). SHI/TierPoint/Pilot Thomas to discuss contract renegotiation options and flexibility during the next call (Action Owner: Stephen Drake to prepare questions, Melanie Sunahara to provide answers/resources). Technical teams to review and potentially implement cross-connect for Cohesity backup to avoid future data overages (Action Owner: Steve Silkaitis/Matt Morris to coordinate with TierPoint technical team). All participants to come prepared to discuss the paused migration plan and identify requirements to re-enable the project (Action Owner: Steve Silkaitis to outline Pilot Thomas’ position; SHI/TierPoint to suggest solutions).
