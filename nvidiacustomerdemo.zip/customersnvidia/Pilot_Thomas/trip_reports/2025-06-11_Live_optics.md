Trip Report | Live optics | Pilot Thomas

Customer: Pilot Thomas
AE: Leslie
Topic: Live optics
Meeting Date 06/11/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Tony A

Prepare a report on ghost VMs (using last power-on data) and recommend a cleanup strategy to customer.

06/25

2

Manuel Z

Present findings, unified recommendations, and answer customer questions on Cohesity, infrastructure, and VM cleanup.

06/25

Item Owner Next Steps/Detail Due Date 1 Tony A Prepare a report on ghost VMs (using last power-on data) and recommend a cleanup strategy to customer. 06/25 2 Manuel Z Present findings, unified recommendations, and answer customer questions on Cohesity, infrastructure, and VM cleanup. 06/25

Summary

Summary

This internal review between Tony Ashby and Manuel Zelaya focused on analyzing infrastructure utilization and right-sizing opportunities for Pilot Thomas’s UCS and Dell environments. The discussion leveraged Live Optics data to examine CPU, memory, and virtual machine (VM) statistics, revealing significant overprovisioning, especially in memory, and a large number of powered-off VMs. The team discussed the implications of these findings for VMware licensing costs and future infrastructure planning. A key

Agenda

Review Live Optics output for UCS and Dell server environments Analyze VM density, utilization, and potential for consolidation Discuss Cohesity’s impact on infrastructure and upcoming renewal Establish internal next steps and alignment

Review Live Optics output for UCS and Dell server environments Analyze VM density, utilization, and potential for consolidation Discuss Cohesity’s impact on infrastructure and upcoming renewal Establish internal next steps and alignment

Opps Identified & BANTC

Opportunity 1: Infrastructure Rightsizing & VMware
Optimization

B: Customer
is interested in lowering VMware (and related infrastructure) costs; sizing recommendations will inform future purchases/licensing.
A: Customer
IT Director (currently not aware of all ghost VMs); SHI team to advise.
N: Overprovisioning,
many dormant VMs, memory bottlenecks; need to optimize for performance, cost, and future growth.
T: Immediate,
as VMware licensing and Cohesity renewal decisions are pending.
C: Status
quo, current hardware vendors, no explicit competitors but SHI’s advice will influence future hardware/software choices.

B: Customer
is interested in lowering VMware (and related infrastructure) costs; sizing recommendations will inform future purchases/licensing.
A: Customer
IT Director (currently not aware of all ghost VMs); SHI team to advise.
N: Overprovisioning,
many dormant VMs, memory bottlenecks; need to optimize for performance, cost, and future growth.
T: Immediate,
as VMware licensing and Cohesity renewal decisions are pending.
C: Status
quo, current hardware vendors, no explicit competitors but SHI’s advice will influence future hardware/software choices.
Opportunity 2: Cohesity Upgrade vs. Renewal Decision

B: Customer
must decide soon (3-4 weeks) whether to renew Cohesity or upgrade (and potentially migrate data/workloads).
A: Leslie
(customer), SHI team (including Tony, Manuel, Flaminio).
N: Cohesity
used for both backup and file shares; current solution is experiencing latency/performance issues.
T: Urgent—renewal
deadline in 3-4 weeks.
C: Status
quo (renew), upgrade path, or alternative storage/backup solutions.

B: Customer
must decide soon (3-4 weeks) whether to renew Cohesity or upgrade (and potentially migrate data/workloads).
A: Leslie
(customer), SHI team (including Tony, Manuel, Flaminio).
N: Cohesity
used for both backup and file shares; current solution is experiencing latency/performance issues.
T: Urgent—renewal
deadline in 3-4 weeks.
C: Status
quo (renew), upgrade path, or alternative storage/backup solutions.

Initiatives

Security: Not primary in this discussion, but referenced as a potential future need. Storage: Central—Cohesity backup/file shares, Pure Storage right-sizing, VM sprawl.

Security: Not primary in this discussion, but referenced as a potential future need. Storage: Central—Cohesity backup/file shares, Pure Storage right-sizing, VM sprawl.

Tech Profile Updates

Current

Environment

UCS (12 servers): 993 GHz CPU, 6.7 TB RAM, 279 VMs (only 55 running). Dell (6 servers): Better utilization, but still excess capacity. Pure Storage arrays supporting VM workloads. Cohesity for backup and file sharing (renewal/upgrade pending). Challenges: Overprovisioned memory and CPU. Ghost VMs inflating resource requirements. Latency/performance complaints. Limited time to act on Cohesity renewal.

Current

Environment

UCS (12 servers): 993 GHz CPU, 6.7 TB RAM, 279 VMs (only 55 running). Dell (6 servers): Better utilization, but still excess capacity. Pure Storage arrays supporting VM workloads. Cohesity for backup and file sharing (renewal/upgrade pending). Challenges: Overprovisioned memory and CPU. Ghost VMs inflating resource requirements. Latency/performance complaints. Limited time to act on Cohesity renewal.

Meeting Notes

Environment

SHI has two Live Optics “collector” runs: one for UCS (12 servers) and one for Dell (6 servers). UCS environment: Very low CPU utilization, high memory allocation, large number of powered-off VMs. Dell environment: Marginally better utilization, possibly sized for consolidation of remaining VMs. Cohesity: Used for both backup and file shares—complicates migration/renewal strategy.

SHI has two Live Optics “collector” runs: one for UCS (12 servers) and one for Dell (6 servers). UCS environment: Very low CPU utilization, high memory allocation, large number of powered-off VMs. Dell environment: Marginally better utilization, possibly sized for consolidation of remaining VMs. Cohesity: Used for both backup and file shares—complicates migration/renewal strategy.

Detailed Discussion

Utilization Analysis: Out of 279 VMs, only 55 are powered on; the rest are likely abandoned/ghost VMs. Memory is the primary bottleneck, but there is significant overallocation. Rightsizing exercise shows current workloads could fit on 4 hosts with 32-core procs and 512GB RAM each, maintaining N-1 redundancy. Could optimize for a 4:1 vCPU:core ratio, standard for production. Customer Direction: Customer leadership may not be aware of ghost VMs—need to review with them and recommend cleanup. Customer will want assurance that rightsized infrastructure provides sufficient headroom/redundancy. Cohesity Decision: Cohesity’s dual use (backup, file share) means migration would require both block and file storage reallocation (likely to Pure). Migration, if pursued, is not feasible before the renewal deadline—timing is a critical risk. Latency issues persist, and “easy button” is likely a Cohesity upgrade (not renewal). Next Steps: Internal alignment with Leslie and Flaminio to finalize recommendation and prep for customer sync.

Utilization Analysis: Out of 279 VMs, only 55 are powered on; the rest are likely abandoned/ghost VMs. Memory is the primary bottleneck, but there is significant overallocation. Rightsizing exercise shows current workloads could fit on 4 hosts with 32-core procs and 512GB RAM each, maintaining N-1 redundancy. Could optimize for a 4:1 vCPU:core ratio, standard for production. Customer Direction: Customer leadership may not be aware of ghost VMs—need to review with them and recommend cleanup. Customer will want assurance that rightsized infrastructure provides sufficient headroom/redundancy. Cohesity Decision: Cohesity’s dual use (backup, file share) means migration would require both block and file storage reallocation (likely to Pure). Migration, if pursued, is not feasible before the renewal deadline—timing is a critical risk. Latency issues persist, and “easy button” is likely a Cohesity upgrade (not renewal). Next Steps: Internal alignment with Leslie and Flaminio to finalize recommendation and prep for customer sync.

Technical Notes

Live Optics provides last power-on data for VMs (to help identify ghosts). Rightsizing spreadsheet models various host/core/RAM configurations (e.g., 4x32-core/512GB, or 6x24-core, etc.). Cohesity’s capacity for both file and backup must be mapped to Pure if migration is considered. Migration effort (timing, data transfer, cutover) likely exceeds renewal window. 4:1 vCPU:core ratio is considered safe for production. Latency issues and performance bottlenecks are primary customer complaints. Suggestion to combine rightsizing with VMware licensing optimization to save costs.

Live Optics provides last power-on data for VMs (to help identify ghosts). Rightsizing spreadsheet models various host/core/RAM configurations (e.g., 4x32-core/512GB, or 6x24-core, etc.). Cohesity’s capacity for both file and backup must be mapped to Pure if migration is considered. Migration effort (timing, data transfer, cutover) likely exceeds renewal window. 4:1 vCPU:core ratio is considered safe for production. Latency issues and performance bottlenecks are primary customer complaints. Suggestion to combine rightsizing with VMware licensing optimization to save costs. List all speakers/Participants of Transcript:

Tony Ashby (SHI) Manuel Zelaya (SHI) Leslie (Customer, referenced for next meeting) Flaminio Guerrero (SHI, referenced for internal sync)

Tony Ashby (SHI) Manuel Zelaya (SHI) Leslie (Customer, referenced for next meeting) Flaminio Guerrero (SHI, referenced for internal sync)

Potential Next Steps

Internal Sync to Align Recommendations

Internal Sync to Align Recommendations

Action: Schedule internal call with Leslie, Tony, Manuel, and Flaminio to finalize rightsizing, Cohesity strategy, and unified customer message. Who: Leslie (to schedule), Tony Ashby, Manuel Zelaya, Flaminio Guerrero

Action: Schedule internal call with Leslie, Tony, Manuel, and Flaminio to finalize rightsizing, Cohesity strategy, and unified customer message. Who: Leslie (to schedule), Tony Ashby, Manuel Zelaya, Flaminio Guerrero

VM Environment Analysis & Cleanup

VM Environment Analysis & Cleanup

Action: Prepare a report on ghost VMs (using last power-on data) and recommend a cleanup strategy to customer. Who: Tony Ashby (to extract/report), Manuel Zelaya (to advise)

Action: Prepare a report on ghost VMs (using last power-on data) and recommend a cleanup strategy to customer. Who: Tony Ashby (to extract/report), Manuel Zelaya (to advise)

Cohesity Renewal/Upgrade Strategic Recommendation

Cohesity Renewal/Upgrade Strategic Recommendation

Action: Draft a clear, logical customer argument for Cohesity upgrade (vs. renewal), emphasizing performance gains, timing, and migration feasibility. Who: Tony Ashby, Manuel Zelaya, Leslie

Action: Draft a clear, logical customer argument for Cohesity upgrade (vs. renewal), emphasizing performance gains, timing, and migration feasibility. Who: Tony Ashby, Manuel Zelaya, Leslie

Model Infrastructure Rightsizing for VMware Licensing

Model Infrastructure Rightsizing for VMware Licensing

Action: Present rightsized host/core/memory recommendations and estimated cost/labor savings from consolidation. Who: Tony Ashby (with support from Manuel)

Action: Present rightsized host/core/memory recommendations and estimated cost/labor savings from consolidation. Who: Tony Ashby (with support from Manuel)

Customer Meeting (Post-Internal Alignment)

Customer Meeting (Post-Internal Alignment)

Action: Present findings, unified recommendations, and answer customer questions on Cohesity, infrastructure, and VM cleanup. Who: Tony Ashby, Manuel Zelaya (primary presenters), Leslie (customer lead)

Action: Present findings, unified recommendations, and answer customer questions on Cohesity, infrastructure, and VM cleanup. Who: Tony Ashby, Manuel Zelaya (primary presenters), Leslie (customer lead) From <https://mindspark.shi.com/My_Agents>
