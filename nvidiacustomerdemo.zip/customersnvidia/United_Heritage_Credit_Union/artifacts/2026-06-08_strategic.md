# Strategic Briefing — United_Heritage_Credit_Union

## Executive summary
As of the Weekly Sync | SHI + United Heritage Credit Union meetings in May–June 2026, Chris Ciolfi (new IT Infrastructure Manager), Brett Mullins, and Stephen Crane are driving evaluations across endpoint security, monitoring, and infrastructure renewals. On 05/14/2026, during the Q2 kickoff with David Atkinson, the team aligned on AI exploration, Dell infrastructure updates, and continued SHI partnership. The customer is actively evaluating Trend Micro vs CrowdStrike vs SentinelOne, PRTG vs alternatives, and Dell PowerStore/PowerEdge renewals while reassessing MFA strategy (RSA vs Entra + YubiKeys). The account is in a transitional state with a new decision-maker and is prioritizing cost optimization, vendor consolidation, and architecture validation before committing to long-term contracts.

## Current initiatives
- **Endpoint Security Platform Evaluation** (Active evaluation) — Comparison of Trend Micro, CrowdStrike, and SentinelOne, including Vision One pricing and demo scheduling
  ↳ next: Decision on vendor direction following demos and pricing review
- **Monitoring Platform Selection** (Active evaluation) — Evaluating PRTG vs ManageEngine, LogicMonitor, NinjaOne, and SolarWinds alternatives with concern about cloud vs on-prem reliability
  ↳ next: Finalize quotes and complete demo evaluations for selection
- **Dell Infrastructure Renewals (PowerEdge, PowerStore)** (In progress) — Customer validating correct support tiers and awaiting updated quotes due to incorrect renewal submissions and vendor delays
  ↳ next: Customer approval after receipt of corrected quotes and tier validation
- **MFA & Identity Strategy (RSA vs Entra + YubiKeys)** (Under review) — Evaluating RSA one-year option alongside Entra ID and YubiKeys to support passwordless MFA for frontline staff without personal devices
  ↳ next: Internal decision by Chris Ciolfi on MFA direction
- **Adobe Licensing Optimization / Expansion** (Quote stage) — Reviewing Acrobat Pro/Standard and evaluating Acrobat Studio with AI tools while optimizing licensing tiers
  ↳ next: Customer decision on Acrobat Studio upgrade
- **AI & Innovation Engagement** (Early-stage) — Customer to confirm availability for AI discussion and align internally on AI Council participation
  ↳ next: Schedule initial AI session with UHCU IT team

## Strategic opportunities
- **Security Stack Consolidation (Endpoint + MFA)** [high, win 0.7] — Position unified architecture across endpoint security + MFA leveraging evaluation phase and new leadership influence
  ↳ next step: Drive consensus workshop with Chris Ciolfi post-demo reviews
- **Monitoring Platform Standardization** [high, win 0.65] — Emphasize on-prem resiliency advantages vs cloud-only tools and align to customer architecture concerns
  ↳ next step: Finalize PRTG pricing and deliver comparative recommendation
- **Dell Infrastructure Expansion / Optimization** [high, win 0.6] — Anchor on cost optimization (tier right-sizing) and service assurance vs competitor confusion
  ↳ next step: Resolve quote issues and present clean consolidated proposal
- **AI Advisory / Services Engagement** [medium, win 0.5] — Lead early advisory discussions tied to AI Council and roadmap alignment
  ↳ next step: Schedule AI intro session and discovery
- **VMware Replacement / Infrastructure Transformation** [high, win 0.55] — Position Hyper-V vs Dell Private Cloud with emphasis on reuse of existing hardware and cost sensitivity
  ↳ next step: Deliver technical validation and demo options

## Immediate next steps
- Schedule SentinelOne demo and finalize timing  _( David Atkinson · Immediate )_
- Provide updated Dell quotes and datasheets  _( David Atkinson · Immediate )_
- Customer to confirm endpoint security direction  _( Chris Ciolfi · Next sync cycle )_
- Coordinate AI discovery session  _( David Atkinson · Near-term )_
- Finalize PRTG and monitoring quotes  _( David Atkinson · Next 1–2 syncs )_

## Risks to monitor
- [medium] New IT leadership (Chris Ciolfi) causing delays in decisions — mitigation: Increase direct engagement and provide structured recommendations
- [high] Vendor quote delays (Dell) impacting momentum — mitigation: Continue escalation and provide interim guidance
- [high] Customer cost sensitivity leading to stalled decisions — mitigation: Frame solutions around cost optimization and ROI
- [medium] Preference for on-prem limiting cloud-based solutions — mitigation: Position hybrid/on-prem capable solutions

## Talking points
- **Security Consolidation**: Align endpoint + MFA strategy to reduce vendor sprawl and simplify operations
- **Cost Optimization**: Focus on right-sizing Dell support tiers and avoiding overprovisioning
- **Monitoring Architecture**: Address reliability concerns around cloud monitoring versus on-prem solutions
- **AI Engagement**: Introduce practical AI use cases aligned to UHCU’s operational priorities
- **Decision Enablement**: Provide clear side-by-side comparisons to accelerate decisions under new leadership
