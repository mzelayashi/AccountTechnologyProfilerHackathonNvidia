Trip Report | Forcepoint | United Heritage Credit Union

Customer: United Heritage Credit Union
AE: David A
Topic: Forcepoint
Meeting Date 03/14/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

Obtain documentation and support from Forcepoint for transition

04/01

2

David A

Transition planning for new appliance OS

04/01

Item Owner Next Steps/Detail Due Date 1 Manuel Z Obtain documentation and support from Forcepoint for transition 04/01 2 David A Transition planning for new appliance OS 04/01

Summary

The meeting involved representatives from SHI, UHCU, and Forcepoint discussing several key issues and future plans related to UHCU's deployment of Forcepoint appliances. The conversation centered around concerns about appliances receiving updates, a roadmap discussion for future appliance strategies, and anomalies with current proxy deployments. Key points included the need to transition from CentOS 7 due to its end-of-life status, resolving current technical support issues, and enhancing communication regarding technical support escalation.

Agenda

Introductions and roles Discussion of current issues with appliances and updates Roadmap and future strategy for appliance deployment Health check and best practices adherence Technical support escalation and improvement Coordination of potential future meetings

Introductions and roles Discussion of current issues with appliances and updates Roadmap and future strategy for appliance deployment Health check and best practices adherence Technical support escalation and improvement Coordination of potential future meetings

Opps Identified & BANTC

Opportunity to Transition Appliance OS

Opportunity to Transition Appliance OS

B: Transition
from CentOS 7 to a new supported OS for UHCU's virtual appliances.
A: Brent
Harris, Alan Matson, and Forcepoint team.
N: Need
for continued security and compliance with updated systems.
T: Immediate
action required due to CentOS 7 end-of-life.
C: Coordination
with Forcepoint for documentation and support.

B: Transition
from CentOS 7 to a new supported OS for UHCU's virtual appliances.
A: Brent
Harris, Alan Matson, and Forcepoint team.
N: Need
for continued security and compliance with updated systems.
T: Immediate
action required due to CentOS 7 end-of-life.
C: Coordination
with Forcepoint for documentation and support.

Opportunity for Enhanced Technical Support

Opportunity for Enhanced Technical Support

B: Escalation
of current unresolved technical issues and improved support.
A: Alan
Matson, Adam Peabody, Erik Inman.
N: Need
for timely and effective resolution of technical anomalies.
T: Immediate,
with ongoing improvements.
C: Internal
Forcepoint escalation and customer advocate involvement.

B: Escalation
of current unresolved technical issues and improved support.
A: Alan
Matson, Adam Peabody, Erik Inman.
N: Need
for timely and effective resolution of technical anomalies.
T: Immediate,
with ongoing improvements.
C: Internal
Forcepoint escalation and customer advocate involvement.

Initiatives

Security

Transition to a supported OS for appliances. Support: Improvement in technical support processes and escalation.

Security

Transition to a supported OS for appliances. Support: Improvement in technical support processes and escalation.

Tech Profile Updates

Current deployment on CentOS 7, transitioning needed. Virtual appliances on VMware infrastructure. Issues with Google’s Manifest V3 and proxy configurations.

Current deployment on CentOS 7, transitioning needed. Virtual appliances on VMware infrastructure. Issues with Google’s Manifest V3 and proxy configurations.

Meeting Notes

Environment

UHCU currently uses Forcepoint appliances deployed on VMware infrastructure, originally on CentOS 7.

UHCU currently uses Forcepoint appliances deployed on VMware infrastructure, originally on CentOS 7.

Detailed Discussion

Brent Harris raised concerns about appliance updates and the need for a roadmap. Alan Matson highlighted the transition necessity from CentOS 7 and shared current deployment issues. Adam Peabody and Erik Inman discussed technical support escalation and customer advocate roles. Tony Marini provided technical insights and suggested a follow-up health check.

Brent Harris raised concerns about appliance updates and the need for a roadmap. Alan Matson highlighted the transition necessity from CentOS 7 and shared current deployment issues. Adam Peabody and Erik Inman discussed technical support escalation and customer advocate roles. Tony Marini provided technical insights and suggested a follow-up health check.

Technical Notes

Transition away from CentOS 7 due to end-of-life. Technical support issues with current proxies, unresolved cases requiring escalation. Inline proxy versus V3 plugin considerations.

Transition away from CentOS 7 due to end-of-life. Technical support issues with current proxies, unresolved cases requiring escalation. Inline proxy versus V3 plugin considerations. List all speakers/Participants of Transcript:

David Atkinson (SHI) Alan Matson (UHCU) Marco Rocha (UHCU) Brent Harris (UHCU) Brett Mullins (UHCU) (audio-only) Inman, Erik (Forcepoint) Peabody, Adam (Forcepoint) Marini, Tony (Forcepoint) Manuel Zelaya (SHI)

David Atkinson (SHI) Alan Matson (UHCU) Marco Rocha (UHCU) Brent Harris (UHCU) Brett Mullins (UHCU) (audio-only) Inman, Erik (Forcepoint) Peabody, Adam (Forcepoint) Marini, Tony (Forcepoint) Manuel Zelaya (SHI)

Potential Next Steps

Action Item: Transition planning for new appliance OS

Action Item: Transition planning for new appliance OS

Involved: Brent Harris, Alan Matson, Tony Marini Outcome: Obtain documentation and support from Forcepoint for transition.

Involved: Brent Harris, Alan Matson, Tony Marini Outcome: Obtain documentation and support from Forcepoint for transition.

Action Item: Escalate current technical support tickets

Action Item: Escalate current technical support tickets

Involved: Alan Matson, Adam Peabody, Erik Inman Outcome: Resolve outstanding issues and improve ongoing support communications.

Involved: Alan Matson, Adam Peabody, Erik Inman Outcome: Resolve outstanding issues and improve ongoing support communications.

Action Item: Schedule follow-up health check meeting

Action Item: Schedule follow-up health check meeting

Involved: Alan Matson, Tony Marini Outcome: Ensure best practices and configurations are adhered to.

Involved: Alan Matson, Tony Marini Outcome: Ensure best practices and configurations are adhered to.

Action Item: Identify and connect
