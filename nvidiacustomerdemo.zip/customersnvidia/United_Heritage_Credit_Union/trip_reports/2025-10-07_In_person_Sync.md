Trip Report | In person Sync | United Heritage Credit Union

Customer: United Heritage Credit Union
AE: David A
Topic: In person Sync
Meeting Date 10/07/2025

*Internal notes – Please read and edit before sending externally*

Summary

The Q4 onsite business review and planning session with United Heritage Credit Union (UHCU) focused on strategic technology initiatives, ongoing projects, and upcoming business/IT challenges. Key topics included the evaluation and migration from on-prem Exchange to a hybrid environment with Microsoft, improvements to data loss prevention (DLP) capabilities—specifically moving away from legacy Forcepoint to a modern solution with integrated CASB features, ongoing PKI Certificate Manager project, network upgrades, and security posture reviews. The session highlighted the need for SHI’s sales engineering team to provide deeper technical guidance, especially around Microsoft hybrid migration, blind spots in current infrastructure, and the selection of next-generation security platforms such as Palo Alto, with the possibility of leveraging SHI Labs for hands-on evaluation. Budgetary planning and timeline synchronization for security and infrastructure upgrades were emphasized, with additional discussions on VMware licensing, future AI initiatives, and the importance of keeping technical and risk teams closely aligned for both daily operations and incident response. The meeting identified several actionable opportunities for SHI to strengthen its partnership with UHCU through proactive technical consultation, solution demos, and strategic planning for 2026 and beyond. Customer Technical Environment Notes:

Predominantly on-prem Microsoft Exchange, considering migration to hybrid deployment. Existing legacy Forcepoint DLP solution, limited CASB capabilities, seeking alternatives. Cisco networking equipment, active renewal and phased decommissioning. VMware for virtualization, exploring options due to licensing/cost changes (TierPoint, HPE, Nutanix). PKI Certificate Manager project underway. Wi-Fi heat mapping scheduled.

Security

posture review last completed two years ago, new review planned for Q1 next year. Network upgrades in process: migration from old 507s to new Nexus switches, data center hardware refresh. AI committee formed, but internal deployment seen as costly—interest in ready-to-deploy solutions. Segmented (not air-gapped) network architecture, with core backup solution air-gapped. Trend Micro legacy email gateway and smart server features being phased out.

Predominantly on-prem Microsoft Exchange, considering migration to hybrid deployment. Existing legacy Forcepoint DLP solution, limited CASB capabilities, seeking alternatives. Cisco networking equipment, active renewal and phased decommissioning. VMware for virtualization, exploring options due to licensing/cost changes (TierPoint, HPE, Nutanix). PKI Certificate Manager project underway. Wi-Fi heat mapping scheduled.

Security

posture review last completed two years ago, new review planned for Q1 next year. Network upgrades in process: migration from old 507s to new Nexus switches, data center hardware refresh. AI committee formed, but internal deployment seen as costly—interest in ready-to-deploy solutions. Segmented (not air-gapped) network architecture, with core backup solution air-gapped. Trend Micro legacy email gateway and smart server features being phased out.

Agenda

Welcome and introductions Review Q4 performance and key metrics Update on ongoing projects/initiatives Discussion of opportunities and challenges Q&A and action items Next steps and closing remarks

Welcome and introductions Review Q4 performance and key metrics Update on ongoing projects/initiatives Discussion of opportunities and challenges Q&A and action items Next steps and closing remarks

Opps Identified & BANTC

Opportunity 1: Microsoft Exchange Migration to Hybrid

B: Clear need for technical guidance and project support in migrating on-prem Exchange to a hybrid deployment. Blind spots acknowledged by customer.
A: SHI
SEs can provide direct consultation and migration planning, leveraging SHI Labs for proof of concept and technical validation. N: Immediate need, as part of broader infrastructure modernization. Project urgency noted for upcoming budget cycle. T: Security and network teams engaged, risk/insurance driving requirements—final selection pending internal and external validation.

B: Dissatisfaction with Forcepoint’s coverage, desire for an integrated DLP/CASB solution (e.g., Palo Alto, others).
A: SHI
can coordinate vendor demos, facilitate lab testing, and provide technical expertise on solution selection and deployment. N: Need to improve coverage for both cloud and internal environments, driven by evolving threat landscape and insurance requirements. T: Research and evaluation in late 2025; implementation target for 2026. Budgetary estimates required for planning. C: Security and network teams engaged, risk/insurance driving requirements—final selection pending internal and external validation.
Opportunity 3: Security Posture Review & Incident
Response Planning

B: Security assessment is outdated; new review needed to comply with insurance/examiner mandates and guide future upgrades. A: SHI’s security engineering resources can conduct assessment, update documentation, and advise on best practices, including incident simulation and tabletop exercises. N: High, as insurance and regulatory pressure mounts; need scheduled for Q1
2026.
T: Discovery and review sessions in Q1; follow-up and remediation mapped for 2026 budget cycle. C: Technical team responsible for implementation; risk team sets policySHI can bridge both.

B: Security assessment is outdated; new review needed to comply with insurance/examiner mandates and guide future upgrades. A: SHI’s security engineering resources can conduct assessment, update documentation, and advise on best practices, including incident simulation and tabletop exercises. N: High, as insurance and regulatory pressure mounts; need scheduled for Q1
2026.
T: Discovery and review sessions in Q1; follow-up and remediation mapped for 2026 budget cycle. C: Technical team responsible for implementation; risk team sets policySHI can bridge both.
Opportunity 4: VMware Licensing Optimization

B: VMware renewal and licensing cost concerns; exploring TierPoint and HPE as alternatives.
A: SHI
can provide analysis of cost models, facilitate licensing transfer, and advise on hybrid/on-prem/cloud options. N: Timely, as renewal deadlines and bundle discontinuations (e.g., Broadcom changes) require quick action. T: Immediate for standard/essentials bundle (pre-Oct 31, 2025), broader planning for hardware refresh by 2028.
C: IT
leadership making decisions; SHI needs to provide clear financial and technical guidance.

B: VMware renewal and licensing cost concerns; exploring TierPoint and HPE as alternatives.
A: SHI
can provide analysis of cost models, facilitate licensing transfer, and advise on hybrid/on-prem/cloud options. N: Timely, as renewal deadlines and bundle discontinuations (e.g., Broadcom changes) require quick action. T: Immediate for standard/essentials bundle (pre-Oct 31, 2025), broader planning for hardware refresh by 2028.
C: IT
leadership making decisions; SHI needs to provide clear financial and technical guidance.

Initiatives (Security or Storage or both)

Security

DLP/CASB modernization, security posture review, incident response planning, PKI Certificate Manager, MFA expansion (RSA ID+ migration), XDR evaluation. Storage/Infrastructure: VMware licensing optimization, TierPoint/HPE/Nutanix evaluation, network hardware upgrades, Wi-Fi heat mapping.

Security

DLP/CASB modernization, security posture review, incident response planning, PKI Certificate Manager, MFA expansion (RSA ID+ migration), XDR evaluation. Storage/Infrastructure: VMware licensing optimization, TierPoint/HPE/Nutanix evaluation, network hardware upgrades, Wi-Fi heat mapping.

Tech Profile Updates

On-prem Exchange moving to hybrid. Forcepoint DLP under review; Palo Alto/CASB considered. Cisco network hardware phased renewal/decommission. VMware infrastructure, considering TierPoint/HPE/Nutanix. AI committee formed—ready-to-deploy AI solutions considered, not full in-house build.

Security

posture review scheduled for Q1 2026. RSA ID+ migration in planning for next budget cycle. Wi-Fi heat mapping and data center hardware refresh ongoing.

On-prem Exchange moving to hybrid. Forcepoint DLP under review; Palo Alto/CASB considered. Cisco network hardware phased renewal/decommission. VMware infrastructure, considering TierPoint/HPE/Nutanix. AI committee formed—ready-to-deploy AI solutions considered, not full in-house build.

Security

posture review scheduled for Q1 2026. RSA ID+ migration in planning for next budget cycle. Wi-Fi heat mapping and data center hardware refresh ongoing.

Meeting Notes

SHI presented SHI One platform, including asset management and lab environments. UHCU team expressed need for Microsoft SE support for Exchange hybrid migration, specifically to identify and mitigate blind spots. Interest in exploring modern DLP/CASB solutions (e.g., Palo Alto) due to dissatisfaction with Forcepoint and evolving cloud requirements. Discussion of PKI Certificate Manager project progress, upcoming demos, and stakeholder involvement. Network upgrade status reviewed; migration to Nexus switches, management switch planning, data center refresh.

Security

posture review and incident response planning highlighted, with tabletop exercises and simulation gaps noted. Budget and timeline alignment for 2026/2027 initiatives discussed; need for early engagement and estimates for RSA migration and other projects. AI use cases workshop offered; committee interested in ready-to-deploy solutions. Trend Micro email gateway and smart server features decommissioning discussed; impact on redundancy and process.

SHI presented SHI One platform, including asset management and lab environments. UHCU team expressed need for Microsoft SE support for Exchange hybrid migration, specifically to identify and mitigate blind spots. Interest in exploring modern DLP/CASB solutions (e.g., Palo Alto) due to dissatisfaction with Forcepoint and evolving cloud requirements. Discussion of PKI Certificate Manager project progress, upcoming demos, and stakeholder involvement. Network upgrade status reviewed; migration to Nexus switches, management switch planning, data center refresh.

Security

posture review and incident response planning highlighted, with tabletop exercises and simulation gaps noted. Budget and timeline alignment for 2026/2027 initiatives discussed; need for early engagement and estimates for RSA migration and other projects. AI use cases workshop offered; committee interested in ready-to-deploy solutions. Trend Micro email gateway and smart server features decommissioning discussed; impact on redundancy and process.

Detailed Discussion Notes

Attendees reviewed ongoing and upcoming projects, emphasizing collaboration and open technical dialogue. SHI One platform demo received positively; lab environments seen as valuable for proof-of-concept and hands-on evaluation. Microsoft

Security

posture review scheduled for Q1 2026; team interested in new assessment to align with evolving risk/insurance mandates. VMware renewal and licensing changes discussed; TierPoint and HPE alternatives noted for cost reduction and operational flexibility. AI committee formed, but internal build seen as costly; interest in SHI-facilitated workshops and ready-to-deploy solutions. Network upgrades progressing: migration to Nexus switches, management switch installation, data center hardware refresh. Trend Micro email gateway and smart server features being phased out; team evaluating redundancy and replacement needs. Tabletop exercises for incident response discussed; gap in full simulation noted, potential for SHI advisory engagement. Team open to both cloud and on-prem solutions, with flexibility to evaluate best fit per application/system renewal. Technical/risk teams alignment discussed; SHI positioned as knowledge bridge for both implementation and policy compliance.

Attendees reviewed ongoing and upcoming projects, emphasizing collaboration and open technical dialogue. SHI One platform demo received positively; lab environments seen as valuable for proof-of-concept and hands-on evaluation. Microsoft

Security

posture review scheduled for Q1 2026; team interested in new assessment to align with evolving risk/insurance mandates. VMware renewal and licensing changes discussed; TierPoint and HPE alternatives noted for cost reduction and operational flexibility. AI committee formed, but internal build seen as costly; interest in SHI-facilitated workshops and ready-to-deploy solutions. Network upgrades progressing: migration to Nexus switches, management switch installation, data center hardware refresh. Trend Micro email gateway and smart server features being phased out; team evaluating redundancy and replacement needs. Tabletop exercises for incident response discussed; gap in full simulation noted, potential for SHI advisory engagement. Team open to both cloud and on-prem solutions, with flexibility to evaluate best fit per application/system renewal. Technical/risk teams alignment discussed; SHI positioned as knowledge bridge for both implementation and policy compliance. Next Steps/detail: Person name responsible Action

Microsoft Exchange Hybrid Migration Planning

Microsoft Exchange Hybrid Migration Planning

Manuel Zelaya / SHI SEs: Schedule technical discovery session, identify blind spots, propose migration roadmap, and provide documentation.

Manuel Zelaya / SHI SEs: Schedule technical discovery session, identify blind spots, propose migration roadmap, and provide documentation.

DLP/CASB Solution Evaluation

DLP/CASB Solution Evaluation

Manuel Zelaya: Coordinate demos (e.g., Palo Alto, others), facilitate SHI Labs hands-on testing, summarize findings and recommendations.

Manuel Zelaya: Coordinate demos (e.g., Palo Alto, others), facilitate SHI Labs hands-on testing, summarize findings and recommendations.

Security Posture Review

Security Posture Review

Manuel Zelaya + SHI Security Engineer: Initiate discovery sessions Q1 2026, prepare assessment deliverable, advise on incident simulation exercises.

Manuel Zelaya + SHI Security Engineer: Initiate discovery sessions Q1 2026, prepare assessment deliverable, advise on incident simulation exercises.

VMware Licensing Optimization

VMware Licensing Optimization

Manuel Zelaya: Provide cost analysis and licensing transfer options for TierPoint/HPE, advise on renewal deadlines, and recommend next steps.

Manuel Zelaya: Provide cost analysis and licensing transfer options for TierPoint/HPE, advise on renewal deadlines, and recommend next steps.

AI Use Case Workshop

AI Use Case Workshop

Manuel Zelaya: Set up workshop for AI committee, provide examples from Glean/Iera, deliver summary of actionable use cases.

Manuel Zelaya: Set up workshop for AI committee, provide examples from Glean/Iera, deliver summary of actionable use cases.

Trend Micro Email Gateway & Smart Server Review

Trend Micro Email Gateway & Smart Server Review

Manuel Zelaya: Review impact of decommissioning, coordinate with UHCU on redundancy/replacement, send email summary of recommendations.

Manuel Zelaya: Review impact of decommissioning, coordinate with UHCU on redundancy/replacement, send email summary of recommendations.

Network Upgrades

Network Upgrades

Brett Mullins/UHCU: Continue migration to Nexus switches, install management switch, schedule data center hardware refresh.

Brett Mullins/UHCU: Continue migration to Nexus switches, install management switch, schedule data center hardware refresh.

RSA ID+ Migration Estimate

RSA ID+ Migration Estimate

Manuel Zelaya: Work with UHCU to provide budgetary estimate, assist with licensing credit process, advise on timeline for migration.

Manuel Zelaya: Work with UHCU to provide budgetary estimate, assist with licensing credit process, advise on timeline for migration. List all speakers/Participants of Transcript:

David Atkinson (SHI, Account Executive) Manuel Zelaya (SHI, Sales Engineer) Greg Miller (SHI, Regional Sales Director) Brett Mullins (UHCU) Stuart Gehrke (UHCU) Stephen Crane (UHCU) Nathan Brown (UHCU) Alan Matson (UHCU, optional) Marco (UHCU, network engineer referenced)

David Atkinson (SHI, Account Executive) Manuel Zelaya (SHI, Sales Engineer) Greg Miller (SHI, Regional Sales Director) Brett Mullins (UHCU) Stuart Gehrke (UHCU) Stephen Crane (UHCU) Nathan Brown (UHCU) Alan Matson (UHCU, optional) Marco (UHCU, network engineer referenced)
