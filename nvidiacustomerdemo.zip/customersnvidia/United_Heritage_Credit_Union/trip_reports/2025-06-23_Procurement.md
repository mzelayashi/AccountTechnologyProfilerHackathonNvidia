Trip Report | Procurement | United Heritage Credit Union

Customer: United Heritage Credit Union
AE: David A
Topic: Procurement
Meeting Date 06/23/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

David A

confirm with Mimecast if lower-tier SKUs or custom add-on combinations are available to mitigate the 30% cost increase.

07/05

2

Manuel Z

Assist in configueration and provide feedback on Add-on patch cables and any issues with new shipments.

07/05

Item Owner Next Steps/Detail Due Date 1 David A confirm with Mimecast if lower-tier SKUs or custom add-on combinations are available to mitigate the 30% cost increase. 07/05 2 Manuel Z Assist in configueration and provide feedback on Add-on patch cables and any issues with new shipments. 07/05

Summary

This weekly sync between SHI and United Heritage Credit Union (UHCU) covered multiple ongoing operational and procurement topics. Brent Harris (UHCU) and Stephen Crane (UHCU) discussed with David Atkinson (SHI) and Manuel Zelaya (SHI) the status of several open items, including a Dell quote (~$20K), Dell and third-party patch cable shipments, a Mimecast license renewal and upgrade (with significant cost increase), Smart Net renewal options, and the Wi-Fi Statement of Work (SOW). The team clarified the reasons for the Mimecast cost jump (retirement of 365 Protect, move to Advanced Protection Cloud Gateway), reviewed the impact of cable brand changes, discussed SOW documentation, and coordinated next steps for portal access, quote delivery, and cable tracking.

Agenda

Review status of Dell hardware and related quotes Update on patch cable orders and shipment/brand changes Mimecast licensing renewal: cost changes, SKU changes, and options Smart Net renewal options and potential savings Wi-Fi SOW review and confirmation of correct version Portal access for Stewart and team Open questions and next steps

Review status of Dell hardware and related quotes Update on patch cable orders and shipment/brand changes Mimecast licensing renewal: cost changes, SKU changes, and options Smart Net renewal options and potential savings Wi-Fi SOW review and confirmation of correct version Portal access for Stewart and team Open questions and next steps

Opps Identified & BANTC

Opportunity 1: Mimecast License Renewal/Upgrade

B (Budget): Last year’s spend was $65K; current renewal is $84K (approx. 30% increase). Significant cost sensitivity. A (Authority): Brent Harris and Stephen Crane are primary UHCU decision-makers for this procurement. N (Need): Email security with features previously provided by Mimecast 365 Protect and add-ons (privacy, secure messaging, archive tools). Seeking equivalent protection at best possible cost. T (Timeline): Renewal cycle in process; urgency due to upcoming expiration and cost increase. C (Competition): Mimecast is incumbent, but cost increase may prompt review of alternatives or lower-tier options.

B (Budget): Last year’s spend was $65K; current renewal is $84K (approx. 30% increase). Significant cost sensitivity. A (Authority): Brent Harris and Stephen Crane are primary UHCU decision-makers for this procurement. N (Need): Email security with features previously provided by Mimecast 365 Protect and add-ons (privacy, secure messaging, archive tools). Seeking equivalent protection at best possible cost. T (Timeline): Renewal cycle in process; urgency due to upcoming expiration and cost increase. C (Competition): Mimecast is incumbent, but cost increase may prompt review of alternatives or lower-tier options.
Opportunity 2: Smart Net Renewal (Cisco Support)

B (Budget): Potential $4K–$10K savings for early renewal or moving to “CX” package. A (Authority): Brent Harris is lead; Rachel (SHI) provides quotes. N (Need): Continued Cisco hardware support (Smart Net); evaluating options to reduce spend. T (Timeline): Early renewal window (by end of July) for maximum savings. C (Competition): Standard Cisco channel; evaluation between early/standard/CX options.

B (Budget): Potential $4K–$10K savings for early renewal or moving to “CX” package. A (Authority): Brent Harris is lead; Rachel (SHI) provides quotes. N (Need): Continued Cisco hardware support (Smart Net); evaluating options to reduce spend. T (Timeline): Early renewal window (by end of July) for maximum savings. C (Competition): Standard Cisco channel; evaluation between early/standard/CX options.
Opportunity 3: Dell Hardware & Patch Cable
Procurement

B (Budget): $20K Dell quote under review; patch cables (various brands) are a small but urgent operational spend. A (Authority): Brent Harris is buyer; David Atkinson managing orders. N (Need): Hardware expansion/refresh and patch cable fulfillment for ongoing projects. T (Timeline): Immediate operational needs. C (Competition): Dell direct and other cable vendors (Monoprice, Add-on, Cables to Go).

B (Budget): $20K Dell quote under review; patch cables (various brands) are a small but urgent operational spend. A (Authority): Brent Harris is buyer; David Atkinson managing orders. N (Need): Hardware expansion/refresh and patch cable fulfillment for ongoing projects. T (Timeline): Immediate operational needs. C (Competition): Dell direct and other cable vendors (Monoprice, Add-on, Cables to Go).

Initiatives

Storage/Infrastructure: Dell hardware (server/storage expansion), patch cables (networking) Security: Mimecast licensing renewal (email security) Network: Cisco Smart Net renewal (support), Wi-Fi SOW (network upgrade/expansion)

Storage/Infrastructure: Dell hardware (server/storage expansion), patch cables (networking) Security: Mimecast licensing renewal (email security) Network: Cisco Smart Net renewal (support), Wi-Fi SOW (network upgrade/expansion)

Tech Profile Updates

Email Security: Mimecast, moving from 365 Protect + add-ons to Advanced Protection Cloud Gateway (includes privacy pack, secure messaging, archive tools). Network: Cisco hardware with Smart Net support, Wi-Fi upgrade SOW in progress. Cabling: Traditionally used Monoprice/Cables to Go; recent shipments are “Add-on” brand, being evaluated for suitability. Dell Infrastructure: $20K quote pending review. Portal: SHI portal in use for order management; Stewart to be (re)set up with access. SOW: Wi-Fi SOW version dated April 23rd is the latest.

Email Security: Mimecast, moving from 365 Protect + add-ons to Advanced Protection Cloud Gateway (includes privacy pack, secure messaging, archive tools). Network: Cisco hardware with Smart Net support, Wi-Fi upgrade SOW in progress. Cabling: Traditionally used Monoprice/Cables to Go; recent shipments are “Add-on” brand, being evaluated for suitability. Dell Infrastructure: $20K quote pending review. Portal: SHI portal in use for order management; Stewart to be (re)set up with access. SOW: Wi-Fi SOW version dated April 23rd is the latest.

Meeting Notes

Environment

UHCU is actively managing multiple infrastructure, procurement, and security projects. Brent and team are hands-on with both hardware and licensing renewals. SHI is coordinating closely, providing quoting, order tracking, and technical guidance.

UHCU is actively managing multiple infrastructure, procurement, and security projects. Brent and team are hands-on with both hardware and licensing renewals. SHI is coordinating closely, providing quoting, order tracking, and technical guidance.

Detailed Discussion

Dell quote (~$20K) under review for approval. Patch cables: Only blue 35’ cables received so far; all are “Add-on” brand, which differs from previous suppliers. Thicker insulation; may offer

Technical Notes

Mimecast licensing has transitioned from “365 Protect” (+ privacy pack, archive, secure messaging add-ons) to “Advanced Protection Cloud Gateway” (bundled). 30% cost increase on Mimecast due to SKU and support changes; SHI to verify possibility of lower-cost alternatives. Only blue Add-on brand patch cables have arrived; others pending. Add-on brand is thicker, may be higher quality. Smart Net renewal: Early option (before end of July) saves $4K; “CX” package (details TBD) could save $10K. Wi-Fi SOW (April 23rd) is current; includes port counts and technical requirements. Dell hardware quote and cable order management ongoing. SHI portal: needs to be updated for Stewart’s access.

Mimecast licensing has transitioned from “365 Protect” (+ privacy pack, archive, secure messaging add-ons) to “Advanced Protection Cloud Gateway” (bundled). 30% cost increase on Mimecast due to SKU and support changes; SHI to verify possibility of lower-cost alternatives. Only blue Add-on brand patch cables have arrived; others pending. Add-on brand is thicker, may be higher quality. Smart Net renewal: Early option (before end of July) saves $4K; “CX” package (details TBD) could save $10K. Wi-Fi SOW (April 23rd) is current; includes port counts and technical requirements. Dell hardware quote and cable order management ongoing. SHI portal: needs to be updated for Stewart’s access. List all speakers/Participants of Transcript:

David Atkinson (SHI) Brent Harris [UHCU] Stephen Crane (UHCU) Manuel Zelaya (SHI) Rachel (SHI, referenced) Stewart (UHCU, referenced)

David Atkinson (SHI) Brent Harris [UHCU] Stephen Crane (UHCU) Manuel Zelaya (SHI) Rachel (SHI, referenced) Stewart (UHCU, referenced)

Potential Next steps

Mimecast Licensing Alternatives

Mimecast Licensing Alternatives

David Atkinson to confirm with Mimecast if lower-tier SKUs or custom add-on combinations are available to mitigate the 30% cost increase. Action: David Atkinson → Mimecast/UHCU (Brent, Stephen)

David Atkinson to confirm with Mimecast if lower-tier SKUs or custom add-on combinations are available to mitigate the 30% cost increase. Action: David Atkinson → Mimecast/UHCU (Brent, Stephen)

Smart Net Renewal Options

Smart Net Renewal Options

Rachel (SHI) to send Smart Net renewal quotes, including early renewal and CX options, to Brent. Brent to review and decide on preferred renewal path. Action: Rachel/David Atkinson → Brent Harris

Rachel (SHI) to send Smart Net renewal quotes, including early renewal and CX options, to Brent. Brent to review and decide on preferred renewal path. Action: Rachel/David Atkinson → Brent Harris

Dell Hardware & Patch Cable Fulfillment

Dell Hardware & Patch Cable Fulfillment

Brent to review $20K Dell quote for next steps. David to track down status of all patch cable orders (especially non-blue/white cables). Brent/Stephen to trial Add-on brand cables and provide feedback; David to coordinate returns if necessary. Action: David Atkinson → Brent Harris/Stephen Crane

Brent to review $20K Dell quote for next steps. David to track down status of all patch cable orders (especially non-blue/white cables). Brent/Stephen to trial Add-on brand cables and provide feedback; David to coordinate returns if necessary. Action: David Atkinson → Brent Harris/Stephen Crane

Portal Access for Stewart

Portal Access for Stewart

David to re-send portal token to Stewart for SHI order management. Action: David Atkinson → Stewart

David to re-send portal token to Stewart for SHI order management. Action: David Atkinson → Stewart

Wi-Fi SOW Review

Wi-Fi SOW Review

Brent to review April 23rd SOW and confirm if any changes are needed; David to support as required. Action: Brent Harris → David Atkinson

Brent to review April 23rd SOW and confirm if any changes are needed; David to support as required. Action: Brent Harris → David Atkinson

General Quote & Order Management

General Quote & Order Management

David to forward all final quotes (Mimecast, Smart Net, Dell) to Brent and Stephen. Action: David Atkinson → Brent Harris/Stephen Crane

David to forward all final quotes (Mimecast, Smart Net, Dell) to Brent and Stephen. Action: David Atkinson → Brent Harris/Stephen Crane

Follow-up/Feedback

Follow-up/Feedback

Brent/Stephen to provide feedback on Add-on patch cables and any issues with new shipments. Action: Brent Harris/Stephen Crane → David Atkinson

Brent/Stephen to provide feedback on Add-on patch cables and any issues with new shipments. Action: Brent Harris/Stephen Crane → David Atkinson
