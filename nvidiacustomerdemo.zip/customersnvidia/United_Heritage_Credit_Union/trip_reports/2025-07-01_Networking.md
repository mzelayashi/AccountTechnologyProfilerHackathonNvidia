Trip Report | Networking | United Heritage Credit Union

Customer: United Heritage Credit Union
AE: David Atkinson
Topic: Networking
Meeting Date 07/01/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

David A

Send finalized list of third-party networking parts (from fs.com) for pricing and compatibility checks.

07/08

2

Manuel Z

Be involved in upcoming server strategy discussions; request consultative session if deeper cloud/on-prem analysis is needed.

07/08

Item Owner Next Steps/Detail Due Date 1 David A Send finalized list of third-party networking parts (from fs.com) for pricing and compatibility checks. 07/08 2 Manuel Z Be involved in upcoming server strategy discussions; request consultative session if deeper cloud/on-prem analysis is needed. 07/08

Summary

This weekly sync between SHI and United Heritage Credit Union (UHCU) focused on several ongoing procurement and technical support initiatives, spanning networking hardware, device peripherals, and security solutions. The primary business aspects discussed included cost control for Cisco and Dell parts (with a preference for third-party options due to budget constraints), order and shipment status updates for ClickShare devices, UPS battery kits, and signature pads, as well as clarification requests regarding Mimecast security bundles. There was also a strategic discussion about the future of on-premises servers versus possible cloud transitions, balancing cost with uptime. The need for comprehensive documentation, improved quoting (especially for security products), and escalation for Dell support quotes were also highlighted. Agenda: • Review outstanding orders and procurement issues
• Discuss Cisco/Dell hardware and third-party
components
• Address recent price increases and SHI’s ability to
match prior pricing
• Mimecast security bundle clarification and
documentation needs
• Update on server strategy (on-prem vs. cloud)
• Status of Dell networking support quote
• Open forum for additional questions and next steps

Opps Identified & BANTC

Opportunity 1: Cisco/Dell Networking Hardware Procurement (Cost-Control & Third-Party Parts)

B: UHCU
has a budget constraint, requiring cost-effective solutions for networking upgrades.
A: Brent
Harris and Stephen Crane are key decision-makers for IT procurement.
N: Immediate;
parts are required to complete infrastructure projects, with urgency due to high cost of OEM fiber optics.
T: Short-term
(weeks); procurement needs to be finalized before Brent leaves his role.
C: Consideration
between OEM and third-party parts, with some need to verify compatibility with Dell.

B: UHCU
has a budget constraint, requiring cost-effective solutions for networking upgrades.
A: Brent
Harris and Stephen Crane are key decision-makers for IT procurement.
N: Immediate;
parts are required to complete infrastructure projects, with urgency due to high cost of OEM fiber optics.
T: Short-term
(weeks); procurement needs to be finalized before Brent leaves his role.
C: Consideration
between OEM and third-party parts, with some need to verify compatibility with Dell. Opportunity 2: ClickShare Device Procurement (Price Matching)

B: Need
to purchase additional units at previously quoted prices due to unexpected price increases.
A: Stephen
Crane is overseeing AV device procurement.
N: Immediate;
two more units required.
T: This
week; order to be placed as soon as pricing is confirmed.
C: Vendor
flexibility to match prior pricing critical for closing the transaction.

B: Need
to purchase additional units at previously quoted prices due to unexpected price increases.
A: Stephen
Crane is overseeing AV device procurement.
N: Immediate;
two more units required.
T: This
week; order to be placed as soon as pricing is confirmed.
C: Vendor
flexibility to match prior pricing critical for closing the transaction. Opportunity 3: Mimecast Security Bundle Clarity/Upgrade

B: Security
upgrades require clear documentation and justification to proceed, possibly with new features (AI/Advanced BEC).
A: Brent
Harris and Stephen Crane are evaluating the value of additional Mimecast features.
N: Short-term;
decision pending documentation and clarification.
T: Within
the next cycle; decision required for budget allocation and renewal.
C: Need
for clear, comparative documentation and marketing materials; concerns about overlap with existing features.

B: Security
upgrades require clear documentation and justification to proceed, possibly with new features (AI/Advanced BEC).
A: Brent
Harris and Stephen Crane are evaluating the value of additional Mimecast features.
N: Short-term;
decision pending documentation and clarification.
T: Within
the next cycle; decision required for budget allocation and renewal.
C: Need
for clear, comparative documentation and marketing materials; concerns about overlap with existing features. Opportunity 4: Server Strategy Consultation (Cloud vs. On-Prem)

B: UHCU
is considering cost-cutting by reducing or eliminating on-prem servers, but concerned about uptime.
A: Brent
Harris and Stephen Crane are IT leads; may need executive input.
N: Medium-term;
currently in evaluation phase.
T: Decision
likely within the next quarter.
C: Requires
strategic consultation and ROI analysis; SHI may offer advisory services.

B: UHCU
is considering cost-cutting by reducing or eliminating on-prem servers, but concerned about uptime.
A: Brent
Harris and Stephen Crane are IT leads; may need executive input.
N: Medium-term;
currently in evaluation phase.
T: Decision
likely within the next quarter.
C: Requires
strategic consultation and ROI analysis; SHI may offer advisory services.

Initiatives

Networking & Hardware Procurement: Storage (Cisco/Dell switches, servers, cables) Security: Mimecast bundle clarification and upgrade End-User Devices: AV (ClickShare), UPS batteries, signature pads Strategic Consulting: Cloud vs. on-prem server assessment

Networking & Hardware Procurement: Storage (Cisco/Dell switches, servers, cables) Security: Mimecast bundle clarification and upgrade End-User Devices: AV (ClickShare), UPS batteries, signature pads Strategic Consulting: Cloud vs. on-prem server assessment

Tech Profile Updates

Increased use of third-party components (fs.com) for cost control Ongoing reliance on Dell for core server/storage needs, but open to alternatives Active Mimecast deployment with potential for advanced features (AI/BEC) Use of ClickShare, Topaz signature pads, and desktop scanners in operations Transitioning device support and maintenance responsibilities (potential personnel changes)

Increased use of third-party components (fs.com) for cost control Ongoing reliance on Dell for core server/storage needs, but open to alternatives Active Mimecast deployment with potential for advanced features (AI/BEC) Use of ClickShare, Topaz signature pads, and desktop scanners in operations Transitioning device support and maintenance responsibilities (potential personnel changes)

Meeting Notes

Environment

Hybrid infrastructure: mix of on-prem servers, Dell/Cisco networking, and SaaS

security (Mimecast)

Cost sensitivity is driving decisions toward third-party hardware components Procurement, shipping, and order status are closely tracked; rapid response to price changes required

Security

posture is evolving, with interest in AI-enhanced protection and advanced bundles Ongoing internal discussion about moving away from on-prem servers for cost reasons

Hybrid infrastructure: mix of on-prem servers, Dell/Cisco networking, and SaaS

security (Mimecast)

Cost sensitivity is driving decisions toward third-party hardware components Procurement, shipping, and order status are closely tracked; rapid response to price changes required

Security

posture is evolving, with interest in AI-enhanced protection and advanced bundles Ongoing internal discussion about moving away from on-prem servers for cost reasons

Detailed Discussion

Brent is finalizing a list of third-party networking components required to keep costs in check; SHI to assist with pricing and compatibility checks. Stephen experienced a $200+ per-unit price increase on ClickShare devices; SHI is working to match last week’s pricing for an additional order. UPS battery kits, signature pads, and most cabling have arrived; one order for Dell cables was canceled and confirmed. Mimecast bundle upgrades require better documentation; questions about what is “new” versus existing features. Discussion about the “Advanced BEC” feature (AI/impersonation attack prevention); SHI to provide marketing slicks or side-by-side charts. Internal debate at UHCU about continuing with on-prem servers vs. moving to cloud; SHI offers consultative support for this transition. Outstanding Dell support quote for networking (PowerStore) is delayed due to vendor-side confusion; SHI to escalate.

Brent is finalizing a list of third-party networking components required to keep costs in check; SHI to assist with pricing and compatibility checks. Stephen experienced a $200+ per-unit price increase on ClickShare devices; SHI is working to match last week’s pricing for an additional order. UPS battery kits, signature pads, and most cabling have arrived; one order for Dell cables was canceled and confirmed. Mimecast bundle upgrades require better documentation; questions about what is “new” versus existing features. Discussion about the “Advanced BEC” feature (AI/impersonation attack prevention); SHI to provide marketing slicks or side-by-side charts. Internal debate at UHCU about continuing with on-prem servers vs. moving to cloud; SHI offers consultative support for this transition. Outstanding Dell support quote for networking (PowerStore) is delayed due to vendor-side confusion; SHI to escalate.

Technical Notes

FS.com third-party optics/cabling to be vetted for Dell compatibility ClickShare model and SKU need to match previous orders for price matching UPS battery kit for Southwest location shipped; delivery confirmed 5ft orange Cat 6A cable is still outstanding (on order list) Mimecast “Advanced BEC” leverages AI for impersonation attack protection Mimecast bundle comparison: “Critical” bundle lacks secure message encryption, privacy pack, and continuity vs. current Need for side-by-side documentation on Mimecast bundles for decision-making Ongoing requirement for Dell support on PowerStore and networking switches; SHI to coordinate with Dell teams Server infrastructure is under review; potential reduction in on-premise servers, considering risk to uptime

FS.com third-party optics/cabling to be vetted for Dell compatibility ClickShare model and SKU need to match previous orders for price matching UPS battery kit for Southwest location shipped; delivery confirmed 5ft orange Cat 6A cable is still outstanding (on order list) Mimecast “Advanced BEC” leverages AI for impersonation attack protection Mimecast bundle comparison: “Critical” bundle lacks secure message encryption, privacy pack, and continuity vs. current Need for side-by-side documentation on Mimecast bundles for decision-making Ongoing requirement for Dell support on PowerStore and networking switches; SHI to coordinate with Dell teams Server infrastructure is under review; potential reduction in on-premise servers, considering risk to uptime List all speakers/Participants of Transcript:

David Atkinson (SHI) Brent Harris (United Heritage Credit Union - UHCU) Stephen Crane (United Heritage Credit Union - UHCU) Stuart (mentioned, to be included in future meetings) Patrick (SHI/Dell - mentioned for quote escalation) Manuel Zelaya (SHI)

David Atkinson (SHI) Brent Harris (United Heritage Credit Union - UHCU) Stephen Crane (United Heritage Credit Union - UHCU) Stuart (mentioned, to be included in future meetings) Patrick (SHI/Dell - mentioned for quote escalation) Manuel Zelaya (SHI)

Potential Next steps

Brent Harris → David Atkinson: Send finalized list of third-party networking parts (from fs.com) for pricing and compatibility checks. David Atkinson → Stephen Crane: Work internally at SHI to match last week’s ClickShare pricing and send updated quote for two additional units. David Atkinson → Brent Harris/Stephen Crane: Provide documentation, side-by-side charts, or marketing slicks on Mimecast bundles, especially focusing on Advanced BEC and feature differences. Brent Harris → David Atkinson: Forward inquiry on Dell support for networking/PowerStore to help SHI escalate and resolve the quoting issue. David Atkinson → Patrick (SHI/Dell): Call Patrick to resolve the delay on Dell support quotes for networking switches. Brent Harris/Stephen Crane → David Atkinson: Keep SHI informed of server strategy discussions; request consultative session if deeper cloud/on-prem analysis is needed. Stephen Crane → Group: Add Stuart to future weekly meetings for broader IT input. David Atkinson → Brent Harris/Stephen Crane: Remain available for rapid response on any new procurement, support, or documentation needs via email/phone.

Brent Harris → David Atkinson: Send finalized list of third-party networking parts (from fs.com) for pricing and compatibility checks. David Atkinson → Stephen Crane: Work internally at SHI to match last week’s ClickShare pricing and send updated quote for two additional units. David Atkinson → Brent Harris/Stephen Crane: Provide documentation, side-by-side charts, or marketing slicks on Mimecast bundles, especially focusing on Advanced BEC and feature differences. Brent Harris → David Atkinson: Forward inquiry on Dell support for networking/PowerStore to help SHI escalate and resolve the quoting issue. David Atkinson → Patrick (SHI/Dell): Call Patrick to resolve the delay on Dell support quotes for networking switches. Brent Harris/Stephen Crane → David Atkinson: Keep SHI informed of server strategy discussions; request consultative session if deeper cloud/on-prem analysis is needed. Stephen Crane → Group: Add Stuart to future weekly meetings for broader IT input. David Atkinson → Brent Harris/Stephen Crane: Remain available for rapid response on any new procurement, support, or documentation needs via email/phone.
