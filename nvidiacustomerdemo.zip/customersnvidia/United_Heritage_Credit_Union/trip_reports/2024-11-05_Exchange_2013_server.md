Trip Report | Exchange 2013 server | United Heritage Credit Union

Customer: United Heritage Credit Union
AE: David A
Topic: Exchange 2013 server
Meeting Date 11/05/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Brent H

review SMTP logs at UHCU.

11/15/24

2

David A

expedite the review and signature process upon document receipt.

11/15/24

Item Owner Next Steps/Detail Due Date 1 Brent H review SMTP logs at UHCU. 11/15/24 2 David A expedite the review and signature process upon document receipt. 11/15/24

Summary

The meeting focused on the decommissioning of United Heritage Credit Union's (UHCU) Exchange 2013 server. The primary goal was to ensure the transition is completed smoothly and within the timeline set for the end of the year. Key participants included representatives from UHCU, Kizan, and SHI. Discussions involved technical considerations such as checking SMTP logs, enabling verbose logging, and potential uninstallation issues. The team also explored industry trends, particularly the shift towards hybrid or cloud solutions for Exchange servers. Deadlines were emphasized, with specific actions assigned to ensure timely project completion. Technical Notes:

Verbose logging recommended for all connectors. ADSI Edit may be necessary for server removal if uninstallation fails. The Exchange server is virtual, simplifying recovery operations.

Verbose logging recommended for all connectors. ADSI Edit may be necessary for server removal if uninstallation fails. The Exchange server is virtual, simplifying recovery operations.

Agenda

Introduction and context of Exchange 2013 decommissioning. Discussion of technical steps and considerations. Timeline and deadlines for project completion. Future plans and industry trends regarding Exchange servers. Assignment of next steps and actions.

Introduction and context of Exchange 2013 decommissioning. Discussion of technical steps and considerations. Timeline and deadlines for project completion. Future plans and industry trends regarding Exchange servers. Assignment of next steps and actions.

Opportunities

Identified & BANTC:

Opportunity: Decommissioning of Exchange 2013

Opportunity: Decommissioning of Exchange 2013

B (): Not explicitly discussed, but implied need for resources to ensure a quick transition. A (): Brent Harris as IT Manager at UHCU is the decision-maker. N (): Urgent need to transition off Exchange 2013 due to internal deadlines and technology shifts. T (): Completion required by the end of 2024, ideally before Thanksgiving. C (): No direct competitors discussed, but internal resource allocation might be a factor.

B (): Not explicitly discussed, but implied need for resources to ensure a quick transition. A (): Brent Harris as IT Manager at UHCU is the decision-maker. N (): Urgent need to transition off Exchange 2013 due to internal deadlines and technology shifts. T (): Completion required by the end of 2024, ideally before Thanksgiving. C (): No direct competitors discussed, but internal resource allocation might be a factor. Tech Profile Updates:

Implementation of verbose logging on SMTP connectors. Consideration of ADSI Edit for potential uninstallation issues. Current Exchange server is virtual, with bare metal and Active Directory backups in place.

Implementation of verbose logging on SMTP connectors. Consideration of ADSI Edit for potential uninstallation issues. Current Exchange server is virtual, with bare metal and Active Directory backups in place. Meeting Notes:

Environment

UHCU has one Exchange 2013 server. The server is virtual, aiding potential recovery processes.

UHCU has one Exchange 2013 server. The server is virtual, aiding potential recovery processes. Detailed Discussion:

Technical Considerations: Emphasis on checking SMTP logs and enabling verbose logging to ensure a seamless decommissioning process. Potential Issues: Uninstallation might require ADSI Edit if traditional methods fail. Recovery Plans: Bare metal and AD backups are available.

Technical Considerations: Emphasis on checking SMTP logs and enabling verbose logging to ensure a seamless decommissioning process. Potential Issues: Uninstallation might require ADSI Edit if traditional methods fail. Recovery Plans: Bare metal and AD backups are available. List of Speakers/Participants:

Brent Harris, IT Manager – UHCU Brett Mullens, Sr. Network Administrator – UHCU Elizabeth Flower, Partner Sales Associate – Kizan Eric Ross, Principal Consultant – Kizan Manuel Zelaya, Solutions Engineer – SHI David Atkinson, Commercial Inside Account Executive – SHI

Brent Harris, IT Manager – UHCU Brett Mullens, Sr. Network Administrator – UHCU Elizabeth Flower, Partner Sales Associate – Kizan Eric Ross, Principal Consultant – Kizan Manuel Zelaya, Solutions Engineer – SHI David Atkinson, Commercial Inside Account Executive – SHI
