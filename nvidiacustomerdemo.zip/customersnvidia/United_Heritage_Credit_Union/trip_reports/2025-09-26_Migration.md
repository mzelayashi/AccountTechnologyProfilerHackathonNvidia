Trip Report | Migration | United Heritage Credit Union

Customer: United Heritage Credit Union
AE: David A
Topic: Migration
Meeting Date 09/26/2025

*Internal notes – Please read and edit before sending externally*

Summary

Summary

• The meeting focused on UHCU’s migration from
unsupported perpetual license appliances to Rocky Linux, with a need for professional services to assist in the transition, particularly around user/data migration and administrative settings.
• Subscription licensing was discussed as a future
consideration, with benefits such as unlimited environments, enterprise clustering, and access to future innovations like containerization.
• The current environment is a classic cluster, not
enterprise, handling critical ACH file transfers for member payments.
• The team agreed to proceed with a professional
services quote for 50 hours to support the migration and configuration, with further education sessions planned to explore subscription licensing options for next year’s budget.
• The meeting included vendor, customer, and
professional services representatives, with clear next steps and ownership for follow-up actions.

Agenda

• Introductions and participant locations/roles
• Review of migration requirements from perpetual
license appliances to Rocky Linux
• Discussion of professional services scope and
options
• Exploration of subscription licensing benefits and
future roadmap
• Agreement on immediate next steps and future
education sessions

Opps Identified & BANTC

Opportunity 1: Migration Professional
Services for SecureTransport
• B: UHCU needs to migrate from unsupported perpetual
license appliances to Rocky Linux, requiring assistance with user/data migration and administrative settings.
• A: Brett, Gordon, and David (UHCU/SHI) are
authorized to proceed with a professional services quote.
• N: Migration is required before mid-July next year
due to appliance end-of-life; critical for daily ACH file transfers.
• T: Timeline is immediate for migration planning,
with professional services engagement to begin soon.
• C: Decision to purchase a 50-hour bucket of
professional services, quote to be delivered via SHI.
Opportunity 2: Subscription Licensing
Migration
• B: UHCU is considering moving from perpetual to
subscription licensing for future scalability, clustering, and innovation access.
• A: Brett and UHCU leadership are open to evaluating
subscription licensing, pending further education and budget review.
• N: Not immediate; targeted for next year’s budget
cycle.
• T: Education sessions to be scheduled, with decision
likely next year.
• C: No commitment yet; information gathering and
budgetary planning underway.

Initiatives

• Migration to Rocky Linux (Storage, Security)
• Evaluation of subscription licensing and enterprise
clustering (Security, Storage)
• Containerization beta access (Security, Storage)

Tech Profile Updates

• Current environment: SUSE Linux VMs, classic cluster
(2 edges, 2 cores in production; 1 edge, 1 core in DR)
• Migration target: Rocky Linux
• File transfer type: ACH files for member payments
• No significant customizations; some external file
operations via Opcon agents
• Considering future use of Axway SecureTransport as a
managed file transfer solution

Meeting Notes

Environment

• Production: 2 edges, 2 cores (classic cluster)
• DR: 1 edge, 1 core (not clustered)
• OS: SUSE Linux (current), moving to Rocky Linux
• Usage: 10–20 accounts, mostly standard setup

Detailed Discussion

• Brett and Gordon described the need to migrate from
unsupported appliances, with a focus on ensuring user/data migration and administrative settings are handled correctly.
• Joel and Jim explained the technical process for
migration, noting that user accounts and workflows can be exported/imported, but system settings require manual transfer.
• Ryan introduced the benefits of subscription
licensing, including unlimited environments, enterprise clustering, and future access to containerization, but acknowledged the cost implications.
• Brett expressed interest in learning more about
subscription licensing for future planning, but confirmed the immediate need is migration support.
• Agreement reached to proceed with a 50-hour
professional services engagement, with SHI to deliver the quote.

Technical Notes

• Migration from SUSE Linux appliances to Rocky Linux
is feasible, with minimal issues expected for user/data migration.
• Administrative/system settings must be manually
transferred; tools exist to identify non-default changes.
• No significant internal customizations; external
file operations managed via Opcon agents.
• Classic cluster setup, not enterprise; SQL Server
clustering not in use.
• SecureTransport handles critical ACH file transfers;
outages can be managed manually but are disruptive.
• Subscription licensing would allow for unlimited
environments and future innovations (containerization, enterprise clustering).
• Containerization is in beta, with general
availability expected soon; subscription customers will have access.

ROLES

• Ryan Mangini – Account Executive, Axway (Vendor)
• Brett Mullins – UHCU (Customer, voice)
• Joel Bauman – Services Account Director, Axway
(Vendor)
• Gordon Rainwater – UHCU (Customer)
• David Atkinson – SHI, UHCU’s main account rep
(Reseller/Partner)
• Jim Vickroy – Axway, Professional Services (Vendor)
• Manuel Zelaya – SHI, Solutions Engineer
(Reseller/Partner)

Potential Next steps

• Joel to provide a 50-hour professional services
quote to David for UHCU’s migration support (Joel → David, Brett, Gordon)
• David to coordinate scheduling and delivery of the
professional services engagement (David → UHCU team, Joel)
