Trip Report | Node Expansion | United Heritage Credit Union

Customer: United Heritage Credit Union
AE: David A
Topic: Node Expansion
Meeting Date 01/26/2026

*Internal notes – Please read and edit before sending externally*

Summary

This call centered on reviewing a node expansion proposal for UHCU’s existing Cohesity/UCS environment. The customer (UHCU) sought confirmation that the newly quoted hardware nodes would be compatible with their current Cisco UCS C220-based clusters. Cohesity (vendor) validated that the recommended nodes were architecturally aligned and fully compatible in both homogeneous and heterogeneous cluster configurations. During the discussion, UHCU shared that an internal project—beginning immediately—would reclaim approximately 4 TB of data by deleting Cohesity backups. This significantly lowers the urgency to purchase new hardware in the short term. They expect to reassess capacity needs within a month and revisit expansion ahead of next year’s cluster end-of-life cycle. UHCU anticipates rising industry hardware costs but acknowledged Cohesity’s price increases were considerably lower compared to other OEMs (5–20% vs. 30–60%). Additional long-term planning considerations included budgeting cycles (due in October), potential refresh timelines, and proactively obtaining quotes for FY planning. Business themes included: capacity planning, lifecycle refresh, cost changes, compatibility validation, reduction of immediate expansion urgency, and alignment on re‑evaluation timelines.

Agenda

• Review node
expansion quote
• Validate
technical compatibility with UHCU’s existing UCS clusters
• Determine
urgency level for procurement
• Discuss pricing
trends and refresh planning
• Establish
follow-up timelines

Opportunities Identified & BANTC

Opportunity 1: Planned Hardware Refresh (Next Year)
B – Budget: Budget cycle occurs in October;
planning and procurement expected late summer.
A – Authority: Brett (UHCU) owns capacity
decisions and procurement recommendations.
N – Need: Existing UCS clusters expected to
reach end-of-life next year; expansion or refresh required.
T – Timeline: Refresh planning begins late
summer; formal budget submission October; hardware needed next year.
C – Competition: Cisco comparative model may be
reviewed; Cohesity currently favored due to compatibility and lower price increases.
Opportunity 2: Potential Node Expansion Revisited in
~1 Month
B – Budget: No immediate spend; depends on
results of internal data reduction project.
A – Authority: Brett leads evaluation; vendor
partners (Cohesity/SHI) support.
N – Need: Capacity relief required depending on
results of data deletion project.
T – Timeline: Project starts tomorrow;
reassessment within one month.
C – Competition: None explicitly mentioned;
internal project may eliminate short‑term need.

Initiatives

• Storage: Node expansion assessment, data
reduction project, capacity relief.
• Storage: Full hardware refresh planning for
next year (due to cluster EOL).

Tech Profile Updates

• Existing
clusters based on Cisco UCS C220, likely 24 TB models.
• Cohesity nodes
quoted are compatible for mixed/homogeneous cluster deployment.
• Planned hybrid
configuration includes both flash and hard drives.
• Anticipated
industry-wide hardware price increases affecting SSDs and key components.

Meeting Notes

• Cohesity
confirmed the quoted nodes are fully compatible with UHCU’s environment.
• UHCU has
initiated an internal project expected to reclaim at least 4 TB in the near term.
• This reduces
immediate expansion urgency but does not eliminate long-term refresh needs.
• Industry
hardware pricing volatility was acknowledged; Cohesity increases are significantly lower.
• UHCU expects to
revisit the quote after assessing data reduction results.
• Budgeting
begins late summer with formal submission in October.

Environment

• Existing
infrastructure: Cisco UCS C220 (24 TB models inferred).
• Cohesity
integrated storage clusters in production.
• Backup
workloads reside on Cohesity platform.
• Internal
project focuses on data deletion to reclaim storage capacity.

Detailed Discussion

• Bretts main
question: whether the quoted nodes would integrate seamlessly with current clusters.
• Jamey
(Cohesity) reviewed internal documentation and confirmed that the quoted nodes are a one‑for‑one match in capabilities, supporting mix-and-match cluster setups.
• Ciscos design
consistency supports hardware interchangeability, easing expansion.
• UHCU’s
immediate expansion need has dropped due to an upcoming internal cleanup project beginning the next day.
• If cleanup
provides the expected capacity relief, UHCU may delay expansion but will revisit when needed.
• Cohesity warned
that hardware and memory pricing across the industry may rise significantly.
• UHCU
acknowledged they've already seen large jumps with other vendors and appreciated Cohesity’s lower increases.
• Long‑term plan:
UHCU anticipates replacing current clusters next year due to lifecycle/EOL.
• Chris
(Cohesity) agreed to follow up in 2–3 weeks to ensure the customer’s project is progressing and determine if expansion discussions should resume.
• Budget planning
timelines were confirmed (October submission).

Technical Notes

• Existing nodes:
Cisco UCS C220 series servers, likely 24 TB configurations.
• Cohesity sizing
methodology supports both homogeneous and heterogeneous nodes within the cluster.
• Compatibility
confirmed at processor, storage capacity, and architectural alignment levels.
• Quoted
configuration includes hybrid storage layout (flash + HDD).
• Price increase
specifics:
– Cohesity: 5–20%
depending on component
– Other
vendors/OEMs: 30–35%+, some SSD increases reported up to 60%
• Internal
project will delete Cohesity backup data to free up ~4 TB.
• Cluster
end-of-life anticipated next year, prompting a future refresh cycle. ROLES: Speakers / Participants Brett Mullins – Customer (UHCU) David Atkinson – SHI Chris H – Cohesity Jamey Rush – Cohesity Manuel Zelaya – SHI / Commercial Solutions Engineer

Potential Next Steps

• Follow‑Up Coordination (Chris to Brett & team):
Chris will send a follow-up note in 2–3 weeks to check progress on UHCU’s data reduction project and determine whether node expansion needs to be revisited. Participants: Chris, Brett, UHCU team.
• Budget Planning Support (Cohesity/SHI to UHCU):
When UHCU begins FY planning toward the end of summer, SHI/Cohesity will prepare refresh quotes aligned with October budget deadlines. Participants: Brett, Chris, David, SHI account team.
• Future Refresh Project (Brett to Vendors):
As clusters approach end-of-life next year, UHCU will engage both SHI and Cohesity to begin formal refresh scoping. Participants: Brett, David, Cohesity team.
• Data Cleanup Project (UHCU Internal):
Brett will assess reclaimed capacity once the internal deletion project starts, then notify the vendor teams if capacity relief is sufficient or if expansion discussions need to resume. Participants: Brett (internal), then communication to SHI/Cohesity.
