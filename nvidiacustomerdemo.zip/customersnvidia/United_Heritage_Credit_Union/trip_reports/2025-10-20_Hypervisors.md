Trip Report | Hypervisors | United Heritage Credit Union

Customer: United Heritage Credit Union
AE: David A
Topic: Hypervisors
Meeting Date 10/20/2025

*Internal notes – Please read and edit before sending externally*

Summary

Summary

• The meeting focused on ongoing technology renewals,
vendor quote processes, and coordination among team members to support end-user technology needs. David and Stuart discussed the status of various renewal quotes, particularly for Smart Net and VMware, and the challenges with vendor timelines due to fiscal year constraints. Health-related personal updates were shared, impacting attendance and participation. The group addressed the need to ensure all relevant stakeholders are included in weekly syncs to streamline communication and decision-making. No new technical deployments or major incidents were reported, but there was emphasis on proactive follow-up with vendors and internal teams to avoid delays.

Agenda

• Review of renewal list and pending quotes
• Status update on Smart Net and VMware renewals
• Discussion of team member availability and meeting
scheduling
• Consideration of adding Alan to weekly syncs
• Follow-up actions for outstanding quotes and demo
coordination

Opps Identified & BANTC

• Opportunity 1: VMware Renewal
• B: Renewal of VMware licensing for continued

infrastructure support

• A: David is responsible for obtaining the quote from
Broadcom
• N: Required for ongoing operations; cannot proceed
without updated quote
• T: Timing dependent on Broadcom’s fiscal year; quote
available after fiscal year end
• C: Contingent on Broadcom’s internal processes and
timely response
• Opportunity 2: Smart Net Renewal
• B: Renewal of Smart Net support contract
• A: David to decide between two quotes after pending
demo
• N: Needed to maintain support coverage; decision
required by end of month
• T: Dependent on completion of demo scheduled for
this week
• C: Dependent on demo outcome and internal approval

Initiatives

• Storage: Smart Net renewal (support contract for
infrastructure)
• Security: No explicit security initiatives discussed

Tech Profile Updates

• No new technology deployments or changes reported
• Pending updates on VMware and Smart Net renewals
• Dell quote request in progress, awaiting
confirmation on build

Meeting Notes

• David and Stuart discussed the status of renewal
quotes and vendor responses
• Steven was absent; his input on Dell quote is
pending
• Alan’s inclusion in weekly syncs was considered to
improve communication
• Personal health updates affected attendance and
participation

Environment

• The team is managing technology renewals and vendor
coordination for infrastructure support
• Communication is primarily through scheduled weekly
syncs and email threads
• No major incidents or outages reported

Detailed Discussion

• David provided updates on the renewal list,
highlighting Smart Net as the immediate priority and VMware as pending due to vendor constraints
• Stuart inquired about the status of the VMware quote
and suggested adding Alan to the meeting invites
• The group acknowledged ongoing challenges with
vendor timelines, particularly with Broadcom’s fiscal year restrictions
• Coordination with Brett and Alan was discussed to
ensure all stakeholders are informed and involved

Technical Notes

• VMware renewal quote cannot be obtained until after
Broadcom’s fiscal year ends; David has requested the quote and is following up
• Smart Net renewal decision is pending a demo
scheduled for this week; two quotes are available for selection
• Dell quote request is in progress; confirmation on
the correct build is needed from Steven
• No new technical configurations or deployments were
discussed

ROLES

• David Atkinson – Vendor representative managing
renewals and quotes

Potential Next steps

• David to follow up with Broadcom for VMware renewal
quote after fiscal year end (David to Broadcom)
• David to decide between Smart Net quotes after demo
completion (David to Stuart)
• Steven to confirm correct Dell build for quote
(Steven to David, pending Steven’s return)
• David to follow up with Brett and Alan on
outstanding items (David to Brett and Alan)
• David to add Alan to weekly sync invites (David to
Stuart and Alan)
