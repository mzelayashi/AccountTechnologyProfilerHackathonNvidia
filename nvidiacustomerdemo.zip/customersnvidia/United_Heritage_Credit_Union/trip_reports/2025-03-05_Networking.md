Trip Report | Networking | United Heritage Credit Union

Customer: United Heritage Credit Union
AE: David A
Topic: Networking
Meeting Date 03/05/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

David A

David to obtain quotes from Dell team.

03/25

2

David A

David to confirm the status of the Cohesity subscription.

03/25

3

Manuel Z

Discuss on call with SHI and Cisco to verify hardware capabilities.

03/25

Item Owner Next Steps/Detail Due Date 1 David A David to obtain quotes from Dell team. 03/25 2 David A David to confirm the status of the Cohesity subscription. 03/25 3 Manuel Z Discuss on call with SHI and Cisco to verify hardware capabilities. 03/25

Summary

The conversation was primarily focused on discussing the renewal synchronization for March and upcoming months for various technology products and services. The participants include representatives from UHCU and SHI, with a focus on addressing technical questions and renewal timelines. Key topics included the renewal of Cisco Flex, Delinia secret server, Dell SAMs, and potential upgrades related to Cisco hardware. The discussion also touched on the need to verify that upgrades and changes meet technical requirements before implementation, specifically around Cisco's Nexus and 9500 switches. Additionally, there was a mention of a Cohesity subscription that seemingly expired, which needed follow-up. A quarterly kickoff meeting was proposed to be scheduled in person, enhancing collaboration.

Agenda

Review of renewal timeline and priorities Discussion of pending quotes Technical questions and clarifications Scheduling the next quarterly kickoff meeting

Review of renewal timeline and priorities Discussion of pending quotes Technical questions and clarifications Scheduling the next quarterly kickoff meeting

Opportunities Identified & BANTC

Cisco Flex Renewal:

Cisco Flex Renewal:

B: Cisco
Flex renewal discussions indicate an ongoing need.
A: Brent
Harris confirmed the entry into the grace period.
N: Renewal
is necessary to maintain service continuity.
T: March
timeline for finalizing the quote, with delays noted.
C: Haley,
the SHI contact, is working on finalizing the quote.

B: Cisco
Flex renewal discussions indicate an ongoing need.
A: Brent
Harris confirmed the entry into the grace period.
N: Renewal
is necessary to maintain service continuity.
T: March
timeline for finalizing the quote, with delays noted.
C: Haley,
the SHI contact, is working on finalizing the quote.

Dell SAMs and Switches:

Dell SAMs and Switches:

B: Upcoming
renewal for Dell SAMs and switches.
A: Brent
Harris mentioned potential renewals in May and October.
N: Required
to maintain operational infrastructure.
T: Quotes
needed, with Brent providing relevant PO numbers.
C: David
to reach out to the Dell team for quotes.

B: Upcoming
renewal for Dell SAMs and switches.
A: Brent
Harris mentioned potential renewals in May and October.
N: Required
to maintain operational infrastructure.
T: Quotes
needed, with Brent providing relevant PO numbers.
C: David
to reach out to the Dell team for quotes.

Cisco Nexus and 9500 Switch Refresh:

Cisco Nexus and 9500 Switch Refresh:

B: Need
for switch refresh due to nearing capacity.
A: Brent
Harris outlined the need for capacity management.
N: Necessary
to support network demands and future growth.
T: Discussion
around verifying functionality before purchase.
C: Coordination
with SHI and Cisco for verification and planning.

B: Need
for switch refresh due to nearing capacity.
A: Brent
Harris outlined the need for capacity management.
N: Necessary
to support network demands and future growth.
T: Discussion
around verifying functionality before purchase.
C: Coordination
with SHI and Cisco for verification and planning.

Initiatives

Security

& Storage: Cohesity subscription renewal and verification. Network Infrastructure: Cisco Nexus and 9500 switch updates.

Security

& Storage: Cohesity subscription renewal and verification. Network Infrastructure: Cisco Nexus and 9500 switch updates.

Tech Profile Updates

Cisco Nexus and 9500 switches are under evaluation for refresh and capacity management. Wi-Fi 6 and 7 considerations for future upgrades.

Cisco Nexus and 9500 switches are under evaluation for refresh and capacity management. Wi-Fi 6 and 7 considerations for future upgrades.

Meeting Notes

Environment

Virtual meeting with multiple participants discussing technology renewals and upgrades.

Virtual meeting with multiple participants discussing technology renewals and upgrades.

Detailed Discussion

Renewal Timeline: Discussed current and upcoming renewals, including Cisco Flex, Delinia secret server, and Dell SAMs. Technical Clarifications: Manuel Zelaya asked about Wi-Fi 6 and 7 relevance for new hardware and data center initiatives. Verification Needs: Brent Harris expressed the need for verification before purchasing enhanced licenses for Cisco switches. Scheduling Meetings: Discussed scheduling the next quarterly kickoff meeting in person in April.

Renewal Timeline: Discussed current and upcoming renewals, including Cisco Flex, Delinia secret server, and Dell SAMs. Technical Clarifications: Manuel Zelaya asked about Wi-Fi 6 and 7 relevance for new hardware and data center initiatives. Verification Needs: Brent Harris expressed the need for verification before purchasing enhanced licenses for Cisco switches. Scheduling Meetings: Discussed scheduling the next quarterly kickoff meeting in person in April.

Technical Notes

Cisco Flex renewal is in the grace period; awaiting the final quote. Dell SAMs and switches renewal due in May and October; PO numbers provided. Cisco Nexus and 9500 switches require verification for enhanced licenses. Cohesity subscription renewal is under review due to an expiration notice.

Cisco Flex renewal is in the grace period; awaiting the final quote. Dell SAMs and switches renewal due in May and October; PO numbers provided. Cisco Nexus and 9500 switches require verification for enhanced licenses. Cohesity subscription renewal is under review due to an expiration notice. List all speakers/Participants of Transcript:

David Atkinson Manuel Zelaya (MZ) Brent Harris [UHCU] (BH) Stephen Crane (SC)

David Atkinson Manuel Zelaya (MZ) Brent Harris [UHCU] (BH) Stephen Crane (SC)

Potential Next Steps

Finalize Cisco Flex Renewal:

Finalize Cisco Flex Renewal:

Action: Haley to provide the final quote. Involved: David Atkinson, Haley.

Action: Haley to provide the final quote. Involved: David Atkinson, Haley.

Dell SAMs and Switches Quotes:

Dell SAMs and Switches Quotes:

Action:

Action:

Involved: David Atkinson, Brent Harris. Cisco Hardware Verification:

Involved: David Atkinson, Brent Harris. Cisco Hardware Verification:

Action: Schedule a call with SHI and Cisco to verify hardware capabilities. Involved: David Atkinson, Manuel Zelaya, Brent Harris, Cisco/SHI team.

Action: Schedule a call with SHI and Cisco to verify hardware capabilities. Involved: David Atkinson, Manuel Zelaya, Brent Harris, Cisco/SHI team.

Cohesity Subscription Follow-up:

Cohesity Subscription Follow-up:

Action: David to confirm the status of the Cohesity subscription. Involved: David Atkinson, Brent Harris.

Action: David to confirm the status of the Cohesity subscription. Involved: David Atkinson, Brent Harris.

Schedule Quarterly Kickoff Meeting:

Schedule Quarterly Kickoff Meeting:

Action: Stephen Crane to provide potential dates; David to send invites. Involved: Stephen Crane, David Atkinson, Brent Harris, Nathan, Sturt.

Action: Stephen Crane to provide potential dates; David to send invites. Involved: Stephen Crane, David Atkinson, Brent Harris, Nathan, Sturt.
