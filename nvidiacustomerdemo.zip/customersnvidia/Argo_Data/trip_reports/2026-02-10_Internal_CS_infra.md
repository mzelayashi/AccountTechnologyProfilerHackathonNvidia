Trip Report | Internal CS infra | Argo Data

Customer: Argo Data
AE: Felix M
Topic: Internal CS infra
Meeting Date 02/10/2026

*Internal notes – Please read and edit before sending externally*

Summary

This call was a technical and business discovery discussion between SHI and Argo Data focused on improving Argo’s internal customer-support access architecture. Argo is a software development organization that provides support to its customers by remotely accessing customer environments through jump boxes. The current design relies on Oracle VirtualBox to allow multiple support engineers to view the same active customer session, but this architecture has become operationally inefficient, overly complex, and difficult to manage. The primary business challenge is eliminating unnecessary layers in the remote-access workflow while preserving the ability for multiple support representatives to simultaneously view or collaborate within the same session. Argo is seeking a cleaner, more secure, on‑prem solution that improves usability without introducing excessive cost or complexity, while still aligning with customer-mandated access constraints such as Citrix and VPN tunnels. From a commercial standpoint, SHI is positioned as a solution architect and advisor, responsible for validating licensing, identifying viable technologies, and proposing a future-state architecture. The call also surfaced opportunities around secure remote access tooling, potential VDI alternatives, and optional environment documentation services. The discussion concluded with clear next steps for SHI to engage internal virtualization expertise and return with solution options.

Agenda

• Review existing
server software and licensing considerations
• Walkthrough of
current remote-access architecture
• Identify pain
points with Oracle VirtualBox and session-sharing
• Explore
alternative multi-session access solutions
• Confirm
technical and security requirements
• Define next
steps and follow-up actions

Opportunities Identified & BANTC

Opportunity 1: Multi-Session Remote Access /
Virtualization Solution B (Budget):
• Not explicitly
stated
• Budget
sensitivity implied, particularly around traditional VDI being perceived as expensive A (Authority):
• Steve Dodds
appears to be the technical decision-maker and primary project owner
• SHI acting in
advisory and solution design role N (Need):
• Replace Oracle
VirtualBox used solely for session sharing
• Enable multiple
users to view or control the same active session
• Reduce
architectural complexity and operational overhead
• Maintain
secure, controlled access to on‑prem jump boxes T (Timeline):
• Short-term
evaluation underway
• SHI to return
with options by the following Wednesday C (Competition):
• NetSupport
Manager already evaluated
• No other
vendors formally ruled out
• General concern
around cost and complexity of VDI solutions
Opportunity 2: Architecture Documentation / Topology
Diagram Service B (Budget):
• Complimentary
offering from SHI A (Authority):
• Steve Dodds
expressed interest N (Need):
• Clear, editable
documentation of current and future-state environments
• Support
internal planning and stakeholder communication T (Timeline):
• Follow-up
information to be sent post-call C (Competition):
• None identified

Initiatives

• Security: Secure access to jump boxes,
controlled authentication, prevention of unauthorized scanning or discovery
• Infrastructure / Virtualization: Session
sharing, remote access architecture, potential VDI or alternative tooling

Tech Profile Updates

• Argo is a
Nutanix customer
• VMware
licensing clarification in progress
• FMC (Firewall
Management Center) license already owned
• Environment is
predominantly Windows-based
• Remote access
constrained by customer-controlled connectivity methods (Citrix, VPN, tunnels)

Meeting Notes

• Current
workflow involves multiple RDP hops creating inefficiency
• Oracle
VirtualBox enables multi-user session viewing but is a weak link
• Support

Environment

• On‑prem Argo
jump boxes (Windows)
• Customer
servers accessed through tunnels or Citrix
• Oracle
VirtualBox hosting VMs for session sharing
• Multiple
support engineers accessing same session concurrently

Detailed Discussion

Steve walked through a Visio diagram explaining the existing architecture, highlighting how support engineers must RDP into a VirtualBox VM, then into an Argo jump box, and finally into customer systems. This design allows session sharing but introduces unnecessary hops and management overhead. Manuel confirmed understanding of the technical requirement and clarified that Argo cannot change anything on the customer side—only the method of connecting into Argo’s jump boxes. Steve explained that NetSupport Manager was tested because it installs an agent and allows centralized session control, but the solution was not ideal.

Security concerns

were emphasized, particularly the need to prevent unauthorized discovery of remote access services. Steve stressed the importance of requiring authenticated clients and avoiding tools that can be easily scanned and exploited. Manuel proposed leveraging SHI’s internal virtualization expertise to identify alternative approaches and offered SHI’s topology diagram service to help document the environment. Steve expressed interest in receiving more information on that deliverable.

Technical Notes

• Oracle
VirtualBox currently used for multi-user session visibility
• Multiple users
logged into the same Windows session
• RDP used
extensively between components
• NetSupport
Manager evaluated: agent-based, centralized server, master password authentication
• Concern about
VDI cost and complexity
• Preference for
on‑prem deployment
• Jump boxes are
Windows-based
• Customers
require access through Citrix or VPN tunnels
• FMC license
already owned, may remove need for additional licensing
• Nutanix

environment impacts VMware SKU considerations

Roles (Participants)

Steve Dodds Role: IT /

Infrastructure Lead

Company: Argo Data Manuel Zelaya Role: Commercial Solutions Engineer Company: SHI Felix Menchaca Role: Account / Solutions Representative Company: SHI

Potential Next Steps

• Felix Menchaca → Steve Dodds

Confirm VMware SKU requirements in Nutanix environment Validate FMC licensing and adjust quote accordingly

Confirm VMware SKU requirements in Nutanix environment Validate FMC licensing and adjust quote accordingly
• Manuel Zelaya → Steve Dodds

Engage SHI internal virtualization expert Evaluate alternative multi-session access technologies Return with architectural options by next Wednesday

Engage SHI internal virtualization expert Evaluate alternative multi-session access technologies Return with architectural options by next Wednesday
• Felix Menchaca → Steve Dodds

Send information on SHI topology diagram deliverable

Send information on SHI topology diagram deliverable
• SHI Internal Team

Review intake requirements for diagram service Align on potential solution paths before follow-up meeting

Review intake requirements for diagram service Align on potential solution paths before follow-up meeting
