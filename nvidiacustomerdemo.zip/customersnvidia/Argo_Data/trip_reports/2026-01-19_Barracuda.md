Trip Report | Barracuda | Argo Data

Customer: Argo Data
AE: Felix
Topic: Barracuda
Meeting Date 01/19/2026

*Internal notes – Please read and edit before sending externally*

Summary

• The call
focused on reviewing Argo Data’s current Barracuda legacy email‑security and archiving bundle, evaluating options to modernize into Barracuda’s Advanced, Premium, or Premium Plus licensing tiers, and understanding how these solutions align with Argo’s needs around email protection, threat detection, archiving, backup, and user training.
• Barracuda
(Jason & Selby) presented major enhancements available in newer bundles including impersonation protection, incident response, AI‑powered threat detection, BEC protection, account takeover prevention, mailbox‑level filtering, post‑delivery remediation, and continuous scanning.
• SHI (Felix)
provided account context, managed logistics, validated customer requirements, and highlighted overlapping tools (notably Sophos Phish Threat licensed through 2031, reducing need for Barracuda training features).
• Argo Data (Tim
& Steve) assessed whether the new Barracuda features justify cost changes vs. their current environment and whether additional components (backup, security awareness training, remediation features) provide business value or duplicate existing solutions.
• The discussion
expanded to managed print (Xerox vs. Kyocera) and HPE maintenance renewal processing—items relevant to SHI’s broader support model for Argo’s infrastructure.
• Next steps
hinge on Barracuda delivering final pricing for the Advanced and Premium bundles so Argo can evaluate their path forward.

Agenda

• Review current
Barracuda legacy email‑security subscription
• Present new
Barracuda licensing tiers: Advanced, Premium, Premium Plus
• Evaluate
security awareness training, filtering upgrades, and archiving requirements
• Discuss backup
capabilities for M365 (OneDrive, SharePoint, Teams, Exchange, Entra ID)
• Understand
customer pain points, budget, and overall needs
• Review managed
print update (Xerox vs. Kyocera)
• Confirm renewal
timelines and pricing extension needs

Opps Identified & BANTC

Opportunity 1 – Modernizing Email Security to
Barracuda Advanced Initiative Type: Security
B – Budget:
Argo emphasizes cost as the determining factor; awaiting pricing from Barracuda.
A – Authority:
Decision makers: Tim and Steve from Argo. SHI (Felix) assists as trusted advisor.
N – Need:
Current setup

Initiatives

• Security: Email filtering enhancements,
impersonation protection, incident response, AI threat detection, BEC protection, account takeover monitoring, QR code detection, continuous tenant scanning.
• Storage: Cloud archiving, cloud‑to‑cloud backup
of M365 services.
• Other: Print fleet refresh; HPE maintenance
renewals.

Tech Profile Updates

• Microsoft 365
tenant with Exchange Online
• Barracuda EGD +
Cloud Archiving legacy bundle
• Sophos Phish
Threat licensed until 2031
• Existing M365
backup solution
• Kyocera
printers with board failures; evaluating Xerox
• Barracuda
filtering currently limited to MX‑level only

Meeting Notes

• Current
Barracuda configuration considered outdated; improved filtering recommended.
• Cloud archiving
remains a key element in deciding between bundles.
• Sophos Phish
Threat is still active, reducing need for Barracuda’s Premium Plus features.
• Customer’s
primary limiting factor: pricing.
• Xerox is viewed
as more reliable than Kyocera (post‑repair success noted).
• HPE maintenance
renewals being updated and processed by SHI.

Environment

• Microsoft 365
cloud environment
• Barracuda-based
email filtering (legacy)
• Sophosbased

security awareness training

• Active M365
cloud backup solution
• Mixed print

environment transitioning away from Kyocera

Detailed Discussion

• Legacy
Barracuda bundles tied to older pricing models; newer bundles offer more value and better protection.
• Advanced bundle
enhances filtering with mailbox-level and post‑delivery layers in addition to MX-level.
• Security
awareness training in Premium Plus considered unnecessary since Sophos licensing continues through 2031.
• Cloud archiving
is essential due to historical compliance requirements and gaps in Microsoft retention capabilities.
• Barracuda’s
Incident Response can automatically remove threats from user mailboxes after delivery.
• Premium adds
broad M365 backup capability including user/group metadata in Entra ID.
• File-share
remediation discussed as email-based recovery mechanism for accidental or improper file sending.
• Print
discussion: Kyocera failures traced to faulty boards replaced on two units; Xerox deemed more reliable.

Technical Notes

• Archiving: The Barracuda message archiver
historically stored all inbound/outbound mail independently of litigation hold.
• Litigation Hold vs Archiver: Litigation hold
must be applied mailbox-by-mailbox and increases search complexity; archiver provides easier e‑discovery.
• Filtering Layers: Advanced adds three
additional layers: mailbox filtering, AI‑powered threat detection, and post‑delivery scanning.
• Threat Remediation: Automatic removal of
malicious emails from user mailboxes.
• Backup: Premium provides point‑in‑time recovery
across M365 applications including accidental file deletion and data retrieval from departed users.
• Email Continuity: EGD allows reading/sending
even during Microsoft outages.
• Security Awareness Training: Monthly content
updates by Barracuda; Sophos content considered outdated.
• Printer Technical Insight: Kyocera board
replacement fixed long‑standing issues, but reliability still viewed as questionable. Participants (Roles Only)
• Tim Tebo – Customer, Argo Data
• Steve Dodds – Customer, Argo Data
• Felix Menchaca – SHI, Account/Solutions
Representative
• Jason Vicknair – Barracuda, Sales / Licensing
• Selby Philipose – Barracuda, Sales Engineer /
Technical Specialist
• Matt Sakamoto – Barracuda, Renewals
Representative (referenced)
• Unknown Speaker – Barracuda internal
participant

Potential Next Steps

• Jason → Felix + Argo:
– Finalize &
send quotes for Advanced and Premium bundles.
– Include
300-license count.
• Jason → Tim:
– Requested Tim
call him directly once quotes are received to walk through pricing and requirements.
• Felix → Argo:
– Send licensing
comparison screenshot/diagram.
– Provide Xerox
quote for printing refresh.
– Proceed with
HPE maintenance renewals; notify customer when orders appear.
• Argo (Tim & Steve) → SHI/Barracuda:
– Review quotes
and decide between Advanced vs Premium.
– Confirm whether
Sophos training is sufficient and whether Barracuda training should be omitted.
• Optional In‑Person Follow‑Up:
– Jason &
Selby offered meeting at local restaurant near Custer/121 to continue discussions informally.
