Trip Report | Cisco Discussion | Argo Data

Customer: Argo Data
AE: Felix M
Topic: Cisco Discussion
Meeting Date 02/18/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Felix M

coordinate with Hannah Ennis to explore Cisco EA options.

2

Felix M

Schedule a follow-up meeting to discuss findings and finalize decision-making on upgrades and EAs.

Item Owner Next Steps/Detail Due Date 1 Felix M coordinate with Hannah Ennis to explore Cisco EA options. 2 Felix M Schedule a follow-up meeting to discuss findings and finalize decision-making on upgrades and EAs.

Summary

Summary

The meeting was primarily focused on evaluating Cisco's security solutions for Argo, specifically concerning DDoS protection capabilities within their existing infrastructure. Joel Rodea and Antonio Serrano III from Cisco met with Tim Tebo, Steve Dodds, and Stephen Drake from Argo to discuss potential upgrades and solutions. Argo is looking for manageable DDoS protection that doesn't require extensive oversight. They have an FTD 1140 but are exploring the capabilities of larger models like the 4100 and 9300 series. It was emphasized that the solution should be cost-effective and fit seamlessly into Argo's current network environment, which includes VPNs, remote access, and F5 reverse proxy systems. Stephen Drake suggested evaluating Cisco's enterprise agreements for long-term savings. The meeting concluded with action items for further research and documentation sharing.

Agenda

Introductions and roles Current Cisco infrastructure and challenges at Argo Discussion on DDoS protection capabilities in Cisco's FTD series Evaluation of higher-end models for future-proofing Enterprise agreements and potential cost savings Next steps and action items

Introductions and roles Current Cisco infrastructure and challenges at Argo Discussion on DDoS protection capabilities in Cisco's FTD series Evaluation of higher-end models for future-proofing Enterprise agreements and potential cost savings Next steps and action items

Opportunities Identified & BANTC

Upgrade to Advanced DDoS Protection:

Upgrade to Advanced DDoS Protection:

B: Argo's
need to protect against DDoS attacks, especially for their ADMS department.
A: Steve
Dodds, with support from Tim Tebo, is in charge of evaluating and implementing network security solutions.
N: Current
FTD 1140 lacks explicit DDoS capabilities; potential need for a more robust solution.
T: Immediate,
as they need to ensure continuous protection and support.
C: Cost-effective
solutions that integrate with existing infrastructure without significant additional expenses.

B: Argo's
need to protect against DDoS attacks, especially for their ADMS department.
A: Steve
Dodds, with support from Tim Tebo, is in charge of evaluating and implementing network security solutions.
N: Current
FTD 1140 lacks explicit DDoS capabilities; potential need for a more robust solution.
T: Immediate,
as they need to ensure continuous protection and support.
C: Cost-effective
solutions that integrate with existing infrastructure without significant additional expenses.

Evaluation of Cisco Enterprise Agreements:

Evaluation of Cisco Enterprise Agreements:

B: Potential
for long-term savings and streamlined management of Cisco products.
A: Stephen
Drake to engage with Cisco’s EA team, led by Hannah Ennis.
N: Upcoming
Cisco purchases and renewals make this a timely discussion.
T: Before
current contracts expire to maximize savings.
C: Evaluate
if EAs provide financial and operational benefits over standalone purchases.

B: Potential
for long-term savings and streamlined management of Cisco products.
A: Stephen
Drake to engage with Cisco’s EA team, led by Hannah Ennis.
N: Upcoming
Cisco purchases and renewals make this a timely discussion.
T: Before
current contracts expire to maximize savings.
C: Evaluate
if EAs provide financial and operational benefits over standalone purchases.

Initiatives

Security: Focus on enhancing DDoS protection capabilities. Cost Management: Exploring enterprise agreements for budget optimization.

Security: Focus on enhancing DDoS protection capabilities. Cost Management: Exploring enterprise agreements for budget optimization.

Tech Profile Updates

Current use of Cisco FTD 1140. Evaluation of potential upgrade to 4100 or 9300 series. Existing infrastructure includes VPNs, remote access, and F5 reverse proxy.

Current use of Cisco FTD 1140. Evaluation of potential upgrade to 4100 or 9300 series. Existing infrastructure includes VPNs, remote access, and F5 reverse proxy.

Meeting Notes

Environment

Argo's network environment is predominantly on-premises with crucial remote access components. Key concern is maintaining uninterrupted service to customer-facing departments.

Argo's network environment is predominantly on-premises with crucial remote access components. Key concern is maintaining uninterrupted service to customer-facing departments.

Detailed Discussion

DDoS Protection: Current FTD 1140 has limited capabilities; exploring options like the 4100 and 9300 series. Throughput Needs: Discussion about throughput requirements with respect to cloud expansion. Enterprise Agreements: Potential for better pricing and value through Cisco's EAs.

DDoS Protection: Current FTD 1140 has limited capabilities; exploring options like the 4100 and 9300 series. Throughput Needs: Discussion about throughput requirements with respect to cloud expansion. Enterprise Agreements: Potential for better pricing and value through Cisco's EAs.

Technical Notes

Cisco FTD 1140: Current model in use, lacks explicit DDoS protection features. Potential Upgrades: 4100 and 9300 series offer more robust solutions, especially for data centers. Integration Concerns: Need to ensure any new solution fits seamlessly with existing VPN, MFA (Duo), and reverse proxy systems.

Cisco FTD 1140: Current model in use, lacks explicit DDoS protection features. Potential Upgrades: 4100 and 9300 series offer more robust solutions, especially for data centers. Integration Concerns: Need to ensure any new solution fits seamlessly with existing VPN, MFA (Duo), and reverse proxy systems. List of Speakers/Participants of Transcript:

Joel Rodea (Cisco) Antonio Serrano III (Cisco) Tim Tebo (Argo) Steve Dodds (Argo) Stephen Drake (Argo) Felix Menchaca (Cisco) Tre' Black - Presley (Cisco)

Joel Rodea (Cisco) Antonio Serrano III (Cisco) Tim Tebo (Argo) Steve Dodds (Argo) Stephen Drake (Argo) Felix Menchaca (Cisco) Tre' Black - Presley (Cisco)

Potential Next Steps

Documentation Sharing:

Documentation Sharing:

Joel Rodea to send FPR documentation detailing DDoS capabilities. Participants: Joel Rodea, Steve Dodds.

Joel Rodea to send FPR documentation detailing DDoS capabilities. Participants: Joel Rodea, Steve Dodds.

Enterprise Agreement Evaluation:

Enterprise Agreement Evaluation:

Stephen Drake to coordinate with Hannah Ennis to explore Cisco EA options. Participants: Stephen Drake, Hannah Ennis, Tim Tebo.

Stephen Drake to coordinate with Hannah Ennis to explore Cisco EA options. Participants: Stephen Drake, Hannah Ennis, Tim Tebo.

Technical Evaluation:

Technical Evaluation:

Steve Dodds to further research the differences between FTD models regarding DDoS capabilities. Participants: Steve Dodds, Joel Rodea.

Steve Dodds to further research the differences between FTD models regarding DDoS capabilities. Participants: Steve Dodds, Joel Rodea.

Follow-Up Meeting:

Follow-Up Meeting:

Schedule a follow-up meeting to discuss findings and finalize decision-making on upgrades and EAs. Participants: Tim Tebo, Steve Dodds, Stephen Drake, Joel Rodea, Antonio Serrano III.

Schedule a follow-up meeting to discuss findings and finalize decision-making on upgrades and EAs. Participants: Tim Tebo, Steve Dodds, Stephen Drake, Joel Rodea, Antonio Serrano III.
