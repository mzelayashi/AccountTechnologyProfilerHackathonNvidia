Trip Report | ScreenConnect | Argo Data

Customer: Argo Data
AE: Felix M
Topic: ScreenConnect
Meeting Date 04/08/2026

*Internal notes – Please read and edit before sending externally*

Summary

This meeting was a technical evaluation and product demonstration focused on ScreenConnect (a ConnectWise remote access solution) as a potential replacement for an existing, fragmented remote access model used by the customer’s operations team. The infrastructure systems using a layered “jump box on top of jump box” approach built on multiple VirtualBox virtual machines. This approach has resulted in operational complexity, sprawl, and an expanded footprint that the customer is actively trying to reduce. The primary business objective discussed was simplifying remote access while maintaining strong security controls, multi‑technician collaboration, and real‑time visibility into multiple systems. From a technology standpoint, the customer sought a centralized, secure, on‑premises remote access platform that could replace their VirtualBox-based environment and provide operational efficiency for approximately 13–15 internal users managing around nine servers. While ScreenConnect demonstrated strong capabilities around unattended access, security, auditing, backend administrative access (Backstage mode), and multi-user sessions, the solution ultimately did not meet a critical operational requirement: the ability to provide a true, continuously live multi-system dashboard view showing all server desktops simultaneously. This requirement is central to how the customer’s teams currently monitor customer environments. As a result, although ScreenConnect aligned well with most requirements, the inability to deliver a true live monitoring dashboard became a blocking issue. The meeting concluded with agreement to gather screenshots of the customer's existing monitoring view and explore whether alternative tools within or outside the ConnectWise ecosystem (including RMM products) could meet this requirement.

Agenda

• Understand the
customer’s existing remote access and monitoring architecture
• Review business
and technical drivers for replacing VirtualBox-based jump boxes
• Demonstrate
ScreenConnect on‑prem capabilities
• Validate
security, access control, and auditing requirements
• Assess live
monitoring and dashboard requirements
• Identify gaps,
risks, and next steps

Opportunities Identified & BANTC

Opportunity 1: Remote Access Platform Consolidation
(On‑Prem) B (Budget): Budget not explicitly confirmed. Customer is actively evaluating replacement solutions, indicating allocated or exploratory funding. A (Authority): Primary technical evaluation led by internal IT leadership. Final decision requires involvement of the department manager responsible for live monitoring operations. N (Need): Eliminate multiple VirtualBox VMs, reduce operational complexity, simplify access paths, maintain security, auditing, and multi-user collaboration. T (Timeline): Timeline not formally committed. Evaluation phase ongoing with urgency tied to operational inefficiencies. C (Challenges): Hard requirement for real-time multi-system monitoring dashboard not met by ScreenConnect.
Opportunity 2: Enhanced Live Monitoring / RMM
Evaluation B (Budget): Undetermined. Potential incremental or alternative tooling budget may be required. A (Authority): Department manager overseeing monitoring workflows is a required stakeholder. N (Need): Centralized, continuously live visual monitoring of multiple servers without manual refresh or session initiation. T (Timeline): Pending evaluation of alternatives after current solution gap identified. C (Challenges): Very limited vendor options known to provide true live dashboard monitoring at scale.

Initiatives

• Infrastructure
Management and Remote Operations
• Classification:
Storage / Operations (Non-Security Primary) with Security Considerations

Tech Profile Updates

• Current
environment uses VirtualBox virtual machines as intermediary access layers
• Agents remote

Meeting Notes

• Goal to
eliminate VirtualBox jump boxes
• Strong
requirement for high-security connectivity
• Need for
multi-user concurrent access to systems
• Desire for
simplified footprint and centralized access
• ScreenConnect
demonstrated unattended access agents, grouping, security, logging, and admin controls
• Critical live
dashboard requirement not met

Environment

• On‑premises

infrastructure

• Multiple
VirtualBox VMs acting as access intermediaries
• Central jump
infrastructure. Customer service agents log into VirtualBox VMs, which then

Technical Notes

• Approximately
13–15 concurrent users expected
• Around 9
servers requiring unattended access
• Requirement for
multi-user concurrent remote sessions
• On‑prem
deployment preferred over SaaS for control and granularity
• Ports 8040 and
8041 used for ScreenConnect on‑prem connectivity
• Ability to
fully restrict access to LAN if required
• Role-based
access and grouped permissions supported
• Backstage mode
allows system-level access separate from user console
• Supports
Windows, Mac, Linux agents
• Supports
multi-monitor environments
• No native
real-time multi-device dashboard
• Preview
functionality requires manual refresh
• Full audit
trail down to session events, commands, file transfers
• Optional
session video recording stored on‑prem
• No built-in RMM
functionality

ROLES (Participants)

Steve Dodds – IT / Operations Lead, Customer Organization Summer Kawa – Product Specialist, ScreenConnect (ConnectWise) Felix Menchaca – Solutions Engineer, SHI Kyle Cromwell – Technical Specialist, SHI Manuel Zelaya - Solution Engineer, -SHI

Potential Next Steps

• Steve Dodds to obtain screenshots of the
current live monitoring dashboard used by the operations team
• Steve Dodds → Felix Menchaca to share
screenshots for vendor comparison
• Felix Menchaca to work with internal resources
to evaluate alternative solutions capable of real-time dashboard monitoring
• Summer Kawa to escalate dashboard requirement
to ConnectWise engineering for feasibility review
• SHI team to assess RMM or alternative platforms
that may meet live monitoring needs
• Follow-up
internal and vendor discussions contingent on findings
