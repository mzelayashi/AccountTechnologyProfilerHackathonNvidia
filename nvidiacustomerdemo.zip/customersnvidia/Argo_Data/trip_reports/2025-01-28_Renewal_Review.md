Trip Report | Renewal Review | Argo Data

Customer: Argo Data
AE: Felix M
Topic: Renewal Review
Meeting Date 01/28/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Felix M

provide updated quotes with serial numbers included

02/20

2

Felix M

engagement with Cisco and Sophos for network upgrade discussions

02/20

Item Owner Next Steps/Detail Due Date 1 Felix M provide updated quotes with serial numbers included 02/20 2 Felix M engagement with Cisco and Sophos for network upgrade discussions 02/20

Summary

The conversation centered around the renewal review between SHI and Argo Data. There were discussions on maintenance renewals, server serial numbers, and coordination with various vendor representatives including HPE, Cisco, and Barracuda. The participants addressed issues around maintenance contract clarity and explored opportunities for network upgrades, especially concerning firewalls and switches. There were technical difficulties during the call which led to a decision to reschedule for a more comprehensive follow-up discussion. Multiple action items were identified, including the need for better alignment and communication on upcoming renewals and technical support.

Technical Notes

• Serial numbers to be included in maintenance renewal
quotes for clarity.
• Barracuda renewal structured on a per-user per-month
basis with discounts for longer terms.
• Cisco gear is
the standard for firewalls and switches; potential for refresh.

Agenda

• Discuss the
confusion and identification of specific server serial numbers tied to maintenance contracts.
• Review
maintenance renewal quotes and align renewal dates for easier management.
• Explore potential network upgrades and firewall
refreshes with Cisco gear.
• Address technical issues and plan for a rescheduled
meeting to cover all agenda items comprehensively.

Opps Identified & BANTC

Opportunity 1: Maintenance Contract Clarification
• B: Need to clarify which serial numbers are tied to
specific maintenance contracts.
• A: Felix
Menchaca to provide serial numbers in quotes.
• N: Ensures
clear understanding of maintenance coverage.
• T: Immediate,
prior to renewal deadlines.
• C:
Coordination with HPE and internal stakeholders.
Opportunity 2: Network Upgrades and Firewall Refresh
• B: Potential need for a firewall refresh and switch
upgrades.
• A: Tim Tebo
and Steve Dodds to assess current network infrastructure.
• N: Maintain network security and performance
• T: Some
upgrades needed sooner, others aligned with December timeline
• C:
Coordination with Cisco and potentially Sophos for firewall solutions. Initiatives: • Security: Firewall refresh and potential integration with Sophos MDR solutions. • Storage: None identified in this conversation.

Tech Profile Updates

• Current firewall: Cisco Firepower.
• Current
switches: Cisco.
• Upcoming
switch renewals and potential firewall refresh planned. Meeting Notes: Environment:
• Technical
difficulties experienced by Steve Dodds, impacting communication. • Multiple vendor reps involved for various maintenance renewals and support discussions.

Detailed Discussion

• Initial
confusion over server serial numbers tied to maintenance contracts.
• Felix
Menchaca to include serial numbers in future renewal quotes.
• Discussions with HPE Rep on aligning maintenance
renewal dates.
• Mention of Barracuda renewal and potential grace
period for renewal due to representative changes. • Need for firewall refresh and switch upgrades identified, with potential involvement of Sophos for

security solutions

• Agreement to reschedule the meeting for better
preparation and alignment. List all speakers/Participants of Transcript: • Stephen Drake • Tim Tebo • Felix Menchaca • Steve Dodds Potential Next steps: • Felix Menchaca to provide updated quotes with serial numbers included. (Action: Felix Menchaca) • Tim Tebo and Steve Dodds to review network infrastructure for potential upgrades. (Action: Tim Tebo, Steve Dodds) • Reschedule meeting for Thursday at 10:00 AM to review all items with full information available. (Action: Felix Menchaca, Tim Tebo, Stephen Drake) • Consider engagement with Cisco and Sophos for network upgrade discussions. (Action: Stephen Drake, Felix Menchaca) ) From <https://mindspark.shi.com/My_Apps>
