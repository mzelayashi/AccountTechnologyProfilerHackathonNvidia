Trip Report | Securioty | Argo Data

Customer: Argo Data
AE: Felix M
Topic: Securioty
Meeting Date 07/25/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Felix M

coordinate with Cisco to ensure processing before EOY shutdown.

08/15

2

M

o discuss with Tim if an AI briefing/workshop is desired; Felix/Manuel to coordinate

08/15

Item Owner Next Steps/Detail Due Date 1 Felix M coordinate with Cisco to ensure processing before EOY shutdown. 08/15 2 M o discuss with Tim if an AI briefing/workshop is desired; Felix/Manuel to coordinate 08/15

Summary

Renewals & Roadmap Review | SHI + Argo — Call Analysis

Summary

This session between SHI (Felix Menchaca, Manuel Zelaya) and Argo (Steve Dodds) focused on reviewing and aligning technology contract renewals for Cisco Duo, SmartNet, Nutanix, F5, and Microsoft. The conversation included operational steps to consolidate renewal dates, resolve Cisco licensing visibility issues, and discuss the potential for a Cisco Enterprise Agreement as Argo’s annual spend approaches the qualification threshold. Nutanix and F5 renewals are on track, with Argo not interested in upsells for Nutanix at this time. The team briefly discussed the SHI AI journey, SHI’s AI enablement offerings (including secure, private data lake solutions), and current cybersecurity market updates such as the Ingram Micro cyberattack, Sophos NDR integration, and a SharePoint zero-day vulnerability. The call concluded with clear next steps, a focus on avoiding renewal lapses, and maintaining operational resilience.

Agenda

Review upcoming renewals: Cisco Duo, SmartNet, Nutanix, F5, Microsoft Align/Consolidate SmartNet renewals; resolve license/visibility issues Discuss Cisco EA eligibility and value Nutanix renewal approach (no upsell interest) SHI’s AI practice and secure AI implementation Security/market updates: Ingram Micro, Sophos NDR, SharePoint zero-day Next steps/action items

Review upcoming renewals: Cisco Duo, SmartNet, Nutanix, F5, Microsoft Align/Consolidate SmartNet renewals; resolve license/visibility issues Discuss Cisco EA eligibility and value Nutanix renewal approach (no upsell interest) SHI’s AI practice and secure AI implementation Security/market updates: Ingram Micro, Sophos NDR, SharePoint zero-day Next steps/action items

Opps Identified & BANTC

Opportunity 1: Cisco Duo & SmartNet Renewals
(including Consolidation and EA Potential)

B: Current
Cisco spend ~$42K/yr, may exceed $50K with new projects; renewals are budgeted and required
A: Steve
Dodds is primary; SHI supports process and vendor engagement
N: Immediate;
Duo renewal due July 25, SmartNet August 7; risk of coverage lapse if not processed before Cisco EOY shutdown
T: Urgent;
PO for Duo needed by July 24 to ensure timely processing
C: Steve
Dodds, Felix Menchaca, Cisco Rep, SHI EA team

B: Current
Cisco spend ~$42K/yr, may exceed $50K with new projects; renewals are budgeted and required
A: Steve
Dodds is primary; SHI supports process and vendor engagement
N: Immediate;
Duo renewal due July 25, SmartNet August 7; risk of coverage lapse if not processed before Cisco EOY shutdown
T: Urgent;
PO for Duo needed by July 24 to ensure timely processing
C: Steve
Dodds, Felix Menchaca, Cisco Rep, SHI EA team
Opportunity 2: Nutanix Renewal

B: 192
cores; renewal scheduled for October 1; budgetary quote provided, refreshed quote pending
A: Steve
Dodds, Felix Menchaca, Nutanix Rep
N: October
1 renewal; no upsell/expansion currently desired
T: Short
term; final quote in progress
C: Steve
Dodds, Felix Menchaca, Nutanix Rep

B: 192
cores; renewal scheduled for October 1; budgetary quote provided, refreshed quote pending
A: Steve
Dodds, Felix Menchaca, Nutanix Rep
N: October
1 renewal; no upsell/expansion currently desired
T: Short
term; final quote in progress
C: Steve
Dodds, Felix Menchaca, Nutanix Rep
Opportunity 3: F5 Premium Support Renewal

B: Standard,
expected renewal; budgeted
A: Steve
Dodds, Felix Menchaca, F5 Rep
N: October
20 renewal; routine support renewal
T: Medium
term; quote requested ~90 days out
C: Steve
Dodds, Felix Menchaca, F5 Rep

B: Standard,
expected renewal; budgeted
A: Steve
Dodds, Felix Menchaca, F5 Rep
N: October
20 renewal; routine support renewal
T: Medium
term; quote requested ~90 days out
C: Steve
Dodds, Felix Menchaca, F5 Rep
Opportunity 4: Microsoft Renewal

B: Managed
via workbook; normal budget process
A: Steve
Dodds, Felix Menchaca, Tyler (MS Rep)
N: October
31 renewal; 14-day grace period
T: Short/Medium
term; workflow in place
C: Steve
Dodds, Felix Menchaca, Tyler

B: Managed
via workbook; normal budget process
A: Steve
Dodds, Felix Menchaca, Tyler (MS Rep)
N: October
31 renewal; 14-day grace period
T: Short/Medium
term; workflow in place
C: Steve
Dodds, Felix Menchaca, Tyler
Opportunity 5: SHI AI Briefings/Workshops & Secure
Data Lake Consultation

B: SHI-funded
workshops are free; potential for future paid project if interest is established
A: Steve
Dodds (IT), Tim (manager/decision maker), SHI AI team
N: Early
stage; no current AI projects, but C-suite pressure rising
T: Flexible;
will be determined by management interest
C: Tim
(Argo), Steve Dodds, Felix Menchaca, Manuel Zelaya

B: SHI-funded
workshops are free; potential for future paid project if interest is established
A: Steve
Dodds (IT), Tim (manager/decision maker), SHI AI team
N: Early
stage; no current AI projects, but C-suite pressure rising
T: Flexible;
will be determined by management interest
C: Tim
(Argo), Steve Dodds, Felix Menchaca, Manuel Zelaya
Opportunity 6: Sophos NDR Review

B: Interest
expressed; evaluation stage, no budget specifics
A: Steve
Dodds, Felix Menchaca, Sophos Rep
N: Not
urgent but on roadmap; NDR product now more robust with SecureWorks integration
T: Flexible/Discovery
C: Steve
Dodds, Felix Menchaca

B: Interest
expressed; evaluation stage, no budget specifics
A: Steve
Dodds, Felix Menchaca, Sophos Rep
N: Not
urgent but on roadmap; NDR product now more robust with SecureWorks integration
T: Flexible/Discovery
C: Steve
Dodds, Felix Menchaca

Initiatives

Security: Cisco Duo, SmartNet, F5, Microsoft renewals; Sophos NDR; SharePoint zero-day awareness; AI security/data residency Storage: Nutanix core renewal Both: AI enablement/readiness, Secure Data Lake (potential)

Security: Cisco Duo, SmartNet, F5, Microsoft renewals; Sophos NDR; SharePoint zero-day awareness; AI security/data residency Storage: Nutanix core renewal Both: AI enablement/readiness, Secure Data Lake (potential)

Tech Profile Updates

Cisco licensing and SmartNet up for renewal; exploring consolidation and EA eligibility Nutanix: 192 cores, October 1 renewal, no expansion or new products at this time Microsoft: Workbook process active; 14-day grace post-expiry F5: Premium support renewal, quote in progress Sophos: NDR with SecureWorks integration under consideration AI: Copilot licenses present but not in active use; SHI offers AI briefings and secure private AI solutions Hardware: HP servers in use; future consideration to move to Dell; Dell rep not yet engaged

Security

Monitoring for major vulnerabilities; proactive on SharePoint zero-day

Cisco licensing and SmartNet up for renewal; exploring consolidation and EA eligibility Nutanix: 192 cores, October 1 renewal, no expansion or new products at this time Microsoft: Workbook process active; 14-day grace post-expiry F5: Premium support renewal, quote in progress Sophos: NDR with SecureWorks integration under consideration AI: Copilot licenses present but not in active use; SHI offers AI briefings and secure private AI solutions Hardware: HP servers in use; future consideration to move to Dell; Dell rep not yet engaged

Security

Monitoring for major vulnerabilities; proactive on SharePoint zero-day

Meeting Notes

Environment

Argo IT led by Steve Dodds (Tim is manager, not present) Audit in progress, operational focus on renewals and compliance Renewals management and contract consolidation a priority SHI providing advisory and technical support, plus market intelligence

Argo IT led by Steve Dodds (Tim is manager, not present) Audit in progress, operational focus on renewals and compliance Renewals management and contract consolidation a priority SHI providing advisory and technical support, plus market intelligence

Detailed Discussion

Renewals: Cisco Duo (July 25), SmartNet (August 7), Nutanix (October 1), F5 (October 20), and Microsoft (October 31) discussed; all on track, with focus on consolidation and visibility. Cisco Licensing: Issue with firewall and switches not appearing; Steve to provide serials/screenshots. Felix to investigate with Cisco. Plan to use an LOA for SHI/Cisco audit and clarity. EA Eligibility: Argo close to $50K/year; if DDoS project pushes them above, will revisit EA for pricing and management benefits. Nutanix: 192 cores, renewal only, no collector/expansion at this time; future hardware may move from HP to Dell. AI/SHI’s Practice: SHI shared internal AI journey, offered free briefings/workshops, emphasized secure/private data lakes for regulated customers. Steve will refer to management (Tim) for next steps.

Security

Updates: Ingram Micro cyberattack, Sophos NDR (SecureWorks integration), and Microsoft SharePoint zero-day vulnerability discussed. OEM EOYs: July/September best for deals; August is slow for EOYs.

Renewals: Cisco Duo (July 25), SmartNet (August 7), Nutanix (October 1), F5 (October 20), and Microsoft (October 31) discussed; all on track, with focus on consolidation and visibility. Cisco Licensing: Issue with firewall and switches not appearing; Steve to provide serials/screenshots. Felix to investigate with Cisco. Plan to use an LOA for SHI/Cisco audit and clarity. EA Eligibility: Argo close to $50K/year; if DDoS project pushes them above, will revisit EA for pricing and management benefits. Nutanix: 192 cores, renewal only, no collector/expansion at this time; future hardware may move from HP to Dell. AI/SHI’s Practice: SHI shared internal AI journey, offered free briefings/workshops, emphasized secure/private data lakes for regulated customers. Steve will refer to management (Tim) for next steps.

Security

Updates: Ingram Micro cyberattack, Sophos NDR (SecureWorks integration), and Microsoft SharePoint zero-day vulnerability discussed. OEM EOYs: July/September best for deals; August is slow for EOYs.

Technical Notes

Cisco Duo/SmartNet renewals: Confirm details, consolidate dates, avoid lapses Cisco device audit: Serial numbers/screenshots required for full visibility LOA: Needed to enable SHI/Cisco to review all devices and licensing; Felix to confirm status/send new if needed Nutanix: 192 core renewal, no expansion, no collector to be run F5: Support renewal, quote pending Microsoft: Workbook process; Tyler available for support AI: Copilot in environment, not used; SHI MindSpark in production at SHI; SHI can help with private AI deployments Sophos NDR: Now includes SecureWorks integration, worth considering for future

security roadmap

Security

security roadmap

Security

Potential Next Steps

Cisco Duo Renewal

Cisco Duo Renewal

Action: Steve to send PO by July 24; Felix to coordinate with Cisco to ensure processing before EOY shutdown. Participants: Steve Dodds (to Felix), Felix Menchaca (to Cisco Rep)

Action: Steve to send PO by July 24; Felix to coordinate with Cisco to ensure processing before EOY shutdown. Participants: Steve Dodds (to Felix), Felix Menchaca (to Cisco Rep)

Cisco SmartNet Device Audit

Cisco SmartNet Device Audit

Action: Steve to send serial numbers/screenshots for missing devices; Felix to investigate with Cisco. Participants: Steve Dodds (to Felix), Felix (to Cisco Team)

Action: Steve to send serial numbers/screenshots for missing devices; Felix to investigate with Cisco. Participants: Steve Dodds (to Felix), Felix (to Cisco Team)

LOA for Cisco Audit

LOA for Cisco Audit

Action: Felix to check LOA status; if expired, send new form to Steve for signature. Participants: Felix (to Steve)

Action: Felix to check LOA status; if expired, send new form to Steve for signature. Participants: Felix (to Steve)

Cisco EA Evaluation

Cisco EA Evaluation

Action: Felix to prepare EA analysis if spend increases; discuss on next Cisco call. Participants: Felix (to Cisco EA Team, Steve, Tim)

Action: Felix to prepare EA analysis if spend increases; discuss on next Cisco call. Participants: Felix (to Cisco EA Team, Steve, Tim)

Nutanix Renewal

Nutanix Renewal

Action: Felix to send updated renewal quote once available; Steve to review and approve. Participants: Felix (to Steve, Nutanix Rep)

Action: Felix to send updated renewal quote once available; Steve to review and approve. Participants: Felix (to Steve, Nutanix Rep)

F5 Renewal

F5 Renewal

Action: Felix to provide updated quote. Participants: Felix (to Steve, F5 Rep)

Action: Felix to provide updated quote. Participants: Felix (to Steve, F5 Rep)

Microsoft Renewal

Microsoft Renewal

Action: Steve to continue workbook updates; Felix to schedule call with Tyler as needed. Participants: Steve (to Felix, Tyler)

Action: Steve to continue workbook updates; Felix to schedule call with Tyler as needed. Participants: Steve (to Felix, Tyler)

AI Briefing/Workshop

AI Briefing/Workshop

Action: Steve to discuss with Tim if an AI briefing/workshop is desired; Felix/Manuel to coordinate if so. Participants: Steve (to Tim), Felix, Manuel

Action: Steve to discuss with Tim if an AI briefing/workshop is desired; Felix/Manuel to coordinate if so. Participants: Steve (to Tim), Felix, Manuel

Sophos NDR Interest

Sophos NDR Interest

Action: Felix to provide additional info/demo opportunity as requested. Participants: Felix (to Steve, Sophos Rep)

Action: Felix to provide additional info/demo opportunity as requested. Participants: Felix (to Steve, Sophos Rep)

General Follow-up

General Follow-up

Action: Felix to send meeting recap and follow up on all open items (Cisco info, renewal quotes, LOA, etc.). Participants: Felix (to Steve)

Action: Felix to send meeting recap and follow up on all open items (Cisco info, renewal quotes, LOA, etc.). Participants: Felix (to Steve)
