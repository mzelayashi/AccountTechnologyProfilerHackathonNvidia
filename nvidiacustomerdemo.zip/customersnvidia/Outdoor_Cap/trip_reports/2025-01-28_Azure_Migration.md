Trip Report | Azure Migration | Outdoor Cap

Customer: Outdoor Cap
AE: Jax M
Topic: Azure Migration
Meeting Date 01/28/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Jax M

Coordinate a call with the client to further understand their needs and discuss the migration plan. Discuss the client's current multi-cloud setup and potential consolidation into Azure.

02/15

Item Owner Next Steps/Detail Due Date 1 Jax M Coordinate a call with the client to further understand their needs and discuss the migration plan. Discuss the client's current multi-cloud setup and potential consolidation into Azure. 02/15

Summary

Discussion revolves around a client's interest in transitioning their on-premise DMZ environment to the cloud, specifically considering Azure. The client is looking to migrate a small number of VMs (3-4), including an FTP proxy and an app proxy. There is a discussion on whether this opportunity is suitable for their organization, given its small scale. The client is interested in a Platform as a Service (PaaS) solution rather than managing their own cloud infrastructure. Potential vendors like Alkira are mentioned as possible fits for the client's needs. The call also touches on the client's current multi-cloud setup using smaller providers and the potential benefits of consolidating to Azure.

Agenda

Discuss the client's interest in moving a small number of VMs to Azure. Evaluate the suitability of this opportunity for the organization. Consider potential vendors for the client's needs. Plan for a future call to explore this opportunity further.

Discuss the client's interest in moving a small number of VMs to Azure. Evaluate the suitability of this opportunity for the organization. Consider potential vendors for the client's needs. Plan for a future call to explore this opportunity further.

Opps Identified & BANTC

Opportunity: Migration to Azure Cloud

Opportunity: Migration to Azure Cloud

B: The
client is interested in moving to Azure due to its natural fit and the small scale of the migration (3-4 VMs).
A: The
client is looking for a PaaS solution rather than managing their own cloud infrastructure.
N: The
need is to consolidate their current multi-cloud setup and simplify management.
T: Timeline
is not explicitly mentioned, but there is a sense of urgency to discuss further with the client.
C: Client's
budget seems limited, as suggested by Jax's reference to the low budget and low scale of the operation.

B: The
client is interested in moving to Azure due to its natural fit and the small scale of the migration (3-4 VMs).
A: The
client is looking for a PaaS solution rather than managing their own cloud infrastructure.
N: The
need is to consolidate their current multi-cloud setup and simplify management.
T: Timeline
is not explicitly mentioned, but there is a sense of urgency to discuss further with the client.
C: Client's
budget seems limited, as suggested by Jax's reference to the low budget and low scale of the operation.

Initiatives

Storage: Potential consolidation of multi-cloud environments into Azure.

Security

Ensuring the security of the migrated VMs and proxies.

Storage: Potential consolidation of multi-cloud environments into Azure.

Security

Ensuring the security of the migrated VMs and proxies.

Tech Profile Updates

Client currently has a multi-cloud setup managed through smaller providers and Meraki Cloud.

Client currently has a multi-cloud setup managed through smaller providers and Meraki Cloud.

Meeting Notes

Environment

Current on-prem DMZ and plans to move to Azure. Small-scale migration involving FTP and app proxies.

Current on-prem DMZ and plans to move to Azure. Small-scale migration involving FTP and app proxies.

Detailed Discussion

The client prefers a PaaS model to avoid managing cloud infrastructure. Potential vendors like Alkira discussed for their fit with the client's needs. The client's current setup involves multiple small cloud providers.

The client prefers a PaaS model to avoid managing cloud infrastructure. Potential vendors like Alkira discussed for their fit with the client's needs. The client's current setup involves multiple small cloud providers.

Technical Notes

Migration involves 3-4 VMs: FTP proxy and app proxy. Current multi-cloud environment managed through Meraki Cloud and smaller providers. Potential consolidation to Azure to simplify and streamline operations.

Migration involves 3-4 VMs: FTP proxy and app proxy. Current multi-cloud environment managed through Meraki Cloud and smaller providers. Potential consolidation to Azure to simplify and streamline operations. List all speakers/Participants of Transcript:

Jax Miley Pierre Gamble Manuel Zelaya

Jax Miley Pierre Gamble Manuel Zelaya
