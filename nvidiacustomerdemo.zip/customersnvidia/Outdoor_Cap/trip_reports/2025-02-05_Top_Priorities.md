Trip Report | Top Priorities | Outdoor Cap

Customer: Outdoor Cap
AE: Jax M
Topic: Top Priorities
Meeting Date 02/05/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Jax M

Set up a meeting to discuss Azure integration.: Evaluate current SQL Server licenses and explore optimization strategies.

03/01

2

Manuel Z

MLS Request and Live Optics Run

03/01

3

Matthew

Follow-up on LoA and Vendor Coordination:

03/01

Item Owner Next Steps/Detail Due Date 1 Jax M Set up a meeting to discuss Azure integration.: Evaluate current SQL Server licenses and explore optimization strategies. 03/01 2 Manuel Z MLS Request and Live Optics Run 03/01 3 Matthew Follow-up on LoA and Vendor Coordination: 03/01

Summary

The conversation focusing on the company's technology infrastructure needs, including servers, networking, and storage. The primary concern is the imminent end of support for their current servers, necessitating urgent action to replace outdated equipment. Helton discussed issues with counterfeit parts and the challenges of maintaining a functional IT environment with limited resources. The discussion also covered the opening of remote offices and the need for efficient network solutions, including VPNs and Meraki hardware. The team explored options for upgrading servers, leveraging Azure for cloud solutions, and improving software licensing strategies. Emphasis was

Agenda

Addressing Outdoor Cap's critical IT infrastructure needs Discussing counterfeit part issues Exploring server and network upgrades Reviewing remote office network solutions Planning for Azure cloud integration Evaluating licensing and cost optimization

Addressing Outdoor Cap's critical IT infrastructure needs Discussing counterfeit part issues Exploring server and network upgrades Reviewing remote office network solutions Planning for Azure cloud integration Evaluating licensing and cost optimization

Opportunities Identified & BANTC

Opportunity: Server Upgrade

Opportunity: Server Upgrade

B: Need
to replace servers by year-end due to end-of-support status.
A: Matthew
Helton
N: Critical
for maintaining IT infrastructure
T: By
end of year
C: SHI
to assist with procurement and cost efficiency

B: Need
to replace servers by year-end due to end-of-support status.
A: Matthew
Helton
N: Critical
for maintaining IT infrastructure
T: By
end of year
C: SHI
to assist with procurement and cost efficiency

Opportunity: Azure Cloud Integration

Opportunity: Azure Cloud Integration

B: Need
to optimize cloud infrastructure
A: Stephen
Drake/SHI
N: Enhanced
cloud management and cost efficiency
T: Ongoing
C: Collaboration
with Microsoft Black Ops team

B: Need
to optimize cloud infrastructure
A: Stephen
Drake/SHI
N: Enhanced
cloud management and cost efficiency
T: Ongoing
C: Collaboration
with Microsoft Black Ops team

Opportunity: SQL Server Optimization

Opportunity: SQL Server Optimization

B: Need
to leverage existing SQL Server licenses effectively
A: Matthew
Helton
N: Cost
efficiency and improved database performance
T: Immediate
C: SHI
to provide guidance on licensing and migration

B: Need
to leverage existing SQL Server licenses effectively
A: Matthew
Helton
N: Cost
efficiency and improved database performance
T: Immediate
C: SHI
to provide guidance on licensing and migration

Initiatives

Security: None explicitly discussed Storage: Server and network upgrades, Azure cloud integration

Security: None explicitly discussed Storage: Server and network upgrades, Azure cloud integration

Tech Profile Updates

Servers: Current servers are outdated and need replacement Networking: Expansion and VPN solutions for remote offices Cloud: Azure integration and SQL Server optimization

Servers: Current servers are outdated and need replacement Networking: Expansion and VPN solutions for remote offices Cloud: Azure integration and SQL Server optimization

Meeting Notes

Environment

Current servers nearing end-of-support Challenges with counterfeit parts and third-party vendors Expansion into remote offices necessitating VPN solutions

Current servers nearing end-of-support Challenges with counterfeit parts and third-party vendors Expansion into remote offices necessitating VPN solutions

Detailed Discussion

Matthew Helton emphasized the urgency of replacing outdated servers and resolving counterfeit part issues. Stephen Drake proposed engaging with SHI's Microsoft team to optimize cloud solutions. Discussion on leveraging Azure for better cloud management and cost efficiency. Focus on SQL Server licensing optimization and potential migration strategies.

Matthew Helton emphasized the urgency of replacing outdated servers and resolving counterfeit part issues. Stephen Drake proposed engaging with SHI's Microsoft team to optimize cloud solutions. Discussion on leveraging Azure for better cloud management and cost efficiency. Focus on SQL Server licensing optimization and potential migration strategies.

Technical Notes

Servers: Consideration of Dell R450 or R650 models for replacement Networking: Site-to-site VPNs and Meraki hardware for remote offices Cloud: Azure setup with low firewall settings, cloud governance framework via SHI One portal SQL Server: Current licenses include a SQL Server Enterprise with Software Assurance

Servers: Consideration of Dell R450 or R650 models for replacement Networking: Site-to-site VPNs and Meraki hardware for remote offices Cloud: Azure setup with low firewall settings, cloud governance framework via SHI One portal SQL Server: Current licenses include a SQL Server Enterprise with Software Assurance List all speakers/Participants of Transcript:

Matthew Helton Stephen Drake Jax Miley

Matthew Helton Stephen Drake Jax Miley

Potential Next Steps

Meeting with Microsoft Black Ops Team:

Meeting with Microsoft Black Ops Team:

Action: Set up a meeting to discuss Azure integration. Involved: Stephen Drake, Jax Miley, Matthew Helton

Action: Set up a meeting to discuss Azure integration. Involved: Stephen Drake, Jax Miley, Matthew Helton

Server Upgrade Planning:

Server Upgrade Planning:

Action: Coordinate with SHI for server procurement and cost analysis. Involved: Matthew Helton, SHI team

Action: Coordinate with SHI for server procurement and cost analysis. Involved: Matthew Helton, SHI team

SQL Server License Review:

SQL Server License Review:

Action: Evaluate current SQL Server licenses and explore optimization strategies. Involved: Matthew Helton, SHI licensing team

Action: Evaluate current SQL Server licenses and explore optimization strategies. Involved: Matthew Helton, SHI licensing team

MLS Request and Live Optics Run:

MLS Request and Live Optics Run:

Action: Jax Miley to initiate MLS pull request and Live Optics analysis. Involved: Jax Miley, Matthew Helton, SHI team

Action: Jax Miley to initiate MLS pull request and Live Optics analysis. Involved: Jax Miley, Matthew Helton, SHI team

Follow-up on LoA and Vendor Coordination:

Follow-up on LoA and Vendor Coordination:

Action: Matthew Helton to conduct face-to-face meeting regarding LoA. Involved: Matthew Helton, relevant third-party vendors

Action: Matthew Helton to conduct face-to-face meeting regarding LoA. Involved: Matthew Helton, relevant third-party vendors
