Trip Report | Managed Engine | Outdoor Cap

Customer: Outdoor Cap
AE: Jax M
Topic: Managed Engine
Meeting Date 02/19/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Jax M

schedule a follow-up meeting with the IT Director and CISO to discuss detailed security solution proposals. (NETWRIX)

02/28

2

Jax M

Prepare a cost-benefit analysis for proposed storage solutions, to be presented in the next meeting.

02/28

Item Owner Next Steps/Detail Due Date 1 Jax M schedule a follow-up meeting with the IT Director and CISO to discuss detailed security solution proposals. (NETWRIX) 02/28 2 Jax M Prepare a cost-benefit analysis for proposed storage solutions, to be presented in the next meeting. 02/28

Summary

Summary: The conversation involved Manuel Zelaya from

Agenda

• Introduction and understanding of customer's current
IT environment • Discussion on security and storage challenges • Exploration of potential solutions and technologies • Identifying immediate and long-term objectives • Next steps and action items

Opps Identified & BANTC

Opportunity 1: Security Enhancement
• B: Customer
requires robust security measures to protect sensitive data.
• A:
Decision-makers are the IT Director and CISO, both present in the meeting.
• N: Compliance with new regulatory requirements by Q3
2025.
• T: Budget
allocated for security improvements is $500K.
• C: Urgency due to recent data breach incidents.
Opportunity 2: Storage Optimization
• B: Need for scalable storage solutions to
accommodate growing data volumes.
• A: IT
Infrastructure Manager is responsible for storage solutions.
• N: Immediate
need to address storage bottlenecks impacting performance.
• T: Budget is
flexible, with potential for increased funding if ROI is demonstrated.
• C: Business expansion plans necessitate scalable
storage. Initiatives: • Security: Implementation of advanced cybersecurity solutions. • Storage: Deployment of scalable and efficient storage systems. Tech Profile Updates: • Security tools currently in use include basic firewall and antivirus software. • Storage infrastructure consists of outdated NAS systems, requiring modernization.

Meeting Notes

Environment: • The customer's IT environment includes legacy systems that are increasingly difficult to maintain. • There is a mix of on-premise and cloud-based solutions, with plans to migrate more services to the cloud. Technical Notes: • Consideration of SIEM (Security Information and Event Management) for real-time analysis of security alerts. • Discussion of implementing SSDs (Solid State Drives) to improve storage performance. • Evaluation of cloud storage providers for cost-effectiveness and scalability. List all speakers/Participants of Transcript:  Manuel Zelaya (SHI) • IT Director (Customer) • CISO (Customer) • IT Infrastructure Manager (Customer)

Potential Next steps

Manuel Zelaya to schedule a follow-up meeting with the IT Director and CISO to discuss detailed security solution proposals. IT Infrastructure Manager to provide current storage usage data to SHI for further analysis. SHI to prepare a cost-benefit analysis for proposed storage solutions, to be presented in the next meeting. Customer to review regulatory requirements with their legal team and share findings with SHI for alignment on compliance solutions.

Manuel Zelaya to schedule a follow-up meeting with the IT Director and CISO to discuss detailed security solution proposals. IT Infrastructure Manager to provide current storage usage data to SHI for further analysis. SHI to prepare a cost-benefit analysis for proposed storage solutions, to be presented in the next meeting. Customer to review regulatory requirements with their legal team and share findings with SHI for alignment on compliance solutions.
