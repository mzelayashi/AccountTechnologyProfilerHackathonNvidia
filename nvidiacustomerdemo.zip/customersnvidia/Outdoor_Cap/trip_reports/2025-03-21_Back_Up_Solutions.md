Trip Report | Back Up Solutions | Outdoor Cap

Customer: Outdoor Cap
AE: Jax M
Topic: Back Up Solutions
Meeting Date 03/21/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Jax

contact Sharad at Manage Engine for updated quotes and discuss potential discounts

04/20

2

Manuel Z

review assist Veeam backup solution in 120 days.

08/20

Item Owner Next Steps/Detail Due Date 1 Jax contact Sharad at Manage Engine for updated quotes and discuss potential discounts 04/20 2 Manuel Z review assist Veeam backup solution in 120 days. 08/20

Summary

The meeting between Jax Miley from SHI and Matthew Helton from Outdoor Cap Co focused on discussing Manage Engine and Meraki solutions, exploring current issues, and planning for future technology deployments. The conversation covered multiple topics, including quotes for Manage Engine, firmware issues with Meraki hardware, Veeam backup solutions, and Microsoft Office 365 management. The participants aimed to align technology solutions with business needs, with an emphasis on cost-effectiveness and efficiency. Specific challenges included managing cloud-based applications and ensuring seamless communication for technical support.

Agenda

Discuss Manage Engine quotes and potential discounts Address Meraki hardware and firmware issues Review Veeam backup server updates and renewal plans Explore Microsoft Office 365 management options Discuss communication and collaboration improvements

Discuss Manage Engine quotes and potential discounts Address Meraki hardware and firmware issues Review Veeam backup server updates and renewal plans Explore Microsoft Office 365 management options Discuss communication and collaboration improvements

Opps Identified & BANTC

Opportunity 1: Manage Engine Implementation

B: The
infrastructure.
A: Matthew
Helton is the decision-maker, actively evaluating Manage Engine for implementation.
N: The
need is driven by existing familiarity with the platform and the requirement for improved application management.
T: The
timeline is immediate, with a goal to implement by the end of the month.
C: The
customer is considering pricing options, with potential discounts available from Manage Engine.

B: The
infrastructure.
A: Matthew
Helton is the decision-maker, actively evaluating Manage Engine for implementation.
N: The
need is driven by existing familiarity with the platform and the requirement for improved application management.
T: The
timeline is immediate, with a goal to implement by the end of the month.
C: The
customer is considering pricing options, with potential discounts available from Manage Engine.
Opportunity 2: Veeam Backup Renewal

B: The
customer needs to renew their Veeam backup solution in 120 days.
A: Matthew
Helton oversees backup solutions and is exploring renewal options.
N: The
need is to ensure continued data protection and backup capabilities.
T: The
renewal is due in 120 days, necessitating timely evaluation.
C: Previous
third-party arrangements are no longer used, requiring direct engagement with Veeam.

B: The
customer needs to renew their Veeam backup solution in 120 days.
A: Matthew
Helton oversees backup solutions and is exploring renewal options.
N: The
need is to ensure continued data protection and backup capabilities.
T: The
renewal is due in 120 days, necessitating timely evaluation.
C: Previous
third-party arrangements are no longer used, requiring direct engagement with Veeam.

Initiatives

Security

Addressing firmware issues in Meraki hardware. Storage: Veeam backup renewal and evaluation of potential alternatives.

Security

Addressing firmware issues in Meraki hardware. Storage: Veeam backup renewal and evaluation of potential alternatives.

Tech Profile Updates

The current use of Meraki hardware has firmware instability issues. Veeam backup solutions are enterprise-level, with Office 365 integration. Manage Engine is being considered for enhanced IT management.

The current use of Meraki hardware has firmware instability issues. Veeam backup solutions are enterprise-level, with Office 365 integration. Manage Engine is being considered for enhanced IT management.

Meeting Notes

Environment

Outdoor Cap Co operates with Microsoft Office 365 and relies on cloud-based applications. Current infrastructure includes Meraki hardware and Veeam backup solutions.

Outdoor Cap Co operates with Microsoft Office 365 and relies on cloud-based applications. Current infrastructure includes Meraki hardware and Veeam backup solutions.

Detailed Discussion

Jax and Matthew discussed the need for updated quotes on Manage Engine, considering recent discounts. They also addressed ongoing issues with Meraki firmware and potential solutions. Veeam's upcoming renewal was highlighted, with Jax expressing interest in participating in the renewal discussions. The conversation also touched on Microsoft Office 365 management and potential improvements in communication through Teams.

Technical Notes

Manage Engine requires careful configuration to ensure permissions are correctly set. Meraki hardware has experienced uncommanded reboots, possibly due to firmware issues. Veeam backup servers are scheduled for updates, with Phoenix being the first to patch. Microsoft Teams communication requires domain permissions for cross-organization messaging.

Manage Engine requires careful configuration to ensure permissions are correctly set. Meraki hardware has experienced uncommanded reboots, possibly due to firmware issues. Veeam backup servers are scheduled for updates, with Phoenix being the first to patch. Microsoft Teams communication requires domain permissions for cross-organization messaging. List all speakers/Participants of Transcript:

Jax Miley (SHI) Matthew Helton (Outdoor Cap Co)

Jax Miley (SHI) Matthew Helton (Outdoor Cap Co)

Potential Next steps

Manage Engine Quote Update:

Manage Engine Quote Update:

Jax Miley to contact Sharad at Manage Engine for updated quotes and discuss potential discounts. Action item involves Jax providing updated quotes to Matthew Helton by the end of the day or early next week.

Jax Miley to contact Sharad at Manage Engine for updated quotes and discuss potential discounts. Action item involves Jax providing updated quotes to Matthew Helton by the end of the day or early next week.

Veeam Renewal Discussion:

Veeam Renewal Discussion:

Jax Miley to engage Veeam resources for renewal planning and pricing discussions. Action item includes coordinating with Matthew Helton to finalize renewal strategy.

Jax Miley to engage Veeam resources for renewal planning and pricing discussions. Action item includes coordinating with Matthew Helton to finalize renewal strategy.

Meraki Firmware Issue Resolution:

Meraki Firmware Issue Resolution:

Matthew Helton to follow up with Meraki support to address firmware stability issues. Action item involves monitoring hardware performance and logging further incidents.

Matthew Helton to follow up with Meraki support to address firmware stability issues. Action item involves monitoring hardware performance and logging further incidents.

Microsoft Teams Communication Setup:

Microsoft Teams Communication Setup:

Matthew Helton to update security settings to allow SHI as a friendly domain for Teams communication. Action item involves testing and verifying cross-organization messaging capabilities.

Matthew Helton to update security settings to allow SHI as a friendly domain for Teams communication. Action item involves testing and verifying cross-organization messaging capabilities.

Follow-up Meeting Scheduling:

Follow-up Meeting Scheduling:

Jax Miley and Matthew Helton to schedule another meeting to review progress on the discussed items. Action item includes maintaining an active chat for ongoing communication.

Jax Miley and Matthew Helton to schedule another meeting to review progress on the discussed items. Action item includes maintaining an active chat for ongoing communication.
