Trip Report | 2025 Panning and Review | SFG

Customer: SFG
AE: Tony V
Topic: 2025 Panning and Review
Meeting Date 02/11/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Tony V

Meeting Setup with Tyler (Microsoft Specialist):

02/28

2

Manuel Z

To arrange a meeting with SHI's managed service experts for Mark Merritt to explore the SHI Complete and AI options.

02/28

3

Tony V

resend the questionnaire and coordinate with Jarrett on leasing options and Dell hardware preferences.

Item Owner Next Steps/Detail Due Date 1 Tony V Meeting Setup with Tyler (Microsoft Specialist): 02/28 2 Manuel Z To arrange a meeting with SHI's managed service experts for Mark Merritt to explore the SHI Complete and AI options. 02/28 3 Tony V resend the questionnaire and coordinate with Jarrett on leasing options and Dell hardware preferences.

Summary

. The main objective is to review and plan the technology roadmap for the upcoming year. Topics include Microsoft licensing, server renewals, software assurance, email security, budget management, endpoint renewals, and potential technology transitions. The discussion highlights the need to streamline operations through leasing options, VPN updates, camera systems, and exploring AI and SHI Complete solutions. The participants aim to align on strategies for managing costs, improving infrastructure, and leveraging new technologies.

Agenda

Review of past year’s technology engagements Discussion on Microsoft licensing and server renewals Email

security plans and budget considerations

VPN and endpoint management Exploration of AI and SHI Complete solutions Technology leasing and hardware preferences Closing remarks and future engagement plans

Review of past year’s technology engagements Discussion on Microsoft licensing and server renewals Email

security plans and budget considerations

VPN and endpoint management Exploration of AI and SHI Complete solutions Technology leasing and hardware preferences Closing remarks and future engagement plans

Opportunities Identified & BANTC

Opportunity: Microsoft Licensing and Server Renewal

Opportunity: Microsoft Licensing and Server Renewal

B: The need to renew server licensing and review Microsoft assurance. A: Mark Merritt, Charles Liljestrand, Tony Villalanti. N: Renewal is necessary to maintain compliance and software support. T: Immediate, as licenses are expiring. C: Aligning with Tyler, the Microsoft specialist, for a meeting.

B: The need to renew server licensing and review Microsoft assurance. A: Mark Merritt, Charles Liljestrand, Tony Villalanti. N: Renewal is necessary to maintain compliance and software support. T: Immediate, as licenses are expiring. C: Aligning with Tyler, the Microsoft specialist, for a meeting.

Opportunity: Email Security Implementation

Opportunity: Email Security Implementation

B: Securing email communication systems. A: Mark Merritt, Tony Villalanti. N: Compliance checks are nearly complete. T: End of the month target for order placement. C: Within budget, quote received aligns with expectations.

B: Securing email communication systems. A: Mark Merritt, Tony Villalanti. N: Compliance checks are nearly complete. T: End of the month target for order placement. C: Within budget, quote received aligns with expectations.

Opportunity: VPN and Multifactor Authentication Enhancement

Opportunity: VPN and Multifactor Authentication Enhancement

B: Upgrade VPN infrastructure and multifactor authentication. A: Mark Merritt, Manuel Zelaya, Tony Villalanti. N: Current systems are outdated and vulnerable. T: Not immediately budgeted but critical for security. C: Exploring vendor-agnostic options.

B: Upgrade VPN infrastructure and multifactor authentication. A: Mark Merritt, Manuel Zelaya, Tony Villalanti. N: Current systems are outdated and vulnerable. T: Not immediately budgeted but critical for security. C: Exploring vendor-agnostic options.

Opportunity: SHI Complete and AI Solutions

Opportunity: SHI Complete and AI Solutions

B: Exploring comprehensive IT management and AI solutions. A: Mark Merritt, Tony Villalanti, Manuel Zelaya. N: To reduce complexity and improve operational efficiency. T: Ongoing exploration, potential integration with existing systems. C: Cost-effective at approximately $120 per user per month.

B: Exploring comprehensive IT management and AI solutions. A: Mark Merritt, Tony Villalanti, Manuel Zelaya. N: To reduce complexity and improve operational efficiency. T: Ongoing exploration, potential integration with existing systems. C: Cost-effective at approximately $120 per user per month.

Initiatives

Security

Email security, VPN, multifactor authentication. Storage: Consideration of camera system upgrades and cloud backup options. Both: SHI Complete and AI solutions to enhance security and storage management.

Security

Email security, VPN, multifactor authentication. Storage: Consideration of camera system upgrades and cloud backup options. Both: SHI Complete and AI solutions to enhance security and storage management.

Tech Profile Updates

Review of current Microsoft, VMware, and Sophos deployments. Exploration of alternative hardware and leasing options with a focus on Dell devices. Evaluation of SHI Complete and AI solutions for broader IT management.

Review of current Microsoft, VMware, and Sophos deployments. Exploration of alternative hardware and leasing options with a focus on Dell devices. Evaluation of SHI Complete and AI solutions for broader IT management.

Meeting Notes

Environment

Current systems and software licenses are under review. Budget considerations are a focal point, with OpEx models being prioritized over CapEx.

Current systems and software licenses are under review. Budget considerations are a focal point, with OpEx models being prioritized over CapEx.

Detailed Discussion

Technical Notes

Microsoft M365 includes CSP and server licensing. Expired server licenses require renewal. Email security quote aligns with budget expectations. VPN infrastructure is outdated, exploring options for always-on VPN with multifactor support. Potential to shift from socket to VUL for cloud backup, though costs are a concern. SHI Complete offers a comprehensive solution with endpoint management tools like Sentinel One. AI solutions like Mindspark offer potential cost savings and operational enhancements.

Microsoft M365 includes CSP and server licensing. Expired server licenses require renewal. Email security quote aligns with budget expectations. VPN infrastructure is outdated, exploring options for always-on VPN with multifactor support. Potential to shift from socket to VUL for cloud backup, though costs are a concern. SHI Complete offers a comprehensive solution with endpoint management tools like Sentinel One. AI solutions like Mindspark offer potential cost savings and operational enhancements. List all speakers/Participants of Transcript:

Tony Villalanti Mark Merritt Charles Liljestrand Manuel Zelaya

Tony Villalanti Mark Merritt Charles Liljestrand Manuel Zelaya

Potential Next Steps

Meeting Setup with Tyler (Microsoft Specialist):

Meeting Setup with Tyler (Microsoft Specialist):

Action by Tony Villalanti to coordinate with Tyler and organize a meeting with Mark Merritt and Charles Liljestrand to discuss server renewals.

Action by Tony Villalanti to coordinate with Tyler and organize a meeting with Mark Merritt and Charles Liljestrand to discuss server renewals.

Email Security Order Placement:

Email Security Order Placement:

Mark Merritt to finalize compliance checks and proceed with order by the end of the month.

Mark Merritt to finalize compliance checks and proceed with order by the end of the month.

VPN and Multifactor Authentication Options:

VPN and Multifactor Authentication Options:

Manuel Zelaya to send a follow-up email with alternative VPN solutions for review by Mark Merritt.

Manuel Zelaya to send a follow-up email with alternative VPN solutions for review by Mark Merritt.

SHI Complete and AI Exploration:

SHI Complete and AI Exploration:

Tony Villalanti to arrange a meeting with SHI's managed service experts for Mark Merritt to explore the SHI Complete and AI options.

Tony Villalanti to arrange a meeting with SHI's managed service experts for Mark Merritt to explore the SHI Complete and AI options.

Leasing and Hardware Evaluation:

Leasing and Hardware Evaluation:

Tony Villalanti to resend the questionnaire and coordinate with Jarrett on leasing options and Dell hardware preferences.

Tony Villalanti to resend the questionnaire and coordinate with Jarrett on leasing options and Dell hardware preferences.

Subscription Management for M365:

Subscription Management for M365:

Tony Villalanti to follow up with Tyler to address issues with adjusting M365 seat counts via SHI.com.

Tony Villalanti to follow up with Tyler to address issues with adjusting M365 seat counts via SHI.com.
