Trip Report | SHI Complete | SFG

Customer: SFG
AE: 
Topic: SHI Complete
Meeting Date 06/09/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Mark

review proposal, cross off unnecessary/duplicated services, and send prioritized needs back to SHI. .

06/25

2

Manuel Z

connect SFG with security architect/professional services for WAF deployment options and pricing.

06/25

Item Owner Next Steps/Detail Due Date 1 Mark review proposal, cross off unnecessary/duplicated services, and send prioritized needs back to SHI. . 06/25 2 Manuel Z connect SFG with security architect/professional services for WAF deployment options and pricing. 06/25

Summary

This meeting was a detailed review of the SHI Complete managed services proposal for SFG, including security, support, network, and infrastructure management, with an emphasis on flexibility and customization. The SHI team presented the “premium” package as a high-end, all-inclusive offering, but made it clear that services can be tailored à la carte to SFG’s needs. The proposal includes a full end-to-end user support model (help desk, endpoint protection, SOC, SIEM, backup, email security, etc.) at $145/user/month, amounting to roughly $33K/month for the full suite. Additional options for network and infrastructure management were explained, as well as pricing models for cloud vs. on-prem. SFG will now review the proposal, pare it down to critical requirements, and compare to competing offers. A separate discussion was held on the need for a Web Application Firewall (WAF) to meet PCI compliance, with SHI confirming capability to deliver this as a managed service or through professional services. Further, Microsoft licensing was discussed, with a likely recommendation to move to Business Premium for enhanced security features. SHI will provide pricing for this upgrade. SFG is considering a 3-year contract but may pilot with a 1-year term. Agenda: • Review SHI Complete managed services proposal
• Discuss service tier options, pricing, and
customization
• Address specific security/compliance needs (WAF,
SIEM, SOC, endpoint)
• Clarify Microsoft licensing requirements
• Identify next steps for proposal iteration and
decision-making

Opps Identified & BANTC

Opportunity 1: Managed Services (SHI Complete)

B: $145/user/month
for premium; total of $33K/month for the full package; lower tiers possible; can be customized; 3-year contract preferred but 1-year pilot possible.
A: Mark
Merritt (primary), Charles Liljestrand; SFG leadership for final authorization.
N: Need
to offload IT support, security, compliance management, and reduce internal staffing burden. Full-stack support including SIEM, EDR, backup,

endpoint protection, and help desk.

T: Immediate
for review, but procurement likely phased as SFG pares down requirements and compares to other vendors.
C: Other
managed services competitors (not named, but SFG is comparing multiple proposals).

B: $145/user/month
for premium; total of $33K/month for the full package; lower tiers possible; can be customized; 3-year contract preferred but 1-year pilot possible.
A: Mark
Merritt (primary), Charles Liljestrand; SFG leadership for final authorization.
N: Need
to offload IT support, security, compliance management, and reduce internal staffing burden. Full-stack support including SIEM, EDR, backup,

endpoint protection, and help desk.

T: Immediate
for review, but procurement likely phased as SFG pares down requirements and compares to other vendors.
C: Other
managed services competitors (not named, but SFG is comparing multiple proposals).
Opportunity 2: Web Application Firewall (WAF) for PCI
Compliance

B: Likely
a few hundred dollars/month if handled as a cloud service; cost to be clarified based on approach.
A: Mark
Merritt, Charles Liljestrand.
N: Mandatory
PCI requirement as of April 1st for all e-commerce and payment-facing assets; “checkbox” compliance, not seeking advanced/proactive features.
T: Immediate
(already two months late on compliance).
C: Multiple
WAF vendors/platforms (to be proposed by SHI).

B: Likely
a few hundred dollars/month if handled as a cloud service; cost to be clarified based on approach.
A: Mark
Merritt, Charles Liljestrand.
N: Mandatory
PCI requirement as of April 1st for all e-commerce and payment-facing assets; “checkbox” compliance, not seeking advanced/proactive features.
T: Immediate
(already two months late on compliance).
C: Multiple
WAF vendors/platforms (to be proposed by SHI).
Opportunity 3: Microsoft Licensing Upgrade

B: Business
Premium recommended for enhanced security; pricing to be provided by SHI.
A: Mark
Merritt, SFG IT.
N: Unlock
more advanced security features; meet compliance and operational needs.
T: Pending
decision on managed services adoption.
C: Current
Business Standard license; E3/E5 only if needed for special compliance/retention.

B: Business
Premium recommended for enhanced security; pricing to be provided by SHI.
A: Mark
Merritt, SFG IT.
N: Unlock
more advanced security features; meet compliance and operational needs.
T: Pending
decision on managed services adoption.
C: Current
Business Standard license; E3/E5 only if needed for special compliance/retention.

Initiatives

Security: Managed endpoint protection, SIEM, EDR, SOC, email security, WAF for PCI, compliance reporting, user security training Storage: Backup and SaaS backup management, infrastructure management (if selected)

Security: Managed endpoint protection, SIEM, EDR, SOC, email security, WAF for PCI, compliance reporting, user security training Storage: Backup and SaaS backup management, infrastructure management (if selected)

Tech Profile Updates

Current: Some Microsoft Business Standard, Aruba Wi-Fi (on-prem, will remain), on-prem servers/infrastructure in transition, internal IT staff Proposed: SHI Complete managed service with full or partial outsourcing of IT operations, endpoint, and security; possible upgrade to Microsoft Business Premium Compliance: PCI-driven needs for SIEM and WAF; regular scanning and reporting

Current: Some Microsoft Business Standard, Aruba Wi-Fi (on-prem, will remain), on-prem servers/infrastructure in transition, internal IT staff Proposed: SHI Complete managed service with full or partial outsourcing of IT operations, endpoint, and security; possible upgrade to Microsoft Business Premium Compliance: PCI-driven needs for SIEM and WAF; regular scanning and reporting

Meeting Notes

Environment

SFG is considering outsourcing all or part of IT support and security, driven by cost, compliance, and internal resource constraints. SFG has a hybrid environment (some on-prem IT, some cloud, likely to increase cloud use over time). PCI compliance is a critical driver—especially for SIEM/log retention and WAF.

SFG is considering outsourcing all or part of IT support and security, driven by cost, compliance, and internal resource constraints. SFG has a hybrid environment (some on-prem IT, some cloud, likely to increase cloud use over time). PCI compliance is a critical driver—especially for SIEM/log retention and WAF.

Detailed Discussion

Proposal Structure: SHI Complete is modular—can be full “white glove or customized. Premium includes 24/7 SOC, SIEM, backup, endpoint, help desk, etc. Pricing: $145/user/month for full service, $33K/month all-in; lower pricing for “frontline” workers with lighter needs, as low as ~$100/user/month for less security. Customization: SFG will review proposal and cross off unnecessary services (e.g., password manager, Wi-Fi support for Aruba, server monitoring if kept in-house). Contract Terms: 3-year preferred for best value, but 1-year pilot is an option. WAF: Not included in base package, but can be added easily via SHI’s pro services bench; PCI “checkbox” compliance is the goal, not deep/proactive. Microsoft Licensing: SHI recommends Business Premium for security features; will provide cost to upgrade from Standard. Professional Services: SFG can access SHI’s pro services team without minimums if enrolled in managed services.

Proposal Structure: SHI Complete is modular—can be full “white glove or customized. Premium includes 24/7 SOC, SIEM, backup, endpoint, help desk, etc. Pricing: $145/user/month for full service, $33K/month all-in; lower pricing for “frontline” workers with lighter needs, as low as ~$100/user/month for less security. Customization: SFG will review proposal and cross off unnecessary services (e.g., password manager, Wi-Fi support for Aruba, server monitoring if kept in-house). Contract Terms: 3-year preferred for best value, but 1-year pilot is an option. WAF: Not included in base package, but can be added easily via SHI’s pro services bench; PCI “checkbox” compliance is the goal, not deep/proactive. Microsoft Licensing: SHI recommends Business Premium for security features; will provide cost to upgrade from Standard. Professional Services: SFG can access SHI’s pro services team without minimums if enrolled in managed services.

Technical Notes

SIEM/SOC: Included in premium, based on per-user pricing; modern, integrated toolset.

Endpoint

Protection: Premium EDR, backup, and email security included. WAF: Can be deployed as cloud service; SHI to advise on options and pricing; can be a lightweight “box-check” or more advanced depending on need. Infrastructure: Pricing for on-prem vs. cloud environments varies; SHI can manage both. Microsoft Licensing: Business Premium unlocks additional security features over Standard; E3/E5 likely unnecessary for SFG’s size/needs unless legal compliance requires.
**Proposal
is comprehensive and can be “dialed back” to match SFG’s exact staffing and operational model.

SIEM/SOC: Included in premium, based on per-user pricing; modern, integrated toolset.

Endpoint

Protection: Premium EDR, backup, and email security included. WAF: Can be deployed as cloud service; SHI to advise on options and pricing; can be a lightweight “box-check” or more advanced depending on need. Infrastructure: Pricing for on-prem vs. cloud environments varies; SHI can manage both. Microsoft Licensing: Business Premium unlocks additional security features over Standard; E3/E5 likely unnecessary for SFG’s size/needs unless legal compliance requires.
**Proposal
is comprehensive and can be “dialed back” to match SFG’s exact staffing and operational model. List all speakers/Participants of Transcript:

Mark Merritt (SFG) Charles Liljestrand (SFG) Tony Villalanti (SHI) Jonathan Barger (SHI)

Mark Merritt (SFG) Charles Liljestrand (SFG) Tony Villalanti (SHI) Jonathan Barger (SHI)

Potential Next Steps

Proposal Review & Feedback

Proposal Review & Feedback

Action: Mark Merritt and Charles Liljestrand to review proposal, cross off unnecessary/duplicated services, and send prioritized needs back to SHI. Who: Mark Merritt, Charles Liljestrand → Tony Villalanti, Jonathan Barger

Action: Mark Merritt and Charles Liljestrand to review proposal, cross off unnecessary/duplicated services, and send prioritized needs back to SHI. Who: Mark Merritt, Charles Liljestrand → Tony Villalanti, Jonathan Barger

Competitive Analysis

Competitive Analysis

Action: SFG to compare SHI proposal to competing managed services offers. Who: Mark Merritt, SFG leadership

Action: SFG to compare SHI proposal to competing managed services offers. Who: Mark Merritt, SFG leadership

WAF Solution Scoping

WAF Solution Scoping

Action: SHI to connect SFG with security architect/professional services for WAF deployment options and pricing. Who: Tony Villalanti, Jonathan Barger → Mark Merritt, Charles Liljestrand

Action: SHI to connect SFG with security architect/professional services for WAF deployment options and pricing. Who: Tony Villalanti, Jonathan Barger → Mark Merritt, Charles Liljestrand

Microsoft Licensing Upgrade Quote

Microsoft Licensing Upgrade Quote

Action: Tony Villalanti to provide pricing to upgrade SFG from Business Standard to Business Premium. Who: Tony Villalanti → Mark Merritt

Action: Tony Villalanti to provide pricing to upgrade SFG from Business Standard to Business Premium. Who: Tony Villalanti → Mark Merritt

Contract Term Decision

Contract Term Decision

Action: SFG to consider 1-year pilot vs. 3-year contract for best pricing. Who: Mark Merritt, SFG leadership

Action: SFG to consider 1-year pilot vs. 3-year contract for best pricing. Who: Mark Merritt, SFG leadership

Iterate and Finalize Proposal

Iterate and Finalize Proposal

Action: SHI to revise proposal based on SFG’s feedback and provide final quote. Who: Tony Villalanti, Jonathan Barger → SFG

Action: SHI to revise proposal based on SFG’s feedback and provide final quote. Who: Tony Villalanti, Jonathan Barger → SFG From <https://mindspark.shi.com/My_Agents>

From <https://mindspark.shi.com/My_Agents>
