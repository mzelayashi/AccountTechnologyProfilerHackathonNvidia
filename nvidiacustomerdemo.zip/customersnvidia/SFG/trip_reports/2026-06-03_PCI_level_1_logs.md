Trip Report | PCI level 1 logs | SFG

Customer: SFG
AE: Tony V
Topic: PCI level 1 logs
Meeting Date 06/03/2026

*Internal notes – Please read and edit before sending externally*

Summary

The meeting centered on two active customer issues with Mark Merritt from SFG: first, resolving onboarding/support and pricing friction with Akamai; second, and more strategically, determining how to restore compliant endpoint security logging

Agenda

• Review Akamai
onboarding/support-hours situation and recent surcharge issue.
• Discuss why
current MSP-delivered Datto EDR is failing PCI evidence requirements.
• Compare
Microsoft Business Premium/Defender/Sentinel versus replacing EDR with another platform.
• Explore how MSP
support responsibilities would work if Microsoft security tooling is adopted.
• Briefly
introduce AI governance and prompt security as a future discussion area. [SHI & SFG | Meeting]

Opps Identified & BANTC

Opportunity 1: Microsoft Business Premium + Defender +
Azure Log Analytics/Sentinel path

Initiatives

• Restore compliant endpoint logging for PCI audit
evidence — Security. The customer is actively trying to close a logging/evidence gap created by the current Datto EDR deployment.
• Evaluate Microsoft security stack expansion
(Business Premium, Defender, Log Analytics/Sentinel, possibly Defender for Servers) — Security. This is being investigated as a way to satisfy logging/compliance requirements and potentially consolidate management.
• Assess alternate EDR/MDR options and
contract/management model — Security. The team discussed Sophos, Trend Micro, Arctic Wolf Aurora, and the broader question of who manages the platform.
• Prepare for future AI governance controls — Security. Prompt security and browser-based AI
control were discussed as a later-stage initiative when the customer is ready.
• Resolve Akamai onboarding/support-hours and surcharge
issue — Security. This was an active account issue discussed at the start of the call, though the transcript does not explicitly classify the Akamai workload as storage-related. [SHI & SFG | Meeting]

Tech Profile Updates

• Customer
currently works with an MSP that provides EDR/AV and RMM services; the EDR product in question is Kaseya Datto.
• Customer
discovered during a PCI audit that Datto EDR does not generate enough logging evidence to sustainably satisfy compliance requirements.
• Previous
endpoint security platform was Sophos; customer said Sophos had strong logging, policy control, scheduling, web control, and device control, but had historically been resource-intensive.
• Microsoft path
under consideration includes Business Premium, Microsoft Defender, Intune, Entra ID, vulnerability management, Azure Log Analytics workspace integration, and possible Sentinel usage.

Meeting Notes

Environment

• External
customer environment with PCI Level 1 compliance requirements.
• MSP-managed
Datto EDR and RMM currently in place.
• Former Sophos
estate expired the previous November.
• Potential
Microsoft security expansion would rely on licensing changes plus Azure Log Analytics/Sentinel-style data handling.

Technical Notes

• Datto EDR
appears to log meaningful events primarily when something is found, and may not emit sufficient evidence when no threat is detected. This is the core compliance gap.

ROLES

• Tony Villalanti
— Commercial Inside Account Executive, SHI International Corp. Role in meeting:
SHI account lead coordinating pricing, vendor follow-up, and customer engagement.
• Manuel Zelaya —
Commercial Solutions Engineer, SHI International Corp. Role in meeting: SHI technical resource providing security/AI governance perspective and agreeing to engage a security SME.
• Mark Merritt —
SFG Network. Official title was not available in the retrieved profile data; in this transcript he acted as the customer technical/compliance stakeholder describing the environment, audit issue, and decision factors. [office.com] [office.com] [SHI & SFG | Meeting], [office.com]

Potential Next steps

• Tony Villalanti
to send/prepare Microsoft pricing for moving from the customer’s current licensing to Business Premium and to account for server protection requirements; involved: Tony Villalanti to Mark Merritt. This supports a likely follow-up review meeting on licensing/commercial comparison.
• Tony Villalanti
and Manuel Zelaya to consult a security SME and return with a recommendation on whether Microsoft or another EDR path is better, and which alternative vendors best fit the requirement; involved: Tony Villalanti, Manuel Zelaya, security SME, and likely Mark Merritt in the follow-up discussion.
• Mark Merritt to
provide refined counts or scoping details if needed, especially regarding users, endpoints, and servers; involved: Mark Merritt to Tony Villalanti. This likely leads to a pricing validation or scope-confirmation meeting.
• Tony Villalanti
to follow back up on Akamai regarding standard support coverage, the 10-hour onboarding question, and the 3% surcharge clarification; involved: Tony Villalanti to Mark Merritt, plus internal SHI approval path mentioned by Tony.
• Future optional
meeting: Manuel Zelaya offered to bring in an expert and demo AI prompt and controls; involved: Manuel Zelaya, potential AI/security specialist, and Mark Merritt
