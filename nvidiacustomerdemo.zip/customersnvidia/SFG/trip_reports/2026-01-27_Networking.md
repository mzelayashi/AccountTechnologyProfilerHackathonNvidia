Trip Report | Networking | SFG

Customer: SFG
AE: Tony V
Topic: Networking
Meeting Date 01/27/2026

*Internal notes – Please read and edit before sending externally*

Summary

The call centers on helping SFG evaluate replacement options for their aging HPE ProCurve 5400‑series switches, which support critical PCI‑scoped environments. Mark (Senior IT Manager & Information Security Co‑Leader at SFG) outlines significant operational, compliance, and lifecycle considerations: aging gear, PCI audit exposure, need for full manageability, redundancy, and adherence to stringent operational practices. Zack (SHI/HPE networking specialist) provides an extensive technical deep dive into Aruba CX switch capabilities, Aruba Central vs. Mist management, module vs. fixed‑port architectures, licensing, redundancy, and lifecycle support. Discussion also covers Fortinet as a strategic option (especially given SFG’s potential WAF project), the recent HPE acquisition of Juniper, and SFG’s desire for long‑term stability and predictable management access. Tony (SHI account rep) helps drive price‑comparison considerations, vendor‑agnostic evaluation, refurbished/renew options, and ties in adjacent infrastructure projects including a potential Fortinet WAF and upcoming server upgrades. This call heavily emphasized operational resilience, consistent CLI‑based workflows, modularity, ease of support, and future readiness (10Gb considerations, Central/Mist AI enhancements, cloud vs. on‑prem manageability). It also clarified key constraints related to PCI compliance, access rights, vendor‑managed Aruba environments, and high availability requirements for mission‑critical cardholder environments.

Agenda

• Introductions
• Review of SFG’s
existing HPE ProCurve switching environment
• Discussion of
Aruba CX chassis vs. stackable options
• Evaluation of
Fortinet and Juniper switch alternatives
• Aruba Central
& GreenLake management rights overview
• Technical
walk‑through of Aruba Central features (new vs. legacy mode)
• Planning around
port density, VLAN usage, PCI segmentation, and redundancy
• Pricing needs,
configuration guidance, and next steps

Opportunities Identified & BANTC

Opportunity 1 – Replacement of Legacy HPE ProCurve
Switches with Aruba CX 5420 (Primary)
B – Budget:
Mark is open to pricing for chassis‑based options, stackable alternatives, and refurbished HPE Renew gear. Cost sensitivity noted but willingness to invest due to compliance and operational needs.
A – Authority:
Mark holds authority for technical direction and appears to be a key decision maker on switching infrastructure. Tony and Zack support with vendor proposals.
N – Need:
• End‑of‑support
ProCurve hardware
• PCI compliance
risk if outdated switches are flagged
• Requirement for
full manageability, redundancy, high availability
• Need for
supported platform capable of modularity and fiber transceivers
T – Timeline:
Active and urgent, as PCI audits are ongoing and outdated firmware is a concern.
C – Competition:
• Aruba CX
(preferred)
• Fortinet
switches (evaluated for bundling with WAF)
• Juniper Mist
(newly HPE‑aligned)
• Cisco (desired
but cost‑prohibitive)
Opportunity 2 – Fortinet Switching Option Paired with
Web Application Firewall Project
B – Budget:
Pricing bundles may provide financial advantage. Fortinet WAF project already underway. A: Mark is involved and owns the decision. Tony is primary account rep presenting options. N: Interest in assessing switching options aligned with broader Fortinet ecosystem. T: Pending completion of bandwidth assessments for WAF project, soon. C: Aruba CX remains the leading alternative, with Juniper as a secondary competitor.
Opportunity 3 – Aruba Central Licensing, Access Rights
Cleanup, and Long‑Term Management Strategy B: Licensing for management is optional; currently paying vendor for Central access through third‑party installer. A: Mark can request full admin access and modify configuration scope. N:
• Need for direct
management (no dependency on vendor)
• Clarifying
admin rights, workspace scope, inventory visibility
• Ensuring rapid
configuration control during outages T: Near‑term, as part of the transition to new switching infrastructure. C: Juniper Mist is an alternative for cloud‑based management.

Initiatives

• Security: PCI compliance, segmentation,
Fortinet WAF alignment
• Networking / Infrastructure: Switch
replacement, Aruba Central management, modernization of data center networking
• Operations: Redundancy, HA, configuration
access, lifecycle modernization

Tech Profile Updates

• SFG operates
multiple HPE ProCurve 5412 and 5406 modular chassis with heavy VLAN usage, fiber uplinks, and POE for legacy VoIP phones.
• Aruba Wi‑Fi
environment exists but is partially vendor‑managed through a third‑party.
• Considering
Central vs. Mist long‑term, though Aruba remains preferred.
• Heavy CLI
preference due to operational efficiency.
• PCI
environments segregated into cardholder data environment, production, development, and web/API environments.

Meeting Notes

• SFG has
long‑term success with HPE ProCurve (no failures since 2008) and values modularity and lifetime warranties.
• PCI auditors
may soon flag outdated switches due to end‑of‑support firmware: urgency rising.
• Aruba CX 5420
was reviewed as a modern modular chassis option.
• Alternatives:
stackable fixed‑port Aruba CX switches (cost‑efficient), Fortinet switching (for ecosystem alignment), Juniper Mist (cloud management).
• Aruba Central’s
new vs. classic dashboard differences demonstrated.
• Key management
challenges: limited admin rights in current Wi‑Fi environment, dependency on third‑party vendor.
• CLI flow and
configuration templates shown via Central’s “multi‑edit tool.”
• Strong desire
for redundant PSUs, fans, and potentially redundant management modules.

Environment

• Multiswitch
ProCurve chassis environment with varying module configurations
• Heavy VLAN
segmentation
• Mixed POE and
fiber requirements
• PCI‑scoped
zones requiring strict separation and traffic inspection
• Aruba APs
managed via HPE GreenLake user environment
• Mix of 1Gb
endpoints with some fiber uplinks; future 10Gb readiness desired

Detailed Discussion

The team reviewed the legacy environment, including several 5412ZL chassis supporting cardholder, production, development, and web environments. Mark emphasized reliability, modularity, and rapid failover needs. Aruba CX 5420 was discussed as a suitable modern modular equivalent, while Aruba stackable CX fixed‑port switches offer cost savings but lower modular flexibility. Zack demonstrated Aruba Central’s site‑based configuration model, firmware tracking, port visibility, POE monitoring, VLAN configuration, and CLI‑focused multi‑switch editing interface. He also clarified that Aruba Central licenses are optional, and switches can be fully CLI‑managed local‑only. Fortinet switches were mentioned, especially as part of the upcoming Fortinet WAF deployment for cost synergy. Juniper Mist was discussed due to HPE’s acquisition of Juniper, offering long‑term roadmap alignment and AI‑driven dashboarding. Mark reiterated that SFG requires full control, redundancy, and the ability to make urgent configuration changes during outages—making dependence on a third‑party vendor unacceptable. The discussion closed with agreement that Tony and Zack will prepare pricing on chassis, stackable options, refurbished items, Central licensing, and Fortinet alternatives.

Technical Notes

• Modular chassis
required principally for:
– Hot‑swap blades
– Rapid cable
migration
– Fiber GBIC
ports for warehouse connectivity
– Redundant
management modules, PSUs, fans
• Aruba CX 5420
sizing: 6‑slot chassis comparable to existing 5406. No 12‑slot variant available.
• Aruba Central
notes:
– New dashboard
emphasizes AI‑driven insights and site‑based configuration.
– Legacy/classic
dashboard still available.
– Monitor‑only
mode supported (limited to show commands).
– Multiedit tool
can push CLI configuration across multiple switches.
– Firmware
management centralized with version recommendations.
• VLAN
segmentation is heavy but routing done at firewall layer.
• PCI
environments require strict segmentation and logging.
• SFG uses many
1Gb endpoints; future 10Gb is probable.
• Fiber uplinks
required for long‑distance warehouse connections.
• Redundant power
and cooling mandatory.
• Fixedport
stacking may reduce modular flexibility and rapid failover capability.
• Refurbished
“HPE Renew” gear is acceptable if still fresh inventory.
• SFG’s Aruba
Wi‑Fi login may be tied to a partner tenant; admin scope may need adjustment for direct control.

Roles of Speakers / Participants

Zack Pigott – Pre‑Sales Networking Engineer, SHI (HPE/Aruba Specialist) Tony Villalanti – SHI Account Executive Mark Merritt – Senior IT Manager & Information

Security Co‑Leader, SFG

Unknown Speaker – Internal participant (unidentified)

Potential Next Steps

• Zack → Mark & Tony:
Provide pricing for:
– Aruba CX 5420
chassis with modular options
– Redundant PSUs,
fans, management modules
– Modules for
fiber and copper
– Stackable
switch alternatives
– Aruba Central
optional licensing
– Fortinet switch
equivalents
• Mark → Tony:
Provide updated bandwidth information for the Fortinet WAF project so Tony can prepare a full quote.
• Mark → Internal / Vendor:
Investigate admin access to HPE GreenLake / Aruba Central workspace to ensure full control.
• Tony → Zack:
Share Synergy stock information (already shared), coordinate follow‑up call once pricing is ready.
• All parties:
Schedule follow‑up review meeting to compare configurations, pricing, and determine final switch architecture direction.
