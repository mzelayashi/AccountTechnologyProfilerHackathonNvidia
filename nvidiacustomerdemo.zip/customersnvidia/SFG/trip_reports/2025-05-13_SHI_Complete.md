Trip Report | SHI Complete | SFG

Customer: SFG
AE: Tony V
Topic: SHI Complete
Meeting Date 05/13/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

to coordinate technical sessions on each SHI Complete service area (support, network, security, infrastructure), tailored to SFG’s environment.

06/05

2

Tony/Manuel

Provide more details or arrange a demo of Power Automate with SharePoint for document management, and compare with Smartsheet.

06/05

Item Owner Next Steps/Detail Due Date 1 Manuel Z to coordinate technical sessions on each SHI Complete service area (support, network, security, infrastructure), tailored to SFG’s environment. 06/05 2 Tony/Manuel Provide more details or arrange a demo of Power Automate with SharePoint for document management, and compare with Smartsheet. 06/05

Summary

Summary

This discussion between Mark Merritt (SFG) and Tony Villalanti (SHI), with input from Manuel Zelaya, centered on SHI Completes managed services and how they could help SFG transition away from direct data center and IT infrastructure management. SFG is evaluating a broad transformation: moving from aging HPE switches and on-premises VMware to potentially fully managed IT services, including support, network/security/infrastructure management, and document/help desk solutions. SFG’s priorities are to reduce total IT ownership costs, avoid overbuilding, and maintain high network performance (notably on 10G VLANs). The conversation touched on practical deadlines (VMware, Sophos, Kaseya renewals), the need for flexible and phased implementation, and the desire for both technical and financial clarity before engaging SFG’s executive decision-makers. Mark also raised specific needs for document management and help desk ticketing, including access management, change history, and the ability to merge document sections for compliance and operational reasons.

Agenda

• Overview of SHI Complete service offerings (a la
carte & bundled) • Current SFG network/hardware landscape and pain points • Transition options for network, infrastructure, and support management • Deadlines for major renewals (VMware, endpoint, help desk) • Document management and help desk requirements • Next steps: technical review and planning Opps Identified & BANTC Opportunity 1: SHI Complete Managed Services (Network, Infrastructure, Support, Security)

B: Mark’s
goal is to lower IT ownership costs, shift to predictable monthly spend, and avoid overbuilding. Cost and clear forecasting are critical for buy-in.
A: Mark
leads technical evaluation; ultimate approval will come from SFG’s boss (Tony) and possibly the Treasurer.
N: SFG
needs to offload data center/infrastructure management, transition from end-of-life switches, and handle upcoming license/renewal deadlines (VMware, Sophos, Kaseya, help desk).
T: Immediate
need to make decisions by end of June (help desk), October (VMware), November (Sophos), December (Kaseya).
C: Incumbent
technologies (HPE, VMware, Palo Alto, Kaseya, Sophos). SFG open to Cisco, Juniper, or others if cost/fit is right. Considering alternatives like Proxmox for virtualization.

B: Mark’s
goal is to lower IT ownership costs, shift to predictable monthly spend, and avoid overbuilding. Cost and clear forecasting are critical for buy-in.
A: Mark
leads technical evaluation; ultimate approval will come from SFG’s boss (Tony) and possibly the Treasurer.
N: SFG
needs to offload data center/infrastructure management, transition from end-of-life switches, and handle upcoming license/renewal deadlines (VMware, Sophos, Kaseya, help desk).
T: Immediate
need to make decisions by end of June (help desk), October (VMware), November (Sophos), December (Kaseya).
C: Incumbent
technologies (HPE, VMware, Palo Alto, Kaseya, Sophos). SFG open to Cisco, Juniper, or others if cost/fit is right. Considering alternatives like Proxmox for virtualization. Opportunity 2: Document Management & Help Desk Solutions

B: Looking
for cost-effective, easy-to-use solutions (current help desk ~$2,500/year for 3 admins; Smartsheet cited at $550/user/year).
A: Mark
is technical lead; executive approval required for spend.
N: Need
for improved document management (version control, permissions, assembly of compliance docs) and better help desk/ticketing/reporting than current Kaseya Vorex.
T: Help
desk decision needed by end of June; document management is important but not a “showstopper.”
C: Current
solution is Kaseya Vorex (not preferred); alternatives like NinjaOne and Smartsheet have been considered.

B: Looking
for cost-effective, easy-to-use solutions (current help desk ~$2,500/year for 3 admins; Smartsheet cited at $550/user/year).
A: Mark
is technical lead; executive approval required for spend.
N: Need
for improved document management (version control, permissions, assembly of compliance docs) and better help desk/ticketing/reporting than current Kaseya Vorex.
T: Help
desk decision needed by end of June; document management is important but not a “showstopper.”
C: Current
solution is Kaseya Vorex (not preferred); alternatives like NinjaOne and Smartsheet have been considered.

Initiatives

Support Services: Offloading general IT support, help desk, and ticketing Network Management: Transition from end-of-life HPE to new switching (HPE/Aruba or alternatives), possibly managed by SHI

Infrastructure

Management: Hosting VMware VMs in SHI’s data center, managed services for compute/storage Security: Endpoint protection (Sophos renewal), Palo Alto firewall management, and general

security services

Document Management: Improve policy/procedure/document versioning, permissioning, and assembly

Support Services: Offloading general IT support, help desk, and ticketing Network Management: Transition from end-of-life HPE to new switching (HPE/Aruba or alternatives), possibly managed by SHI

Infrastructure

Management: Hosting VMware VMs in SHI’s data center, managed services for compute/storage Security: Endpoint protection (Sophos renewal), Palo Alto firewall management, and general

security services

Document Management: Improve policy/procedure/document versioning, permissioning, and assembly Tech Profile Updates:

Network: HPE 5412/5406 ZL switches (EOL), considering Aruba, Cisco, Juniper Firewall: Palo Alto Virtualization: VMware (renewal in October, looking for alternatives, possibly Proxmox)

Endpoint

Protection: Sophos (renewal in November) Help Desk: Kaseya Vorex (expires end of June, $2,500/year for 3 admins), considering alternatives Document Management: Current system is ad hoc; exploring Smartsheet, Power Automate/SharePoint, and other options Connectivity: 10G VLANs, high performance required Current Pain Points: Data center costs, aging hardware, managing renewals, overbuilding risk, fragmented document management

Network: HPE 5412/5406 ZL switches (EOL), considering Aruba, Cisco, Juniper Firewall: Palo Alto Virtualization: VMware (renewal in October, looking for alternatives, possibly Proxmox)

Endpoint

Protection: Sophos (renewal in November) Help Desk: Kaseya Vorex (expires end of June, $2,500/year for 3 admins), considering alternatives Document Management: Current system is ad hoc; exploring Smartsheet, Power Automate/SharePoint, and other options Connectivity: 10G VLANs, high performance required Current Pain Points: Data center costs, aging hardware, managing renewals, overbuilding risk, fragmented document management Meeting Notes:

Environment

SFG is open to a phased, modular approach to managed services (can offload support/help desk first, then network/infrastructure, etc.). Mark values historical reliability and cost-effectiveness of HPE but is open to alternatives. SFG wants to avoid being in the data center business and is considering hosting VMs with SHI. Cost forecasting and flexibility for future growth are key. Mark requires direct (not necessarily full superuser) access to managed switches for contingency.

SFG is open to a phased, modular approach to managed services (can offload support/help desk first, then network/infrastructure, etc.). Mark values historical reliability and cost-effectiveness of HPE but is open to alternatives. SFG wants to avoid being in the data center business and is considering hosting VMs with SHI. Cost forecasting and flexibility for future growth are key. Mark requires direct (not necessarily full superuser) access to managed switches for contingency.

Detailed Discussion

Mark wants to see technical overviews of each SHI service area (support, network, security, infrastructure) before involving finance/executive leadership. Timing of transitions will be driven by renewal dates and phased approach (e.g., VMware first, then endpoint, then Kaseya). Document management must support compliance, granular permissions, change history, and easy assembly of documents. Smartsheet and Power Automate/SharePoint discussed as possible document management tools; Power Automate has strong integration with SharePoint and versioning/permissions. Help desk ticketing system must support ticket management, reporting, and easy historical invoice lookup. NinjaOne was previously quoted; ticketing add-on alone was $1,200. Mark is open to SHI recommendations but wants to evaluate technically before going to bosses.

Mark wants to see technical overviews of each SHI service area (support, network, security, infrastructure) before involving finance/executive leadership. Timing of transitions will be driven by renewal dates and phased approach (e.g., VMware first, then endpoint, then Kaseya). Document management must support compliance, granular permissions, change history, and easy assembly of documents. Smartsheet and Power Automate/SharePoint discussed as possible document management tools; Power Automate has strong integration with SharePoint and versioning/permissions. Help desk ticketing system must support ticket management, reporting, and easy historical invoice lookup. NinjaOne was previously quoted; ticketing add-on alone was $1,200. Mark is open to SHI recommendations but wants to evaluate technically before going to bosses. Technical Notes:

HPE 5412/5406 ZL switches are EOL; replacements could be newer HPE/Aruba or other vendors. Hosting VMware VMs at SHI would require solid connectivity (bandwidth/latency sensitive due to 10G VLANs). Mark wants predictable monthly costs, including data growth/trending. Help desk system must allow 3+ admins, robust search/reporting, and potential for expansion. Document management must allow for controlled editing, version history, section assembly, and access control (6–12 users). Power Automate + SharePoint recommended as a cost-effective, robust option for document management. Smartsheet enterprise plan is $550/user/year (for reference). Kaseya Vorex is not preferred; NinjaOne previously quoted at $9,000 (all-in). SFG wants to maintain some access to managed switches for troubleshooting. SFG wants to “lean out” to SHI for various services but may supplement with external vendors as needed.

HPE 5412/5406 ZL switches are EOL; replacements could be newer HPE/Aruba or other vendors. Hosting VMware VMs at SHI would require solid connectivity (bandwidth/latency sensitive due to 10G VLANs). Mark wants predictable monthly costs, including data growth/trending. Help desk system must allow 3+ admins, robust search/reporting, and potential for expansion. Document management must allow for controlled editing, version history, section assembly, and access control (6–12 users). Power Automate + SharePoint recommended as a cost-effective, robust option for document management. Smartsheet enterprise plan is $550/user/year (for reference). Kaseya Vorex is not preferred; NinjaOne previously quoted at $9,000 (all-in). SFG wants to maintain some access to managed switches for troubleshooting. SFG wants to “lean out” to SHI for various services but may supplement with external vendors as needed. List of Speakers/Participants of Transcript:

Tony Villalanti (SHI) Mark Merritt (SFG, technical lead/decision-maker) Manuel Zelaya (SHI, technical advisor)

Tony Villalanti (SHI) Mark Merritt (SFG, technical lead/decision-maker) Manuel Zelaya (SHI, technical advisor) Potential

Next Steps

Technical Overviews / Deep Dives

Technical Overviews / Deep Dives

Action: SHI (Tony/Manuel) to coordinate technical sessions on each SHI Complete service area (support, network, security, infrastructure), tailored to SFG’s environment. Involved: Tony, Manuel, SHI Complete technical team, Mark Merritt

Action: SHI (Tony/Manuel) to coordinate technical sessions on each SHI Complete service area (support, network, security, infrastructure), tailored to SFG’s environment. Involved: Tony, Manuel, SHI Complete technical team, Mark Merritt

Document Management Evaluation

Document Management Evaluation

Action: SHI/Manuel to provide more details or arrange a demo of Power Automate with SharePoint for document management, and compare with Smartsheet. Involved: Manuel, Tony, Mark

Action: SHI/Manuel to provide more details or arrange a demo of Power Automate with SharePoint for document management, and compare with Smartsheet. Involved: Manuel, Tony, Mark

Help Desk/Ticketing System Options

Help Desk/Ticketing System Options

Action: SHI to provide options for help desk/ticketing (including cost breakdowns for SHI’s solution, NinjaOne, and any others). Involved: Tony, Mark

Action: SHI to provide options for help desk/ticketing (including cost breakdowns for SHI’s solution, NinjaOne, and any others). Involved: Tony, Mark

Monthly Cost Modeling & Data Growth Forecasting

Monthly Cost Modeling & Data Growth Forecasting

Action: SHI to provide example pricing models for managed hosting, infrastructure management, and data growth scenarios. Involved: Tony, SHI Complete team, Mark

Action: SHI to provide example pricing models for managed hosting, infrastructure management, and data growth scenarios. Involved: Tony, SHI Complete team, Mark

Managed Switch Access Policy Discussion

Managed Switch Access Policy Discussion

Action: SHI to clarify access policies for customer-owned vs. SHI-managed switches, ensuring Mark can maintain necessary access. Involved: Tony, SHI technical team, Mark

Action: SHI to clarify access policies for customer-owned vs. SHI-managed switches, ensuring Mark can maintain necessary access. Involved: Tony, SHI technical team, Mark

Phased Implementation Planning

Phased Implementation Planning

Action: Mark and Tony to map project phases to SFG’s renewal/expiration calendar (help desk – June, VMware – October, Sophos – November, Kaseya – December). Involved: Mark, Tony

Action: Mark and Tony to map project phases to SFG’s renewal/expiration calendar (help desk – June, VMware – October, Sophos – November, Kaseya – December). Involved: Mark, Tony

Internal SFG Review/Recommendation

Internal SFG Review/Recommendation

Action: Mark to review technical findings, prepare recommendations for SFG leadership (boss Tony, Treasurer), and identify any showstoppers before involving finance. Involved: Mark

Action: Mark to review technical findings, prepare recommendations for SFG leadership (boss Tony, Treasurer), and identify any showstoppers before involving finance. Involved: Mark

Follow-Up Meeting Scheduling

Follow-Up Meeting Scheduling

Action: Tony to schedule follow-up after technical reviews and initial cost modeling, possibly including SFG finance/leadership if technical fit is confirmed. Involved: Tony, Mark, Manuel, SHI team, SFG leadership

Action: Tony to schedule follow-up after technical reviews and initial cost modeling, possibly including SFG finance/leadership if technical fit is confirmed. Involved: Tony, Mark, Manuel, SHI team, SFG leadership
