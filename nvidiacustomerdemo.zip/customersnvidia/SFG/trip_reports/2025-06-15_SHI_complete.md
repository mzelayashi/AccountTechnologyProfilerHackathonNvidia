Trip Report | SHI complete | SFG

Customer: SFG
AE: Tony V
Topic: SHI complete
Meeting Date 06/15/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Tony/Johnathon

provide tailored pricing/options for requested features/phased adoption

05/15

2

Manuel Z

Assist customer clarify technical, compliance, and cost issues as needed

15

Item Owner Next Steps/Detail Due Date 1 Tony/Johnathon provide tailored pricing/options for requested features/phased adoption 05/15 2 Manuel Z Assist customer clarify technical, compliance, and cost issues as needed 15

Summary

This meeting served as an introductory session between SFG  and SHI’s Complete Managed Services team. SFG is a small IT shop (about 140 users), running its own data center and physical hardware, with a focus on PCI Level 1 compliance and high security. Their IT costs are high (~12% of company budget) and they want to reduce this to below 10% by outsourcing aspects of IT. SFG’s leadership, Mark Merritt and Charles Liljestrand, seek to offload day-to-day IT operations, especially help desk, network/security management, and infrastructure, to focus more on strategic initiatives. They are open to a phased, hybrid approach and are evaluating multiple MSPs. SHI’s Jonathan Barger presented the SHI Complete offering: end-to-end MSP services (user/device management, security, infrastructure, help desk, network), flexible modular packaging, premium security options, co-managed tools, and lifecycle management. SHI can support SFG’s compliance and security needs, including robust reporting for audits, infrastructure management (on-prem or cloud), and hardware/software lifecycle, with a focus on cost-efficient, cloud-first operations. SFG is interested in phased adoption to match contract renewals and may keep some specialty systems in-house (IBM Power i). Next steps include SFG specifying desired features and SHI providing tailored pricing and solution options.

Agenda

• Introductions: SHI Complete team, SFG IT leadership
• SFG overview: current IT model, pain points, compliance needs, transformation
goals • SHI Complete MSP overview: services, security/compliance, co-management, lifecycle management • Discussion of fit, options for modular/partial adoption, infrastructure/cloud roadmap • Q&A: licensing, pricing, platform flexibility, rollout options • Next steps

Opps Identified & BANTC

Opportunity 1: SFG Outsourcing IT Operations &

Security to SHI Complete MSP

• B: Budget – SFG spends ~12% of company budget on IT,
wants to reduce below 10%. Current costs are driven by compliance (PCI L1), not user count. SHI’s minimum ($100k) is within expected budget range.
• A: Authority – Mark Merritt (IT leader) and Charles
Liljestrand (virtualization/network/security) are key decision makers.
• N: Need – Reduce IT cost/overhead, offload routine
management (help desk, network, security, infrastructure), maintain/enhance PCI/SOC compliance, enable strategic focus, and support business transformation.
• T: Timeline – Phased adoption preferred to align
with existing contract anniversaries; transformation is already underway.
• C: Competition – SFG is evaluating at least two
other MSPs/vendors in parallel.
Opportunity 2: Infrastructure Modernization
(Cloud/On-Prem, Device Lifecycle, Security)
• B: Budget – Looking for options to shift from CapEx
to OpEx, open to hardware leasing, cloud, or hybrid.
• A: Authority – Mark Merritt, Charles Liljestrand
• N: Need – Modernize infrastructure, support PCI
compliance, consider migration of IBM Power i to cloud, enable efficient device lifecycle and cloud-based security controls.
• T: Timeline – Flexible; some systems (IBM Power i)
may remain on-prem/in-house for now.
• C: Competition – Internal evaluation and other
vendors.

Initiatives

Security

(PCI L1, SoC, privileged access, EDR/MDR, managed SIEM) Storage (infrastructure management, device lifecycle, cloud migration) Both

Security and Storage are relevant

Security

(PCI L1, SoC, privileged access, EDR/MDR, managed SIEM) Storage (infrastructure management, device lifecycle, cloud migration) Both

Security and Storage are relevant

Tech Profile Updates

• 140 users, small IT team, high regulatory compliance
(PCI L1) • Currently on-prem data center, physical hardware (CapEx model, staggered lifecycle) • IBM Power i midrange system remains in-house; most web hosting/dev done in-house • Considering cloud/hybrid for infrastructure and IBM workloads • RMM platform in use; open to SHI’s SentinelOne, Arctic Wolf, etc. • Heavy use of Microsoft 365; may require Business Premium or E3/E5 for compliance • Evaluating options for device lifecycle, leasing, and cloud services (Azure/AWS) • High focus on security, privileged access, logging, and PCI reporting

Meeting Notes

Environment

SFG: Small shop (140 users), running physical hardware and in-house data center PCI Level 1 service bureau, heavy compliance and security requirements High IT cost relative to revenue/user base Virtualization platform managed by Charles (VMware/Hyper-V/Proxmox) Palo Alto firewalls, network/security managed internally IBM Power i for core business, staying in-house for now RMM platform in use, but open to SHI’s stack

SFG: Small shop (140 users), running physical hardware and in-house data center PCI Level 1 service bureau, heavy compliance and security requirements High IT cost relative to revenue/user base Virtualization platform managed by Charles (VMware/Hyper-V/Proxmox) Palo Alto firewalls, network/security managed internally IBM Power i for core business, staying in-house for now RMM platform in use, but open to SHI’s stack

Detailed Discussion

Mark and Charles seek to offload routine IT work (especially help desk, network, security) to focus on strategy and transformation PCI compliance is expensive and drives much of the IT cost; SFG needs robust support for audits, privileged access, and reporting SHI Complete offers flexible, modular MSP services: help desk, infra/network/security management, managed backup, MDR/EDR, device lifecycle, with co-management and full reporting SHI Complete’s standard onboarding includes Intune/Autopilot, zero-touch deployment, policy-based management to reduce tickets and increase consistency

Infrastructure

management can be added for on-prem or cloud; SHI is cloud-agnostic and can integrate with Azure, AWS, and possibly IBM Cloud

Security

stack includes SentinelOne (EDR), Arctic Wolf (SoC), managed SIEM; privileged access, logging, and reporting included in premium package SHI One portal provides service ticketing, BI dashboards, asset tracking, spend management, and a free virtual lab for testing Minimum commitment ($100k) is in line with SFG’s expectations; SHI Complete has ~60-80 full-package customers, hundreds more using a la carte services SFG open to phased rollout, modular adoption aligned with contract renewals Co-management emphasized: SFG retains visibility and some control, SHI handles day-to-day

Mark and Charles seek to offload routine IT work (especially help desk, network, security) to focus on strategy and transformation PCI compliance is expensive and drives much of the IT cost; SFG needs robust support for audits, privileged access, and reporting SHI Complete offers flexible, modular MSP services: help desk, infra/network/security management, managed backup, MDR/EDR, device lifecycle, with co-management and full reporting SHI Complete’s standard onboarding includes Intune/Autopilot, zero-touch deployment, policy-based management to reduce tickets and increase consistency

Infrastructure

management can be added for on-prem or cloud; SHI is cloud-agnostic and can integrate with Azure, AWS, and possibly IBM Cloud

Security

stack includes SentinelOne (EDR), Arctic Wolf (SoC), managed SIEM; privileged access, logging, and reporting included in premium package SHI One portal provides service ticketing, BI dashboards, asset tracking, spend management, and a free virtual lab for testing Minimum commitment ($100k) is in line with SFG’s expectations; SHI Complete has ~60-80 full-package customers, hundreds more using a la carte services SFG open to phased rollout, modular adoption aligned with contract renewals Co-management emphasized: SFG retains visibility and some control, SHI handles day-to-day

Technical Notes

SHI Complete MSP can manage both user/device and infrastructure/network (on-prem or cloud) Supports Microsoft 365 Business Premium, E3/E5 for compliance/audit Intune/Autopilot onboarding: standardizes device deployment, reduces support tickets

Security

stack: SentinelOne (EDR), Arctic Wolf (SoC), managed SIEM, SASE, privileged access, logging Co-managed model; SFG has access to security/monitoring tools and dashboards SHI One portal: integrated ticketing, BI, spend visibility, asset/lifecycle management, virtual lab Cloud migration: SHI can advise on IBM Power i hosting, cloud-based web firewall, Azure/AWS Modular service adoption: help desk, infra, network can be enabled/disabled as needed per phase Hardware as a service/leasing options available for device lifecycle management Can integrate SHI ticketing with ServiceNow or other API-enabled systems Minimum $100k annual spend for SHI Complete

SHI Complete MSP can manage both user/device and infrastructure/network (on-prem or cloud) Supports Microsoft 365 Business Premium, E3/E5 for compliance/audit Intune/Autopilot onboarding: standardizes device deployment, reduces support tickets

Security

stack: SentinelOne (EDR), Arctic Wolf (SoC), managed SIEM, SASE, privileged access, logging Co-managed model; SFG has access to security/monitoring tools and dashboards SHI One portal: integrated ticketing, BI, spend visibility, asset/lifecycle management, virtual lab Cloud migration: SHI can advise on IBM Power i hosting, cloud-based web firewall, Azure/AWS Modular service adoption: help desk, infra, network can be enabled/disabled as needed per phase Hardware as a service/leasing options available for device lifecycle management Can integrate SHI ticketing with ServiceNow or other API-enabled systems Minimum $100k annual spend for SHI Complete List all speakers/Participants of Transcript:

Mark Merritt (SFG, IT lead) Charles Liljestrand (SFG, virtualization/network/security) Tony Villalanti (SHI Account Team) Jonathan Barger (SHI, Managed Services Solutions Engineer) Manuel Zelaya

Mark Merritt (SFG, IT lead) Charles Liljestrand (SFG, virtualization/network/security) Tony Villalanti (SHI Account Team) Jonathan Barger (SHI, Managed Services Solutions Engineer) Manuel Zelaya

Potential Next Steps

SFG to specify which features/modules they want included in SHI Complete proposal

SFG to specify which features/modules they want included in SHI Complete proposal

Action: Mark Merritt/Charles Liljestrand to review SHI Complete offerings, identify must-haves (help desk, infra, network, security, device lifecycle, reporting, etc.) Owner: Mark Merritt, Charles Liljestrand (to Jonathan Barger/Tony Villalanti/SHI)

Action: Mark Merritt/Charles Liljestrand to review SHI Complete offerings, identify must-haves (help desk, infra, network, security, device lifecycle, reporting, etc.) Owner: Mark Merritt, Charles Liljestrand (to Jonathan Barger/Tony Villalanti/SHI)

SHI to provide tailored pricing/options for requested features/phased adoption

SHI to provide tailored pricing/options for requested features/phased adoption

Action: Jonathan Barger to assemble modular pricing for selected services, clarify onboarding/migration details, and provide documentation/case studies Owner: Jonathan Barger (to Mark Merritt, Charles Liljestrand, Tony Villalanti)

Action: Jonathan Barger to assemble modular pricing for selected services, clarify onboarding/migration details, and provide documentation/case studies Owner: Jonathan Barger (to Mark Merritt, Charles Liljestrand, Tony Villalanti)

SFG and SHI to coordinate phased rollout plan aligned with contract anniversaries and internal staffing

SFG and SHI to coordinate phased rollout plan aligned with contract anniversaries and internal staffing

Action: Tony Villalanti to facilitate roadmap discussion, ensure modular onboarding Owner: Tony Villalanti (to Mark Merritt, Charles Liljestrand, Jonathan Barger)

Action: Tony Villalanti to facilitate roadmap discussion, ensure modular onboarding Owner: Tony Villalanti (to Mark Merritt, Charles Liljestrand, Jonathan Barger)

SHI to arrange technical deep-dive/call with architect for IBM Power i/cloud migration and compliance specifics

SHI to arrange technical deep-dive/call with architect for IBM Power i/cloud migration and compliance specifics

Action: Jonathan Barger to schedule session with SHI architect as needed Owner: Jonathan Barger (to Mark Merritt, Charles Liljestrand)

Action: Jonathan Barger to schedule session with SHI architect as needed Owner: Jonathan Barger (to Mark Merritt, Charles Liljestrand)

Demo of SHI One portal, ticketing, and lifecycle management for SFG team

Demo of SHI One portal, ticketing, and lifecycle management for SFG team

Action: Jonathan Barger to coordinate demo session Owner: Jonathan Barger (to Mark Merritt, Charles Liljestrand, Tony Villalanti)

Action: Jonathan Barger to coordinate demo session Owner: Jonathan Barger (to Mark Merritt, Charles Liljestrand, Tony Villalanti)

Ongoing Q&A: SFG to send any follow-up questions; SHI to clarify technical, compliance, and cost issues as needed

Ongoing Q&A: SFG to send any follow-up questions; SHI to clarify technical, compliance, and cost issues as needed

Action: Both parties Owner: Mark Merritt, Charles Liljestrand, Jonathan Barger, Tony Villalanti

Action: Both parties Owner: Mark Merritt, Charles Liljestrand, Jonathan Barger, Tony Villalanti
