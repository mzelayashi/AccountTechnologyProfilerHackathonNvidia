Trip Report | HPE Greenlake | SFG

Customer: SFG
AE: Tony V
Topic: HPE Greenlake
Meeting Date 04/11/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

Send Cloud Physics scan to gather detailed information on SFG's current infrastructure.

05/03

2

Tony V

Schedule a meeting for late April to review Cloud Physics results and discuss HPE's solutions in more detail.

05/03

Item Owner Next Steps/Detail Due Date 1 Manuel Z Send Cloud Physics scan to gather detailed information on SFG's current infrastructure. 05/03 2 Tony V Schedule a meeting for late April to review Cloud Physics results and discuss HPE's solutions in more detail. 05/03

Summary

Summary

The meeting focused on discussing SFG's server and virtualization needs, with a particular interest in exploring HPE's GreenLake solutions as a potential alternative to their current VMware setup. SFG is considering shifting from a CapEx to an OpEx model and is open to solutions that can enhance performance while being cost-effective. The conversation highlighted SFG's dissatisfaction with VMware post-Broadcom acquisition and their interest in exploring other virtualization platforms like Proxmox. The team discussed HPE's offerings, including GreenLake's flexibility, storage solutions, and how they can potentially address SFG's current bottlenecks and future scalability needs.

Agenda

Introduction and Purpose of Meeting Overview of SFG's Current Infrastructure and Challenges Discussion on HPE's GreenLake and Other Solutions Consideration of OpEx vs. CapEx Models Next Steps and Action Items

Introduction and Purpose of Meeting Overview of SFG's Current Infrastructure and Challenges Discussion on HPE's GreenLake and Other Solutions Consideration of OpEx vs. CapEx Models Next Steps and Action Items

Opportunities Identified & BANTC

Opportunity 1: Adoption of HPE
GreenLake for Virtualization and Storage

Opportunity 1: Adoption of HPE
GreenLake for Virtualization and Storage

B: Need
to replace aging infrastructure and improve virtualization capabilities.
A: Mark
Merritt, Senior IT Manager; Charles Liljestrand, Senior Systems Administrator.
N: Immediate,
with a decision needed by Q3 to implement changes by October.
T: Evaluation
of cost-effectiveness compared to current VMware setup.
C: Interest
in solutions that offer better performance, scalability, and fit within budget constraints.

B: Need
to replace aging infrastructure and improve virtualization capabilities.
A: Mark
Merritt, Senior IT Manager; Charles Liljestrand, Senior Systems Administrator.
N: Immediate,
with a decision needed by Q3 to implement changes by October.
T: Evaluation
of cost-effectiveness compared to current VMware setup.
C: Interest
in solutions that offer better performance, scalability, and fit within budget constraints.

Initiatives

Storage: Exploring HPE's GreenLake for both storage and virtualization as a potential holistic solution.

Storage: Exploring HPE's GreenLake for both storage and virtualization as a potential holistic solution.

Tech Profile Updates

Current infrastructure includes Dell servers and Nimble storage, with VMware for virtualization. Interest in moving away from VMware due to dissatisfaction with Broadcom's management.

Current infrastructure includes Dell servers and Nimble storage, with VMware for virtualization. Interest in moving away from VMware due to dissatisfaction with Broadcom's management.

Meeting Notes

Environment

SFG's current setup consists of three physical Dell servers and Nimble storage arrays. The organization is undergoing a transformation, realigning business lines and technology infrastructure.

SFG's current setup consists of three physical Dell servers and Nimble storage arrays. The organization is undergoing a transformation, realigning business lines and technology infrastructure.

Detailed Discussion

HPE's GreenLake: Discussed the flexibility of GreenLake in offering both OpEx and CapEx models. Emphasized its ability to integrate with existing infrastructure and provide a scalable solution. Performance Bottlenecks: SFG is experiencing performance issues with older servers, particularly those with Silver processors, and is interested in upgrading to Gold processors. Cloud vs. On-Prem: SFG is open to cloud solutions but remains cautious about cost implications compared to on-prem deployments.

HPE's GreenLake: Discussed the flexibility of GreenLake in offering both OpEx and CapEx models. Emphasized its ability to integrate with existing infrastructure and provide a scalable solution. Performance Bottlenecks: SFG is experiencing performance issues with older servers, particularly those with Silver processors, and is interested in upgrading to Gold processors. Cloud vs. On-Prem: SFG is open to cloud solutions but remains cautious about cost implications compared to on-prem deployments.

Technical Notes

HPE's GreenLake allows for a shared everything architecture, separating performance nodes from capacity nodes. The solution supports both block and NAS connectivity and can scale up to exabyte levels.

HPE's GreenLake allows for a shared everything architecture, separating performance nodes from capacity nodes. The solution supports both block and NAS connectivity and can scale up to exabyte levels. List all speakers/Participants of Transcript:

Tony Villalanti Combs, Austin Mark Merritt Charles Liljestrand Fawcett, Scott Manuel Zelaya

Tony Villalanti Combs, Austin Mark Merritt Charles Liljestrand Fawcett, Scott Manuel Zelaya

Potential Next Steps

Cloud Physics Setup:

Cloud Physics Setup:

Set up a Cloud Physics scan to gather detailed information on SFG's current infrastructure. Action by Charles Liljestrand, coordinated with Scott Fawcett and Manuel Zelaya.

Set up a Cloud Physics scan to gather detailed information on SFG's current infrastructure. Action by Charles Liljestrand, coordinated with Scott Fawcett and Manuel Zelaya.

Follow-up Meeting:

Follow-up Meeting:

Schedule a meeting for late April to review Cloud Physics results and discuss HPE's solutions in more detail. Action by Tony Villalanti, involving all participants.

Schedule a meeting for late April to review Cloud Physics results and discuss HPE's solutions in more detail. Action by Tony Villalanti, involving all participants.

Internal Review:

Internal Review:

Mark Merritt and Charles Liljestrand to review internal requirements and define key metrics for the new solution. Action by Mark Merritt and Charles Liljestrand.

Mark Merritt and Charles Liljestrand to review internal requirements and define key metrics for the new solution. Action by Mark Merritt and Charles Liljestrand.
