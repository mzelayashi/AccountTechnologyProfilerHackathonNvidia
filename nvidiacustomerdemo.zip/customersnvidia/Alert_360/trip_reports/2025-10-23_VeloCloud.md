Trip Report | VeloCloud | Alert 360

Customer: Alert 360
AE: David Hamilton
Topic: VeloCloud
Meeting Date 10/23/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

David H

Add advanced support to 3400’s and engage services team for migration

10/23/2024

Item Owner Next Steps/Detail Due Date 1 David H Add advanced support to 3400’s and engage services team for migration 10/23/2024

Summary

The meeting focused on VMware VeloCloud deployment for Alert 360, with a primary objective to streamline their migration process and ensure minimal downtime. The discussion highlighted the need for advanced support and strategic planning sessions. David will spearhead the efforts by engaging the services team and adding advanced support options. The migration aims to be efficient, with a targeted cutover time to minimize disruptions. Customer Technical Environment Notes:

VMware VeloCloud implementation Emphasis on cloud migration efficiency Requirement for minimal downtime

VMware VeloCloud implementation Emphasis on cloud migration efficiency Requirement for minimal downtime

Agenda

Discuss VMware VeloCloud deployment Plan migration strategy Address support requirements

Discuss VMware VeloCloud deployment Plan migration strategy Address support requirements

Opps Identified & BANTC

[NEW]
Opportunity 1: Advanced Support for 3400’s
B: Existing
relationship with Alert 360
A: David
will manage advanced support addition
N: Need
for robust support during migration
T: Immediate
addition of support to quotes
C: George
and Jose available for assistance

[NEW]
Opportunity 1: Advanced Support for 3400’s
B: Existing
relationship with Alert 360
A: David
will manage advanced support addition
N: Need
for robust support during migration
T: Immediate
addition of support to quotes
C: George
and Jose available for assistance

Initiatives

Focus on Secure Cloud Migration

Focus on Secure Cloud Migration

Tech Profile Updates

Addition of 1 and 3-year advanced support for VMware VeloCloud

Addition of 1 and 3-year advanced support for VMware VeloCloud

Meeting Notes

David to add advanced support to quotes Engagement with services team for migration

David to add advanced support to quotes Engagement with services team for migration

Detailed Discussion Notes

Two planning sessions proposed for effective communication and migration execution Migration cutover planned for 10:30 PM to ensure minimal downtime

Two planning sessions proposed for effective communication and migration execution Migration cutover planned for 10:30 PM to ensure minimal downtime List all speakers/Participants

David George Jose

David George Jose
