Trip Report | SD-WAN Velocloud | Alert 360

Customer: Alert 360
AE: David H
Topic: SD-WAN Velocloud
Meeting Date 10/21/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

D Hamilton

arrange with SHI or third-party services Plan and support transition from 840 to 3400.

10/29/24

2

D Hamilton

rovide quotes for 1-year and 3-year advanced support. Compare costs and align with existing Palo Alto services.

10/29/24

3

Dan Marchewka

George Shih’s support by set up planning sessions for transition logistics and testing.

11/1/24

Item Owner Next Steps/Detail Due Date 1 D Hamilton arrange with SHI or third-party services Plan and support transition from 840 to 3400. 10/29/24 2 D Hamilton rovide quotes for 1-year and 3-year advanced support. Compare costs and align with existing Palo Alto services. 10/29/24 3 Dan Marchewka George Shih’s support by set up planning sessions for transition logistics and testing. 11/1/24

Summary

The conversation involved Dan Marchewka, George Shih, David Hamilton, and Kevin Egger discussing the replacement and upgrade of SD-WAN infrastructure, specifically transitioning from 840 to 3400 devices. The discussion centered around the technical aspects, project planning, and potential issues related to the deployment of new hubs and redundancy solutions. They also considered using SD-WAN instead of traditional firewalls for redundancy at a disaster recovery site. Issues such as licensing, support, maintenance, and potential professional services were addressed. The call concluded with action items for professional services and support quotes. Technical Notes:

3400 devices support up to 10 gig ports. Bandwidth licensing flexibility under Broadcom. Recommendations to use 5.2 firmware for stability and bug fixes. Integration challenges with new VPN client post-Broadcom acquisition.

3400 devices support up to 10 gig ports. Bandwidth licensing flexibility under Broadcom. Recommendations to use 5.2 firmware for stability and bug fixes. Integration challenges with new VPN client post-Broadcom acquisition.

Agenda

Replacement of end-of-life SD-WAN devices. Setting up a new DR site in Orlando. Discussion on redundancy and backup solutions. Licensing and support structures. Professional services and transition planning.

Replacement of end-of-life SD-WAN devices. Setting up a new DR site in Orlando. Discussion on redundancy and backup solutions. Licensing and support structures. Professional services and transition planning.

Opportunities

Identified & BANTC: Opportunity 1: Upgrade from 840 to 3400 [NEW]

B: Need
to replace end-of-life 840 devices.
A: Dan
Marchewka, decision maker for infrastructure upgrades.
N: Transition
without downtime, maintain connectivity for critical sites.
T: Immediate,
within the next 6-9 months.
C: Budget
considerations for new equipment and services.

B: Need
to replace end-of-life 840 devices.
A: Dan
Marchewka, decision maker for infrastructure upgrades.
N: Transition
without downtime, maintain connectivity for critical sites.
T: Immediate,
within the next 6-9 months.
C: Budget
considerations for new equipment and services. Opportunity 2: Implementing SD-WAN at DR Site [NEW]

B: Establish
redundancy and backup communication.
A: Dan
Marchewka, with input from IT team.
N: Ensure
continuity in case of failure at primary site.
T: Align
with DR site setup Q4 Discussion
C: Cost-effective
alternative to traditional firewalls, pending approval from management.

B: Establish
redundancy and backup communication.
A: Dan
Marchewka, with input from IT team.
N: Ensure
continuity in case of failure at primary site.
T: Align
with DR site setup Q4 Discussion
C: Cost-effective
alternative to traditional firewalls, pending approval from management.

Initiatives

Security evaluating SD-WAN capabilities

for redundancy and as a potential firewall replacement.

Security evaluating SD-WAN capabilities

for redundancy and as a potential firewall replacement. Tech Profile Updates:

Transition from 840 to 3400 devices, which offer higher throughput and additional ports. Introduction of a new DR site with potential SD-WAN deployment.

Transition from 840 to 3400 devices, which offer higher throughput and additional ports. Introduction of a new DR site with potential SD-WAN deployment. Meeting Notes:

Environment

Current setup involves 840 devices that are reaching end-of-life. New DR site planned for Orlando with considerations for redundancy and minimal downtime.

Current setup involves 840 devices that are reaching end-of-life. New DR site planned for Orlando with considerations for redundancy and minimal downtime. Detailed Discussion:

Considerations for transitioning from 840 to 3400 with minimal disruption. Technical capabilities and differences between 3400 and higher models like 3800. Discussion on client VPN solutions and their integration.

Considerations for transitioning from 840 to 3400 with minimal disruption. Technical capabilities and differences between 3400 and higher models like 3800. Discussion on client VPN solutions and their integration. List of Speakers/Participants:

Dan Marchewka George Shih David Hamilton Kevin Egger

Dan Marchewka George Shih David Hamilton Kevin Egger
