Trip Report | Locuz Cisco Network | GetixHealth

Customer: GetixHealth
AE: Felix M
Topic: Locuz Cisco Network
Meeting Date 10/03/2025

*Internal notes – Please read and edit before sending externally*

Summary

The meeting focused on supporting a healthcare revenue cycle management company’s expansion in India, specifically the transition to larger office spaces in Bangalore and Delhi. Monty Tan outlined the need for new networking infrastructure, emphasizing Cisco/Meraki solutions, strict data residency requirements, and a phased approach to deployment. SHI and Locus (now part of SHI) presented managed networking and IT services, highlighting cost efficiency, local expertise, and global support capabilities. The discussion covered equipment sizing, managed services, cabling, and deployment logistics, with a strong emphasis on compliance, scalability, and operational independence from previous BPO arrangements.

Agenda

• Overview of customer’s business model and office
expansion
• Requirements for new networking infrastructure
• Introduction to Locus managed services and SHI’s
India capabilities
• Discussion of equipment sizing, cabling, and
deployment phases
• Data residency and compliance considerations
• Next steps and action items

Opps Identified & BANTC

Opportunity 1: Networking
Infrastructure Refresh for New Bangalore Office
• B: Need for new route/switch infrastructure for
600-seat office, replacing legacy BPO-owned equipment
• A: Decision-makers are Monty Tan and their IT team;
SHI and Locus are vendors
• N: Urgent, as lease ends March 2026 and transition
must be completed within 2-3 months post-vacate
• T: Budgetary pricing required immediately for
planning; phased approach for procurement and deployment
• C: Compliance with Indian data laws, preference for
local vendors, Cisco/Meraki only, no data offshoring
Opportunity 2: Managed Services &
Cabling Deployment
• B: Need for managed switch services, cabling,
desktop drops, and possible device deployment
• A: Monty Tan to evaluate SHI/Locus proposals; Felix
and Manuel to provide recommendations
• N: Immediate for equipment sizing; subsequent phases
for cabling and deployment
• T: Initial model numbers needed ASAP, full proposal
and pricing to follow
• C: Must align with healthcare data security, local
compliance, and operational independence

Initiatives

• Security: Focus on network security, firewall
(Meraki MX, possible FTD), restricted Wi-Fi access, compliance with Indian encryption laws
• Storage: Not explicitly discussed; file sharing and
domain controllers mentioned but not as a storage initiative

Tech Profile Updates

• Transition from BPO-managed infrastructure to
in-house Cisco/Meraki networking
• Two 500 Mbps fiber circuits with scalability to 1
Gbps each
• MDF/IDF architecture with fiber interconnects,
supporting 600 endpoints plus auxiliary devices
• Strict data residency and security controls; minimal
Wi-Fi usage

Meeting Notes

Environment

• Healthcare revenue cycle management company with 9
US offices, 2 in India
• Bangalore office moving to a new 600-seat space;
Delhi office expanding slightly
• Previous BPO arrangement being replaced with direct
management and local HR/IT

Detailed Discussion

• Monty described the business context, office
layouts, and transition timelines
• SHI/Locus presented managed networking, security,
and IT operations services, emphasizing cost savings and local expertise
• Monty requested Cisco/Meraki-only solutions, with a
preference for rack switches over chassis for maintainability
• Discussion of MDF/IDF design, fiber connectivity,

endpoint counts, and auxiliary device support

• Wi-Fi to be restricted to select staff for security
reasons
• Data residency and compliance with Indian law are
critical; no data offshoring
• Action items include equipment sizing, cabling
proposals, and phased deployment planning

Technical Notes

• MDF/IDF setup: Each closet serves ~300 endpoints
plus ~100 auxiliary devices (sensors, cameras, printers)
• Fiber interconnects between MDF and IDF; minimum
10Gb, option for 40Gb considered
• Meraki MX firewall at MDF, possible FTD addition
• Two 500 Mbps fiber circuits, scalable to 1 Gbps,
handed off to MX for telemetry and monitoring
• Preference for standard rack switches over Cisco
9400 chassis for easier maintenance and break/fix
• Wi-Fi limited to ~10 users (managers/directors);
most staff on wired connections
• Need for cabling, desktop drops, and device
deployment as part of managed services
• Existing HPE servers (domain controllers, file
share) to be migrated; all other infrastructure to be new
• Compliance with Indian encryption laws and avoidance
of data offshoring

ROLES

• Monty Tan – Customer (Healthcare revenue cycle
management)
• Manuel Zelaya – Vendor (SHI)
• Felix Menchaca – Vendor (SHI)

Potential Next steps

• Felix to set up a follow-up meeting for equipment
sizing and model recommendations (requested by Monty to Felix)
• Manuel and Felix to provide high-level Cisco/Meraki
model numbers to Monty by Monday for budgetary planning
• Monty to send office layout PDFs to Felix and Manuel
for more accurate sizing
• Manuel to share Locus capabilities slide deck with
Monty for internal review
• Manuel to work over the weekend to compile
recommendations and follow up next week
• Monty to handle initial budgetary pricing once model
numbers are received
• Further meetings to be scheduled for cabling,
deployment, and managed services proposals as phases progress

Trip Report | SHI| GettixHealth Internal Sync

CRM Link:   https://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=f2dc68ea-71c9-e311-b71a-005056a70048

Customer

AE

Topic

District

Meeting Date

GetixHealth

Felix

Sync

TOLA1

10/06

*Internal notes – Please read and edit before sending
externally*

Summary

• The meeting focused on designing a network
infrastructure for a customer site in India, addressing requirements for scalability, redundancy, security, and future-proofing. The team discussed options for firewalls, switches, Wi-Fi, IoT sensors, and security cameras, emphasizing Meraki solutions and Cisco Catalyst switches. Key business aspects included ensuring compatibility for future bandwidth upgrades, supporting multi-gigabit connectivity, and handling international logistics for hardware delivery and implementation. The conversation also covered licensing models, video retention options, and the need for clear port counts and connectivity details. The team explored leveraging internal and partner resources for on-premises installation and management, with attention to commission structures and freight forwarding for international shipments.

Agenda

infrastructure

• Discuss hardware options (firewalls, switches,
Wi-Fi, cameras, IoT)
• Clarify technical specifications and redundancy
needs
• Address implementation and management services,
especially for India
• Plan next steps and action items

Opps Identified & BANTC

Opportunity 1: Network Infrastructure
Deployment for India Site
• B: Customer needs scalable, redundant, and
future-proof network infrastructure (firewalls, switches, Wi-Fi, cameras, IoT sensors)
• A: Decision-makers are present (Felix, Manuel,
Michael, Greg) and actively discussing requirements and solutions
• N: Urgent need to finalize hardware specs,
licensing, and implementation plan for upcoming deployment
• T: Timeline is short; Michael aims to deliver an
estimate by end of day, with follow-up meetings planned
• C: Budget considerations discussed (multi-year
licensing discounts, freight forwarding costs, commission splits)
Opportunity 2: Implementation &
Management Services for India Site
• B: Customer requires on-premises installation and
ongoing management, especially for international locations
• A: Felix and Manuel are coordinating with Greg to
identify SHI/Stratoscale/Locus resources for India
• N: Need to confirm service provider capabilities and
commission structure for international work
• T: Felix to submit sales request form and set up
internal sync with Locus team; response expected within hours
• C: Cost and commission split concerns discussed;
freight forwarding logistics considered

Initiatives

• Security: Firewall deployment, perimeter security,
Meraki cameras, video retention
• Storage: Camera video retention (cloud and onboard),
IoT sensor data
• Both: Network infrastructure supports both security
and storage needs

Tech Profile Updates

• Meraki firewalls with redundancy
• Cisco Catalyst 9300 and 9200 switches (core and
edge), 48-port, 40Gb uplinks, modular options
• Wi-Fi 6/6E access points (admin-only, 1Gb ports)
• IoT sensors (temperature, humidity, PoE-powered)
• Meraki security cameras (PoE, cloud/onboard
retention, 15 units as ballpark)
• Layer 3 at core, Layer 2 at edge/IDF
• International logistics: freight forwarding,
SHI/Locus/Stratoscale services for India

Meeting Notes

Environment

• Customer site in Bangalore, India
• Network design for scalability, redundancy, and
future upgrades
• Hardware to be shipped from US via freight
forwarding

Detailed Discussion

• Felix confirmed need for compatibility with future
1Gb+ bandwidth upgrades
• Michael proposed firewalls supporting up to 2Gb
traffic, with redundancy
• Switch stack to include three 48-port switches with
40Gb uplinks and redundant power
• Manuel noted requirement for switch redundancy, but
port count still needs clarification
• Wi-Fi 6/6E APs for admin use only, likely no need
for multi-gig ports
• Michael suggested 9300s for core, 9200s for edge,
but 9200s only support up to 10Gb uplinks; 9300s needed for 40Gb
• Security cameras: Meraki flavor, 15 units,
PoE-powered, cloud/onboard retention options
• IoT sensors: temperature/humidity, PoE-powered
• Licensing: 3-year preferred for cost savings
• Implementation: Locus/Stratoscale/SHI services for
on-prem work in India; freight forwarding logistics discussed
• Commission split concerns for international deals
• Felix to follow up with ASG and Locus for
implementation services
• Greg provided guidance on shipping and service
provider contacts

Technical Notes

• Firewalls must support up to 2Gb traffic and be
redundant
• Switches: 48-port, 40Gb uplinks, modular uplink
options, stacked for redundancy
• 9300s required for 40Gb uplinks; 9200s only support
up to 10Gb unless M-gig version is used
• Wi-Fi APs: Wi-Fi 6/6E, 1Gb ports, admin-only use,
minimal bandwidth needs
• Security cameras: Meraki, PoE, cloud/onboard
retention, 15 units as estimate
• IoT sensors: temperature/humidity, PoE-powered
• Licensing: 3-year term preferred for all
hardware/software
• Layer 3 at core, Layer 2 at edge/IDF
• Freight forwarding from US warehouse to India; SHI
international sales alias to coordinate
• Implementation services: Locus/Stratoscale/SHI
resources, sales request form to be submitted
• Commission split and cost considerations for
international deals

ROLES

• Michael Munoz – SHI Cisco SA Team
• Manuel Zelaya –
• Felix Menchaca –
• Greg Miller –

Potential Next steps

• Michael to send estimate and hardware options to
Manuel and Felix by end of day
• Manuel to clarify port count and connectivity
details with customer
• Felix to follow up with ASG and Locus for
implementation services in India
• Felix to submit Locus sales request form and set up
internal sync with Locus team
• Greg to provide freight forwarding contact/alias to
Felix and Manuel
• Manuel to follow up with Michael regarding
secondary/satellite site requirements
• Michael to reach out to Manuel for any outstanding
clarifications (port count, camera/IoT specs)
• Felix, Manuel, Greg to coordinate on commission
structure and logistics for international deployment

Trip Report | SHI| GettixHealth Internal Sync

CRM Link:   https://shi.crm.dynamics.com/main.aspx?appid=39a3350e-9fea-4717-8c1c-fe61a1be0652&pagetype=entityrecord&etn=account&id=f2dc68ea-71c9-e311-b71a-005056a70048

Customer

AE

Topic

District

Meeting Date

GetixHealth

Felix

Sync

TOLA1

10/06

*Internal notes – Please read and edit before sending
externally*

Summary

• The meeting focused on designing a network
infrastructure for a customer site in India, addressing requirements for scalability, redundancy, security, and future-proofing. The team discussed options for firewalls, switches, Wi-Fi, IoT sensors, and security cameras, emphasizing Meraki solutions and Cisco Catalyst switches. Key business aspects included ensuring compatibility for future bandwidth upgrades, supporting multi-gigabit connectivity, and handling international logistics for hardware delivery and implementation. The conversation also covered licensing models, video retention options, and the need for clear port counts and connectivity details. The team explored leveraging internal and partner resources for on-premises installation and management, with attention to commission structures and freight forwarding for international shipments.

Agenda

infrastructure

• Discuss hardware options (firewalls, switches,
Wi-Fi, cameras, IoT)
• Clarify technical specifications and redundancy
needs
• Address implementation and management services,
especially for India
• Plan next steps and action items

Opps Identified & BANTC

Opportunity 1: Network Infrastructure
Deployment for India Site
• B: Customer needs scalable, redundant, and
future-proof network infrastructure (firewalls, switches, Wi-Fi, cameras, IoT sensors)
• A: Decision-makers are present (Felix, Manuel,
Michael, Greg) and actively discussing requirements and solutions
• N: Urgent need to finalize hardware specs,
licensing, and implementation plan for upcoming deployment
• T: Timeline is short; Michael aims to deliver an
estimate by end of day, with follow-up meetings planned
• C: Budget considerations discussed (multi-year
licensing discounts, freight forwarding costs, commission splits)
Opportunity 2: Implementation &
Management Services for India Site
• B: Customer requires on-premises installation and
ongoing management, especially for international locations
• A: Felix and Manuel are coordinating with Greg to
identify SHI/Stratoscale/Locus resources for India
• N: Need to confirm service provider capabilities and
commission structure for international work
• T: Felix to submit sales request form and set up
internal sync with Locus team; response expected within hours
• C: Cost and commission split concerns discussed;
freight forwarding logistics considered

Initiatives

• Security: Firewall deployment, perimeter security,
Meraki cameras, video retention
• Storage: Camera video retention (cloud and onboard),
IoT sensor data
• Both: Network infrastructure supports both security
and storage needs

Tech Profile Updates

• Meraki firewalls with redundancy
• Cisco Catalyst 9300 and 9200 switches (core and
edge), 48-port, 40Gb uplinks, modular options
• Wi-Fi 6/6E access points (admin-only, 1Gb ports)
• IoT sensors (temperature, humidity, PoE-powered)
• Meraki security cameras (PoE, cloud/onboard
retention, 15 units as ballpark)
• Layer 3 at core, Layer 2 at edge/IDF
• International logistics: freight forwarding,
SHI/Locus/Stratoscale services for India

Meeting Notes

Environment

• Customer site in Bangalore, India
• Network design for scalability, redundancy, and
future upgrades
• Hardware to be shipped from US via freight
forwarding

Detailed Discussion

• Felix confirmed need for compatibility with future
1Gb+ bandwidth upgrades
• Michael proposed firewalls supporting up to 2Gb
traffic, with redundancy
• Switch stack to include three 48-port switches with
40Gb uplinks and redundant power
• Manuel noted requirement for switch redundancy, but
port count still needs clarification
• Wi-Fi 6/6E APs for admin use only, likely no need
for multi-gig ports
• Michael suggested 9300s for core, 9200s for edge,
but 9200s only support up to 10Gb uplinks; 9300s needed for 40Gb
• Security cameras: Meraki flavor, 15 units,
PoE-powered, cloud/onboard retention options
• IoT sensors: temperature/humidity, PoE-powered
• Licensing: 3-year preferred for cost savings
• Implementation: Locus/Stratoscale/SHI services for
on-prem work in India; freight forwarding logistics discussed
• Commission split concerns for international deals
• Felix to follow up with ASG and Locus for
implementation services
• Greg provided guidance on shipping and service
provider contacts

Technical Notes

• Firewalls must support up to 2Gb traffic and be
redundant
• Switches: 48-port, 40Gb uplinks, modular uplink
options, stacked for redundancy
• 9300s required for 40Gb uplinks; 9200s only support
up to 10Gb unless M-gig version is used
• Wi-Fi APs: Wi-Fi 6/6E, 1Gb ports, admin-only use,
minimal bandwidth needs
• Security cameras: Meraki, PoE, cloud/onboard
retention, 15 units as estimate
• IoT sensors: temperature/humidity, PoE-powered
• Licensing: 3-year term preferred for all
hardware/software
• Layer 3 at core, Layer 2 at edge/IDF
• Freight forwarding from US warehouse to India; SHI
international sales alias to coordinate
• Implementation services: Locus/Stratoscale/SHI
resources, sales request form to be submitted
• Commission split and cost considerations for
international deals

ROLES

• Michael Munoz – SHI Cisco SA Team
• Manuel Zelaya –
• Felix Menchaca –
• Greg Miller –

Potential Next steps

• Michael to send estimate and hardware options to
Manuel and Felix by end of day
• Manuel to clarify port count and connectivity
details with customer
• Felix to follow up with ASG and Locus for
implementation services in India
• Felix to submit Locus sales request form and set up
internal sync with Locus team
• Greg to provide freight forwarding contact/alias to
Felix and Manuel
• Manuel to follow up with Michael regarding
secondary/satellite site requirements
• Michael to reach out to Manuel for any outstanding
clarifications (port count, camera/IoT specs)
• Felix, Manuel, Greg to coordinate on commission
structure and logistics for international deployment
