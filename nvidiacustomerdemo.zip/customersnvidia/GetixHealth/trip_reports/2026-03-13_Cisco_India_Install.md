Trip Report | Cisco India Install | GetixHealth

Customer: GetixHealth
AE: Felix M
Topic: Cisco India Install
Meeting Date 03/13/2026

*Internal notes – Please read and edit before sending externally*

Summary

This meeting focused on final alignment between GetixHealth (customer), SHI (partner), and Cisco India (vendor) regarding the upcoming India office buildout and technology deployment. The primary objective was to validate and finalize the networking and collaboration Bill of Materials (BOM/BOQ), confirm licensing coverage, identify remaining gaps, and ensure timeline feasibility relative to construction and go‑live goals. Key business drivers included avoiding delays caused by incorrect BOM versions, managing long‑lead hardware (notably Cisco Catalyst 9300/9500 series), and ensuring that licensing—particularly Webex device registration—was already covered under existing enterprise agreements to avoid unnecessary spend. The customer emphasized the importance of speed, accuracy, and minimizing rework, given multiple prior revisions and tight timelines. Operationally, the discussion reinforced a two‑phase approach: vendors submit best pricing first without deal registration, followed by deal registration once final quantities are confirmed. The call also addressed logistics constraints (manufacturing, transit, customs), local construction dependencies, and coordination challenges caused by file‑sharing and access restrictions.

Agenda

• Review and
confirm latest Networking and Collaboration BOM
• Validate Cisco
licensing requirements and coverage
• Discuss lead
times and delivery risks
• Align on
deployment timelines relative to construction
• Identify next
steps and ownership across parties

Opportunities Identified & BANTC

Opportunity 1: Cisco Networking & Collaboration
Deployment – India Office
B: Budget
• Budget exists
and is approved in principle
• Pricing
optimization required before deal registration
• No incremental
licensing spend anticipated for Webex device registration
A: Authority
• Customer IT
leadership (GetixHealth) is driving decisions
• Vendor and
partner teams are aligned on scope and process
N: Need
• New India
office requires full networking and collaboration stack
• Need to avoid
single points of failure and ensure redundancy
• Accurate BOM
critical to prevent deployment delays
T: Timeline
• Target go‑live
aligned with July timeframe
• Hardware must
be delivered by mid‑June to support rack, stack, and cabling
• Quotes and
award expected by end of week following the call
C: Competition
• Cisco is the
selected platform
• Competition
exists only at the pricing and fulfillment level, not technology selection

Initiatives

• Category: Networking and Collaboration
• New office

infrastructure deployment

• Enterprise
collaboration expansion (Webex endpoints and control)

Tech Profile Updates

• Cisco Catalyst
switching (9300 and 9500 series)
• Wi‑Fi 7 access
points (updated from prior Wi‑Fi 6 models)
• Cisco Webex
devices and Contact Center
• Existing Cisco
Webex Enterprise Agreement in place
• Centralized
aggregation switches added to remove single points of failure

Meeting Notes

Environment

• New India
office buildout
• Construction
handled by local landlord/technology provider
• Passive cabling
and data drops included in construction scope
• Active
networking and collaboration provided by Cisco via SHI

Detailed Discussion

The customer highlighted ongoing issues caused by multiple BOM revisions and stressed that the version shared during the call should be treated as the most current. Networking quantities were increased, wireless models were upgraded to Wi‑Fi 7, and aggregation switches were added at the top‑of‑rack layer to eliminate single points of failure. Licensing was reviewed in detail, with confirmation that existing Webex device registration licenses (633) exceed actual device counts, eliminating the need for additional purchases. Collaboration licensing was confirmed to fall under the existing enterprise agreement. Lead time discussions identified the Cisco Catalyst 9300 series as the longest‑lead component, with approximately 28 days manufacturing time plus additional transit and customs buffers. Despite geopolitical and logistics concerns, all parties agreed the July go‑live target remains achievable if ordering proceeds promptly. File‑sharing challenges using Teams and OneDrive were raised as a blocker, prompting the

Technical Notes

• Wi‑Fi model
updated from prior generation to Wi‑Fi 7
• Wireless AP
quantity increased from earlier BOM versions
• Cisco Catalyst
9500 fiber switches added as top‑of‑rack aggregation
• Aggregation
switches connect downstream access switch stacks
• Design
eliminates single points of failure at rack level
• Existing Webex
device registration licenses total 633
• No additional
Webex licensing required
• Collaboration
includes Webex and Webex Contact Center
• Not an EA for
all components, but collaboration licenses are enterprise‑covered
• Lead time: ~28
days manufacturing + 3–4 weeks transit + customs buffer
• Hardware
delivery deadline: mid‑June
• Rack, stack,
fiber, and copper cross‑connects begin post‑delivery
• Construction
estimated under 90 days, likely closer to 60–75 days List all speakers / Participants (ROLES):
• Monty Tan – Customer IT Lead, GetixHealth
• Felix Menchaca – Solutions Engineer / Partner
Representative, SHI
• Prithviraj G – Account / Program Lead, Cisco
India
• Prashanth JK – Technical Engineer, Cisco India
• Saquib Aslam – Licensing Specialist, Cisco
• Pradeep Jacob – Cisco Engineering / Local
Support
• Pratik Sen – Cisco Team Member

Potential Next Steps

• Cisco India (Prithviraj / Team):
– Deliver final
pricing quotes based on latest BOM
– Confirm lead
times for Catalyst 9300 and related components
• SHI (Felix):
– Review incoming
quotes
– Turn pricing
quickly back to customer
– Coordinate
internal alignment and vendor follow‑ups
• GetixHealth (Monty):
– Confirm final
quantities once quotes are received
– Proceed with
vendor selection and deal registration
– Share updated
Gantt timeline once construction dates are finalized
• All Parties:
– Use Webex/email
for document sharing to avoid access issues
– Schedule
follow‑up meetings as needed for final award and deployment planning
