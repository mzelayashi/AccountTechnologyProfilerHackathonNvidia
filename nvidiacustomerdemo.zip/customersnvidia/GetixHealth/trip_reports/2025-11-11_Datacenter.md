Trip Report | Datacenter | GetixHealth

Customer: GetixHealth
AE: Manuel Z
Topic: Datacenter
Meeting Date 11/11/2025

*Internal notes – Please read and edit before sending externally*

Summary

The meeting focused on GetixHealth’s expansion in India, specifically relocating from the current Concentrix office in Bangalore to a new facility with increased capacity (from 350 to 600–700 seats). The discussion covered:

Business Drivers: Acquisition by a PE firm emphasizing India growth, need for larger office space, and strategic hiring ramp-up. Project Scope: Full office build-out including cubicles, MDF/IDF setup, fiber interconnects, cabling, racks, and network infrastructure. Procurement Strategy: Debate on sourcing equipment locally in India vs. importing from the U.S., considering customs, taxation, and ROI. Vendor Engagement: SHI India introduced capabilities beyond Cisco BOQ—end-user computing, staffing, and managed services. Timeline: Move-in targeted between March and June, with phased migration before lease expiration in June. Challenges: Strict DLP policies for file sharing, discrepancies in BOQ, and need for optimized configurations. Technical Considerations: Fiber capacity, Meraki sensors, firewall throughput, AP heat mapping, and compatibility with Panduit for cable management.

Business Drivers: Acquisition by a PE firm emphasizing India growth, need for larger office space, and strategic hiring ramp-up. Project Scope: Full office build-out including cubicles, MDF/IDF setup, fiber interconnects, cabling, racks, and network infrastructure. Procurement Strategy: Debate on sourcing equipment locally in India vs. importing from the U.S., considering customs, taxation, and ROI. Vendor Engagement: SHI India introduced capabilities beyond Cisco BOQ—end-user computing, staffing, and managed services. Timeline: Move-in targeted between March and June, with phased migration before lease expiration in June. Challenges: Strict DLP policies for file sharing, discrepancies in BOQ, and need for optimized configurations. Technical Considerations: Fiber capacity, Meraki sensors, firewall throughput, AP heat mapping, and compatibility with Panduit for cable management.

Agenda

Introductions and overview of SHI India capabilities. Discussion on new Bangalore office build-out requirements. Review of BOQ and sourcing strategy. Timeline and project management approach.

Next steps for deal

registration and technical validation.

Introductions and overview of SHI India capabilities. Discussion on new Bangalore office build-out requirements. Review of BOQ and sourcing strategy. Timeline and project management approach.

Next steps for deal

registration and technical validation.

Opportunities Identified & BANTC

Opportunity 1: Bangalore Office Build-Out

B (Budget): Decision pending; cost optimization through local sourcing vs. U.S. procurement discussed. A (Authority): Monty Tan (decision influencer), finance team for final sourcing decision. N (Need): Full turnkey solution for office build-out, network infrastructure, and cabling. T (Timeline): March–June 2026 for phased migration. C (Competition): Existing local project manager (Kranti) and other vendors; SHI India positioned as competitive alternative.

B (Budget): Decision pending; cost optimization through local sourcing vs. U.S. procurement discussed. A (Authority): Monty Tan (decision influencer), finance team for final sourcing decision. N (Need): Full turnkey solution for office build-out, network infrastructure, and cabling. T (Timeline): March–June 2026 for phased migration. C (Competition): Existing local project manager (Kranti) and other vendors; SHI India positioned as competitive alternative.
Opportunity 2: Cisco Network Deployment

B: Pricing yet to be
finalized; deal registration required for discounts.
A: Monty Tan and Felix
coordinating; Cisco India team involvement.
N: High-capacity switches
(40Gb uplinks), Meraki integration, firewall sizing.
T: Align with office build-out
timeline.
C: Competing Cisco partners;
need for early DR/OIP submission.

B: Pricing yet to be
finalized; deal registration required for discounts.
A: Monty Tan and Felix
coordinating; Cisco India team involvement.
N: High-capacity switches
(40Gb uplinks), Meraki integration, firewall sizing.
T: Align with office build-out
timeline.
C: Competing Cisco partners;
need for early DR/OIP submission.
Opportunity 3: Staffing & Managed Services

B: Not discussed in detail;
implied cost advantage via SHI India’s payroll model.
A: Monty Tan open to exploring
staffing for rapid scale-up.
N: Skilled resources for IT
operations and support.
T: Post-build-out, ongoing
support.
C: Local staffing vendors.

B: Not discussed in detail;
implied cost advantage via SHI India’s payroll model.
A: Monty Tan open to exploring
staffing for rapid scale-up.
N: Skilled resources for IT
operations and support.
T: Post-build-out, ongoing
support.
C: Local staffing vendors.

Initiatives

Security: Firewall sizing, Meraki sensors, DLP compliance. Storage: Not explicitly discussed; implied in rack/server build-out. Networking: Core initiative—fiber interconnects, AP heat mapping, switch configurations.

Security: Firewall sizing, Meraki sensors, DLP compliance. Storage: Not explicitly discussed; implied in rack/server build-out. Networking: Core initiative—fiber interconnects, AP heat mapping, switch configurations.

Tech Profile Updates

Preference for Panduit for patch panels and cable management. Cisco Meraki for network and sensors. Limited Wi-Fi access for security; desktops prioritized. MDF/IDF with 4–6 fiber pairs for redundancy and growth.

Preference for Panduit for patch panels and cable management. Cisco Meraki for network and sensors. Limited Wi-Fi access for security; desktops prioritized. MDF/IDF with 4–6 fiber pairs for redundancy and growth.

Meeting Notes

Monty emphasized “single throat to choke” for accountability. SHI India showcased broader capabilities (EUC, staffing). BOQ discrepancies flagged by Prashanth; optimization suggested. Heat mapping proposed to validate AP count. Power adapter availability for Meraki sensors in India noted as a challenge.

Monty emphasized “single throat to choke” for accountability. SHI India showcased broader capabilities (EUC, staffing). BOQ discrepancies flagged by Prashanth; optimization suggested. Heat mapping proposed to validate AP count. Power adapter availability for Meraki sensors in India noted as a challenge.

Environment

Current: Concentrix office, 350 seats. Future: New Bangalore office, 600–700 seats, full build-out. Strict DLP and cybersecurity policies for file sharing.

Current: Concentrix office, 350 seats. Future: New Bangalore office, 600–700 seats, full build-out. Strict DLP and cybersecurity policies for file sharing.

Detailed Discussion

Procurement: Local sourcing preferred for ROI; customs and taxation hurdles highlighted. Technical Scope: Cabling, racks, fiber interconnects, dual drops, BOM for network gear. Timeline: Ramp-up hiring before June; phased migration. Vendor Strategy: SHI India to provide case studies and references (e.g., AT&T project). Competitive Edge: Early DR/OIP submission critical for Cisco opportunity.

Procurement: Local sourcing preferred for ROI; customs and taxation hurdles highlighted. Technical Scope: Cabling, racks, fiber interconnects, dual drops, BOM for network gear. Timeline: Ramp-up hiring before June; phased migration. Vendor Strategy: SHI India to provide case studies and references (e.g., AT&T project). Competitive Edge: Early DR/OIP submission critical for Cisco opportunity.

Technical Notes

MDF/IDF with 4–6 fiber pairs for scalability. Cisco switches: 40Gb uplinks required; Meraki integration. Firewall sizing concerns for user load; MX105 questioned. Meraki MT10 sensors: Power adapters unavailable in India; alternative sourcing needed. Heat mapping recommended for AP placement; initial estimate of 10 APs likely insufficient. Limited Wi-Fi scope due to security; desktops dominate. Rack stack and cable dressing included in scope. Preference for Panduit for cable management and patch panels.

MDF/IDF with 4–6 fiber pairs for scalability. Cisco switches: 40Gb uplinks required; Meraki integration. Firewall sizing concerns for user load; MX105 questioned. Meraki MT10 sensors: Power adapters unavailable in India; alternative sourcing needed. Heat mapping recommended for AP placement; initial estimate of 10 APs likely insufficient. Limited Wi-Fi scope due to security; desktops dominate. Rack stack and cable dressing included in scope. Preference for Panduit for cable management and patch panels.

ROLES

Potential Next Steps

Monty → Felix: Share updated BOQ and finalize deal registration within 24 hours. Felix → SHI India Team: Send floor plans and preliminary notes for review. Prashanth → Felix: Optimize BOQ, suggest model changes (e.g., 9300 vs.
9200), include fiber modules.
Felix → Cisco Rep: Submit OIP for teaming approval. SHI India → Felix: Provide case studies and references (AT&T example). Monty → Team: Schedule next call with Kranti for formal introduction and scope alignment. Manuel Zelaya: Oversee SHI india to conduct heat mapping and validate AP count; prepare recommendations. Prashanth → Felix: Request site address and contact details for DR submission.

Monty → Felix: Share updated BOQ and finalize deal registration within 24 hours. Felix → SHI India Team: Send floor plans and preliminary notes for review. Prashanth → Felix: Optimize BOQ, suggest model changes (e.g., 9300 vs.
9200), include fiber modules.
Felix → Cisco Rep: Submit OIP for teaming approval. SHI India → Felix: Provide case studies and references (AT&T example). Monty → Team: Schedule next call with Kranti for formal introduction and scope alignment. Manuel Zelaya: Oversee SHI india to conduct heat mapping and validate AP count; prepare recommendations. Prashanth → Felix: Request site address and contact details for DR submission.
