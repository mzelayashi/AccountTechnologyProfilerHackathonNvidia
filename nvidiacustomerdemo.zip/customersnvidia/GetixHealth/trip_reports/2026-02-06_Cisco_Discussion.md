Trip Report | Cisco Discussion | GetixHealth

Customer: GetixHealth
AE: Felix M
Topic: Cisco Discussion
Meeting Date 02/06/2026

*Internal notes – Please read and edit before sending externally*

Summary

This was a complex, multi‑party technical and commercial working session between the customer (GetixHealth), vendor (Cisco), and partner (SHI) focused on design validation, bill of materials (BOM) correction, infrastructure readiness, and deployment planning for a new India call‑center facility. The call addressed network architecture decisions, security posture, WAN and ISP termination, switching and stacking design, wireless access strategy, firewall placement, and peripheral standardization for a large‑scale end‑user environment running Chrome OS Flex and Windows. Significant time was spent identifying gaps and errors in the existing BOM, confirming hardware quantities, clarifying stacking, power, optics, and WAN switching requirements, and aligning on deployment responsibilities between the customer, SHI India delivery teams, and Cisco. From a business standpoint, the meeting reinforced a hard go‑live deadline, highlighted budget sensitivity tied to timeline risk, and surfaced procurement and sourcing challenges, particularly around docking stations and peripherals compatible with Chrome OS Flex in India. The outcome was a clear alignment on next actions, ownership, and parallel workstreams across design correction, sourcing, pricing, and execution readiness to support an aggressive operational launch.

Agenda

• Review and
validate current network and security design
• Walk through
and correct Cisco BOM discrepancies
• Confirm WAN,
ISP, firewall, and switching architecture
• Validate
wireless deployment approach and security posture
• Review
conferencing and room technology assumptions
• Discuss
end‑user device, docking, and peripheral compatibility
• Align on
sourcing strategy (India vs US)
• Establish
timelines, go‑live targets, and accountability
• Define next
steps and ownership

Opportunities Identified & BANTC

Opportunity 1: New India Call Center Network &

Security Infrastructure

B (Budget): Budget exists but is tightly linked to schedule adherence. Additional spend may be required if timelines slip. Executive awareness and urgency confirmed. A (Authority): Customer technical leadership (IT infrastructure and architecture) holds decision authority, with procurement flowing through corporate channels. N (Need): Full greenfield deployment including WAN, switching, wireless, firewalls, racks, power, cabling, and security controls to support a secure call‑center environment. T (Timeline): Target operational readiness by mid‑May with hard business go‑live by early June. No flexibility beyond that without financial impact. C (Competition): No direct competitor mentioned; focus is on execution risk, sourcing availability, and lead times rather than vendor displacement.
Opportunity 2: End‑User Compute & Peripheral
Standardization (Chrome OS Flex) B (Budget): Defined but under pressure due to quantity corrections and sourcing challenges. A (Authority): Customer IT leadership and operations jointly approve standards. N (Need): Reliable, Chrome OS Flex‑compatible docking stations, keyboards, mice, headsets, and cables at scale. T (Timeline): Must align with facility readiness; sourcing delays directly threaten go‑live. C (Competition): Multiple vendors evaluated; very limited options confirmed as compatible.

Initiatives

• Security: Network segmentation, firewall
termination, SD‑WAN, VLAN mapping, restricted wireless coverage
• Infrastructure: Switching, WAN, wireless,
racks, cabling, power
• End‑User Computing: Chrome OS Flex and Windows
deployment standardization Classification: Security and Infrastructure (Primary), End‑User Computing (Secondary)

Tech Profile Updates

• Transition from
MPLS to dual DIA with additional Equinix connectivity
• Firewalls
terminate WAN directly with added WAN switch requirement
• Catalyst
switching with stacked access architecture
• Meraki
firewalls with SD‑WAN licensing
• Chrome OS Flex
as primary endpoint OS for call‑center users
• Windows for
supervisors and management roles

Meeting Notes

Environment

• New India
office, greenfield deployment
•
Call‑center‑centric design with high endpoint density
• Secure wireless
only in controlled management zones
• Mixed endpoint
OS environment (Chrome OS Flex and Windows)

Detailed Discussion

• Confirmed Wi‑Fi
will not blanket the entire call‑center floor due to security requirements
• Access points
limited to management and controlled areas
• CAD drawings
required to finalize AP placement
• Shift from
original WAN design due to addition of Equinix circuit
• Identified need
for an additional WAN switch not previously included
• Validated
access switch stacking model and corrected stack counts
• Identified
incorrect quantities for power supplies, stacking cables, and uplink modules
• Clarified fiber
vs copper ISP handoff assumptions
• Reviewed
firewall port utilization and 10G requirements
• Confirmed rack
types, rack counts, and power outlet standards
• Identified
missing patch panels, patch cables, and passive infrastructure scope
• Reviewed room
collaboration equipment quantities and adjusted assumptions
• Flagged major
compatibility issues with non‑approved docking stations
• Confirmed only
specific docking stations work reliably with Chrome OS Flex
• Discussed
sourcing challenges in India and parallel US sourcing paths
• Reinforced hard
operational deadlines tied to business readiness

Technical Notes

• Dual DIA
circuits plus Equinix connectivity
• WAN termination
primarily on firewalls with added L2 WAN switch
• Catalyst 9300
series access switches
• Stacked access
layer design across MDF and IDF
• 10G and 25G
uplinks required at aggregation/core
• VLAN and IP
mappings to be provided by customer
• No WiFi
coverage across full call‑center floor
• Meraki
firewalls with SD‑WAN licensing (one‑year initially)
• Power stacking
and redundant PSUs required on all switches
• Corrected
stacking cable lengths (.5m and 3m as needed)
• Fiber
terminations require passive cabling support
• Racks: closed,
two‑post, 42U confirmed
• Standard
three‑pin power outlets preferred
• UPS handled
under separate procurement
• Chrome OS Flex
compatibility excludes many common docks
• Thunderbolt 4
USB‑C cables required
• Docking
stations must be fixed, multi‑port (not passive hubs)
• Peripheral
quantities revised upward to match headcount
• Monitor
quantities corrected for dual‑monitor setups List of Speakers / Participants (Roles Only)
• Customer –

Infrastructure Architect

• Customer – IT
Leadership
• Customer –
Operations / Deployment Lead
• Partner –
Solutions Engineer
• Partner –
Account Executive
• Partner – India
Delivery Team Lead
• Vendor –
Networking Architect
• Vendor –

Security Specialist

• Vendor –
Collaboration Specialist

Potential Next Steps

• Customer Infrastructure Lead → Partner & Vendor:
Provide finalized CAD drawings for AP placement
