Trip Report | Network Visibility | GetixHealth

Customer: GetixHealth
AE: Felix M
Topic: Network Visibility
Meeting Date 06/14/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

Engage internal and partner engineering resources to validate if any further latency improvements or architectural changes are feasible.

07/05

2

Felix

follow up with Avant and other partners; report findings to Getix and SHI team.SHI to provide consultative support for new Indian office site selection based on provider coverage and circuit quality.

07/05

Item Owner Next Steps/Detail Due Date 1 Manuel Z Engage internal and partner engineering resources to validate if any further latency improvements or architectural changes are feasible. 07/05 2 Felix follow up with Avant and other partners; report findings to Getix and SHI team.SHI to provide consultative support for new Indian office site selection based on provider coverage and circuit quality. 07/05

Summary

The discussion between Getix Health Network (represented by Monty Tan) and SHI (including Felix Menchaca, Regan Kingsbury, and Matthew Bracy) focused on persistent latency challenges experienced by Getix's India BPO operations when accessing critical healthcare applications hosted in the U.S. The network architecture is designed around strict compliance needs (HIPAA, PCI, PHI) and leverages Citrix farms in Louisville, KY, accessed by around 700 BPO users in India. Recent changes in BGP routes by global MPLS providers (Verizon, AT&T) have increased latency to levels that approach the threshold of Citrix usability. Multiple vendors (Equinix, Alkira, AWS, etc.) have been evaluated, but the problem is largely considered a “physics” and regulatory constraint. The group explored whether there are alternative interconnects or application publishing technologies that might improve user experience. SHI offered to leverage their service provider group and partner (Avant) to survey more connectivity options, and Getix expressed interest in exploring new office locations in India based on provider availability and possible lighter alternatives to Citrix (such as Google Kameo). No immediate technical solution was identified, but multiple next steps and action items were agreed upon.

Agenda

• Understand Getix's network and application delivery
architecture for India BPO operations
• Review latency challenges and constraints
(compliance, regulatory, physical, and provider limitations)
• Discuss approaches tried so far (vendors,
architectures, optimizations)
• Explore potential SHI/Avant assistance for new
provider/circuit options
• Consider alternatives to Citrix for remote
application delivery
• Establish action items and next steps

Opportunities Identified & BANTC

Opportunity 1: Optimizing/Improving International
Connectivity for India BPO

B: Getix
Health Network needs to reduce latency for 700+ India BPO users accessing U.S.-hosted healthcare applications, as higher latency is impacting productivity and potentially endangering application usability.
A: Monty
Tan and IT leadership; final decision may involve compliance and executive management.
N: High
— latency is at the upper threshold of Citrix tolerance; further increases
could disrupt operations.
T: Immediate/short-term;
issues are already present, and Getix is seeking alternatives proactively.
C: Budget
is not explicitly discussed, but the urgency and scope suggest willingness to invest in viable solutions.

B: Getix
Health Network needs to reduce latency for 700+ India BPO users accessing U.S.-hosted healthcare applications, as higher latency is impacting productivity and potentially endangering application usability.
A: Monty
Tan and IT leadership; final decision may involve compliance and executive management.
N: High
— latency is at the upper threshold of Citrix tolerance; further increases
could disrupt operations.
T: Immediate/short-term;
issues are already present, and Getix is seeking alternatives proactively.
C: Budget
is not explicitly discussed, but the urgency and scope suggest willingness to invest in viable solutions.
Opportunity 2: Assessment of Application Delivery
Alternatives (Citrix vs. Others)

B: Interest
in exploring lighter, more efficient alternatives to Citrix (e.g., Google Kameo) to improve user experience and possibly reduce latency impact.
A: Monty
Tan; likely requires broader IT consensus and compliance review.
N: Medium
— Citrix is still the preferred/known solution, but alternatives are being
considered as part of continuous improvement.
T: Medium-term;
active research underway but not an emergency need.
C: Not
specified; likely open to pilot/PoC investment.

B: Interest
in exploring lighter, more efficient alternatives to Citrix (e.g., Google Kameo) to improve user experience and possibly reduce latency impact.
A: Monty
Tan; likely requires broader IT consensus and compliance review.
N: Medium
— Citrix is still the preferred/known solution, but alternatives are being
considered as part of continuous improvement.
T: Medium-term;
active research underway but not an emergency need.
C: Not
specified; likely open to pilot/PoC investment.
Opportunity 3: Data Center/Office Location Selection
Advisory

B: Getix
is relocating its India BPO office and needs advice on site selection based on connectivity and provider access.
A: Monty
Tan and facilities/IT leadership.
N: Moderate
— driven by expiring lease and need to maintain connectivity.
T: Near-term;
site search is underway.
C: Not
specified; more consultative/advisory opportunity.

B: Getix
is relocating its India BPO office and needs advice on site selection based on connectivity and provider access.
A: Monty
Tan and facilities/IT leadership.
N: Moderate
— driven by expiring lease and need to maintain connectivity.
T: Near-term;
site search is underway.
C: Not
specified; more consultative/advisory opportunity.

Initiatives

• Security: HIPAA/PHI/PCI compliance, endpoint
lockdown, and secure application access
• Storage: Not discussed directly
• Networking/Connectivity: International WAN
optimization and interconnect provider selection
• Application Delivery: Evaluation of Citrix, Google
Kameo, and other application publishing methods

Tech Profile Updates

• Primary U.S. data center: Flexential (Louisville,
KY), moving to North Las Vegas
• India BPO users access U.S. apps via Citrix (Chrome
OS Flex endpoints, highly restricted, no local data)
• Key providers: Verizon, AT&T (MPLS), Equinix,
Alkira, AWS, Tata in India
• Endpoint strategy: Chrome OS Flex, URL
allow-listing, local wipe on logout
• Monitoring: SolarWinds via Concentrix, reports
provided to Getix
• Considering Google Kameo as alternative to Citrix

Meeting Notes

Environment

• 9 U.S. offices, 2 India offices (Bangalore, Delhi)
• India offices operated as BPO, ~700 users in 2 main
shifts
• Citrix farm in U.S. (Louisville, KY) is primary
application hub
• Traffic from India is backhauled over MPLS to U.S.
for compliance reasons
• Chrome OS Flex endpoints with strict security
controls

Detailed Discussion

Latency has historically been 220–230ms, now 235–242ms due to provider BGP changes; Citrix starts to degrade above 237ms. All India traffic is forced through Citrix for HIPAA/PHI/PCI; no local data or credit card processing in India. Chrome OS Flex endpoints are used for their manageability and security; all local data is wiped on logout, and internet access is tightly allow-listed. Multiple providers (Equinix, AWS, Alkira, AT&T, Verizon) evaluated; all face same limitations due to physics/geography and regulatory landscape (India market dominated by Tata). SHI (via Avant partnership) to explore additional circuit/provider options, possibly outside current provider shortlist. Discussion on application delivery alternatives: Citrix is currently lightest/most secure, but exploring new options like Google Kameo. Getix is planning to relocate Indian BPO office and may seek advice from SHI on best connected location. SHI team to follow up with additional research and internal resources.

Latency has historically been 220–230ms, now 235–242ms due to provider BGP changes; Citrix starts to degrade above 237ms. All India traffic is forced through Citrix for HIPAA/PHI/PCI; no local data or credit card processing in India. Chrome OS Flex endpoints are used for their manageability and security; all local data is wiped on logout, and internet access is tightly allow-listed. Multiple providers (Equinix, AWS, Alkira, AT&T, Verizon) evaluated; all face same limitations due to physics/geography and regulatory landscape (India market dominated by Tata). SHI (via Avant partnership) to explore additional circuit/provider options, possibly outside current provider shortlist. Discussion on application delivery alternatives: Citrix is currently lightest/most secure, but exploring new options like Google Kameo. Getix is planning to relocate Indian BPO office and may seek advice from SHI on best connected location. SHI team to follow up with additional research and internal resources.

Technical Notes

Citrix used for secure app delivery (no VPN, no local data, all apps run in U.S. data center). Chrome OS Flex endpoints: No copy/paste, screenshots, or local saves URL allow-list (20 URLs), all else blocked Wipe profile on logout for endpoint hygiene SolarWinds monitoring via Concentrix; Getix receives regular circuit performance reports. BGP changes by AT&T/Verizon raised latency; no provider has materially improved upon 220–230ms baseline. Equinix offers Mumbai-to-Singapore or AZ West drop, with Singapore at 208ms average (best observed). Alkira's SDN control plane not effective as hoped; relies on same backbones as others, no unique optimization. SHI's mapping tools (Atlas) recently changed, now require deeper navigation to see fiber/circuit options. Tata Communications has ~80% market share for Indian international circuits. Google Kameo (new, Google Cloud-backed application publishing) under consideration. Office move: Getix last tenant in current tech park; seeking new space.

Citrix used for secure app delivery (no VPN, no local data, all apps run in U.S. data center). Chrome OS Flex endpoints: No copy/paste, screenshots, or local saves URL allow-list (20 URLs), all else blocked Wipe profile on logout for endpoint hygiene SolarWinds monitoring via Concentrix; Getix receives regular circuit performance reports. BGP changes by AT&T/Verizon raised latency; no provider has materially improved upon 220–230ms baseline. Equinix offers Mumbai-to-Singapore or AZ West drop, with Singapore at 208ms average (best observed). Alkira's SDN control plane not effective as hoped; relies on same backbones as others, no unique optimization. SHI's mapping tools (Atlas) recently changed, now require deeper navigation to see fiber/circuit options. Tata Communications has ~80% market share for Indian international circuits. Google Kameo (new, Google Cloud-backed application publishing) under consideration. Office move: Getix last tenant in current tech park; seeking new space. List all speakers/Participants of Transcript:

Monty Tan (Getix Health Network) Felix Menchaca (SHI) Regan Kingsbury (SHI) Matthew Bracy (SHI)

Monty Tan (Getix Health Network) Felix Menchaca (SHI) Regan Kingsbury (SHI) Matthew Bracy (SHI)

Potential Next Steps

Matthew Bracy (SHI) to reach out to provider contacts (including Avant) to identify any alternative circuit/interconnect options for Getix’s India BPO offices.

Matthew Bracy (SHI) to reach out to provider contacts (including Avant) to identify any alternative circuit/interconnect options for Getix’s India BPO offices.

Action: Matthew Bracy to Action: Monty Tan to send shortlist of candidate locations to SHI once available; SHI team (incl. Regan Kingsbury, Matthew Bracy) to advise using Atlas and other mapping tools.

Action: Matthew Bracy to Action: Monty Tan to send shortlist of candidate locations to SHI once available; SHI team (incl. Regan Kingsbury, Matthew Bracy) to advise using Atlas and other mapping tools.

Getix to consider Google Kameo and possibly other emerging application publishing technologies as alternatives to Citrix.

Getix to consider Google Kameo and possibly other emerging application publishing technologies as alternatives to Citrix.

Action: Monty Tan to pilot or further research Kameo; SHI to provide technical briefings or connect with Google resources if needed.

Action: Monty Tan to pilot or further research Kameo; SHI to provide technical briefings or connect with Google resources if needed.

SHI to engage internal and partner engineering resources to validate if any further latency improvements or architectural changes are feasible.

SHI to engage internal and partner engineering resources to validate if any further latency improvements or architectural changes are feasible.

Action: Felix Menchaca, Regan Kingsbury to consult with engineering and report back to Monty Tan.

Action: Felix Menchaca, Regan Kingsbury to consult with engineering and report back to Monty Tan.

Both parties to reconvene after SHI completes provider research and internal discussions.

Both parties to reconvene after SHI completes provider research and internal discussions.

Action: Felix Menchaca to coordinate scheduling of next meeting with Monty Tan and relevant SHI resources.

Action: Felix Menchaca to coordinate scheduling of next meeting with Monty Tan and relevant SHI resources.
