Trip Report | Fine Tuning AI | GetixHealth

Customer: GetixHealth
AE: Felix M
Topic: Fine Tuning AI
Meeting Date 02/05/2026

*Internal notes – Please read and edit before sending externally*

Summary

This call focused on evaluating and shaping a Fine‑Tuning as a Service engagement for GetixHealth, with broader discussion around their AI maturity, data science posture, and adjacent AI initiatives. The primary business objective is to help GetixHealth improve the efficiency, accuracy, and scalability of an existing AI/ML model that was originally developed internally but now suffers from limited data science capacity, unstructured data challenges, and lack of continuous optimization. From a business standpoint, the customer is undergoing a significant transformation toward automation, AI-driven operations, and digital-first workflows, including workforce reduction in favor of AI bots. The discussion clarified that Fine‑Tuning as a Service is positioned as pure data science work, not full data engineering, with scope boundaries around model optimization, algorithm assessment, feature engineering evaluation, and performance iteration. Cost drivers, timelines, and resource models were discussed in depth, highlighting that engagements are typically iterative, outcome-driven, and variable in length, depending on business value derived from incremental model improvements. Additional AI initiatives (Copilot, agents, automation, analytics) were acknowledged but intentionally deprioritized for this engagement to avoid scope creep.

Agenda

Align on customer expectations for Fine‑Tuning as a Service Understand current AI/ML model ownership and architecture Define scope boundaries between data science vs data engineering Discuss cost drivers, engagement duration, and staffing model Identify adjacent AI

opportunities without expanding current scope

Align on next steps and scheduling follow‑up with senior data scientists

Align on customer expectations for Fine‑Tuning as a Service Understand current AI/ML model ownership and architecture Define scope boundaries between data science vs data engineering Discuss cost drivers, engagement duration, and staffing model Identify adjacent AI

opportunities without expanding current scope

Align on next steps and scheduling follow‑up with senior data scientists

Opportunities Identified & BANTC

Opportunity 1: Fine‑Tuning as a Service (Primary
Opportunity) B (Budget): Budget is variable and dependent on engagement length, number of senior data scientists involved, and business value of incremental accuracy improvements. Rates discussed align with senior data scientist market rates (high three‑digit hourly range). A (Authority): Customer technical authority includes Monty (original model author) and executive stakeholders driving AI-first transformation. Business alignment appears strong. N (Need):

Existing ML model requires efficiency improvements Limited internal data science resources Model performance impacted by unstructured and poorly categorized data Need for expert validation of current algorithms and feature engineering

Existing ML model requires efficiency improvements Limited internal data science resources Model performance impacted by unstructured and poorly categorized data Need for expert validation of current algorithms and feature engineering T (Timeline): Initial engagement expected to be minimum 3–4 weeks, with potential to extend based on iteration results and ROI. C (Competition): Internal-only optimization is not viable due to staffing gaps. External vendors or alternative consulting firms are implied but not named.
Opportunity 2: Data Engineering & Data
Classification (Adjacent, Separate Scope) B (Budget): Not defined; acknowledged as a separate engagement requiring additional resources. A (Authority):

Initiatives

Fine‑Tuning as a Service
– Storage & Data (Primary)
AI Automation / Bots / RPA – Both Security & Storage (Future) Microsoft Copilot & AI Agents – Security & Storage (Future)

Fine‑Tuning as a Service
– Storage & Data (Primary)
AI Automation / Bots / RPA – Both Security & Storage (Future) Microsoft Copilot & AI Agents – Security & Storage (Future)

Tech Profile Updates

Meeting Notes

Environment

AI/ML model focused on classification, anomaly detection, and predictive outcomes Data sources include structured and unstructured datasets Model performance impacted by data quality and feature relevance No standardized ML lifecycle tooling (MLflow/Qflow) confirmed

AI/ML model focused on classification, anomaly detection, and predictive outcomes Data sources include structured and unstructured datasets Model performance impacted by data quality and feature relevance No standardized ML lifecycle tooling (MLflow/Qflow) confirmed

Detailed Discussion

Fine‑Tuning as a Service defined as pure data science engagement, not infrastructure or pipeline build Engagement involves reviewing algorithms (LSTM, classical ML, forests, etc.), feature engineering, and training curves Iterative model training emphasized; performance plateaus analyzed over epochs Cost driven by senior data scientist involvement rather than headcount Example cited where similar ML engagement lasted nearly a year due to ROI sensitivity Data labeling and lineage recognized as critical but out of scope for this engagement Adjacent data sources (geography, metadata) discussed as potential signal enhancers Copilot and AI agents acknowledged but deferred to avoid overloading current scope

Fine‑Tuning as a Service defined as pure data science engagement, not infrastructure or pipeline build Engagement involves reviewing algorithms (LSTM, classical ML, forests, etc.), feature engineering, and training curves Iterative model training emphasized; performance plateaus analyzed over epochs Cost driven by senior data scientist involvement rather than headcount Example cited where similar ML engagement lasted nearly a year due to ROI sensitivity Data labeling and lineage recognized as critical but out of scope for this engagement Adjacent data sources (geography, metadata) discussed as potential signal enhancers Copilot and AI agents acknowledged but deferred to avoid overloading current scope

Technical Notes

Discussion around classical ML vs potential generative AI components Focus on model efficiency, not model replacement Emphasis on training curves, epochs, plateau analysis Feature engineering depth considered a key lever Data annotation typically handled by third parties or internal teams No direct access or

Potential Next Steps

Schedule Follow‑Up Technical Deep Dive

Owner: Ganesh Tyagali Audience: Senior Vendor Data
