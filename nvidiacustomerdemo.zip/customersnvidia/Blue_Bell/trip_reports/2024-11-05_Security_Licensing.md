Trip Report | Security Licensing | Blue Bell

Customer: Blue Bell
AE: Tony V
Topic: Security Licensing
Meeting Date 11/05/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

lead an internal SPR light version or setup a Full SPR depending on their decision

11/10

2

Manuel Z

Send Mark Cloud Physics

Environment Scan

11/08

3

Tony V

Detailed discussion about

Microsoft licensing and security features.

11/08

Item Owner Next Steps/Detail Due Date 1 Manuel Z lead an internal SPR light version or setup a Full SPR depending on their decision 11/10 2 Manuel Z Send Mark Cloud Physics

Environment Scan

11/08 3 Tony V

Detailed discussion about

Microsoft licensing and security features. 11/08

Summary

The meeting primarily focused on discussing Data Loss Prevention (DLP) solutions and understanding their relevance to the business environment. Discussion with participation provided insights into DLP's significance and potential application. The session also touched on the broader security landscape, emphasizing the importance of data protection and understanding current IT assets and strategies. A Security Posture Review (SPR) was proposed to assess the company's existing setup comprehensively. The team also planned for a follow-up Microsoft licensing and security conversation.

Tech Profile Updates

Current e-mail system: Exchange on-premises E-mail security: Proofpoint Microsoft environment: Older versions in use (e.g., Office 2013)

Security

tools: Discussed potential integration with Microsoft security tools

Current e-mail system: Exchange on-premises E-mail security: Proofpoint Microsoft environment: Older versions in use (e.g., Office 2013)

Security

tools: Discussed potential integration with Microsoft security tools

Agenda

Introduction of team members Discussion on Data Loss Prevention (DLP)

Security

Posture Review (SPR) proposal Microsoft licensing and security review Next steps and action items

Introduction of team members Discussion on Data Loss Prevention (DLP)

Security

Posture Review (SPR) proposal Microsoft licensing and security review Next steps and action items

Opportunities Identified & BANTC

Opportunity: Security Posture Review (SPR)

Opportunity: Security Posture Review (SPR)

B: Bluebell interested in understanding and potentially enhancing their

security framework.

A: Decision-makers at Bluebell, including Mark, are involved. N: Need for a comprehensive understanding of current security measures and potential vulnerabilities. T: Timeline suggested to align with Microsoft conversation and within a month. C: Cost is not directly mentioned, but the SPR is described as a complimentary service.

B: Bluebell interested in understanding and potentially enhancing their

security framework.

A: Decision-makers at Bluebell, including Mark, are involved. N: Need for a comprehensive understanding of current security measures and potential vulnerabilities. T: Timeline suggested to align with Microsoft conversation and within a month. C: Cost is not directly mentioned, but the SPR is described as a complimentary service.

Initiatives

Security

(focus on Data Loss Prevention and overall security enhancement)

Security

(focus on Data Loss Prevention and overall security enhancement)

Meeting Notes

Detailed Discussion

DLP Discussion: Highlighted the importance of data protection and different DLP strategies, including network, endpoint, and cloud-based solutions. SPR Proposal: Suggested a Security Posture Review to identify vulnerabilities and recommend solutions. Microsoft Licensing: Planned for a detailed conversation about current Microsoft licensing and potential upgrades to enhance security and functionality.

DLP Discussion: Highlighted the importance of data protection and different DLP strategies, including network, endpoint, and cloud-based solutions. SPR Proposal: Suggested a Security Posture Review to identify vulnerabilities and recommend solutions. Microsoft Licensing: Planned for a detailed conversation about current Microsoft licensing and potential upgrades to enhance security and functionality.

Technical Notes

DLP solutions vary based on business needs: network, endpoint, cloud, and e-mail DLP. Microsoft offers built-in security tools that could be leveraged with potential updates to the environment. Proofpoint is currently used for e-mail security; consideration of additional features or integration was discussed.

DLP solutions vary based on business needs: network, endpoint, cloud, and e-mail DLP. Microsoft offers built-in security tools that could be leveraged with potential updates to the environment. Proofpoint is currently used for e-mail security; consideration of additional features or integration was discussed. List of Speakers/Participants:

Tony Villalanti Stephen Drake Manuel Zelaya Mark Blue Bell

Tony Villalanti Stephen Drake Manuel Zelaya Mark Blue Bell
