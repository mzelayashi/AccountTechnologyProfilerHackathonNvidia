Trip Report | IAM solution | Sendero

Customer: Sendero
AE: Jax M
Topic: IAM solution
Meeting Date 05/07/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

Work with okta team to ensure that we demonstrate HRIS integration, lifecycle management, and SSO/MFA configuration

05/25

2

Jax  M

to assist with pricing, contract structuring, and ongoing account management

05/25

Item Owner Next Steps/Detail Due Date 1 Manuel Z Work with okta team to ensure that we demonstrate HRIS integration, lifecycle management, and SSO/MFA configuration 05/25 2 Jax  M to assist with pricing, contract structuring, and ongoing account management 05/25

Summary

This discovery call between Sendero Provisions, SHI, and Okta focused on Sendero’s need for a centralized Identity and Access Management (IAM) solution to support rapid company growth, international travel, and improved security. Sendero, a fast-growing retail company based in Waco, TX, with 60 employees (projected to reach 75 by year-end), currently uses Google Workspace with manual onboarding and no enforced MFA. They are seeking to automate user lifecycle management, implement single sign-on (SSO), and multi-factor authentication (MFA), and streamline onboarding through HR integration. Okta provided an overview of its capabilities (Universal Directory, SSO, MFA, lifecycle management, and integration with HR systems) and discussed flexible licensing and onboarding logistics. Next steps include a more technical follow-up with Okta resources to dive into HRIS integration and detailed app configuration.

Agenda

•
Introductions and company overviews
•
Sendero’s current IT environment and growth trajectory
• Pain
points: manual onboarding, lack of MFA, need for centralized IAM
• Okta
capability overview (SSO, MFA, Universal Directory, lifecycle management, HR integration)
•
Discussion of application landscape and integration options
•
Questions around onboarding process, licensing, and user count scaling
• Next
steps: Schedule technical deep-dive and follow-up meeting Opps Identified & BANTC Opportunity 1: Okta Deployment for IAM Modernization

B: Budget
Not explicitly discussed, but Sendero is price-conscious and interested in discount options for anticipated growth (60 to 75 users). Okta offers flexible user-based licensing and discount locks for growth.
A: Authority
Austin Crider (IT Manager, Sendero) is the technical and operational lead; Jax Miley (SHI) is account executive and broker; Claudia (Okta Account Manager) is vendor rep.
N: Need
Automate user onboarding from HRIS, centralize identity via SSO/MFA, secure remote/international access, reduce manual IT burden, prepare for continued growth.
T: Timeline
Immediate to near-term; Austin is three weeks into the IT manager role and prioritizing IAM modernization as an early initiative.
C: Competition
No direct competitors mentioned, but LastPass/Keeper/password managers currently fill some gaps. Okta’s SSO and automation would replace these.

B: Budget
Not explicitly discussed, but Sendero is price-conscious and interested in discount options for anticipated growth (60 to 75 users). Okta offers flexible user-based licensing and discount locks for growth.
A: Authority
Austin Crider (IT Manager, Sendero) is the technical and operational lead; Jax Miley (SHI) is account executive and broker; Claudia (Okta Account Manager) is vendor rep.
N: Need
Automate user onboarding from HRIS, centralize identity via SSO/MFA, secure remote/international access, reduce manual IT burden, prepare for continued growth.
T: Timeline
Immediate to near-term; Austin is three weeks into the IT manager role and prioritizing IAM modernization as an early initiative.
C: Competition
No direct competitors mentioned, but LastPass/Keeper/password managers currently fill some gaps. Okta’s SSO and automation would replace these.

Initiatives

Security (SSO, MFA,

user lifecycle automation, directory consolidation) [Potential Storage/Cloud not primary, but part of application integration]

Security (SSO, MFA,

user lifecycle automation, directory consolidation) [Potential Storage/Cloud not primary, but part of application integration] Tech Profile Updates:

Current environment: Google Workspace (IDP, email, chat), NetSuite (ERP), no Microsoft 365/Intune Users: 60 (projected 75 by year-end, uncertain for 2026) Onboarding: Manual; no current HRIS integration or SSO MFA: Not enforced, possibly SMS; Google Authenticator not confirmed in use Applications: Google Workspace, Google Chat (possible move to Slack), NetSuite; others not detailed Security: No centralized MFA/SSO; no lifecycle management Integration needs: HRIS to Okta to Google; interest in SWA for apps not supporting SAML/OAuth

Current environment: Google Workspace (IDP, email, chat), NetSuite (ERP), no Microsoft 365/Intune Users: 60 (projected 75 by year-end, uncertain for 2026) Onboarding: Manual; no current HRIS integration or SSO MFA: Not enforced, possibly SMS; Google Authenticator not confirmed in use Applications: Google Workspace, Google Chat (possible move to Slack), NetSuite; others not detailed Security: No centralized MFA/SSO; no lifecycle management Integration needs: HRIS to Okta to Google; interest in SWA for apps not supporting SAML/OAuth Meeting Notes:

Environment

Sendero Provisions, Waco, TX, retail apparel, rapid growth Warehouse and office locations, distributed/international workforce Manual IT processes, looking to automate and secure

Sendero Provisions, Waco, TX, retail apparel, rapid growth Warehouse and office locations, distributed/international workforce Manual IT processes, looking to automate and secure Detailed Discussion:

Okta’s Universal Directory can serve as a source of truth, pulling users from HRIS and automating provisioning to Google Workspace Okta offers SSO/MFA as core functions, with lifecycle management to reduce IT burden and improve compliance Discussed use of SWA (Secure Web Authentication) for apps that do not support SAML/OAuth Okta can help eliminate the need for standalone password managers (LastPass, Keeper, etc.) Flexible user licensing: Okta allows for growth, honors original discounts, and easy user count adjustments Onboarding: Okta onboarding can be quick; specifics to be covered in technical follow-up International travel and distributed employees: Okta’s MFA and SSO features help reduce risk from remote access

Okta’s Universal Directory can serve as a source of truth, pulling users from HRIS and automating provisioning to Google Workspace Okta offers SSO/MFA as core functions, with lifecycle management to reduce IT burden and improve compliance Discussed use of SWA (Secure Web Authentication) for apps that do not support SAML/OAuth Okta can help eliminate the need for standalone password managers (LastPass, Keeper, etc.) Flexible user licensing: Okta allows for growth, honors original discounts, and easy user count adjustments Onboarding: Okta onboarding can be quick; specifics to be covered in technical follow-up International travel and distributed employees: Okta’s MFA and SSO features help reduce risk from remote access Technical Notes:

Okta integrates via API to HRIS for automated user creation/provisioning MFA options: Okta supports TOTP, push, SMS, and more; current state at Sendero is unclear, likely not enforced SWA available for non-SAML/OAuth apps Okta provides documentation and support for custom app integrations Licensing: Per-user, easy to scale, true-up process for growth, no service interruption if user count is exceeded short-term

Okta integrates via API to HRIS for automated user creation/provisioning MFA options: Okta supports TOTP, push, SMS, and more; current state at Sendero is unclear, likely not enforced SWA available for non-SAML/OAuth apps Okta provides documentation and support for custom app integrations Licensing: Per-user, easy to scale, true-up process for growth, no service interruption if user count is exceeded short-term List all speakers/Participants of Transcript:

Jax Miley (SHI Account Executive) Austin Crider (IT Manager, Sendero Provisions) Claudia (Okta Account Manager)

Jax Miley (SHI Account Executive) Austin Crider (IT Manager, Sendero Provisions) Claudia (Okta Account Manager) Potential

Next Steps

Action: Claudia (Okta) to schedule and send invite for a technical follow-up (next Monday) with Okta technical resources

Action: Claudia (Okta) to schedule and send invite for a technical follow-up (next Monday) with Okta technical resources

Who: Claudia → Austin Crider, Jax Miley Status: In progress (invite to be sent)

Who: Claudia → Austin Crider, Jax Miley Status: In progress (invite to be sent)

Action: Okta technical resource to demonstrate HRIS integration, lifecycle management, and SSO/MFA configuration

Action: Okta technical resource to demonstrate HRIS integration, lifecycle management, and SSO/MFA configuration

Who: Okta SE (to be assigned) → Austin Crider, Sendero IT Status: To occur in next meeting

Who: Okta SE (to be assigned) → Austin Crider, Sendero IT Status: To occur in next meeting

Action: Sendero to provide details of HRIS platform and key applications needing SSO/MFA

Action: Sendero to provide details of HRIS platform and key applications needing SSO/MFA

Who: Austin Crider → Okta/SHI Status: Pending; likely to come up in next call

Who: Austin Crider → Okta/SHI Status: Pending; likely to come up in next call

Action: SHI (Jax Miley) to assist with pricing, contract structuring, and ongoing account management

Action: SHI (Jax Miley) to assist with pricing, contract structuring, and ongoing account management

Who: Jax Miley → Austin Crider Status: Ongoing

Who: Jax Miley → Austin Crider Status: Ongoing

Action: Okta to provide documentation or guidance on SWA and custom app integration

Action: Okta to provide documentation or guidance on SWA and custom app integration

Who: Claudia/Okta SE → Austin Crider Status: To be covered in next session

Who: Claudia/Okta SE → Austin Crider Status: To be covered in next session 🔄
