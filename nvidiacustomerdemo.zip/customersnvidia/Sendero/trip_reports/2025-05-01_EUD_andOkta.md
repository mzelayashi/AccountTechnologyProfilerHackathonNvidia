Trip Report | EUD andOkta | Sendero

Customer: Sendero
AE: Jax
Topic: EUD andOkta
Meeting Date 05/01/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Jax M

provide detailed pricing comparisons for Lenovo, Dell, and Surface laptops. coordinate with Austin Crider.

05/15

2

Manuel Z

Once log in is proviosin assist in SHI Labs account and provide virtual tour of access to virtual environments for technology trials.

05/15

Item Owner Next Steps/Detail Due Date 1 Jax M provide detailed pricing comparisons for Lenovo, Dell, and Surface laptops. coordinate with Austin Crider. 05/15 2 Manuel Z Once log in is proviosin assist in SHI Labs account and provide virtual tour of access to virtual environments for technology trials. 05/15

Summary

The meeting was centered around Sendero Provisions' evaluation of laptop options and the integration with SHI Labs for IT infrastructure enhancements. The client expressed interest in comparing Microsoft Surface laptops with Lenovo and Dell counterparts, focusing on specifications such as RAM and SSD capacity. The discussion also covered potential leasing programs and eligibility requirements for Apple products, which may not be viable due to budget constraints. Additionally, there was a focus on identity provider solutions with Okta and exploration of SHI Labs for technology trials, particularly around cybersecurity and EDR solutions. The client's preference for Okta was affirmed despite being a Google shop, with considerations for alternatives like Microsoft Azure Active Directory.

Agenda

Laptop comparison and selection Leasing program eligibility for Apple products Identity provider solutions Introduction to SHI Labs and potential trials Next steps and action items

Laptop comparison and selection Leasing program eligibility for Apple products Identity provider solutions Introduction to SHI Labs and potential trials Next steps and action items

Opps Identified & BANTC

Opportunity 1: Laptop Procurement

B: Sendero
Provisions is looking for laptops with specific specs (16GB RAM, 512GB SSD) and is considering Surface, Lenovo, and Dell.
A: The
COO and Austin Crider are the decision-makers.
N: Immediate
need for hardware upgrades.
T: Purchase
decision expected within the next few weeks.
C: Budget
considerations are crucial; comparisons needed to determine best value.

B: Sendero
Provisions is looking for laptops with specific specs (16GB RAM, 512GB SSD) and is considering Surface, Lenovo, and Dell.
A: The
COO and Austin Crider are the decision-makers.
N: Immediate
need for hardware upgrades.
T: Purchase
decision expected within the next few weeks.
C: Budget
considerations are crucial; comparisons needed to determine best value.
Opportunity 2: Identity Provider
Solutions with Okta

B: Sendero
Provisions needs a robust IDP solution and is considering Okta.
A: Austin
Crider leading the decision-making process.
N: Need
to integrate with existing Google infrastructure.
T: Decision
expected shortly; demo and discovery call in progress.
C: Pricing
and onboarding details pending; high budget for IDP solutions.

B: Sendero
Provisions needs a robust IDP solution and is considering Okta.
A: Austin
Crider leading the decision-making process.
N: Need
to integrate with existing Google infrastructure.
T: Decision
expected shortly; demo and discovery call in progress.
C: Pricing
and onboarding details pending; high budget for IDP solutions.

Initiatives

Security

Infrastructure

Security

Infrastructure

Tech Profile Updates

Sendero Provisions is primarily a Google shop with no significant Microsoft investment, requiring IDP solutions compatible with Google infrastructure. Current hardware includes laptops needing upgrades to meet operational demands.

Meeting Notes

Environment

Sendero Provisions is exploring technology solutions to enhance operational efficiency and security. They are considering scalable solutions for hardware and identity management.

Detailed Discussion

The conversation explored laptop specifications and potential leasing options, with Sendero Provisions leaning towards Surface laptops but open to alternatives based on pricing. The eligibility for Apple leasing programs was discussed but deemed unlikely due to financial constraints. Okta was identified as the preferred IDP solution, with plans for a demo and detailed pricing discussions. SHI Labs was introduced as a platform for exploring cybersecurity and other IT solutions, offering free trials and virtual environments for testing.

Technical Notes

Laptop specs focus: 16GB RAM, 512GB SSD. Okta integration considerations with existing Google infrastructure. SHI Labs offers virtual environments for testing various technologies, including EDR solutions like CrowdStrike and SentinelOne.

Laptop specs focus: 16GB RAM, 512GB SSD. Okta integration considerations with existing Google infrastructure. SHI Labs offers virtual environments for testing various technologies, including EDR solutions like CrowdStrike and SentinelOne. List all speakers/Participants of Transcript:

Jax Miley (SHI Representative) Austin Crider (Sendero Provisions) Manuel Zelaya (SHI Labs Representative)

Jax Miley (SHI Representative) Austin Crider (Sendero Provisions) Manuel Zelaya (SHI Labs Representative)

Potential Next steps

Action Item 1: Jax Miley to provide detailed pricing comparisons for Lenovo, Dell, and Surface laptops.

Action Item 1: Jax Miley to provide detailed pricing comparisons for Lenovo, Dell, and Surface laptops.

Responsible: Jax Miley to coordinate with Austin Crider.

Responsible: Jax Miley to coordinate with Austin Crider.

Action Item 2: Set up a demo and discovery call with the Okta sales team.

Action Item 2: Set up a demo and discovery call with the Okta sales team.

Responsible: Jax Miley to organize and involve Austin Crider.

Responsible: Jax Miley to organize and involve Austin Crider.

Action Item 3: Establish SHI Labs account and provide access to virtual environments for technology trials.

Action Item 3: Establish SHI Labs account and provide access to virtual environments for technology trials.

Responsible: Jax Miley to send invite link and assist Austin Crider with setup.

Responsible: Jax Miley to send invite link and assist Austin Crider with setup.

Action Item 4: Confirm pricing and onboarding details for Okta after the discovery call.

Action Item 4: Confirm pricing and onboarding details for Okta after the discovery call.

Responsible: Jax Miley to work with Okta team and update Austin Crider.

Responsible: Jax Miley to work with Okta team and update Austin Crider.

Action Item 5: Schedule a follow-up meeting for next week to discuss invoicing and finalize purchase decisions.

Action Item 5: Schedule a follow-up meeting for next week to discuss invoicing and finalize purchase decisions.

Responsible: Jax Miley to coordinate with Austin Crider and accounting team.

Responsible: Jax Miley to coordinate with Austin Crider and accounting team.
