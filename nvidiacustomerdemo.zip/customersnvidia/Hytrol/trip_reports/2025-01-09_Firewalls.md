Trip Report | Firewalls | Hytrol

Customer: Hytrol
AE: Nicole A
Topic: Firewalls
Meeting Date 01/09/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Todd C

provide contact details for SonicWall reps to explore renewal

02/01

2

Nicole/Manuel

to assess network switch requirements and provide options for industrial-grade replacements

02/01

Item Owner Next Steps/Detail Due Date 1 Todd C provide contact details for SonicWall reps to explore renewal 02/01 2 Nicole/Manuel to assess network switch requirements and provide options for industrial-grade replacements 02/01

Summary

The discussion revolved around current challenges and potential upgrades in their IT infrastructure, with a focus on firewalls, storage, and network switches. The team discussed delays in installation and budgetary constraints, explored options for month-to-month licensing for SonicWall, and considered potential transitions to Fortigate. They also addressed the need for durable network switches in specific environments and shared insights on their use of VX Rail and hyper-converged infrastructure. The conversation highlighted the importance of aligning technology solutions with budget and operational needs.

Agenda

Introduction and greetings Discussion on current firewall and VPN issues Exploration of budgetary constraints and potential solutions Review of network switch reliability and potential upgrades Future planning for

infrastructure and technology transitions

Closing remarks and

next steps

Introduction and greetings Discussion on current firewall and VPN issues Exploration of budgetary constraints and potential solutions Review of network switch reliability and potential upgrades Future planning for

infrastructure and technology transitions

Closing remarks and

next steps

Opps Identified & BANTC: Opportunity 1: Firewall Transition to Fortigate • B: Budget constraints due to upcoming fiscal planning. • A: Todd Caldwell (IT authority) is involved in decision-making. • N: Immediate need to ensure continuity of security functions. • T: Transition to Fortigate is planned but delayed; seeking interim solutions. • C: Currently using SonicWall; exploring options to transition to Fortigate. Opportunity 2: Network Switch Upgrades • B: Budget available for critical one-off upgrades.
• A: Todd Caldwell is overseeing network hardware decisions. • N: Need for
reliable network switches in harsh environments. • T: Immediate requirement due to existing switch failures. • C: Currently using consumer-grade switches; considering industrial-grade options. Opportunity 3: Storage and Backup Solutions • B: Budgetary approval pending for Rubrik backup solutions. • A: CFO and CIO involved in budget decisions. • N: Need for robust backup and storage solutions. • T: Decision pending due to internal budgetary review processes. • C: Exploring vendors for cost-effective solutions.

Initiatives

Security

Transition from SonicWall to Fortigate with interim licensing solutions. Storage: Explore backup solutions with Rubrik, pending budget approval. Networking: Upgrade to industrial-grade network switches to improve reliability.

Security

Transition from SonicWall to Fortigate with interim licensing solutions. Storage: Explore backup solutions with Rubrik, pending budget approval. Networking: Upgrade to industrial-grade network switches to improve reliability. Tech Profile Updates:

Current use of SonicWall for firewall; exploring transition to Fortigate. Network infrastructure includes legacy consumer-grade switches needing replacement. Storage solutions under review, with potential Rubrik integration.

Current use of SonicWall for firewall; exploring transition to Fortigate. Network infrastructure includes legacy consumer-grade switches needing replacement. Storage solutions under review, with potential Rubrik integration. Meeting Notes:

Environment

The customer operates with a mix of legacy and modernized systems, including VX Rail and hyper-converged infrastructure.

The customer operates with a mix of legacy and modernized systems, including VX Rail and hyper-converged infrastructure. Detailed Discussion:

Manuel Zelaya discussed potential sizing options for the Fortigate firewall, considering current and future needs. Todd Caldwell highlighted challenges with SonicWall licensing and the need for a budgetary review. Nicole Agoncillo and Manuel Zelaya agreed to explore month-to-month licensing options. The reliability of network switches in harsh environments was discussed, with a need to replace consumer-grade switches. Todd Caldwell mentioned pending approval for Rubrik backup solutions, indicating a need for further budget discussions.

Manuel Zelaya discussed potential sizing options for the Fortigate firewall, considering current and future needs. Todd Caldwell highlighted challenges with SonicWall licensing and the need for a budgetary review. Nicole Agoncillo and Manuel Zelaya agreed to explore month-to-month licensing options. The reliability of network switches in harsh environments was discussed, with a need to replace consumer-grade switches. Todd Caldwell mentioned pending approval for Rubrik backup solutions, indicating a need for further budget discussions. Technical Notes:

SonicWall functions primarily as a firewall with VPN capabilities; content filtering requires additional licenses. Fortigate sizing and transition discussed, with potential interim solutions through SonicWall. Network switch failures in harsh environments highlighted the need for durable replacements. Discussion on VX Rail and hyper-converged infrastructure, with a focus on future planning and stability.

SonicWall functions primarily as a firewall with VPN capabilities; content filtering requires additional licenses. Fortigate sizing and transition discussed, with potential interim solutions through SonicWall. Network switch failures in harsh environments highlighted the need for durable replacements. Discussion on VX Rail and hyper-converged infrastructure, with a focus on future planning and stability. List all speakers/Participants of Transcript:

Manuel Zelaya (SHI) Nicole Agoncillo (SHI) Todd Caldwell (Customer IT Authority) Kelvin Laffoon (Customer IT Team)

Manuel Zelaya (SHI) Nicole Agoncillo (SHI) Todd Caldwell (Customer IT Authority) Kelvin Laffoon (Customer IT Team)
