Trip Report | Fortigate and ZTNA | Hytrol

Customer: Hytrol
AE: Nicole A
Topic: Fortigate and ZTNA
Meeting Date 10/16/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Jordan Marshall

Provide a quote for FortiClient ZTNA for 725 users, hosted on FortiCloud.

10/19

2

Chris Wagner

Investigate and communicate Fortinet's integration capabilities with SentinelOne and Darktrace.

10/23

3

Nicole A

Ensure a scheduled follow-up demo focusing on FortiClient EMS and more detailed ZTNA architecture.

10/24

Item Owner Next Steps/Detail Due Date 1 Jordan Marshall Provide a quote for FortiClient ZTNA for 725 users, hosted on FortiCloud. 10/19 2 Chris Wagner Investigate and communicate Fortinet's integration capabilities with SentinelOne and Darktrace. 10/23 3 Nicole A Ensure a scheduled follow-up demo focusing on FortiClient EMS and more detailed ZTNA architecture. 10/24

Summary

The meeting focused on demonstrating Fortinet's Fortigate and ZTNA (Zero Trust Network Access) capabilities to address the client's needs for enhanced network security and management. Participants discussed the potential replacement or supplement of their current SonicWall and TrueGrid solutions with Fortinet products. Key features such as SD-WAN, ease of GUI use, firewall policies, and ZTNA were highlighted. The conversation also covered the synchronization of security policies, integration with existing systems like SentinelOne and Darktrace, and potential cost implications of deploying Fortinet solutions.

Technical Notes

Fortigate Features: SD-WAN capabilities, intuitive GUI, CLI access, policy management, and security profiles. ZTNA Details: Continuous checks, client requirements, and comparison with Zscaler. Policy Management: Use of FortiManager for template-based policy synchronization. Integration Possibilities: Inquiry into existing integrations with SentinelOne and Darktrace

Fortigate Features: SD-WAN capabilities, intuitive GUI, CLI access, policy management, and security profiles. ZTNA Details: Continuous checks, client requirements, and comparison with Zscaler. Policy Management: Use of FortiManager for template-based policy synchronization. Integration Possibilities: Inquiry into existing integrations with SentinelOne and Darktrace

Agenda

Introduction and purpose of the meeting. Demonstration of Fortigate’s capabilities. Discussion on ZTNA and its benefits. Synchronization of security policies across devices. Integration possibilities with existing systems. Next steps and potential quotes for solutions.

Introduction and purpose of the meeting. Demonstration of Fortigate’s capabilities. Discussion on ZTNA and its benefits. Synchronization of security policies across devices. Integration possibilities with existing systems. Next steps and potential quotes for solutions.

Opportunities Identified & BANTC

[New] Opportunity 1: Fortigate as a replacement for SonicWall

[New] Opportunity 1: Fortigate as a replacement for SonicWall

B (Budget): Not explicitly discussed, but implied interest in cost-effectiveness compared to SonicWall. A (Authority): Kelvin Laffoon and Todd Caldwell as decision-makers. N (Need): Need for a more intuitive and robust firewall solution. T (Timeline): Not specified. C (Competition): SonicWall.

B (Budget): Not explicitly discussed, but implied interest in cost-effectiveness compared to SonicWall. A (Authority): Kelvin Laffoon and Todd Caldwell as decision-makers. N (Need): Need for a more intuitive and robust firewall solution. T (Timeline): Not specified. C (Competition): SonicWall.

[New] Opportunity 2: Implementing ZTNA to replace or supplement TrueGrid

[New] Opportunity 2: Implementing ZTNA to replace or supplement TrueGrid

B (Budget): Concern about cost implications; interest in quotes. A (Authority): Kelvin Laffoon and Todd Caldwell. N (Need): Better control and visibility for remote access users. T (Timeline): Not specified. C (Competition): Zscaler, TrueGrid.

B (Budget): Concern about cost implications; interest in quotes. A (Authority): Kelvin Laffoon and Todd Caldwell. N (Need): Better control and visibility for remote access users. T (Timeline): Not specified. C (Competition): Zscaler, TrueGrid.

Initiatives

Security: Focus on ZTNA for enhanced security posture. Storage: Not specifically addressed.

Security: Focus on ZTNA for enhanced security posture. Storage: Not specifically addressed.

Tech Profile Updates

Consideration of Fortinet solutions to replace or supplement existing network security systems. Interest in integrating Fortinet with existing solutions like SentinelOne and Darktrace.

Consideration of Fortinet solutions to replace or supplement existing network security systems. Interest in integrating Fortinet with existing solutions like SentinelOne and Darktrace.

Meeting Notes

Environment

Current use of SonicWall and TrueGrid. Interest in Fortinet's centralized management and ease of use.

Current use of SonicWall and TrueGrid. Interest in Fortinet's centralized management and ease of use.

Detailed Discussion

Fortigate Demonstration: Emphasized intuitive GUI, SD-WAN, firewall policies, and security fabric integration. ZTNA Explanation: Discussed its ability to replace VPN, enhance security checks, and provide seamless access control. Policy Synchronization: Discussed challenges and solutions using FortiManager for centralized policy management. Integration with Existing Systems: Explored potential integrations with SentinelOne and Darktrace.

Fortigate Demonstration: Emphasized intuitive GUI, SD-WAN, firewall policies, and security fabric integration. ZTNA Explanation: Discussed its ability to replace VPN, enhance security checks, and provide seamless access control. Policy Synchronization: Discussed challenges and solutions using FortiManager for centralized policy management. Integration with Existing Systems: Explored potential integrations with SentinelOne and Darktrace. List of Speakers/Participants:

Nicole Agoncillo Kelvin Laffoon Todd Caldwell Jordan Marshall Chris Wagner Manuel Zelaya

Nicole Agoncillo Kelvin Laffoon Todd Caldwell Jordan Marshall Chris Wagner Manuel Zelaya
