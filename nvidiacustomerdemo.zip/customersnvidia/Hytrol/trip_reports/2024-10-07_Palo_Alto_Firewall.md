Trip Report | Palo Alto Firewall | Hytrol

Customer: Hytrol
AE: Nicole A
Topic: Palo Alto Firewall
Meeting Date 10/07/2024

*Internal notes – Please read and edit before sending externally*

Summary

1x1 Golden Zelaya The meeting focused on transitioning from SonicWall to Palo Alto Networks to enhance security and visibility, with features like route-based VPNs and advanced threat protection. Palo Alto's Application Control Center and packet capture capabilities were highlighted for detailed traffic analysis and troubleshooting. Future steps involve reviewing quotes and considering Prisma Access for Zero Trust Network Access. Action Items:

Item

Owner

Next Steps/Detail

Due Date

Quote

Nicole A

Create PA Quote

10/14

Review

Nicole

Set up call to review with Hytrol Team

10/21

Item Owner Next Steps/Detail Due Date Quote Nicole A Create PA Quote 10/14 Review Nicole Set up call to review with Hytrol Team 10/21

Agenda

Discussion on transitioning from SonicWall to Palo Alto Networks for enhanced

security and visibility.

Palo Alto offers both route-based and policy-based VPNs, with a preference for route-based. Detailed demo of Palo Alto's Application Control Center for traffic analysis. Emphasis on user activity tracking and threat investigation capabilities. Packet capture functionality available for troubleshooting and event-based analysis. Palo Alto provides comprehensive logging and customizable reports. Highlighted advanced threat protection features: antivirus, antispyware, and vulnerability protection. Future steps include reviewing quotes and potential configurations.

Discussion on transitioning from SonicWall to Palo Alto Networks for enhanced

security and visibility.

Palo Alto offers both route-based and policy-based VPNs, with a preference for route-based. Detailed demo of Palo Alto's Application Control Center for traffic analysis. Emphasis on user activity tracking and threat investigation capabilities. Packet capture functionality available for troubleshooting and event-based analysis. Palo Alto provides comprehensive logging and customizable reports. Highlighted advanced threat protection features: antivirus, antispyware, and vulnerability protection. Future steps include reviewing quotes and potential configurations. ss

Opps Identified & BANTC

Palo Alto Networks Firewall Upgrade
B: $150,000
A: Todd
Caldwell
N: Enhance
security and visibility, replace current SonicWall system
T: Q1
2025
C: Fortinet,
Zscaler

Palo Alto Networks Firewall Upgrade
B: $150,000
A: Todd
Caldwell
N: Enhance
security and visibility, replace current SonicWall system
T: Q1
2025
C: Fortinet,
Zscaler Attendees: SHI:

Nicole Agoncillo Gil ( Palo Alto) Manuel Zelaya (you) Syed

Nicole Agoncillo Gil ( Palo Alto) Manuel Zelaya (you) Syed

Customer:

Todd Caldwell Kelvin Laffoon

Todd Caldwell Kelvin Laffoon

Initiatives

Security (Firewall)

Tech Profile Updates

None

Meeting Notes

Environment

Current firewall: SonicWall Considering: Palo Alto Networks (PA) Internet setup: Adding another gig link from a different provider, to run concurrently current 1 Gig link

Current firewall: SonicWall Considering: Palo Alto Networks (PA) Internet setup: Adding another gig link from a different provider, to run concurrently current 1 Gig link Users:

Total users: 800 Remote access needs: Discussion on replacing True Grid with Zero Trust solution for remote access (Prisma Access)

Total users: 800 Remote access needs: Discussion on replacing True Grid with Zero Trust solution for remote access (Prisma Access) Discussion Summary:

Palo Alto's visibility, reporting, and control features Route-based VPNs Application Control Center for detailed traffic analysis Global filter for user activity tracking Packet capture capabilities for troubleshooting Advanced threat protection with antivirus, antispyware, vulnerability protection Zero Trust Network Access (ZTNA) with Prisma Access Customizable

security profiles and policy rules

Separate data planes for individual customers to prevent collateral damage Scalability and automation in handling traffic and threats

Palo Alto's visibility, reporting, and control features Route-based VPNs Application Control Center for detailed traffic analysis Global filter for user activity tracking Packet capture capabilities for troubleshooting Advanced threat protection with antivirus, antispyware, vulnerability protection Zero Trust Network Access (ZTNA) with Prisma Access Customizable

security profiles and policy rules

Separate data planes for individual customers to prevent collateral damage Scalability and automation in handling traffic and threats Additional Notes:

Consideration of Prisma Access vs. Zscaler: Discussion on outbound IP addresses and scaling Future steps involve receiving and reviewing quotes

Consideration of Prisma Access vs. Zscaler: Discussion on outbound IP addresses and scaling Future steps involve receiving and reviewing quotes
