Trip Report | GWN Cloud Management | Ezee Fiber

Customer: Ezee Fiber
AE: Jax M
Topic: GWN Cloud Management
Meeting Date 04/25/2026

*Internal notes – Please read and edit before sending externally*

Summary

Summary: • This meeting was a technical and strategic alignment between Ezee Fiber (customer), Grandstream (vendor), and SHI (partner) focused on evaluating whether Grandstream’s networking portfolio can expand beyond its existing telephony footprint within Ezee Fiber and enable advanced managed Wi-Fi offerings in MDU (multi-dwelling unit) environments.
• Ezee Fiber is
currently operating a fiber-to-the-unit model and primarily relies on Eero (with some Ruckus) for Wi-Fi, but is encountering limitations in centralized management, feature flexibility, scalability, and enterprise-grade capabilities required for more complex deployments such as student housing, mixed-use properties, and advanced developer-driven RFPs.
• The business
driver is Ezee Fiber’s desire to evolve from basic connectivity to enhanced managed Wi-Fi services that provide more value to property owners, developers, and tenants—including segmentation, automation, analytics, and service differentiation.
• Grandstream
positioned its GWN networking portfolio and GDMS (cloud management platform) as a solution capable of delivering unified visibility across networking and voice, scalable tenant isolation using PPSK, strong cost positioning, and ease of deployment.
• The
conversation also identified gaps—specifically around Layer 3 services and security (IDS/IPS, DPI, DNS protection), which are not native to the AP layer and require additional routing/firewall components.
• The outcome of
the call is a progression toward technical validation, product evaluation (hands-on testing), and follow-up architecture sessions to explore a broader full-stack replacement or augmentation strategy. Agenda: • Introductions and alignment of participants
• Overview of
current Ezee Fiber MDU networking model
• Identification
of limitations within existing Wi-Fi solution (Eero)
• Grandstream
networking portfolio overview (APs, switching, routing, GDMS)
• Deep dive into
GDMS cloud management capabilities
• Technical
Q&A (architecture, scalability, segmentation, security)
• Alignment on
product evaluation and next steps

Opps Identified

& BANTC
Opportunity 1:
Managed Wi-Fi Transformation (MDU Expansion)
• B: Not formally
defined; implied evaluation phase for future deployments
• A: Cory Baker
(VP), Ashley Havard (Sr Director MDU), Bill See (Director Product Engineering)
• N: Need for
more advanced managed Wi-Fi capabilities including tenant segmentation, operational control, and developer-aligned feature sets
• T: Near-term
tied to ongoing/new MDU projects and RFP complexity
• C: Current Eero
platform lacks advanced management features, scalability, and enterprise-grade controls
Opportunity 2:
Wi-Fi 7 Standardization Initiative
• B: Not
explicitly stated; strategic direction confirmed
• A: Bill See,
Cory Baker
• N: Transition
to Wi-Fi 7-only deployments for new markets
• T: Immediate
for new deployments; ongoing rollout
• C: Requires
vendor alignment and ecosystem that fully supports Wi-Fi 7 across APs, management, and infrastructure
Opportunity 3:
Full Network Stack Expansion (Routing, Security, Switching)
• B: Not defined;
exploratory stage
• A: Bill See
• N: Need for
Layer 2/Layer 3 architecture including integrated security (IDS, IPS, DPI, DNS security)
• T: Mid-term
depending on outcome of evaluation
• C: Grandstream
APs alone do not satisfy full networking and security requirements; additional components required Initiatives: • Managed Wi-Fi Expansion → Networking Infrastructure
• Wi-Fi 7
Transition → Networking Infrastructure
• Unified Device
Management (Voice + Network via GDMS) → Networking
• Security
Architecture Evaluation (Firewall, IDS/IPS) → Security Tech Profile Updates: • Current Wi-Fi environment: Predominantly Eero, limited Ruckus
• Network
architecture: Fiber-to-the-unit
• Wi-Fi standards
in use: Mix of Wi-Fi 6 and Wi-Fi 7, moving to Wi-Fi 7 only
• Management
platform: GDMS (currently used for telephony, expanding evaluation for networking)
• Capabilities
gap: Limited enterprise features (policy control, segmentation, automation, and analytics)

Meeting Notes

Environment: • Multi-Dwelling Units (MDU), student housing, mixed-use developments
• High-density
user environments requiring scalable wireless infrastructure
• Distributed AP
deployments, primarily wired
• Cloud-managed
infrastructure with desire for centralized visibility and control Detailed Discussion: • Ezee Fiber articulated that their current model works well for fiber delivery but lacks differentiation in managed Wi-Fi offerings, especially in competitive or complex RFP scenarios
• Limitations
with Eero include restricted control, limited IP flexibility, and lack of enterprise-grade features needed for advanced use cases
• Grandstream
introduced its GWN portfolio emphasizing flexibility in AP deployment (ceiling, wall-mounted, Wi-Fi 7 capable devices)
• Extensive
discussion on PPSK (Private Pre-Shared Key) as a method for scalable tenant segmentation—allowing unique credentials per resident mapped to VLANs for isolation
• Student housing
and hospitality use cases were explored as key scenarios where this architecture provides operational and user experience advantages
• GDMS
demonstration showed centralized provisioning, SSID configuration, VLAN mapping, captive portal creation, and role-based access controls
• Discussion
highlighted capability to automate provisioning via CSV uploads and automatically distribute credentials to users
• RF optimization
functions (RRM) were discussed to dynamically adjust channel and power settings across large AP deployments
• Security
discussion revealed that APs do not handle advanced security (IDS/IPS, DPI) and require integration with routing/firewall solutions

Technical Notes

• AP capabilities:
– Supports Wi-Fi
5, 6, 6E, and 7
– Multi-form
factor (ceiling and wall mount)
– PoE-powered
with optional additional device power output
• SSID
configuration:
– Up to 16 SSIDs
per AP
– Recommended
model: single SSID with PPSK for large deployments
• PPSK
functionality:
– Up to
~3000–3500 unique credentials per SSID (Wi-Fi 7 models)
– Credentials
mapped to VLAN for per-user isolation
– Supports
automated generation and distribution via GDMS
• GDMS
capabilities:
– Centralized
device onboarding (manual, CSV, or distributor assignment)
– SSID
configuration, VLAN tagging, captive portal creation
– Role-based
access control with granular permissions
– Automated
credential distribution via email
– Reporting and
data export (user info, connection data)
• Captive portal:
– Supports social
login, SSO (Entra ID / AD), SMS/email authentication
– Customizable UI
(drag-and-drop)
• Mesh
networking:
– Supported up to
5 APs with cascading up to 3 levels
– Wired backhaul
preferred in MDU environments
• RF management:
– Manual tuning
or automatic optimization (RRM)
– Adjustable per
band (2.4 GHz, 5 GHz, 6 GHz)
• Security
architecture:
– APs do not
provide IDS/IPS, DPI, or DNS-level security
– Security
functions handled at router/firewall layer
• Device
management:
– Bulk
configuration across multiple APs
– Changes applied
via centralized GUI, not individual device touch List all speakers/Participants of Transcript (titles and companies for the folks in the meeting please, should display as just ROLES:
• Jax Miley –
Partner Account Representative (SHI)
• Ben Conway –
Sales / Partner Account Manager (Grandstream)
• Dave Richards –
Product Manager, Networking (Grandstream)
• Abdel Jabar –
Technical Support Engineer (Grandstream)
• Christopher
Cook – Technical Lead / Engineering (Ezee Fiber)
• Bill See –
Director of Product Engineering (Ezee Fiber)
• Sammie Dixon –
Engineering / Voice Team (Ezee Fiber)
• Ashley Havard –
Senior Director, MDU (Ezee Fiber)
• Cory Baker –
Vice President, Master Planning Communities (Ezee Fiber)
• Tony Stuckey –
Director, Enterprise SMB Voice (Ezee Fiber)
• Onochie Obioha
– Voice Engineer (Ezee Fiber)
Potential Next steps:
• Dave Richards →
Bill See
– Deliver SKU
list including Wi-Fi 7 APs, switches, routers, and MSRP pricing
– Provide
documentation on routing/firewall capabilities and security features
• Bill See →
Grandstream
– Provide list of
currently deployed Eero SKUs for comparison mapping
• Christopher
Cook → Internal Ezee Fiber team (including Bill)
– Provision
access to GDMS tenant for hands-on evaluation and testing
• Jax Miley → All
participants
– Send meeting
recap and coordinate follow-up sessions
• Grandstream →
Ezee Fiber
– Ship evaluation
hardware (Wi-Fi 7 APs, networking components) for lab testing
• Dave Richards +
Abdel Jabar → Ezee Fiber technical team
– Schedule
deep-dive architecture session covering:
– GDMS detailed
workflow
– End-to-end
network architecture (AP + switching + routing)
• Joint (SHI +
Grandstream + Ezee Fiber)
– Define
potential pilot deployment or proof-of-concept aligned to MDU use case
– Align on
technical validation criteria and success metrics
