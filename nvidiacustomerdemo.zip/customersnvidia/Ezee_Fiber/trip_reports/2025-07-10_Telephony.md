Trip Report | Telephony | Ezee Fiber

Customer: Ezee Fiber
AE: Jax M
Topic: Telephony
Meeting Date 07/10/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

Assist in Ezee Fiber to test demo gear, evaluate fit (performance, SNMP, Q-in-Q, management, “dying gasp”, etc.), and provide feedback to Grandstream/SHI.

07/25

2

Jax M

re-engage Ezee Fiber when Ruckus licenses expire or new Wi-Fi needs arise; keep Ezee Fiber informed of Wi-Fi 7/mesh/SFP+ product launches.

07/25

Item Owner Next Steps/Detail Due Date 1 Manuel Z Assist in Ezee Fiber to test demo gear, evaluate fit (performance, SNMP, Q-in-Q, management, “dying gasp”, etc.), and provide feedback to Grandstream/SHI. 07/25 2 Jax M re-engage Ezee Fiber when Ruckus licenses expire or new Wi-Fi needs arise; keep Ezee Fiber informed of Wi-Fi 7/mesh/SFP+ product launches. 07/25

Summary

This meeting brought together Ezee Fiber, SHI, and Grandstream Networks to discuss the potential for Ezee Fiber to standardize more of its CPE (customer premises equipment) and possibly enterprise switching on Grandstream’s networking portfolio. Ezee Fiber currently uses a mix of Juniper, Nokia, Calix, and Cisco for core/aggregation and CPE, with Ruckus for office Wi-Fi and Eero for customer Wi-Fi (due to strong internal advocacy and pricing). Grandstream presented its switches, routers, and management platform (GDMS), emphasizing their cost-effectiveness, zero-license model, remote management, and roadmap for advanced features (e.g., more 10G SFP+, Wi-Fi 7, SFP routers). Ezee Fiber’s key requirements are multiple 10G ports, MEF compliance, SNMP/SolarWinds compatibility, and features like “dying gasp.” Grandstream’s current and upcoming products were reviewed for fit, and the team agreed to send demo gear (routers/switches) to Ezee Fiber for lab evaluation. Follow-up will include feature roadmap details and support for requested features.

Agenda

• Introductions
• Review of Ezee Fiber’s current network architecture
and vendor mix
• Grandstream’s networking product portfolio and
management capabilities
• Discussion of technical requirements and feature
gaps
• Demo/evaluation process and next steps
Opps Identified & BANTC Opportunity 1: Ezee Fiber Standardizing CPE/Access Layer on Grandstream Switches/Routers

B (Budget): Ezee Fiber is price-sensitive for CPE and access gear, but currently pays premium for Juniper, Nokia, and Ruckus. Grandstream offers lower cost and no recurring licensing fees. A (Authority): Tony Stuckey (Director of Network Engineering) is key decision maker; Rodney (VP) influences CPE Wi-Fi choice. N (Need): Switches with multiple 10G SFP+ ports (min 2, ideally 4) MEF compliance, SNMP (SolarWinds), Q-in-Q, remote management, “dying gasp” alert Compatibility with current Juniper/Nokia/Cisco core Wi-Fi: Ruckus for offices (locked for now), Eero for customer sites (entrenched, but open to future alternatives) Demo/eval process before any standardization T (Timeline): Immediate for lab evaluation; broader standardization would follow successful testing and feature confirmation. Some features (e.g., SFP+ routers, more 10G ports) are on Grandstream’s roadmap for late 2024/early 2025. C (Competition): Incumbent: Juniper (access/aggregation), Nokia/Calix (PON), Ruckus/Eero (Wi-Fi), Cisco (legacy) Alternatives: Stick with current vendors if Grandstream cannot meet technical or price requirements

B (Budget): Ezee Fiber is price-sensitive for CPE and access gear, but currently pays premium for Juniper, Nokia, and Ruckus. Grandstream offers lower cost and no recurring licensing fees. A (Authority): Tony Stuckey (Director of Network Engineering) is key decision maker; Rodney (VP) influences CPE Wi-Fi choice. N (Need): Switches with multiple 10G SFP+ ports (min 2, ideally 4) MEF compliance, SNMP (SolarWinds), Q-in-Q, remote management, “dying gasp” alert Compatibility with current Juniper/Nokia/Cisco core Wi-Fi: Ruckus for offices (locked for now), Eero for customer sites (entrenched, but open to future alternatives) Demo/eval process before any standardization T (Timeline): Immediate for lab evaluation; broader standardization would follow successful testing and feature confirmation. Some features (e.g., SFP+ routers, more 10G ports) are on Grandstream’s roadmap for late 2024/early 2025. C (Competition): Incumbent: Juniper (access/aggregation), Nokia/Calix (PON), Ruckus/Eero (Wi-Fi), Cisco (legacy) Alternatives: Stick with current vendors if Grandstream cannot meet technical or price requirements

Initiatives

Primary: Networking/Access (Switches, Routers, Wi-Fi) Secondary: Security (Firewall/Router features), Management (Remote/Cloud)

Primary: Networking/Access (Switches, Routers, Wi-Fi) Secondary: Security (Firewall/Router features), Management (Remote/Cloud) Tech Profile Updates:

Core/Aggregation: Juniper (new), Nokia/Calix (PON/XGS-PON), Cisco (legacy) CPE: Eero (Wi-Fi, customer), Nokia Beacon (advanced), Ruckus (office Wi-Fi, controller-based, long-term license), some Nokia CPE Access: Juniper EX2300, Nokia for high-capacity Management: SolarWinds, SNMP required, preference for remote config/provisioning Feature asks: 2+ 10G SFP+ ports, MEF compliance, Q-in-Q, SNMP, “dying gasp (power loss alert), static IP, CLI access, mass provisioning Grandstream: GDMS platform (cloud, multi-tenant, unlimited scale), Wi-Fi 5/6/7, switches (Layer 2/3), upcoming SFP+ routers, no recurring licenses, pre-provisioning before device shipment

Core/Aggregation: Juniper (new), Nokia/Calix (PON/XGS-PON), Cisco (legacy) CPE: Eero (Wi-Fi, customer), Nokia Beacon (advanced), Ruckus (office Wi-Fi, controller-based, long-term license), some Nokia CPE Access: Juniper EX2300, Nokia for high-capacity Management: SolarWinds, SNMP required, preference for remote config/provisioning Feature asks: 2+ 10G SFP+ ports, MEF compliance, Q-in-Q, SNMP, “dying gasp (power loss alert), static IP, CLI access, mass provisioning Grandstream: GDMS platform (cloud, multi-tenant, unlimited scale), Wi-Fi 5/6/7, switches (Layer 2/3), upcoming SFP+ routers, no recurring licenses, pre-provisioning before device shipment Meeting Notes:

Environment

Ezee Fiber serves enterprise, SMB, and commercial customers using a mix of high-end vendor gear. Wi-Fi for customers is Eero (value, ease); office Wi-Fi is Ruckus (coverage/capacity, existing investment). Juniper is entrenched for enterprise/aggregation. Management via SolarWinds/SNMP, needs advanced reporting/alerting. Feature requests: “dying gasp,” MEF compliance, Q-in-Q, easy remote config, static IP, CLI.

Ezee Fiber serves enterprise, SMB, and commercial customers using a mix of high-end vendor gear. Wi-Fi for customers is Eero (value, ease); office Wi-Fi is Ruckus (coverage/capacity, existing investment). Juniper is entrenched for enterprise/aggregation. Management via SolarWinds/SNMP, needs advanced reporting/alerting. Feature requests: “dying gasp,” MEF compliance, Q-in-Q, easy remote config, static IP, CLI.

Detailed Discussion

Grandstream demoed GDMS (remote/cloud management, CLI, multi-site, pre-provisioning). Access switches: GWN 7806 (48x1G, 6x10G SFP+), Layer 2/3, SNMP, Q-in-Q, mesh Wi-Fi, static IP config. Wi-Fi 6/6E/7 product roadmap; Wi-Fi 7 (dual/tri-band) coming late 2024/early
2025.
Routers: SFP+ models on roadmap (2.5G & 10G), currently copper only. “Dying gasp” not yet implemented; Grandstream will submit feature request and follow up on development/timeline. Demo gear (routers/switches) to be sent for lab testing. Ezee Fiber open to evaluating alternatives for future standardization, especially if cost/features align.

Grandstream demoed GDMS (remote/cloud management, CLI, multi-site, pre-provisioning). Access switches: GWN 7806 (48x1G, 6x10G SFP+), Layer 2/3, SNMP, Q-in-Q, mesh Wi-Fi, static IP config. Wi-Fi 6/6E/7 product roadmap; Wi-Fi 7 (dual/tri-band) coming late 2024/early
2025.
Routers: SFP+ models on roadmap (2.5G & 10G), currently copper only. “Dying gasp” not yet implemented; Grandstream will submit feature request and follow up on development/timeline. Demo gear (routers/switches) to be sent for lab testing. Ezee Fiber open to evaluating alternatives for future standardization, especially if cost/features align. Technical Notes:

Switches: GWN 7806 (48x1G, 6x10G SFP+) fits many access-layer needs; Layer 2/3, Q-in-Q, SNMP, CLI, remote management. Wi-Fi: Ruckus stays for now (controller/license sunk cost); Grandstream Wi-Fi 7/6 roadmap for future refresh cycles; mesh supported; powered by PoE (no DC jack). Routers: SFP+ (2.5G/10G) models on roadmap for late 2024/early 2025. Management: GDMS supports remote config, CLI, no device/tenant limit, mass pre-provisioning, secure tunnels for remote access, static IP, template-based provisioning. “Dying gasp”: Not yet supported; will check with engineering for roadmap and timeline. MEF compliance: Not confirmed on call; requires follow-up. Deployment: Demo/eval units to be sent; feedback and further roadmap coordination pending results.

Switches: GWN 7806 (48x1G, 6x10G SFP+) fits many access-layer needs; Layer 2/3, Q-in-Q, SNMP, CLI, remote management. Wi-Fi: Ruckus stays for now (controller/license sunk cost); Grandstream Wi-Fi 7/6 roadmap for future refresh cycles; mesh supported; powered by PoE (no DC jack). Routers: SFP+ (2.5G/10G) models on roadmap for late 2024/early 2025. Management: GDMS supports remote config, CLI, no device/tenant limit, mass pre-provisioning, secure tunnels for remote access, static IP, template-based provisioning. “Dying gasp”: Not yet supported; will check with engineering for roadmap and timeline. MEF compliance: Not confirmed on call; requires follow-up. Deployment: Demo/eval units to be sent; feedback and further roadmap coordination pending results. List all speakers/Participants of Transcript:

Tony Stuckey (Ezee Fiber) Kip Rouse (Ezee Fiber) Sammie Dixon (Ezee Fiber) Christopher Cook (Ezee Fiber) Jax Miley (SHI) Dave Richards (Grandstream Networks) Abdel J (Grandstream Networks, Support) Ben Conway (Grandstream Networks) (Rodney, Ezee Fiber VP, referenced)

Tony Stuckey (Ezee Fiber) Kip Rouse (Ezee Fiber) Sammie Dixon (Ezee Fiber) Christopher Cook (Ezee Fiber) Jax Miley (SHI) Dave Richards (Grandstream Networks) Abdel J (Grandstream Networks, Support) Ben Conway (Grandstream Networks) (Rodney, Ezee Fiber VP, referenced) Potential

Next Steps

Grandstream to Send Demo Units

Grandstream to Send Demo Units

Action: Grandstream to ship demo switches and routers (with 10G SFP+ where possible) to Ezee Fiber for lab evaluation. Who: Dave/Abdel/Grandstream → Tony/Kip/Ezee Fiber

Action: Grandstream to ship demo switches and routers (with 10G SFP+ where possible) to Ezee Fiber for lab evaluation. Who: Dave/Abdel/Grandstream → Tony/Kip/Ezee Fiber

Feature/Compliance Follow-Up

Feature/Compliance Follow-Up

Action: Grandstream to confirm/clarify MEF compliance, provide timeline for “dying gasp implementation, and share details on SFP+ router/switch roadmap. Who: Dave/Abdel/Grandstream → Tony/Ezee Fiber

Action: Grandstream to confirm/clarify MEF compliance, provide timeline for “dying gasp implementation, and share details on SFP+ router/switch roadmap. Who: Dave/Abdel/Grandstream → Tony/Ezee Fiber

Lab Testing & Feedback

Lab Testing & Feedback

Action: Ezee Fiber to test demo gear, evaluate fit (performance, SNMP, Q-in-Q, management, “dying gasp”, etc.), and provide feedback to Grandstream/SHI. Who: Tony/Kip/Christopher/Ezee Fiber → Grandstream/SHI

Action: Ezee Fiber to test demo gear, evaluate fit (performance, SNMP, Q-in-Q, management, “dying gasp”, etc.), and provide feedback to Grandstream/SHI. Who: Tony/Kip/Christopher/Ezee Fiber → Grandstream/SHI

Pricing/Comparison

Pricing/Comparison

Action: Grandstream to provide indicative pricing for evaluated models; Ezee Fiber to compare to Juniper/Nokia/Cisco/Ruckus/Eero TCO. Who: Dave/Grandstream → Tony/Ezee Fiber

Action: Grandstream to provide indicative pricing for evaluated models; Ezee Fiber to compare to Juniper/Nokia/Cisco/Ruckus/Eero TCO. Who: Dave/Grandstream → Tony/Ezee Fiber

Future Wi-Fi/Access Refresh Planning

Future Wi-Fi/Access Refresh Planning

Action: SHI/Grandstream to re-engage Ezee Fiber when Ruckus licenses expire or new Wi-Fi needs arise; keep Ezee Fiber informed of Wi-Fi 7/mesh/SFP+ product launches. Who: Jax/SHI, Dave/Grandstream → Tony/Ezee Fiber

Action: SHI/Grandstream to re-engage Ezee Fiber when Ruckus licenses expire or new Wi-Fi needs arise; keep Ezee Fiber informed of Wi-Fi 7/mesh/SFP+ product launches. Who: Jax/SHI, Dave/Grandstream → Tony/Ezee Fiber

Potential Site Visit

Potential Site Visit

Action: Grandstream to plan Texas road trip, meet Ezee Fiber team in person for further relationship building and technical alignment. Who: Ben/Dave/Grandstream → Ezee Fiber

Action: Grandstream to plan Texas road trip, meet Ezee Fiber team in person for further relationship building and technical alignment. Who: Ben/Dave/Grandstream → Ezee Fiber
