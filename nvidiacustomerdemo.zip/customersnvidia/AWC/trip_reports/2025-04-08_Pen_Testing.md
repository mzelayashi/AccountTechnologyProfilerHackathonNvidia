Trip Report | Pen Testing | AWC

Customer: AWC
AE: Tony V
Topic: Pen Testing
Meeting Date 04/08/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

provide updates on new Stratascale services and offerings to the AWC team.

5/02

2

Jace R

d Nick Schmitt scoping questions and budgetary pricing for penetration testing and C10 services.

05/02

Item Owner Next Steps/Detail Due Date 1 Manuel Z provide updates on new Stratascale services and offerings to the AWC team. 5/02 2 Jace R d Nick Schmitt scoping questions and budgetary pricing for penetration testing and C10 services. 05/02

Summary

Summary

The call featured SHI and AWC Inc discussing potential penetration testing services with Stratascale, a subsidiary of SHI, to enhance AWC's cybersecurity posture. Participants included representatives from both companies, focusing on the need for a comprehensive external penetration test to identify potential exposures and help AWC build a security roadmap. The conversation highlighted Stratascale's capabilities in cybersecurity services, including their managed and incident response services, and explored budgetary concerns and alignment with AWC's growth and compliance needs.

Agenda

Introductions and participant locations Overview of Stratascale's presence and services Discussion on the need for penetration testing at AWC Stratascale's service offerings and capabilities Budgetary considerations and next steps

Introductions and participant locations Overview of Stratascale's presence and services Discussion on the need for penetration testing at AWC Stratascale's service offerings and capabilities Budgetary considerations and next steps

Opps Identified & BANTC

Opportunity 1: Penetration Testing for
AWC Inc

Opportunity 1: Penetration Testing for
AWC Inc

B: Budgetary
pricing to be provided post-discussion to align with AWC's financial planning.
A: Decision-making
involves Nick Schmitt and potentially Julius regarding compliance and insurance impacts.
N: Need
for external penetration testing to identify exposure and build a security roadmap.
T: No
immediate timeframe; discovery phase to determine if the service aligns with their needs.
C: Current
reliance on free SysSA scans; interest in evaluating Stratascale’s capabilities against current practices.

B: Budgetary
pricing to be provided post-discussion to align with AWC's financial planning.
A: Decision-making
involves Nick Schmitt and potentially Julius regarding compliance and insurance impacts.
N: Need
for external penetration testing to identify exposure and build a security roadmap.
T: No
immediate timeframe; discovery phase to determine if the service aligns with their needs.
C: Current
reliance on free SysSA scans; interest in evaluating Stratascale’s capabilities against current practices.

Initiatives

Security

Initiatives focused on identifying vulnerabilities through penetration testing and enhancing the overall security posture of AWC.

Security

Initiatives focused on identifying vulnerabilities through penetration testing and enhancing the overall security posture of AWC.

Tech Profile Updates

AWC currently utilizes free SysSA scans monthly for vulnerability assessments. Interest in transitioning to more comprehensive and frequent penetration tests.

AWC currently utilizes free SysSA scans monthly for vulnerability assessments. Interest in transitioning to more comprehensive and frequent penetration tests.

Meeting Notes

Environment

AWC is exploring security enhancements due to business growth and potential compliance requirements. The existing process includes automated monthly SysSA scans.

AWC is exploring security enhancements due to business growth and potential compliance requirements. The existing process includes automated monthly SysSA scans.

Detailed Discussion

The primary objective is to evaluate AWC's external vulnerabilities and refine their security strategy. Stratascale offers various cybersecurity services, emphasizing their incident response retainers and continuous testing capabilities.

The primary objective is to evaluate AWC's external vulnerabilities and refine their security strategy. Stratascale offers various cybersecurity services, emphasizing their incident response retainers and continuous testing capabilities.

Technical Notes

Stratascale's penetration testing is SKU-based and quickly deployable.

Security

services encompass governance, risk, compliance, identity and zero trust, network security architecture, and hybrid cloud security. Managed services offer ongoing engagements and incident response retainers.

Stratascale's penetration testing is SKU-based and quickly deployable.

Security

services encompass governance, risk, compliance, identity and zero trust, network security architecture, and hybrid cloud security. Managed services offer ongoing engagements and incident response retainers. List all speakers/Participants of Transcript:

Manuel Zelaya (SHI) Tony Villalanti (AWC Inc) Jace Rose (Stratascale) Nick Schmitt (AWC Inc) Ashton Mellott (AWC Inc)

Manuel Zelaya (SHI) Tony Villalanti (AWC Inc) Jace Rose (Stratascale) Nick Schmitt (AWC Inc) Ashton Mellott (AWC Inc)

Potential Next Steps

Action Item: Jace Rose to send Nick Schmitt scoping questions and budgetary pricing for penetration testing and C10 services. (Assigned to Jace Rose and Nick Schmitt) Action Item: AWC Inc to discuss internally with Julius regarding timelines and further interest in continuous testing services. (Assigned to Nick Schmitt and Ashton Mellott) Action Item: Schedule a demo of Stratascale's platform if budgetary pricing aligns with AWC's requirements. (Assigned to Jace Rose and AWC Inc team) Action Item: Manuel Zelaya to provide updates on new Stratascale services and offerings to the AWC team. (Assigned to Manuel Zelaya)

Action Item: Jace Rose to send Nick Schmitt scoping questions and budgetary pricing for penetration testing and C10 services. (Assigned to Jace Rose and Nick Schmitt) Action Item: AWC Inc to discuss internally with Julius regarding timelines and further interest in continuous testing services. (Assigned to Nick Schmitt and Ashton Mellott) Action Item: Schedule a demo of Stratascale's platform if budgetary pricing aligns with AWC's requirements. (Assigned to Jace Rose and AWC Inc team) Action Item: Manuel Zelaya to provide updates on new Stratascale services and offerings to the AWC team. (Assigned to Manuel Zelaya)
