Trip Report | Azure Architect Review | AmeriVet

Customer: AmeriVet
AE: Jax M
Topic: Azure Architect Review
Meeting Date 12/12/2026

*Internal notes – Please read and edit before sending externally*

Summary

This call centered on evaluating and architecting a scalable Azure Virtual WAN (VWAN)–based connectivity model for AmeriVet’s rapidly expanding clinic footprint, with integration requirements for Imprivata appliances hosted in Azure. SHI, acting as the solution advisor, facilitated the discussion to help AmeriVet determine the most appropriate cloud networking architecture, cost considerations, appliance sizing, redundancy strategy, and VPN configuration model needed to support secure authentication workflows across 214 current clinics (projected to 500 by 2030). AmeriVet is fully cloud‑native with no on‑prem infrastructure and must ensure secure, efficient communication between Imprivata's Azure‑hosted authentication appliances and each physical clinic location. Core topics included VWAN Basic vs. Standard tiers, hub strategy (single 1vs. multi‑region), active/active Imprivata deployment requirements, expected VPN throughput, storage/cost growth implications, split tunneling strategies, and future scalability. Several action items emerged involving SHI determining consulting scope, AmeriVet reviewing Azure management options through SHI, and Imprivata sharing technical specifications. The conversation also explored architectural dependencies such as ExpressRoute considerations (ultimately unnecessary), Azure Site Recovery compatibility, VM SKU guidance, and implications for multi‑region appliance deployment.

Agenda

• Review
AmeriVet’s current and projected Azure networking needs
• Discuss
connectivity requirements for Imprivata authentication appliances
• Evaluate Azure
Virtual WAN Basic vs. Standard
• Assess hub
strategy (single region vs. multi‑region)
• Review
performance, availability, and latency considerations
• Discuss VM
sizing, appliance limitations, and user load impacts
• Align on
expectations for consulting, implementation assistance, and follow‑up steps

Opportunities Identified & BANTC

Opportunity 1: Azure Virtual WAN Architecture &
Deployment Support (AmeriVet → SHI)
B – Budget:
AmeriVet is pricing VWAN by estimating monthly data usage and hub costs; Taylor and Joey emphasized minimal bandwidth consumption for authentication traffic. costs expected to be low. Jason ran initial calculator estimates.
A – Authority:
Key decisionmakers appear to be Jason, Dieter, and Mark on the AmeriVet side. SHI (Jax & Joey) provide technical recommendation authority but not purchasing authority.
N – Need:
AmeriVet seeks guidance designing and deploying VPN connectivity between ~214 (future ~500) clinics and Azure‑hosted Imprivata appliances. They need help determining VWAN tier, hub count, VPN routing strategy, and ensuring scalable, manageable architecture.
T – Timeline:
Expansion to 214+ sites expected by end of 2027; full scaling by 2030. Next steps involve scoping services ASAP.
C – Competition:
No other vendors explicitly mentioned; SHI appears positioned as the preferred advisor. Imprivata participates for product integration, not competition.
Opportunity 2: SHI Azure Management / CSP Migration
B – Budget:
Not scoped yet but AmeriVet is open to SHI managing Azure as part of this initiative; requires additional conversation.
A – Authority:
Dieter indicated this would require broader internal agreement.
N – Need:
AmeriVet currently manages Azure directly. They may want SHI to manage Azure to streamline access to experts like Joey and ensure alignment with larger projects.
T – Timeline:
Post‑architecture review; future discussion.
C – Competition:
Potentially Microsoft direct; no other partner mentioned.

Initiatives

• Security:
– Imprivata
authentication appliances integration
– VPN
site‑to‑site and split‑tunnel security strategy
– Identity
traffic routing across clinics and Azure
• Infrastructure / Cloud Networking (Storage component
minimal):
– Azure Virtual
WAN architecture
– Hub/hub
connectivity
– VM sizing,
bandwidth planning
– Multiregion
active/active considerations

Tech Profile Updates

• AmeriVet is 100% Azure, with no
on‑prem infrastructure.
• No production
VPNs currently exist; one test VPN created recently.
• Microsoft Entra
ID fully leveraged for user authentication and SSO.
• Data team
maintains separate VM workloads (not relevant in this meeting).
• Imprivata
appliances run on pre‑packaged VMs requiring active/active pairs.
• Current POC
uses F4s_v2 SKU (~4 vCPU, 8GB RAM).

Meeting Notes

Environment

AmeriVet operates entirely in Azure with distributed clinics relying on cloud authentication services. The goal is to architect a performant, redundant, and cost‑efficient way for clinics to communicate with Imprivata’s Azure‑hosted authentication appliances over site‑to‑site VPN.

Detailed Discussion

• SHI opened with
an overview: objective is to evaluate AmeriVet’s Azure environment and identify needed changes to support the Imprivata integration.
• Imprivata
highlighted two pre‑meeting concerns:
– Need for
centralized ISP strategy
– Lack of static
public IPs at some clinic locations
• AmeriVet has
214 clinics today and expects ~500 by 2030.
• Authentication
traffic is lightweight; unlikely to exceed 100GB/month even at full scale.
• Virtual WAN
Basic vs. Standard:
– Basic includes
site‑to‑site VPN only
– Standard adds
Azure Firewall, express route, hub‑to‑hub
– AmeriVet likely
needs Basic unless multi‑region hubs are required
• Imprivata
requires an active/active pair of appliances for new customers.
• Appliances can
be deployed across different regions if desired (e.g., East + West).
• Azure Site
Recovery could integrate into the design for redundancy.
• Split tunneling
required to avoid unnecessary cost spikes.
• Joey (SHI) to
work with internal delivery team to determine consulting scope and implementation engagement model.
• SHI proposed
discussing AmeriVet moving Azure under SHI’s management to streamline advisory services.

Technical Notes (Granular Details)

• Imprivata appliances:
– Run on VMware,
Hyper‑V, Nutanix, Azure (AWS & GCP coming).
– Pre‑packaged
virtual machines; sizing is fixed except for data growth.
– Standard
performance capacity: up to ~28,000 user auth events per 15 minutes.
– Bandwidth
consumption extremely low (443 traffic only).
– Requires two appliances (active/active).
– Uses Oracle
GoldenGate replication; limited to two nodes.
• Azure VM SKU details:
– POC appliance
running on F4s_v2 (4 vCPU, 8GB RAM).
– Expected to
duplicate for active/active.
– Appliance cost
mostly fixed; storage growth variable.
• Azure VWAN:
– Regional
construct; inherently redundant across zones.
– Cost: cents per
hour for hub; additional cost per GB data processed.
– Supports
site‑to‑site and point‑to‑site VPN with equal pricing.
– Basic = only
site‑to‑site VPN.
– Standard =
firewall, express route, hub‑to‑hub.
– Hub/hub
required for multi‑region operations if devices are deployed in separate regions.
• Redundancy & Region Strategy:
– Active/active
across different regions is possible but not required.
– Imprivata
appliances can be failed over by cloning a healthy node.
– If only one
VWAN hub is deployed initially, a second hub can be added later.
• Connectivity Notes:
– Split tunneling
is required to avoid routing general traffic through Azure.
– Only
authentication‑specific traffic should traverse VPN.
– Lack of static
IPs at some clinics must be addressed; centralized ISP may solve. Roles: Speakers / Participants Jax Miley – SHI (Facilitator / Account Team) Joey Nikkel – SHI (Azure Architect / Technical Resource) Jason Marves – AmeriVet (Technical Lead) Dieter Karkut – AmeriVet (Technical / Infrastructure) Mark Berry – AmeriVet (Technical / Infrastructure) Taylor LeBlanc – Imprivata (Technical Architect) Natalie (Imprivata – referenced but absent)

Potential Next Steps

1. SHI to determine consulting engagement model
• Who: Joey (SHI)
• To: Dieter, Jason, Mark (AmeriVet)
• Joey will
contact SHI Delivery to confirm presets, scoping approaches, and minimum engagement model for VWAN deployment support.
2. Imprivata to share specifications and screenshots
• Who: Taylor (Imprivata)
• To: Meeting attendees
• Taylor
committed to sending architecture slides, ports, requirements, and VM specs.
3. Evaluate Azure management through SHI
• Who: Jax (SHI)
• To: Dieter (AmeriVet) and AmeriVet leadership
• Followup call
needed to explore shifting Azure management to SHI.
4. Determine final VWAN architecture (Basic vs.
Standard, 1 vs. multiple hubs)
• Who: AmeriVet (Jason, Dieter, Mark) with SHI
(Joey)
• Based on region
strategy, redundancy needs, ISP centralization, and Imprivata appliance placement.
5. Plan follow‑up architecture meeting
• Who: Jax (SHI)
• To: AmeriVet + Imprivata
• Triggered after
Joey defines consulting scope and options.
