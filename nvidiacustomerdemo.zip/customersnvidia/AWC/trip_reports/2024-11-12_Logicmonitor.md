Trip Report | Logicmonitor | AWC

Customer: AWC
AE: Kyle G
Topic: Logicmonitor
Meeting Date 11/12/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Julius

Compare Logic Monitor with other market leaders like Dynatrace and Datadog. Conduct a high-level walkthrough of the platform to assess its capabilities.

11/19/24

2

Shabnam

Plan for implementation if the decision is made to move forward.

11/19/24

Item Owner Next Steps/Detail Due Date 1 Julius Compare Logic Monitor with other market leaders like Dynatrace and Datadog. Conduct a high-level walkthrough of the platform to assess its capabilities. 11/19/24 2 Shabnam Plan for implementation if the decision is made to move forward. 11/19/24

Summary

The meeting focused on reviewing the Proof of Value (POV) sessions conducted with AWC, addressing the challenges they face with their current monitoring tools, and discussing how Logic Monitor can help overcome those challenges. The key issues identified include the use of multiple monitoring tools that lead to inefficiencies, a need for scalability due to anticipated growth, and the desire to reduce Mean Time to Repair (MTTR) with more proactive alerts. The session also highlighted Logic Monitor's capabilities in providing centralized visibility, automated resource discovery, and anomaly detection. The meeting concluded with discussions on the next steps, including internal reviews and potential implementation timelines.

Technical Notes

Logic Monitor provides out-of-the-box dashboards and automated resource discovery. The platform supports anomaly detection and proactive alerting. Synthetics can be used for web-based applications to monitor response times and perform simulations.

Logic Monitor provides out-of-the-box dashboards and automated resource discovery. The platform supports anomaly detection and proactive alerting. Synthetics can be used for web-based applications to monitor response times and perform simulations.

Agenda

Introduction and meeting commencement Review of POV sessions and findings Discussion of Logic Monitor's capabilities and solutions Addressing questions and concerns from the AWC team Discussion on Professional Services and post-sale support Next steps and timeline for decision-making

Introduction and meeting commencement Review of POV sessions and findings Discussion of Logic Monitor's capabilities and solutions Addressing questions and concerns from the AWC team Discussion on Professional Services and post-sale support Next steps and timeline for decision-making

Opps Identified & BANTC

Opportunity 1:

B: AWC
needs a scalable monitoring solution to handle growth and reduce MTTR.
A: Julius,
Ashton, Garen, and Brandon have the authority to evaluate and potentially approve the solution.
N: The
need is driven by the inefficiencies of current monitoring tools and the anticipated growth of AWC.
T: The
decision needs to be made by the end of November to start planning for the new year.
C: The
concern is whether Logic Monitor can integrate all necessary features.

B: AWC
needs a scalable monitoring solution to handle growth and reduce MTTR.
A: Julius,
Ashton, Garen, and Brandon have the authority to evaluate and potentially approve the solution.
N: The
need is driven by the inefficiencies of current monitoring tools and the anticipated growth of AWC.
T: The
decision needs to be made by the end of November to start planning for the new year.
C: The
concern is whether Logic Monitor can integrate all necessary features.

Initiatives

Security

Storage

Security

Storage

Tech Profile Updates

AWC is currently using multiple monitoring tools like PRTG and Zabbix, which are not scalable. Logic Monitor is proposed as a centralized solution to improve visibility and efficiency.

AWC is currently using multiple monitoring tools like PRTG and Zabbix, which are not scalable. Logic Monitor is proposed as a centralized solution to improve visibility and efficiency.

Meeting Notes

Environment

AWC is facing challenges with tool sprawl, manual work, and inefficiencies in monitoring.

AWC is facing challenges with tool sprawl, manual work, and inefficiencies in monitoring.

Detailed Discussion

The POV sessions demonstrated how Logic Monitor can provide centralized monitoring and reduce MTTR. The discussion included potential use cases for synthetic monitoring. The meeting covered post-sale support, including professional services and customer success management.

The POV sessions demonstrated how Logic Monitor can provide centralized monitoring and reduce MTTR. The discussion included potential use cases for synthetic monitoring. The meeting covered post-sale support, including professional services and customer success management. List all speakers/Participants of Transcript:

Julius Manuel Zelaya Ashton Dion Shab Garen Brandon

Julius Manuel Zelaya Ashton Dion Shab Garen Brandon
