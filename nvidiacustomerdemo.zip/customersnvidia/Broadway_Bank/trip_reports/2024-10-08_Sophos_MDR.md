Trip Report | Sophos MDR | Broadway Bank

Customer: Broadway Bank
AE: David A
Topic: Sophos MDR
Meeting Date 10/08/2024

*Internal notes – Please read and edit before sending externally*

Summary

ss. Action Items:

Item

Owner

Next Steps/Detail

Due Date

Quote

David A

Create PA Quote

10/14

Item Owner Next Steps/Detail Due Date Quote David A Create PA Quote 10/14

Agenda

Discussion on transitioning from SonicWall to Palo Alto Networks for enhanced

security and visibility.

Palo Alto offers both route-based and policy-based VPNs, with a preference for route-based. Detailed demo of Palo Alto's Application Control Center for traffic analysis. Emphasis on user activity tracking and threat investigation capabilities. Packet capture functionality available for troubleshooting and event-based analysis. Palo Alto provides comprehensive logging and customizable reports. Highlighted advanced threat protection features: antivirus, antispyware, and vulnerability protection. Future steps include reviewing quotes and potential configurations.

Discussion on transitioning from SonicWall to Palo Alto Networks for enhanced

security and visibility.

Palo Alto offers both route-based and policy-based VPNs, with a preference for route-based. Detailed demo of Palo Alto's Application Control Center for traffic analysis. Emphasis on user activity tracking and threat investigation capabilities. Packet capture functionality available for troubleshooting and event-based analysis. Palo Alto provides comprehensive logging and customizable reports. Highlighted advanced threat protection features: antivirus, antispyware, and vulnerability protection. Future steps include reviewing quotes and potential configurations.

Opps Identified & BANTC

Palo Alto Networks Firewall Upgrade
B: $150,000
A: Todd
Caldwell
N: Enhance
security and visibility, replace current SonicWall system
T: Q1
2025
C: Fortinet,
Zscaler

Palo Alto Networks Firewall Upgrade
B: $150,000
A: Todd
Caldwell
N: Enhance
security and visibility, replace current SonicWall system
T: Q1
2025
C: Fortinet,
Zscaler Attendees: SHI:

Nicole Agoncillo Gil ( Palo Alto) Manuel Zelaya (you) Syed

Nicole Agoncillo Gil ( Palo Alto) Manuel Zelaya (you) Syed

Customer:

Todd Caldwell Kelvin Laffoon

Todd Caldwell Kelvin Laffoon

Initiatives

Security (Firewall)

Tech Profile Updates

None

Meeting Notes

Environment

Current firewall: SonicWall Considering: Palo Alto Networks (PA) Internet setup: Adding another gig link from a different provider, to run concurrently current 1 Gig link

Current firewall: SonicWall Considering: Palo Alto Networks (PA) Internet setup: Adding another gig link from a different provider, to run concurrently current 1 Gig link Users:

Total users: 100-999

Total users: 100-999
