Trip Report | Microsoft Vmware | Broadway Bank

Customer: Broadway Bank
AE: David A
Topic: Microsoft Vmware
Meeting Date 07/22/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

David A

Send updated VMware license inventory reflecting retired host.Monitor EA expiration; engage on CSP/MPSA conversion; provide transition planning support.

08/15

Item Owner Next Steps/Detail Due Date 1 David A Send updated VMware license inventory reflecting retired host.Monitor EA expiration; engage on CSP/MPSA conversion; provide transition planning support. 08/15

Summary

The meeting with Broadway Bank centered around their evolving virtualization and cloud licensing needs, with a strong focus on technical strategy and operational efficiency. The bank is actively managing its VMware environment, recently retiring a host to optimize licensing costs, and is concurrently evaluating alternative hypervisors such as Nutanix Acropolis (noting industry shifts and the blurring lines between offerings from vendors like HPE, IBM, and Oracle). They are planning for their upcoming EA (Enterprise Agreement) to CSP/MPSA conversion as their contract nears expiration (8/31/2025), highlighting a significant licensing and cloud management transition opportunity for SHI. Security and compliance are key priorities, evidenced by ongoing Sophos deployment and interest in advanced employee access management/user attestation solutions (potentially SalePoint), pending budget approval for 2026. The SHI One portal was demonstrated, emphasizing its supplemental role to existing Microsoft admin portals, with particular attention to new features like project roadmaps, asset/license management, and cost/security analytics. The customer is also leveraging SHI’s infrastructure for hands-on labs and values portal-based project tracking for improved visibility and accountability. Overall, Broadway Bank is in a state of technical evaluation and optimization, with short-term focus on cloud licensing transitions and Sophos optimization, and medium-term interest in IAM and continued platform rationalization. Customer Technical Environment Notes:

Currently running VMware, actively assessing license needs. Recent hardware change: retirement of one VMware host to reduce license count. Exploring Nutanix Acropolis as an alternative hypervisor; familiar with Nutanix from prior use. Comparing hypervisor options (Nutanix, HPE, IBM, Oracle), aware of kernel similarities. Sophos security solution deployed (5-year term), focus on full feature adoption and tuning. M365/Azure environment; uses Microsoft portals. Interest in employee access management/user attestation (possible SalePoint). Engaged with SHI One for asset, license, and project management. Utilizing SHI’s on-demand labs for testing new infrastructure solutions.

Currently running VMware, actively assessing license needs. Recent hardware change: retirement of one VMware host to reduce license count. Exploring Nutanix Acropolis as an alternative hypervisor; familiar with Nutanix from prior use. Comparing hypervisor options (Nutanix, HPE, IBM, Oracle), aware of kernel similarities. Sophos security solution deployed (5-year term), focus on full feature adoption and tuning. M365/Azure environment; uses Microsoft portals. Interest in employee access management/user attestation (possible SalePoint). Engaged with SHI One for asset, license, and project management. Utilizing SHI’s on-demand labs for testing new infrastructure solutions.

Agenda

Review of VMware usage and current license posture. Discussion of alternative hypervisor platforms. Update on Sophos deployment and roadmap for feature utilization. Demonstration of SHI One portal (asset management, license monitoring, project roadmap). Overview of CSP value adds and transition from EA to CSP/MPSA.

Next steps for 2026

planning and budget cycle. Q&A and action item review.

Review of VMware usage and current license posture. Discussion of alternative hypervisor platforms. Update on Sophos deployment and roadmap for feature utilization. Demonstration of SHI One portal (asset management, license monitoring, project roadmap). Overview of CSP value adds and transition from EA to CSP/MPSA.

Next steps for 2026

planning and budget cycle. Q&A and action item review. Opps Identified & BANTC Opportunity 1: EA to CSP/MPSA Conversion

B: High – Contract
(EA) expires 8/31/2025; required transition to CSP/MPSA for ongoing cloud subscriptions.
A: Strong –
Customer has existing Microsoft workloads, uses SHI portals, and is actively planning the transition.
N: Immediate –
Licensing continuity and cost optimization; must avoid service disruption.
T: Next month
(August 2025); aligns with renewal/budget cycle.
C: Decision makers
identified (Jason, Tom, Michael); SHI well-positioned as incumbent and trusted advisor.

B: High – Contract
(EA) expires 8/31/2025; required transition to CSP/MPSA for ongoing cloud subscriptions.
A: Strong –
Customer has existing Microsoft workloads, uses SHI portals, and is actively planning the transition.
N: Immediate –
Licensing continuity and cost optimization; must avoid service disruption.
T: Next month
(August 2025); aligns with renewal/budget cycle.
C: Decision makers
identified (Jason, Tom, Michael); SHI well-positioned as incumbent and trusted advisor. Opportunity 2: Employee Access Management/User Attestation (IAM Solution, e.g., SalePoint)

B: Contingent –
Pending 2026 budget approval.
A: Moderate
Interest expressed, scope and funding to be determined.
N: Compliance and
security need; desire for comprehensive user attestation/employee access solution.
T: Targeting 2026,
decision post-budget cycle (late 2025).
C: IT leadership
involved, will escalate with budget clarity.

B: Contingent –
Pending 2026 budget approval.
A: Moderate
Interest expressed, scope and funding to be determined.
N: Compliance and
security need; desire for comprehensive user attestation/employee access solution.
T: Targeting 2026,
decision post-budget cycle (late 2025).
C: IT leadership
involved, will escalate with budget clarity. Opportunity 3: Sophos Optimization & Advanced Security Features

B: Secured –
Already purchased Sophos (5-year).
A: Active –
Customer seeks to maximize ROI, adopt new features, and tune deployment.
N: Ongoing –
Continuous security improvement and feature adoption.
T: Immediate and
ongoing.
C: Security team,
SHI technical support, and vendor engagement for enablement.

B: Secured –
Already purchased Sophos (5-year).
A: Active –
Customer seeks to maximize ROI, adopt new features, and tune deployment.
N: Ongoing –
Continuous security improvement and feature adoption.
T: Immediate and
ongoing.
C: Security team,
SHI technical support, and vendor engagement for enablement.

Initiatives

(Security or Storage or both):

Security: Sophos deployment/optimization, IAM/user attestation research. Storage/Virtualization: VMware environment management, evaluation of alternative hypervisors (Nutanix Acropolis, HPE, IBM, Oracle). Cloud Licensing/Management: Transition from EA to CSP/MPSA, leverage of SHI One for asset/license management and cost optimization.

Security: Sophos deployment/optimization, IAM/user attestation research. Storage/Virtualization: VMware environment management, evaluation of alternative hypervisors (Nutanix Acropolis, HPE, IBM, Oracle). Cloud Licensing/Management: Transition from EA to CSP/MPSA, leverage of SHI One for asset/license management and cost optimization. Tech Profile Updates:

VMware host count decreased by one (host retired). Evaluating Nutanix Acropolis as a possible VMware alternative. Sophos in post-deployment phase; two new features pending enablement. SHI One portal in active use; exploring additional features (roadmaps, project management). Upcoming transition to CSP/MPSA for Microsoft licensing. Interest in onboarding IAM/user attestation platform (2026).

VMware host count decreased by one (host retired). Evaluating Nutanix Acropolis as a possible VMware alternative. Sophos in post-deployment phase; two new features pending enablement. SHI One portal in active use; exploring additional features (roadmaps, project management). Upcoming transition to CSP/MPSA for Microsoft licensing. Interest in onboarding IAM/user attestation platform (2026). Meeting Notes:

next steps reviewed; SHI to follow up as new needs emerge.

next steps reviewed; SHI to follow up as new needs emerge. Detailed Discussion Notes:

VMware environment is actively managed; customer retired a host, requests updated license inventory from SHI. Nutanix Acropolis considered a strong candidate for future hypervisor needs, with customer having positive past experience. Market confusion due to similar core architectures across hypervisor vendors; customer appreciates SHI’s insight on market trends. Sophos security
