Trip Report | Rapid7's InsightVM tool | TGS

Customer: TGS
AE: Leslie S
Topic: Rapid7's InsightVM tool
Meeting Date 12/17/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Chelsea W

Follow up with TGS to explain Rapid7's position regarding InsightVM renewal efforts and discuss alternative offerings that align with their current tech strategy.

12/23

2

Leslie S

Internal SHI and TGS Sync Call

12/27

Item Owner Next Steps/Detail Due Date 1 Chelsea W Follow up with TGS to explain Rapid7's position regarding InsightVM renewal efforts and discuss alternative offerings that align with their current tech strategy. 12/23 2 Leslie S Internal SHI and TGS Sync Call 12/27

Summary

Summary

During the recent meeting with TGS Inc., it was proposed that they maybe transitioning to Microsoft Defender for Vulnerability Management, opting to replace Rapid7's InsightVM tool. This decision stems from the executive leadership's directive to maximize existing investments in Microsoft Defender, which has already been purchased and offers comparable functionalities to InsightVM. The timeline confusion reported by the customer indicates a two-week delay in their decision-making process, underscoring the need for more frequent timeline updates. The customer's preference to pivot away from InsightVM in favor of a different data risk management product created some tension, as Rapid7 was focused on retaining them within the InsightVM ecosystem to secure renewal credits for the Customer Success Manager. Despite InsightVM's non-renewal, TGS's strategy to consolidate their tech stack by offboarding competitors and centralizing on Microsoft technologies reflects an internal shift influenced by recent mergers. The cost was not the primary concern; rather, the redundancy of InsightVM's functionalities with those included in the Microsoft Defender package was decisive. Customer Technical Environment Notes:

Transitioning from InsightVM to Microsoft Defender for Vulnerability Management. Consolidating tech stack post-merger, focusing on Microsoft solutions. Existing licensing with Microsoft Defender covering vulnerability management needs.

Transitioning from InsightVM to Microsoft Defender for Vulnerability Management. Consolidating tech stack post-merger, focusing on Microsoft solutions. Existing licensing with Microsoft Defender covering vulnerability management needs.

Agenda

Discuss TGS's decision to transition to Microsoft Defender. Address timeline discrepancies and improve communication strategies. Explore potential Rapid7 offerings that align with TGS’s evolving requirements.

Discuss TGS's decision to transition to Microsoft Defender. Address timeline discrepancies and improve communication strategies. Explore potential Rapid7 offerings that align with TGS’s evolving requirements.

Opps Identified & BANTC

Opportunity 1: Data Risk Management
Solution

Opportunity 1: Data Risk Management
Solution

B: TGS's
leadership directive to maximize Microsoft investments.
A: Executive
leadership team at TGS.
N: Need
for streamlined data risk management post-merger.
T: Immediate
(due to merger-driven tech consolidation).
C: Aligns
with TGS's strategic direction to use existing Microsoft solutions.

B: TGS's
leadership directive to maximize Microsoft investments.
A: Executive
leadership team at TGS.
N: Need
for streamlined data risk management post-merger.
T: Immediate
(due to merger-driven tech consolidation).
C: Aligns
with TGS's strategic direction to use existing Microsoft solutions.

Initiatives (Security or Storage or both)

Security

Focus on Microsoft Defender integration. Potential for exploring new data risk management solutions.

Security

Focus on Microsoft Defender integration. Potential for exploring new data risk management solutions.

Tech Profile Updates

MSFT Defender adoption for vulnerability management. Phasing out InsightVM as part of tech stack optimization.

MSFT Defender adoption for vulnerability management. Phasing out InsightVM as part of tech stack optimization.

Meeting Notes

Confusion over timeline could have been mitigated with a reverse timeline visual. Awkwardness perceived in Rapid7's attempts to retain InsightVM. Importance of clarifying Rapid7's position to the customer for credit considerations.

Confusion over timeline could have been mitigated with a reverse timeline visual. Awkwardness perceived in Rapid7's attempts to retain InsightVM. Importance of clarifying Rapid7's position to the customer for credit considerations.

Detailed Discussion Notes

TGS's decision heavily influenced by executive leadership's cost-optimization strategy. Rapid7's focus on renewal credits and retention strategies. TGS's internal merging activities accelerating tech stack consolidation. Need for improved communication and timeline tracking with TGS.

TGS's decision heavily influenced by executive leadership's cost-optimization strategy. Rapid7's focus on renewal credits and retention strategies. TGS's internal merging activities accelerating tech stack consolidation. Need for improved communication and timeline tracking with TGS. Next Steps/detail:

Person: Chelsea Weber Action: Follow up with TGS to explain Rapid7's position regarding InsightVM renewal efforts and discuss alternative offerings that align with their current tech strategy.

Person: Chelsea Weber Action: Follow up with TGS to explain Rapid7's position regarding InsightVM renewal efforts and discuss alternative offerings that align with their current tech strategy. List all Participants

Chelsea Weber (Organizer) Manuel Zelaya David Shapiro John Keating Tor Saltveit Leslie Schmulson Gilberto Suarez Jeff Nicksa

Chelsea Weber (Organizer) Manuel Zelaya David Shapiro John Keating Tor Saltveit Leslie Schmulson Gilberto Suarez Jeff Nicksa
