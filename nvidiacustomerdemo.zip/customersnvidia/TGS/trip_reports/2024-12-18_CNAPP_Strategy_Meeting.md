Trip Report | CNAPP Strategy Meeting | TGS

Customer: TGS
AE: Leslie S
Topic: CNAPP Strategy Meeting
Meeting Date 12/18/2024

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Jake W

Provide scripts to estimate billable workloads for potential CSPM tools

01/10

2

Leslie S

Follow up with documentation on Wiz and Orca for evaluation.

01/10

3

Leslie S

Schedule a follow-up call in the new year to discuss further steps and potential engagements with CSPM vendors.

01/10

Item Owner Next Steps/Detail Due Date 1 Jake W Provide scripts to estimate billable workloads for potential CSPM tools 01/10 2 Leslie S Follow up with documentation on Wiz and Orca for evaluation. 01/10 3 Leslie S Schedule a follow-up call in the new year to discuss further steps and potential engagements with CSPM vendors. 01/10

Summary

The conversation primarily revolves around the challenges and considerations faced by ain managing their cloud security across multiple platforms, including Azure, GCP, and AWS. The company is leveraging native tools like Azure Defender for Cloud and Google Security Command Center but is exploring third-party solutions like Wiz and Orca for enhanced security posture management (CSPM) and multi-cloud visibility. They are also considering the integration and impact of these tools on their workflow, budget, and team capacity.

Agenda

Overview of current cloud security tools and challenges Discussion of potential third-party tools for CSPM Evaluation of licensing models and costs Strategies for integration and governance Next steps and follow-up actions

Overview of current cloud security tools and challenges Discussion of potential third-party tools for CSPM Evaluation of licensing models and costs Strategies for integration and governance Next steps and follow-up actions

Opps Identified & BANTC

Opportunity 1: Adoption of a
Third-Party CSPM Tool

B: Small
to medium-sized company with distributed teams managing multi-cloud environments.
A: The
security team, DevOps, and platform engineering teams.
N: Need
for better visibility and management of security posture across Azure, GCP, and AWS.
T: Immediate
exploration and potential implementation in the following year.
C: Budget
constraints and the need for a cost-effective solution; interest in vendors like Wiz, Orca, and Rapid7.

B: Small
to medium-sized company with distributed teams managing multi-cloud environments.
A: The
security team, DevOps, and platform engineering teams.
N: Need
for better visibility and management of security posture across Azure, GCP, and AWS.
T: Immediate
exploration and potential implementation in the following year.
C: Budget
constraints and the need for a cost-effective solution; interest in vendors like Wiz, Orca, and Rapid7.

Initiatives

Security

Enhance cloud security posture management.

Security

Enhance cloud security posture management.

Tech Profile Updates

Current tools: Azure Defender for Cloud, Google Security Command Center. Potential tools: Wiz, Orca, Rapid7, Prisma Cloud.

Current tools: Azure Defender for Cloud, Google Security Command Center. Potential tools: Wiz, Orca, Rapid7, Prisma Cloud.

Meeting Notes

Environment

Multi-cloud setup with Azure, GCP, and AWS. Use of native security tools on each platform. Interest in third-party solutions for improved multi-cloud security visibility.

Multi-cloud setup with Azure, GCP, and AWS. Use of native security tools on each platform. Interest in third-party solutions for improved multi-cloud security visibility.

Detailed Discussion

OVERVIEW

The company is looking for CSPM solutions that can integrate with existing cloud environments and provide a unified view of security posture across multiple clouds. Discussion on the challenges of adopting a large-scale security tool given the current team's size and capacity. Consideration of different licensing models and costs associated with third-party tools. Emphasis on starting with CSPM to address high-risk, internet-exposed vulnerabilities before deeper integration.

The company is looking for CSPM solutions that can integrate with existing cloud environments and provide a unified view of security posture across multiple clouds. Discussion on the challenges of adopting a large-scale security tool given the current team's size and capacity. Consideration of different licensing models and costs associated with third-party tools. Emphasis on starting with CSPM to address high-risk, internet-exposed vulnerabilities before deeper integration.

Current Cloud Security Tools and Challenges:

Current Cloud Security Tools and Challenges:

The customer described their multi-cloud environment, utilizing Azure, GCP, and AWS. They are currently leveraging native tools such as Azure Defender for Cloud and Google Security Command Center to manage their basic security posture. The main challenge is the lack of comprehensive visibility and management across all cloud platforms, especially as they scale up operations. There's a particular need for a unified view of security across their geographically distributed teams and environments.

The customer described their multi-cloud environment, utilizing Azure, GCP, and AWS. They are currently leveraging native tools such as Azure Defender for Cloud and Google Security Command Center to manage their basic security posture. The main challenge is the lack of comprehensive visibility and management across all cloud platforms, especially as they scale up operations. There's a particular need for a unified view of security across their geographically distributed teams and environments.

Exploration of Third-Party Tools:

Exploration of Third-Party Tools:

security maturity grows. This approach would help manage costs and reduce the risk of overwhelming the security team.

The conversation delved into the licensing models of third-party tools, which often involve different pricing tiers based on the number of billable security maturity grows. This approach would help manage costs and reduce the risk of overwhelming the security team.

Integration and Governance:

Integration and Governance:

The customer highlighted the importance of integrating new security tools with existing workflows and the potential challenges of involving multiple teams such as DevOps and platform engineering. The discussion touched on governance frameworks and the need for a coordinated approach to security across different parts of the organization. There was recognition that any new tool would require buy-in from various stakeholders to be effective.

The customer highlighted the importance of integrating new security tools with existing workflows and the potential challenges of involving multiple teams such as DevOps and platform engineering. The discussion touched on governance frameworks and the need for a coordinated approach to security across different parts of the organization. There was recognition that any new tool would require buy-in from various stakeholders to be effective.

Technical Considerations:

Technical Considerations:

The technical feasibility of excluding ephemeral workloads from licensing calculations was discussed. These workloads are part of the company's data processing operations and are isolated in their own environments. The conversation also addressed the technical capabilities of tools like Wiz and Orca, particularly their ability to provide real-time security insights and integrate with existing cloud infrastructure.

The technical feasibility of excluding ephemeral workloads from licensing calculations was discussed. These workloads are part of the company's data processing operations and are isolated in their own environments. The conversation also addressed the technical capabilities of tools like Wiz and Orca, particularly their ability to provide real-time security insights and integrate with existing cloud infrastructure.

Technical Notes

Importance of modular tool adoption to manage risk without overwhelming the team. Evaluation of tools like Wiz and Orca, which offer comprehensive security visibility but require significant investment. Discussion on the feasibility of excluding ephemeral workloads from licensing calculations.

Importance of modular tool adoption to manage risk without overwhelming the team. Evaluation of tools like Wiz and Orca, which offer comprehensive security visibility but require significant investment. Discussion on the feasibility of excluding ephemeral workloads from licensing calculations.
