Trip Report | Cloud Backup | TGS

Customer: TGS
AE: Leslie
Topic: Cloud Backup
Meeting Date 07/18/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

tNext Steps/Detail

Due Date

1

Leslie S

to coordinate a complimentary health check with technical SMEs (possibly Russ’s team) to review TGSs backup and storage environment (Veeam + Dell/Pure) and validate/optimize architecture.

08/15

2

Manuel Z

outline strategic consulting/PMO services for AWS migration, including potential workshops, roadmap development, and coordination with existing integrator (EPAM).

0815

Item Owner tNext Steps/Detail Due Date 1 Leslie S to coordinate a complimentary health check with technical SMEs (possibly Russ’s team) to review TGSs backup and storage environment (Veeam + Dell/Pure) and validate/optimize architecture. 08/15 2 Manuel Z outline strategic consulting/PMO services for AWS migration, including potential workshops, roadmap development, and coordination with existing integrator (EPAM). 0815

Summary

This meeting brought together stakeholders from SHI and TGS to review the current partnership, discuss TGS’s major digital transformation (moving from on-prem and GCP to AWS), and revisit the ongoing challenges and upcoming renewals across storage, security, and infrastructure. Key business drivers include a directive to fully migrate to AWS by April 2026, the retirement of on-prem HPC, and the consolidation of various IT platforms and licenses. The discussion illuminated pain points around backup and storage (especially with Veeam and Dell/Pure environments), VMware/Broadcom licensing confusion, and the need for streamlined renewal processes. Participants from SHI offered value-add services, such as technical health checks and strategic planning workshops, and outlined next steps to position themselves as consultative partners rather than transactional vendors. There are also upcoming opportunities for further engagement around security solutions, infrastructure workshops, and customer executive briefings.

Agenda

Updates on organizational and personnel changes at TGS Overview of TGS’s cloud migration initiative (GCP/on-prem to AWS) Review of current/expiring renewals (VMware, Pure Storage, Cisco Meraki, Veeam, SentinelOne, Okta, etc.) Discussion of pain points in backup and storage architecture (focus on Veeam + Dell/Pure) SHI’s value proposition: Health checks, technical workshops, and strategic planning Next steps for follow-up on renewals, health checks, and cloud migration support Invitation to SHI executive briefing events

Updates on organizational and personnel changes at TGS Overview of TGS’s cloud migration initiative (GCP/on-prem to AWS) Review of current/expiring renewals (VMware, Pure Storage, Cisco Meraki, Veeam, SentinelOne, Okta, etc.) Discussion of pain points in backup and storage architecture (focus on Veeam + Dell/Pure) SHI’s value proposition: Health checks, technical workshops, and strategic planning Next steps for follow-up on renewals, health checks, and cloud migration support Invitation to SHI executive briefing events

Opportunities Identified & BANTC

Opportunity 1: Storage & Backup Health Check/Optimization

B: High
(Critical pain: Current backup jobs are causing storage outages and data recovery issues. Need to validate/fix backup architecture and process.)
A: Tyler
McAfee (owns infrastructure/networking), Darren Kozlek (HPC/software stack), supported by IT team; SHI team to provide technical experts/health check.
N: Immediate/urgent
(systems are crashing, data at risk, impacting business continuity and future cloud migration projects).
T: Short-term,
with initial engagement as a complimentary health check; could expand to paid consulting/services depending on findings.
C: Consulting,
technical workshop, and possible follow-on projects for remediation or optimization.

B: High
(Critical pain: Current backup jobs are causing storage outages and data recovery issues. Need to validate/fix backup architecture and process.)
A: Tyler
McAfee (owns infrastructure/networking), Darren Kozlek (HPC/software stack), supported by IT team; SHI team to provide technical experts/health check.
N: Immediate/urgent
(systems are crashing, data at risk, impacting business continuity and future cloud migration projects).
T: Short-term,
with initial engagement as a complimentary health check; could expand to paid consulting/services depending on findings.
C: Consulting,
technical workshop, and possible follow-on projects for remediation or optimization. Opportunity 2: Renewal Management (Storage, Security, Networking)

B: Moderate
to high (multiple renewals coming up: Pure Storage, VMware, Cisco Meraki, SentinelOne, Okta, Veeam, etc.; need to maintain support through transition).
A: Tyler
McAfee (infrastructure/network), Espen’s team (M365/Okta), John Keating (security), TGS procurement; SHI AE Leslie Schmulson, Stephen Drake.
N: Medium
(renewal deadlines: October 2025–2027, with some requiring immediate attention, e.g., Pure X50, SentinelOne, Meraki).
T: Rolling
renewal periods over the next 6–18 months.
C: SHI
to provide renewal options, streamline processes, possibly bundle services, and assist with vendor negotiations.

B: Moderate
to high (multiple renewals coming up: Pure Storage, VMware, Cisco Meraki, SentinelOne, Okta, Veeam, etc.; need to maintain support through transition).
A: Tyler
McAfee (infrastructure/network), Espen’s team (M365/Okta), John Keating (security), TGS procurement; SHI AE Leslie Schmulson, Stephen Drake.
N: Medium
(renewal deadlines: October 2025–2027, with some requiring immediate attention, e.g., Pure X50, SentinelOne, Meraki).
T: Rolling
renewal periods over the next 6–18 months.
C: SHI
to provide renewal options, streamline processes, possibly bundle services, and assist with vendor negotiations. Opportunity 3: Cloud Migration Strategy and PMO Support

B: High
(mandated AWS migration, need for technical PMO to coordinate storage, compute, and application transitions).
A: Tyler
McAfee (infra), Darren Kozlek (HPC), John Keating/Louis (cloud), SHI strategic consulting team, Russ (TPX/strategic officer).
N: High
(AWS migration must be completed by April 2026; multiple dependencies and lease expirations).
T: Multi-phase,
starting immediately through 2026.
C: Strategic
consulting, project management, technical advisory.

B: High
(mandated AWS migration, need for technical PMO to coordinate storage, compute, and application transitions).
A: Tyler
McAfee (infra), Darren Kozlek (HPC), John Keating/Louis (cloud), SHI strategic consulting team, Russ (TPX/strategic officer).
N: High
(AWS migration must be completed by April 2026; multiple dependencies and lease expirations).
T: Multi-phase,
starting immediately through 2026.
C: Strategic
consulting, project management, technical advisory. Opportunity 4: Security Solutions & Modernization

B: Moderate
(evaluating Wiz/Arctic Wolf/Palo Alto, endpoint protection, Okta migration, backup security).
A: Tor
(security manager), John Keating (security lead), Espen (M365/Okta), SHI

security specialists.

N: Medium
(some renewals and migrations due in Q4 2025; ongoing evaluation of new solutions).
T: Ongoing
through 2026.
C: Security
architecture review, product evaluation, integration services.

B: Moderate
(evaluating Wiz/Arctic Wolf/Palo Alto, endpoint protection, Okta migration, backup security).
A: Tor
(security manager), John Keating (security lead), Espen (M365/Okta), SHI

security specialists.

N: Medium
(some renewals and migrations due in Q4 2025; ongoing evaluation of new solutions).
T: Ongoing
through 2026.
C: Security
architecture review, product evaluation, integration services.

Initiatives

Storage: Health check, renewal management, backup optimization, storage migration planning, Pure Storage, Dell, Veeam issues. Security: Endpoint protection renewal (SentinelOne), Okta/M365 migration, security architecture (Wiz, Arctic Wolf, Palo Alto), backup security. Both: Cloud migration support, holistic infrastructure & security planning.

Storage: Health check, renewal management, backup optimization, storage migration planning, Pure Storage, Dell, Veeam issues. Security: Endpoint protection renewal (SentinelOne), Okta/M365 migration, security architecture (Wiz, Arctic Wolf, Palo Alto), backup security. Both: Cloud migration support, holistic infrastructure & security planning.

Tech Profile Updates

Retiring all on-prem HPC (340 racks by April 2026) Full migration from GCP and on-prem to AWS (contract signed with AWS) Current storage: Dell Compellent, EqualLogic, Unity; Pure Storage FlashBlade/X50; legacy systems Backups: Veeam (with recent NAS licensing, issues with backup jobs causing outages) VMware vSphere (transitioning licenses, confusion over Broadcom/VCF, possible migration to alternative platforms) Network: Cisco Meraki (renewal needed), networking recently refreshed

Security

Okta (employee MFA moving to M365, client MFA sticking with Okta for now), SentinelOne (reduced footprint, renewal), considering Wiz/Arctic Wolf/Palo Alto Other: Kanji for Mac devices (moving to Jamf), Rapid7 (Tor’s team), M365 (Espen’s team)

Retiring all on-prem HPC (340 racks by April 2026) Full migration from GCP and on-prem to AWS (contract signed with AWS) Current storage: Dell Compellent, EqualLogic, Unity; Pure Storage FlashBlade/X50; legacy systems Backups: Veeam (with recent NAS licensing, issues with backup jobs causing outages) VMware vSphere (transitioning licenses, confusion over Broadcom/VCF, possible migration to alternative platforms) Network: Cisco Meraki (renewal needed), networking recently refreshed

Security

Okta (employee MFA moving to M365, client MFA sticking with Okta for now), SentinelOne (reduced footprint, renewal), considering Wiz/Arctic Wolf/Palo Alto Other: Kanji for Mac devices (moving to Jamf), Rapid7 (Tor’s team), M365 (Espen’s team)

Meeting Notes

Environment

TGS is undergoing a major organizational and technical transformation: all on-prem HPC and GCP workloads migrating to AWS by April 2026. Significant staff turnover and role changes (e.g., Matthew and Robert gone, Tyler now over infrastructure/networking). Current IT landscape is a mix of legacy and modern platforms, with overlapping/expiring contracts and maintenance agreements. Ongoing pain with backup/storage (Veeam + Dell/Pure), creating operational risk and business continuity concerns. SHI positioned as a value-add partner, offering technical workshops, health checks, and strategic planning. TGS is working with EPAM as primary AWS integrator for HPC, but needs additional help for general IT/storage/infrastructure.

TGS is undergoing a major organizational and technical transformation: all on-prem HPC and GCP workloads migrating to AWS by April 2026. Significant staff turnover and role changes (e.g., Matthew and Robert gone, Tyler now over infrastructure/networking). Current IT landscape is a mix of legacy and modern platforms, with overlapping/expiring contracts and maintenance agreements. Ongoing pain with backup/storage (Veeam + Dell/Pure), creating operational risk and business continuity concerns. SHI positioned as a value-add partner, offering technical workshops, health checks, and strategic planning. TGS is working with EPAM as primary AWS integrator for HPC, but needs additional help for general IT/storage/infrastructure.

Detailed Discussion

Digital Transformation: TGS is under executive mandate to fully evacuate GCP and on-prem data centers and operate in AWS by April 2026. This involves retiring 340 racks and migrating all corporate and HPC workloads. Renewals & Licensing: Multiple systems up for renewal (Pure, VMware, Meraki, SentinelOne, Veeam, Okta, Kanji, Rapid7). Confusion over VMware licensing (vSphere Standard vs. VCF), Pure Storage Evergreen requirements, and best practices for renewals. Backup/Storage Issues: Backups (Veeam) are causing storage outages when backing up new NAS data. Licensing complexity (capacity vs. unlimited, NAS vs. iSCSI), system crashes, and need for technical validation and architecture review. Security: Endpoint protection footprint reduced; migration from Okta to Microsoft Authenticator for employees (but not clients); considering new security vendors (Wiz, Arctic Wolf, Palo Alto); need to connect SHI with key

security stakeholders.

Partner Value: SHI offered complimentary technical health checks, workshops, and strategic planning support to help TGS with immediate pain points and long-term transformation. Professional Services: TGS may need to run a formal bid process due to involvement of EPAM and procurement standards. Next Steps: SHI to coordinate technical health check for storage/backup; engage with TGS security team leads for upcoming projects; provide renewal options for storage and networking; send info on SHI executive briefing events.

Digital Transformation: TGS is under executive mandate to fully evacuate GCP and on-prem data centers and operate in AWS by April 2026. This involves retiring 340 racks and migrating all corporate and HPC workloads. Renewals & Licensing: Multiple systems up for renewal (Pure, VMware, Meraki, SentinelOne, Veeam, Okta, Kanji, Rapid7). Confusion over VMware licensing (vSphere Standard vs. VCF), Pure Storage Evergreen requirements, and best practices for renewals. Backup/Storage Issues: Backups (Veeam) are causing storage outages when backing up new NAS data. Licensing complexity (capacity vs. unlimited, NAS vs. iSCSI), system crashes, and need for technical validation and architecture review. Security: Endpoint protection footprint reduced; migration from Okta to Microsoft Authenticator for employees (but not clients); considering new security vendors (Wiz, Arctic Wolf, Palo Alto); need to connect SHI with key

security stakeholders.

Partner Value: SHI offered complimentary technical health checks, workshops, and strategic planning support to help TGS with immediate pain points and long-term transformation. Professional Services: TGS may need to run a formal bid process due to involvement of EPAM and procurement standards. Next Steps: SHI to coordinate technical health check for storage/backup; engage with TGS security team leads for upcoming projects; provide renewal options for storage and networking; send info on SHI executive briefing events.

Technical Notes

Veeam Licensing: New NAS backup license acquired (1PB), but backup jobs are overwhelming storage systems, causing outages. Need to review Veeam configuration (NAS vs. iSCSI mounts, capacity, unlimited use licensing, backup job scheduling, resource allocation). Pure Storage Evergreen: Eligibility requires 3-year upfront payment; annual payments do not qualify. Must verify renewal/payment structure for controller upgrades. VMware/Broadcom: Uncertainty around vSphere Standard availability, pressure from Broadcom to move to VCF, customer resistance to new licensing model. Storage Environment: Mix of Dell (Compellent, EqualLogic, Unity), Pure Storage FlashBlade/X50, legacy platforms; leases expiring in 2026/2027, need for migration planning. Network: Cisco Meraki up for renewal; last renewed October 2024. Security: Okta moving to M365 for employee MFA, but client MFA remains on Okta for now; SentinelOne renewal for server endpoints only; considering new cloud security solutions (Wiz, Arctic Wolf, Palo Alto). Professional Services: Technical PMO needed for AWS migration, strategic oversight for storage/infrastructure transitions. Upcoming Projects: Data center move, AWS migration phases, lease buyouts/end-of-life planning for legacy systems.

Veeam Licensing: New NAS backup license acquired (1PB), but backup jobs are overwhelming storage systems, causing outages. Need to review Veeam configuration (NAS vs. iSCSI mounts, capacity, unlimited use licensing, backup job scheduling, resource allocation). Pure Storage Evergreen: Eligibility requires 3-year upfront payment; annual payments do not qualify. Must verify renewal/payment structure for controller upgrades. VMware/Broadcom: Uncertainty around vSphere Standard availability, pressure from Broadcom to move to VCF, customer resistance to new licensing model. Storage Environment: Mix of Dell (Compellent, EqualLogic, Unity), Pure Storage FlashBlade/X50, legacy platforms; leases expiring in 2026/2027, need for migration planning. Network: Cisco Meraki up for renewal; last renewed October 2024. Security: Okta moving to M365 for employee MFA, but client MFA remains on Okta for now; SentinelOne renewal for server endpoints only; considering new cloud security solutions (Wiz, Arctic Wolf, Palo Alto). Professional Services: Technical PMO needed for AWS migration, strategic oversight for storage/infrastructure transitions. Upcoming Projects: Data center move, AWS migration phases, lease buyouts/end-of-life planning for legacy systems. List of Speakers/Participants:

Leslie Schmulson (SHI Account Executive) Tyler McAfee (TGS Infrastructure/Networking lead) Darren Kozlek (TGS HPC/software stack lead) Stephen Drake (SHI) Espen (TGS, M365/Okta owner; referenced) Tor (TGS Security Manager; referenced) John Keating (TGS Security Lead) Louis Bayul (TGS Cloud Architect, UK-based; referenced) Russ (SHI Strategic Officer/TPX; referenced) Manuel Zelaya (SHI) Matthew (Former TGS; referenced) Robert Bradley (Former TGS Network Team; referenced) Gilbert (TGS Security; referenced) Others referenced but not directly involved in the conversation: Kanji/Jamf lead, Oslo manager

Leslie Schmulson (SHI Account Executive) Tyler McAfee (TGS Infrastructure/Networking lead) Darren Kozlek (TGS HPC/software stack lead) Stephen Drake (SHI) Espen (TGS, M365/Okta owner; referenced) Tor (TGS Security Manager; referenced) John Keating (TGS Security Lead) Louis Bayul (TGS Cloud Architect, UK-based; referenced) Russ (SHI Strategic Officer/TPX; referenced) Manuel Zelaya (SHI) Matthew (Former TGS; referenced) Robert Bradley (Former TGS Network Team; referenced) Gilbert (TGS Security; referenced) Others referenced but not directly involved in the conversation: Kanji/Jamf lead, Oslo manager

Potential Next Steps

Storage & Backup Health Check

Storage & Backup Health Check

Action: SHI (Leslie, Stephen) to coordinate a complimentary health check with technical SMEs (possibly Russ’s team) to review TGS’s backup and storage environment (Veeam + Dell/Pure) and validate/optimize architecture. Who: Leslie/Stephen (SHI) <> Tyler McAfee/Darren Kozlek (TGS); Russ (SHI Strategic Officer) to be engaged.

Action: SHI (Leslie, Stephen) to coordinate a complimentary health check with technical SMEs (possibly Russ’s team) to review TGS’s backup and storage environment (Veeam + Dell/Pure) and validate/optimize architecture. Who: Leslie/Stephen (SHI) <> Tyler McAfee/Darren Kozlek (TGS); Russ (SHI Strategic Officer) to be engaged.

Renewal Management

Renewal Management

Action: SHI to provide detailed renewal options for upcoming contracts (Pure Storage, Cisco Meraki, SentinelOne, VMware, Veeam, Okta, etc.), clarifying payment structures (e.g., Evergreen eligibility for Pure), SKU availability (VMware), and possible bundling. Who: Leslie (SHI) <> Tyler (TGS); Espen (M365/Okta), John Keating (security), Tor (security), as needed.

Action: SHI to provide detailed renewal options for upcoming contracts (Pure Storage, Cisco Meraki, SentinelOne, VMware, Veeam, Okta, etc.), clarifying payment structures (e.g., Evergreen eligibility for Pure), SKU availability (VMware), and possible bundling. Who: Leslie (SHI) <> Tyler (TGS); Espen (M365/Okta), John Keating (security), Tor (security), as needed.

Security Engagement

Security Engagement

Action: SHI to engage with Tor, John Keating, and Louis Bayul for security solution discussions (Wiz, Arctic Wolf, Palo Alto, SentinelOne, Okta/M365 migration). Who: Leslie/Stephen (SHI) <> Tor/John/Louis (TGS)

Action: SHI to engage with Tor, John Keating, and Louis Bayul for security solution discussions (Wiz, Arctic Wolf, Palo Alto, SentinelOne, Okta/M365 migration). Who: Leslie/Stephen (SHI) <> Tor/John/Louis (TGS)

Cloud Migration/PMO Support

Cloud Migration/PMO Support

Action: SHI to propose/outline strategic consulting/PMO services for AWS migration, including potential workshops, roadmap development, and coordination with existing integrator (EPAM). Who: Leslie/Stephen (SHI), Russ (SHI), Tyler/Darren/John/Louis (TGS)

Action: SHI to propose/outline strategic consulting/PMO services for AWS migration, including potential workshops, roadmap development, and coordination with existing integrator (EPAM). Who: Leslie/Stephen (SHI), Russ (SHI), Tyler/Darren/John/Louis (TGS)
