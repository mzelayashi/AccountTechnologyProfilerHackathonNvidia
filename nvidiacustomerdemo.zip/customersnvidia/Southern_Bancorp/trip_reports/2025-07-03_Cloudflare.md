Trip Report | Cloudflare | Southern Bancorp

Customer: Southern Bancorp
AE: Jax M
Topic: Cloudflare
Meeting Date 07/03/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Jax M

Deliver Cloudflare proposal and multi-year pricing – Due 7/7

07/07

2

Manuel Z

Assist and Coordinate DNS and application security transition with SHI

07/09

Item Owner Next Steps/Detail Due Date 1 Jax M Deliver Cloudflare proposal and multi-year pricing – Due 7/7 07/07 2 Manuel Z Assist and Coordinate DNS and application security transition with SHI 07/09

Summary

Southern Bancorp is actively seeking to enhance its security and web application infrastructure as part of a broader modernization initiative. The client currently manages multiple domains, with the primary domain being banksouthern.com, and handles most web traffic within the Southern US, facing no significant latency issues. However, their current DNS and application security provider has feature limitations, prompting a transition plan towards a more robust and flexible solution. Southern Bancorp is building out its application analytics and security stack in Azure, with a preference to keep DNS zone management within Azure while leveraging Cloudflare for advanced security and content delivery capabilities, notably Web Application Firewall (WAF) and CDN. The bank requires a tailored Cloudflare proposal that integrates seamlessly with Azure and supports future scalability and feature expansion. Decision-making involves both Rudi Ornelas and Marlene Dehart, with implementation scheduling targeting end of August due to internal resource constraints. The organization is open to multi-year agreements and requires detailed pricing and feature breakdowns from SHI for proper evaluation. Coordination between SHI, Cloudflare, and Southern Bancorp’s internal teams will be critical for a smooth DNS and application security transition. Customer Technical Environment Notes:

Multiple domains managed, primary: banksouthern.com, banksouthern.org DNS and application security currently managed by Smiley Most web traffic is regional (Southern US), minimal latency concerns Application stack and analytics being developed in Azure DNS zone management preferred in Azure Seeking Cloudflare for WAF, CDN, and additional security features Current provider lacks required advanced features

Multiple domains managed, primary: banksouthern.com, banksouthern.org DNS and application security currently managed by Smiley Most web traffic is regional (Southern US), minimal latency concerns Application stack and analytics being developed in Azure DNS zone management preferred in Azure Seeking Cloudflare for WAF, CDN, and additional security features Current provider lacks required advanced features Agenda: • Review of current security posture and domain management • Discussion of Cloudflare WAF/CDN capabilities and Azure integration • Outline transition plan from current DNS/application security provider • Determine initial domain scope for Cloudflare deployment • Explore multi-year pricing/options for Cloudflare • Define next steps and responsibilities for both SHI and Southern Bancorp

Opps Identified & BANTC

Opportunity 1: Cloudflare WAF and CDN Deployment
(Azure Integration) • B: Confirmed need for WAF and CDN to address security gaps and feature limitations with current provider • A: Rudi Ornelas (Cloud Info Security Architect) and Marlene Dehart (approvals/major decisions) • N: Immediate need to enhance security and enable future feature expansion; initial deployment by end of August targeted • T: Implementation to begin by end of August, pending internal scheduling and domain confirmation • C: Multi-year agreement options under evaluation; pricing and feature proposals required for approval
Opportunity 2: DNS/Application Security Transition
Support • B: Requirement to plan and execute DNS/application security transition from Smiley to Cloudflare (while managing DNS zones in Azure)  A: Rudi Ornelas, Smiley (internal lead), SHI Solutions Engineering • N: Ensuring no disruption during transition; need for integration support and configuration best practices • T: Transition planning to be completed by July 15; feedback on readiness and proposed timeline by July 31 • C: Dependent on internal readiness and Cloudflare feature alignment

Initiatives (Security or Storage or both)

Security

Cloudflare WAF, CDN, application security integration with Azure DNS/Application modernization and transition planning

Security

Cloudflare WAF, CDN, application security integration with Azure DNS/Application modernization and transition planning

Tech Profile Updates

Addition of Cloudflare WAF and CDN under evaluation Increased Azure integration for DNS zone management Decommissioning of legacy DNS/application security provider planned

Addition of Cloudflare WAF and CDN under evaluation Increased Azure integration for DNS zone management Decommissioning of legacy DNS/application security provider planned

Meeting Notes

Rudi (Southern Bancorp) oversees security, access management, and approves invoices Chrissy supports as cloud engineer Smiley currently manages DNS/application security, transition planning in scope Web traffic primarily Southern US; no current latency concerns

Security

enhancement (WAF, CDN) is critical; Cloudflare selected for evaluation DNS to remain in Azure; Cloudflare to augment security and delivery Multi-year Cloudflare agreements of interest Timeline driven by internal resource availability, aiming for August implementation

Rudi (Southern Bancorp) oversees security, access management, and approves invoices Chrissy supports as cloud engineer Smiley currently manages DNS/application security, transition planning in scope Web traffic primarily Southern US; no current latency concerns

Security

enhancement (WAF, CDN) is critical; Cloudflare selected for evaluation DNS to remain in Azure; Cloudflare to augment security and delivery Multi-year Cloudflare agreements of interest Timeline driven by internal resource availability, aiming for August implementation

Detailed Discussion Notes

SHI to provide Cloudflare proposal covering WAF, CDN, and Azure integration, including multi-year pricing (due 7/7) Southern Bancorp to confirm domain count for initial Cloudflare scope (due 7/7) Transition planning with Smiley for DNS/application security (due 7/15) Feedback on proposed timeline/readiness to start by end of August (due 7/31) Flexibility in future feature additions to Cloudflare stack discussed Approvals and scheduling coordinated between Rudi and Marlene; implementation window limited until end of August

SHI to provide Cloudflare proposal covering WAF, CDN, and Azure integration, including multi-year pricing (due 7/7) Southern Bancorp to confirm domain count for initial Cloudflare scope (due 7/7) Transition planning with Smiley for DNS/application security (due 7/15) Feedback on proposed timeline/readiness to start by end of August (due 7/31) Flexibility in future feature additions to Cloudflare stack discussed Approvals and scheduling coordinated between Rudi and Marlene; implementation window limited until end of August Next Steps/detail: Person name responsible Action

SHI (Jax Miley/Manuel Zelaya): Deliver Cloudflare proposal and multi-year pricing – Due 7/7 Southern Bancorp (Rudi Ornelas): Confirm number of domains for Cloudflare – Due 7/7 Southern Bancorp (Smiley): Coordinate DNS and application security transition with SHI – Due 7/15 Southern Bancorp (Team): Provide additional application/frontend requirements  Due 7/15 Southern Bancorp (Rudi/Marlene): Feedback on timeline, confirm readiness – Due 7/31

SHI (Jax Miley/Manuel Zelaya): Deliver Cloudflare proposal and multi-year pricing – Due 7/7 Southern Bancorp (Rudi Ornelas): Confirm number of domains for Cloudflare – Due 7/7 Southern Bancorp (Smiley): Coordinate DNS and application security transition with SHI – Due 7/15 Southern Bancorp (Team): Provide additional application/frontend requirements  Due 7/15 Southern Bancorp (Rudi/Marlene): Feedback on timeline, confirm readiness – Due 7/31 List all speakers/Participants of Transcript:

Rudi Ornelas, Cloud Info Security Architect, Southern Bancorp Marlene Dehart, Southern Bancorp (decision maker) Chrissy, Cloud Engineer, Southern Bancorp Smiley, DNS/Application Security Lead, Southern Bancorp Jordan Miles, Account Manager, Cloudflare Jax Miley, Commercial Account Executive, SHI Manuel Zelaya, Commercial Solutions Engineer, SHI

Rudi Ornelas, Cloud Info Security Architect, Southern Bancorp Marlene Dehart, Southern Bancorp (decision maker) Chrissy, Cloud Engineer, Southern Bancorp Smiley, DNS/Application Security Lead, Southern Bancorp Jordan Miles, Account Manager, Cloudflare Jax Miley, Commercial Account Executive, SHI Manuel Zelaya, Commercial Solutions Engineer, SHI
