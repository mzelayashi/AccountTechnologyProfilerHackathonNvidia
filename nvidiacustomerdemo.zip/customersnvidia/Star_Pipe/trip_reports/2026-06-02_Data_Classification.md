Trip Report | Data Classification | Star Pipe

Customer: Star Pipe
AE: Felix M
Topic: Data Classification
Meeting Date 06/02/2026

*Internal notes – Please read and edit before sending externally*

Summary

• This meeting
between SHI and Star Pipe Products focused on evaluating Data Classification

Agenda

• Review customer
progress on DLP/Data Classification evaluations
• Present SHI
market comparison across vendors (Concentric, Varonis, Netrix, Fortra)
• Discuss
technical fit: deployment, automation, AI readiness
• Identify

Opps Identified & BANTC

Opportunity 1: Data Classification / DLP Platform
(Primary – Concentric Focus)
• B: Budget not
explicitly confirmed; customer reviewing quotes and sizing concerns (initial quote included excessive storage sizing)
• A: Jeff Greer
(Director of IT, Star Pipe Products) is primary decision maker
• N: Need to
identify data location, permissions, and sensitive data; prevent data exposure and support AI governance
• T: Near-term –

Initiatives

• Security – Data
classification, DLP, AI governance readiness
• Security –
Evaluation of automated policy enforcement vs manual rule-based controls
• (Secondary)
Platform/Cloud Management – Microsoft licensing and management optimization

Tech Profile Updates

• Current storage
platform includes NetApp (integration issues observed with Varonis)
• Limited
exposure to regulated data (no major HIPAA/PCI footprint)
• Sensitive data
includes engineering drawings and custom ERP code
• Prior tool
usage includes Fortra (Frontline vulnerability scanning)
• Actively
evaluating Concentric AI; previously attempted Varonis deployment

Meeting Notes

Environment

• Hybrid/on-prem

environment with NetApp storage

• Limited
regulatory constraints; focus is operational visibility and governance
• Early-stage AI
adoption planning

Detailed Discussion

• Customer
confirmed unsuccessful Varonis POC due to inability to integrate with NetApp without enabling deprecated features, which they refused for security reasons.
• SHI presented
vendor comparison showing Concentric and Varonis as top performers, with Concentric leading in data discovery/classification and deployment simplicity.
• Customer
validated alignment with findings and confirmed they are “on the right path” with current evaluation strategy.
• AI governance
emerged as a key theme—customer wants to prevent misuse of AI tools (e.g., prompts exposing sensitive data).
• Discussion
highlighted contrast between rule-based systems (Varonis, Fortra) vs AI-driven automated solutions (Concentric, Netrix).
• Deployment
complexity and operational overhead were major decision drivers, favoring Concentric and Netrix over Varonis.

Technical Notes

• Varonis
integration issue: required enabling deprecated NetApp features to function
• Concentric:

AI-driven classification and policy enforcement Requires training period (~1–2 months before automation matures) Strong performance in data discovery/classification Weaker in formal compliance frameworks (less FedRAMP/CMMC maturity)
• Netrix:
Strong deployment support (white-glove implementation) Good admin usability and automation capabilities
• Fortra:
Previously used for vulnerability scanning (Frontline) Lower performance in DLP/classification categories
• Rule-based vs AI automation:
Varonis/Fortra require manual policy definition (IF/AND logic) Concentric/Netrix automate detection and enforcement post-training
• AI governance use case:
Preventing sensitive data leakage via prompts to AI tools (ChatGPT/Claude)
• Quote issue:
Initial Concentric quote incorrectly sized (~550TB); being corrected
• Sensitive data type scope:
Engineering drawings Custom ERP code
• No heavy regulatory requirements impacting solution choice

AI-driven classification and policy enforcement Requires training period (~1–2 months before automation matures) Strong performance in data discovery/classification Weaker in formal compliance frameworks (less FedRAMP/CMMC maturity)
• Netrix:
Strong deployment support (white-glove implementation) Good admin usability and automation capabilities
• Fortra:
Previously used for vulnerability scanning (Frontline) Lower performance in DLP/classification categories
• Rule-based vs AI automation:
Varonis/Fortra require manual policy definition (IF/AND logic) Concentric/Netrix automate detection and enforcement post-training
• AI governance use case:
Preventing sensitive data leakage via prompts to AI tools (ChatGPT/Claude)
• Quote issue:
Initial Concentric quote incorrectly sized (~550TB); being corrected
• Sensitive data type scope:
Engineering drawings Custom ERP code
• No heavy regulatory requirements impacting solution choice

ROLES

• Manuel Zelaya –
Commercial Solutions Engineer, SHI
• Felix Menchaca
– Commercial Inside Account Representative, SHI
• Jeff Greer –
Director of Information Technology, Star Pipe Products
• Parth Patel –
IT / Help Desk, Star Pipe Products
• Stephen Drake –
SHI (supporting role, not active in discussion)

Potential Next steps

• Felix Menchaca
→ Jeff Greer: Send corrected Concentric quotes and validate sizing
• Felix Menchaca
→ Jeff Greer: Schedule follow-up with Concentric rep (Jason) to initiate POC and review LOA terms
• Jeff Greer →
SHI: Review quote and confirm willingness to proceed with POC
• Felix Menchaca
→ Internal SHI + Customer: Clarify procurement language (try-and-buy / exit clauses)
• Felix Menchaca
→ Jeff Greer: Schedule Microsoft strategy/pricing discussion for next week
• Parth Patel →
SHI: Engage SHI for escalation support on future vendor issues as needed
