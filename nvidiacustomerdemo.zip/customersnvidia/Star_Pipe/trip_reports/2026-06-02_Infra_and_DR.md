Trip Report | Infra and DR | Star Pipe

Customer: Star Pipe
AE: Felix M
Topic: Infra and DR
Meeting Date 06/02/2026

*Internal notes – Please read and edit before sending externally*

Summary

Summary

• This call
focused on Star Pipe Products’ disaster recovery strategy, colocation direction, and whether a managed DR-as-a-service model is viable versus building and operating a customer-owned secondary DR environment. The customer made clear they are still in evaluation mode and likely will not execute until next year, but they are leaning toward building their own DR site in a DataBank colocation facility, most likely in Kansas City, because they already trust DataBank in Houston, want operational control, and need flexibility to fail over and fail back without incurring variable hosted-service costs.
• The strongest
business driver is resiliency without lock-in. Jeff emphasized that any solution must support failback cleanly, preserve the existing NetApp-based file services environment, and accommodate networking and firewall dependencies

Agenda

• Review Star
Pipe’s current infrastructure and DR direction
• Discuss
colocation versus DRaaS options
• Understand
technical constraints including NetApp, SD-WAN, firewall, DNS, and failback requirements
• Explore
potential geographies for DR outside Texas
• Determine
whether SHI should help with market analysis and provider comparisons
• Briefly align
on next-day discussion regarding data classification and DLP vendor evaluation

Opps Identified & BANTC

Opportunity 1: Disaster Recovery / Colocation Strategy
and Potential Provider Evaluation
• B: Budget not formally disclosed. Customer
indicated DRaaS economics matter and that hosted models become less attractive when compared to owning infrastructure that can be used for failover during refreshes without added ongoing failover charges. Preliminary pricing from Flexential was requested as a “gut check,” suggesting pricing sensitivity exists but no approved budget was shared.
• A: Jeff Greer appears to be the primary
technical decision-maker and lead evaluator. Parth Patel is involved technically. SHI resources include Felix Menchaca and Matthew Bracy.

environment in DataBank.

Opportunity 2: Data Classification / DLP Vendor
Evaluation
• B: No budget disclosed. Felix indicated SHI
could provide Concentric quotes quickly.
• A: Jeff Greer appears to be the lead evaluator;
Parth Patel also participates. Felix is guiding the vendor discussion on SHI’s side.

Initiatives

• Infrastructure Resiliency / Disaster Recovery
Modernization — Storage Focus on designing a secondary DR environment, determining whether to build or consume DRaaS, and aligning the architecture to NetApp replication, SD-WAN, firewalls, and failback requirements.
• Data Classification and DLP Evaluation — Security
Early-stage evaluation of data classification and data protection vendors, with preference for an agnostic market discussion before narrowing to a product.

Tech Profile Updates

• Current
colocation provider in Houston is DataBank
• Preferred DR
build location currently leaning toward Kansas City
• Customer is
likely to keep colocation with DataBank if they pursue build-versus-buy
• Star Pipe runs
NetApp, including a CIFS virtual machine hosting approximately 8 TB of CIF shares

Meeting Notes

Environment

• Production
colocation currently sits in DataBank Houston

Technical Notes

• DataBank
Houston is the customer’s current production colocation environment
• Desired DR
geography must be outside Texas
• Kansas City is
attractive due to DataBank presence and nearby warehouse staff who can provide local assistance
• Alternative
acceptable geographies mentioned: Salt Lake City, Sacramento, Indianapolis area, and outside Atlanta

ROLES

• Manuel Zelaya — Solutions Engineer, SHI
• Felix Menchaca — Commercial Inside Account
Representative / Account Lead, SHI
• Matthew Bracy — Solution Specialist, Service
Providers Practice, SHI
• Jeff Greer — Director of Information
Technology, Star Pipe Products
• Parth Patel — Technical participant / IT
stakeholder, Star Pipe Products
• Stephen Drake — SHI participant listed on
meeting invite, not active in transcript

Potential Next steps

• Jeff Greer to Matthew Bracy / SHI: Send RVTools
export and provide workload categorization using green / yellow / red so SHI can size a potential DRaaS option appropriately. Involved: Jeff Greer, Matthew Bracy, Felix Menchaca
• Matthew Bracy to Jeff Greer / Star Pipe: Use
the RVTools data to engage Flexential for preliminary DRaaS pricing and architecture alignment, especially around NetApp-based replication support. Involved: Matthew Bracy, Jeff Greer, Felix Menchaca
• Matthew Bracy / SHI internal follow-up: Gather
any additional technical questions after reviewing the RVTools output and consolidate them through Felix if more customer clarification is needed. Involved: Matthew Bracy, Felix Menchaca, Jeff Greer, Parth Patel
• SHI to Star Pipe: Return with preliminary
Flexential numbers within roughly one to two weeks after receipt of RVTools so
