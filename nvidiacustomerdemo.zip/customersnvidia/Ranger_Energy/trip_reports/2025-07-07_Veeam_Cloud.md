Trip Report | Veeam Cloud | Ranger Energy

Customer: Ranger Energy
AE: Felix M
Topic: Veeam Cloud
Meeting Date 07/07/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Felix M

coordinate with Val (SHI Renewals Rep). Consolidate all Veeam Data Vault (Foundation/Advanced) and Data Cloud for M365 quotes

07/16

2

Manuel Z

provide further demos if needed; Matt Bennett/Steve Miller to request as required. Action: If needed, schedule hands-on, trial, or further technical deep-dive prior to final decision

07/16

Item Owner Next Steps/Detail Due Date 1 Felix M coordinate with Val (SHI Renewals Rep). Consolidate all Veeam Data Vault (Foundation/Advanced) and Data Cloud for M365 quotes 07/16 2 Manuel Z

provide further demos if needed; Matt Bennett/Steve Miller to request as required. Action: If needed, schedule hands-on, trial, or further technical deep-dive prior to final decision

provide further demos if needed; Matt Bennett/Steve Miller to request as required. Action: If needed, schedule hands-on, trial, or further technical deep-dive prior to final decision

provide further demos if needed; Matt Bennett/Steve Miller to request as required. Action: If needed, schedule hands-on, trial, or further technical deep-dive prior to final decision 07/16

Summary

Summary

This meeting was a technical and business review/demo of Veeam Data Vault, with SHI presenting to Ranger Energy Services. The conversation focused on comparing Veeam Data Vault to the customer’s current Wasabi solution for backup storage and immutability, as well as evaluating Veeam Data Cloud for M365 for protecting SharePoint Online and OneDrive data for C-level users. Key points discussed included the differentiators between Veeam and Wasabi (immutability, end-to-end encryption, pricing, restore policies), challenges with immutable storage and backup retention management, pricing models (per user vs per storage), and roadmap items for future integration. There was also a discussion around contract renewals, sizing, and quote requirements, as well as the value of the vendor relationship and SHI’s

Agenda

Review main differentiators between Veeam Data Vault and Wasabi Discuss requirements and limitations around immutability and backup management Explore M365 backup use cases, integration status, and potential transition paths Address restore scenarios, pricing, and consumption models Review contract timelines and quoting process Discuss

next steps and action items

Review main differentiators between Veeam Data Vault and Wasabi Discuss requirements and limitations around immutability and backup management Explore M365 backup use cases, integration status, and potential transition paths Address restore scenarios, pricing, and consumption models Review contract timelines and quoting process Discuss

next steps and action items

Opps Identified & BANTC Opportunity 1: Replace/augment Wasabi with Veeam Data Vault for B&R

B (Budget): Customer is in renewal window, open to competitive pricing, has reviewed quotes for both Foundation and Advanced. A (Authority): Matt Bennett (IT), Steve Miller (IT), C-level users impacted; Matt appears to be decision maker, with Felix as procurement. N (Need): Need for scalable, immutable backup storage with manageable restore policies, cost-effective, secure, and with flexibility for retention policies. T (Timeline): Wasabi renewal in ~45 days (August); need to finalize decision and PO before end of current contract. C (Competition): Wasabi (incumbent), possibly others; Veeam Data Vault must demonstrate clear differentiators.

B (Budget): Customer is in renewal window, open to competitive pricing, has reviewed quotes for both Foundation and Advanced. A (Authority): Matt Bennett (IT), Steve Miller (IT), C-level users impacted; Matt appears to be decision maker, with Felix as procurement. N (Need): Need for scalable, immutable backup storage with manageable restore policies, cost-effective, secure, and with flexibility for retention policies. T (Timeline): Wasabi renewal in ~45 days (August); need to finalize decision and PO before end of current contract. C (Competition): Wasabi (incumbent), possibly others; Veeam Data Vault must demonstrate clear differentiators. Opportunity 2: Implement Veeam Data Cloud for M365 for C-suite SharePoint/OneDrive

B (Budget): Will require separate quote; per-user pricing for ~15 C-level users, with flexibility to add more. A (Authority): Matt Bennett and Steve Miller; C-suite user needs are the business driver. N (Need): M365-specific backup-as-a-service with ease of restoration, unlimited retention, and no need for on-prem hardware. T (Timeline): Aligned with Wasabi renewal; could be implemented as a step-up/transition. C (Competition): Wasabi (for current M365 backup), possibly other SaaS backup providers.

B (Budget): Will require separate quote; per-user pricing for ~15 C-level users, with flexibility to add more. A (Authority): Matt Bennett and Steve Miller; C-suite user needs are the business driver. N (Need): M365-specific backup-as-a-service with ease of restoration, unlimited retention, and no need for on-prem hardware. T (Timeline): Aligned with Wasabi renewal; could be implemented as a step-up/transition. C (Competition): Wasabi (for current M365 backup), possibly other SaaS backup providers.

Initiatives

Security: Immutability, ransomware protection, end-to-end encryption, restore integrity. Storage: Cloud backup consolidation, cost-effective scaling, retention management, policy flexibility. Both: M365 data protection, SaaS backup adoption, hybrid backup strategy.

Security: Immutability, ransomware protection, end-to-end encryption, restore integrity. Storage: Cloud backup consolidation, cost-effective scaling, retention management, policy flexibility. Both: M365 data protection, SaaS backup adoption, hybrid backup strategy. Tech Profile Updates:

Current backup storage: Wasabi (cloud), on-prem file server phased out, SharePoint Online/OneDrive used for core business data. Veeam B&R in place; M365 backup for SharePoint Online and 15 C-level user OneDrives. Exploring move to Veeam Data Vault for immutable cloud storage (Foundation or Advanced). Considering Veeam Data Cloud for M365 for SaaS-native backup. Retention periods mostly short-term (2 weeks to 30 days), some SOX/financial compliance data may require longer retention. No Teams data backup required.

Current backup storage: Wasabi (cloud), on-prem file server phased out, SharePoint Online/OneDrive used for core business data. Veeam B&R in place; M365 backup for SharePoint Online and 15 C-level user OneDrives. Exploring move to Veeam Data Vault for immutable cloud storage (Foundation or Advanced). Considering Veeam Data Cloud for M365 for SaaS-native backup. Retention periods mostly short-term (2 weeks to 30 days), some SOX/financial compliance data may require longer retention. No Teams data backup required. Meeting Notes:

Environment

Ranger Energy has migrated most users off on-prem file servers to SharePoint Online. Current backup jobs are sized for 25-35 TB. Only 15 C-level users require advanced M365 backup. File server backup rotation offloaded to SharePoint; legacy air-gap strategies replaced by cloud-native immutability.

Ranger Energy has migrated most users off on-prem file servers to SharePoint Online. Current backup jobs are sized for 25-35 TB. Only 15 C-level users require advanced M365 backup. File server backup rotation offloaded to SharePoint; legacy air-gap strategies replaced by cloud-native immutability. Detailed Discussion:

Immutability: Both Wasabi and Veeam enforce data retention strictly; deletion only after policy expires. Multiple vaults/retention policies available. Restore/Egress: Wasabi and Veeam Data Vault Foundation both have “fair use” (20% of total data per year) before extra charges; Advanced has unlimited. Most customers never hit the threshold. M365 Integration: Veeam Data Vault does not yet support direct M365 backup; Data Cloud for M365 is available as a SaaS option, with per-user pooled storage (100-300GB/user). Retention Management: Changing retention periods applies only to new backups; existing backups remain locked for their original period. Growth

Next steps

Quote Consolidation & Review:

Quote Consolidation & Review:

Who: Felix Menchaca (SHI) to Matt Bennett (Ranger), Lew Reed (SHI) to coordinate with Val (SHI Renewals Rep). What: Consolidate all Veeam Data Vault (Foundation/Advanced) and Data Cloud for M365 quotes; send to Matt for review. Action: Felix to email and follow up. Lew to ensure Val sends quotes to Felix for relay to Matt. Timeline: ASAP, prior to Wasabi renewal (in ~45 days).

Who: Felix Menchaca (SHI) to Matt Bennett (Ranger), Lew Reed (SHI) to coordinate with Val (SHI Renewals Rep). What: Consolidate all Veeam Data Vault (Foundation/Advanced) and Data Cloud for M365 quotes; send to Matt for review. Action: Felix to email and follow up. Lew to ensure Val sends quotes to Felix for relay to Matt. Timeline: ASAP, prior to Wasabi renewal (in ~45 days).

Sizing Verification:

Sizing Verification:

Who: Matt Bennett, Steve Miller (Ranger) with support from Lew Reed (SHI). What: Use Veeam sizing calculator to validate 25/35TB numbers for Data Vault, confirm user count for M365. Action: Matt to use calculator link provided in chat; follow-up with SHI/ Lew if further clarification needed.

Who: Matt Bennett, Steve Miller (Ranger) with support from Lew Reed (SHI). What: Use Veeam sizing calculator to validate 25/35TB numbers for Data Vault, confirm user count for M365. Action: Matt to use calculator link provided in chat; follow-up with SHI/ Lew if further clarification needed.

Demo/POC/Further Technical Review:

Demo/POC/Further Technical Review:

Who: Matt Ellis (SHI) to provide further demos if needed; Matt Bennett/Steve Miller to request as required. Action: If needed, schedule hands-on, trial, or further technical deep-dive prior to final decision.

Who: Matt Ellis (SHI) to provide further demos if needed; Matt Bennett/Steve Miller to request as required. Action: If needed, schedule hands-on, trial, or further technical deep-dive prior to final decision.

Decision & Purchase Order:

Decision & Purchase Order:

Who: Matt Bennett (Ranger) to approve, Felix Menchaca (SHI) to process. What: Once pricing/quotes are confirmed, consolidate into one PO for both Data Vault and M365 solutions. Timeline: Before Wasabi contract renewal deadline.

Who: Matt Bennett (Ranger) to approve, Felix Menchaca (SHI) to process. What: Once pricing/quotes are confirmed, consolidate into one PO for both Data Vault and M365 solutions. Timeline: Before Wasabi contract renewal deadline.

Optional – Onsite Meeting:

Optional – Onsite Meeting:

Who: Lew Reed (SHI), Matt Bennett, Steve Miller, Felix Menchaca. What: Lew to visit Houston for in-person relationship-building/lunch, as discussed. Timeline: Next month (per Lew’s travel schedule).

Who: Lew Reed (SHI), Matt Bennett, Steve Miller, Felix Menchaca. What: Lew to visit Houston for in-person relationship-building/lunch, as discussed. Timeline: Next month (per Lew’s travel schedule).

Monitor Roadmap for M365 Direct Integration:

Monitor Roadmap for M365 Direct Integration:

Who: SHI (Lew, Matt Ellis) to update Ranger as Veeam roadmap develops. What: Notify when direct Data Vault support for M365 backup is GA.

Who: SHI (Lew, Matt Ellis) to update Ranger as Veeam roadmap develops. What: Notify when direct Data Vault support for M365 backup is GA.

Internal:

Internal:

Who: Matt Bennett, Steve Miller. What: Discuss “offline” strategy for M365 backup coverage gap until Veeam integration is ready.

Who: Matt Bennett, Steve Miller. What: Discuss “offline” strategy for M365 backup coverage gap until Veeam integration is ready.
