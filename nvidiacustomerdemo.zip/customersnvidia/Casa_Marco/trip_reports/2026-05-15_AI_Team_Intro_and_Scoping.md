Trip Report | AI Team Intro and Scoping | Casa Marco

Customer: Casa Marco
AE: Tony V
Topic: AI Team Intro and Scoping
Meeting Date 05/15/2026

*Internal notes – Please read and edit before sending externally*

Summary

Summary: This meeting focused on early-stage AI strategy alignment between SHI (sales and AI specialists) and Casa Marco (customer), centered on evaluating scalable AI solutions to support internal business operations and future customer-facing environment, with limited centralized governance, inconsistent tooling (SharePoint, Box, local servers, hard drives), and minimal AI adoption beyond ad hoc usage of tools like ChatGPT and Claude. Executive leadership (owner and CEO) is highly motivated to deploy AI rapidly, but expectations are misaligned with the effort required to implement enterprise-grade workflows. Key business themes include: • Need for centralized data strategy before AI deployment
• Desire for
simplified, low-maintenance AI solutions due to small IT team
• Interest in
cost-effective multi-model AI platforms (e.g., Expedient)
• Exploration of
Microsoft Copilot as a governance-first enterprise standard
• Strong
opportunity to drive efficiency across departments (accounting, HR, creative, inventory)
• Early demand
for AI-powered automation, analytics, and image processing (especially around artwork classification and retrieval)
• Broader
opportunity to position SHI as both strategic advisor (readiness, governance, use cases) and implementation partner Agenda: • Introductions and roles within SHI AI team
• Review of Casa
Marco’s current AI usage and exploration efforts
• Discussion of
Expedient platform and multi-model AI approach
• Evaluation of
Microsoft Copilot capabilities and fit
• Data readiness,
governance, and structuring challenges
• Identification
of potential AI use cases (internal and external)
• Exploration of
AI services: readiness assessment, workshops, POCs
• Alignment on

next steps including demos and follow-ups

Opps Identified

& BANTC
Opportunity 1:
Microsoft Copilot Enterprise Adoption (Primary) • B: Budget exists within existing Microsoft licensing; potential expansion expected
• A: Mark (IT
lead), with influence from Owner and CEO
• N: Need for
secure, governed enterprise AI platform integrated with existing Microsoft stack
• T: Near-term
(post-demo evaluation and internal training dependent)
• C: Competition
includes standalone AI tools (ChatGPT, Claude, Expedient multi-model platform)
Opportunity 2: AI
Readiness + Data Governance Services • B: Likely funded through SHI/Microsoft programs
• A: SHI to
guide; Casa Marco leadership required for alignment
• N: Critical
need to organize and structure data across multiple repositories before AI deployment
• T: Immediate
(blocking dependency for AI expansion)
• C: Internal DIY
approach or delay in initiative
Opportunity 3:
AI-Powered Image Classification / Artwork Management POC • B: TBD (POC opportunity)
• A: Mark and
creative/operations team
• N: Difficulty
locating artwork due to poor metadata and labeling; inefficient manual processes
• T: Near-term
(requires process documentation first)
• C: Manual
processes; potential niche AI vendors
Opportunity 4:
Camera Systems + AI Video Analytics (Security) • B: Existing spend (evaluation phase)
• A: Mark (also
overseeing security)
• N: Replace
fragmented on-prem camera systems with centralized cloud-based AI-enabled platform
• T: Mid-term
(after evaluation of vendors like Verkada)
• C: Multiple
camera vendors; cost sensitivity noted Initiatives: • AI Transformation (Both – Security + Data/Storage + AI Applications)
• Data
Consolidation & Governance (Storage)
• Copilot
Enablement & Automation (Both)
• AI Image
Recognition / Vision Use Cases (Both)
• AI Security
& Camera Modernization (Security) Tech Profile Updates: • Microsoft environment in place (M365, SharePoint, OneDrive, Teams)
• Limited Copilot
usage (only ~1 license currently deployed)
• Data spread
across SharePoint, Box, SAN, hard drives, and legacy servers
• Movement away
from Slack toward Microsoft Teams
• Cloud-first
preference (no desire for on-prem AI workloads)
• Small IT team
(3 people) requiring low operational overhead solutions
• Limited Power
BI / Power Platform awareness and adoption

Meeting Notes

Environment: • Hybrid environment transitioning toward cloud-first
• Fragmented data
storage across multiple platforms
• Legacy
infrastructure still in place (servers recently purchased but not aligned with strategy)
• No unified data
governance model currently implemented
• Limited AI
tooling standardized across enterprise Detailed

Security and

camera infrastructure gaps were also discussed, including concerns about on-prem DVR systems and need for centralized cloud-based monitoring with AI capabilities.

Technical Notes

• Multi-model AI platforms discussed (Expedient aggregating multiple LLMs)
• RAG (Retrieval
Augmented Generation) architecture explained for internal data security
• Copilot
supports integration with SharePoint, OneDrive, Teams, Outlook, Power BI
• Copilot Studio
allows agent creation with enterprise data access
• Token-free
consumption model in Copilot vs usage-based API pricing elsewhere
• Data ingestion
challenges: multiple repositories, lack of structure, large file volumes
• Vision AI use
cases include image labeling, security monitoring, and analytics
• NVIDIA
pre-built models available for image recognition workflows
• AI agents can
automate reporting, summarization, and workflow execution
• Need for
API-level customization for advanced use cases beyond generic search
• RPA vs AI agent
decision criteria briefly discussed
• Purview
identified as governance tool but requires enablement support
• Ignite
mentioned as file access/streaming optimization solution
• Cloud-native
camera systems preferred over on-prem DVR storage ROLES: • Manuel Zelaya – Solutions Engineer / AI & Infrastructure Specialist (SHI)
• Tony Villalanti
– Account Executive (SHI)
• John Lefeber –
AI Solution Specialist, AGT Team (SHI)
• Mark Schempp –
IT Lead / Infrastructure & Security (Casa Marco) Potential Next steps: • Tony to schedule Copilot demo session with Microsoft resources (Zack or equivalent) for Casa Marco stakeholders
• John to engage
Microsoft funding team and submit request for Copilot and AI workshops
• John to
initiate outreach to Expedient contacts for potential demo
• Manuel to
coordinate AI vision/image classification POC discussion with internal AI lab resources and Mark
• Manuel to
schedule separate session with Mark focused on AI camera/security solutions
• Mark to provide
process documentation for artwork management workflow to enable POC development
• Tony and team
to assess Microsoft licensing environment and provide visibility into current usage
• SHI team to
propose AI readiness assessment workshop with executive stakeholders
