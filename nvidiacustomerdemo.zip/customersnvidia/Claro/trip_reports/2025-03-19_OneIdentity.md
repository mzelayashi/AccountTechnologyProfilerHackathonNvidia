Trip Report | OneIdentity | Claro

Customer: Claro
AE: David A
Topic: OneIdentity
Meeting Date 03/19/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Cara Hansford

Send PowerPoint presentation and usage data to Renzo Novella.

04/21

2

Manuel and One Identity team

Send detailed information about the Radius feature to Renzo.

04/24

Item Owner Next Steps/Detail Due Date 1 Cara Hansford Send PowerPoint presentation and usage data to Renzo Novella. 04/21 2 Manuel and One Identity team Send detailed information about the Radius feature to Renzo. 04/24

Summary

The meeting was primarily focused on the upcoming renewal of OneIdentity services for Claro Enterprise Solutions. The call involved representatives from SHI, Claro, and OneIdentity, discussing the current satisfaction level with the services, potential upgrades or changes in the service bundles, and administrative and technical support aspects. Renzo Novella from Claro expressed satisfaction with the current services and indicated a preference to continue with the existing setup. The call included a presentation on current usage, potential new bundles, and additional features that could be considered. The possibility of moving from a legacy bundle to a new one was discussed, although Renzo preferred to maintain the current setup for now. The call concluded with plans to send detailed documentation and a follow-up on potential future agreements.

Agenda

Introductions and purpose of the call Discussion of the upcoming renewal in May Presentation of current usage and service bundles Discussion of potential changes or upgrades to service bundles Administrative and technical support overview Next steps and follow-up actions

Introductions and purpose of the call Discussion of the upcoming renewal in May Presentation of current usage and service bundles Discussion of potential changes or upgrades to service bundles Administrative and technical support overview Next steps and follow-up actions

Opps Identified & BANTC

Opportunity to move from legacy to new service bundle:

Opportunity to move from legacy to new service bundle:

B: Claro
Enterprise Solutions
A: Renzo
Novella
N: Current
satisfaction with the legacy bundle; open to reviewing information about Radius and other features
T: May
25th renewal date
C: Potential
for cost savings and enhanced features with new bundles

B: Claro
Enterprise Solutions
A: Renzo
Novella
N: Current
satisfaction with the legacy bundle; open to reviewing information about Radius and other features
T: May
25th renewal date
C: Potential
for cost savings and enhanced features with new bundles

Opportunity for a multi-year agreement:

Opportunity for a multi-year agreement:

B: Claro
Enterprise Solutions
A: Renzo
Novella
N: Consideration
of cost benefits with longer-term contracts
T: Discussion
to be had with John
C: Potential
discounts for two or three-year agreements

B: Claro
Enterprise Solutions
A: Renzo
Novella
N: Consideration
of cost benefits with longer-term contracts
T: Discussion
to be had with John
C: Potential
discounts for two or three-year agreements

Initiatives

The initiatives discussed were related to Storage management and service bundle optimization.

The initiatives discussed were related to Storage management and service bundle optimization.

Tech Profile Updates

Consideration of moving to a newer service bundle, which includes features like Smart MFA and sandbox environments. Interest in receiving more detailed information about the Radius feature.

Consideration of moving to a newer service bundle, which includes features like Smart MFA and sandbox environments. Interest in receiving more detailed information about the Radius feature.

Meeting Notes

Environment: Claro Enterprise Solutions is currently using a legacy bundle with OneIdentity services and is satisfied with the current setup. They are operating with 700 licenses.

Environment: Claro Enterprise Solutions is currently using a legacy bundle with OneIdentity services and is satisfied with the current setup. They are operating with 700 licenses.

Detailed Discussion

Usage Overview: Claro is utilizing the unlimited legacy bundle effectively, with a healthy account management process in place. Legacy Bundle Discussion: While encouraged to consider newer bundles, Renzo opted to maintain the current setup, pending further information on specific features. Administrative Support: Cara Hansford emphasized the value of the knowledge base and support systems in place, including ticketing and escalation procedures. Technical Support: Updates on Chrome extension issues and the final migration to the Aurora system were discussed to ensure better stability and capabilities.

Usage Overview: Claro is utilizing the unlimited legacy bundle effectively, with a healthy account management process in place. Legacy Bundle Discussion: While encouraged to consider newer bundles, Renzo opted to maintain the current setup, pending further information on specific features. Administrative Support: Cara Hansford emphasized the value of the knowledge base and support systems in place, including ticketing and escalation procedures. Technical Support: Updates on Chrome extension issues and the final migration to the Aurora system were discussed to ensure better stability and capabilities.

Technical Notes

Chrome Extension Issues: Updates are underway following an update in October, aimed at resolving issues with form-based apps. Aurora Migration: Scheduled for finalization in April, promising improved stability and server load management. Radius Feature: Renzo requested additional information on the Radius feature, indicating potential consideration for future updates.

Chrome Extension Issues: Updates are underway following an update in October, aimed at resolving issues with form-based apps. Aurora Migration: Scheduled for finalization in April, promising improved stability and server load management. Radius Feature: Renzo requested additional information on the Radius feature, indicating potential consideration for future updates. List all speakers/Participants of Transcript:

David Atkinson (SHI) Benjamin Land (OneIdentity) Renzo Novella (Claro Enterprise Solutions) Manuel Zelaya (SHI) Cara Hansford (OneIdentity)

David Atkinson (SHI) Benjamin Land (OneIdentity) Renzo Novella (Claro Enterprise Solutions) Manuel Zelaya (SHI) Cara Hansford (OneIdentity)

Potential Next steps

Documentation and Information Sharing:

Documentation and Information Sharing:

Action: Send PowerPoint presentation and usage data to Renzo Novella. Responsible: Cara Hansford and Benjamin Land

Action: Send PowerPoint presentation and usage data to Renzo Novella. Responsible: Cara Hansford and Benjamin Land

Discussion on Multi-Year Agreement:

Discussion on Multi-Year Agreement:

Action: Renzo to discuss with John the potential for a two or three-year agreement for additional discounts. Responsible: Renzo Novella

Action: Renzo to discuss with John the potential for a two or three-year agreement for additional discounts. Responsible: Renzo Novella

Quarterly or Semi-Annual Meetings:

Quarterly or Semi-Annual Meetings:

Action: Consider setting up regular meetings to discuss usage and account management. Responsible: Renzo Novella and Benjamin Land

Action: Consider setting up regular meetings to discuss usage and account management. Responsible: Renzo Novella and Benjamin Land

Radius Feature Information:

Radius Feature Information:

Action: Send detailed information about the Radius feature to Renzo. Responsible: Benjamin Land

Action: Send detailed information about the Radius feature to Renzo. Responsible: Benjamin Land
