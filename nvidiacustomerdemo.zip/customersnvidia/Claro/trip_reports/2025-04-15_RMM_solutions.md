Trip Report | RMM solutions | Claro

Customer: Claro
AE: Nicole A
Topic: RMM solutions
Meeting Date 04/15/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

provide detailed information on NinjaOne and other RMM solutions, including demos if needed.

05/03

2

Nicole A

Schedule a call to continue internal discussions regarding VMware licensing and potential alternatives

05/03

Item Owner Next Steps/Detail Due Date 1 Manuel Z provide detailed information on NinjaOne and other RMM solutions, including demos if needed. 05/03 2 Nicole A Schedule a call to continue internal discussions regarding VMware licensing and potential alternatives 05/03

Summary

The meeting between Claro and SHI centered around understanding Remote Monitoring and Management (RMM) solutions, specifically focusing on NinjaOne. Claro is exploring options to provide RMM solutions to their customers and is considering whether to continue with NinjaOne or explore alternatives. The discussion included assessing NinjaOne’s capabilities, considering other RMM solutions, and understanding customer needs for a more informed decision. Additionally, the call briefly touched on Claro's internal considerations regarding VMware alternatives and financial models, highlighting ongoing business strategy discussions that affect technology decisions.

Agenda

Introductions and Meeting Purpose Discussion on RMM Solutions and NinjaOne Capabilities Exploring Other RMM Options Considerations for

Initiatives

RMM Solutions: Evaluating NinjaOne and other potential RMM tools to meet customer demands.

RMM Solutions: Evaluating NinjaOne and other potential RMM tools to meet customer demands. Tech Profile Updates:

Current use of NinjaOne with interest in other options such as Kaseya VSA. Ongoing evaluation of technology solutions to align with Claro's business strategies and customer requirements.

Current use of NinjaOne with interest in other options such as Kaseya VSA. Ongoing evaluation of technology solutions to align with Claro's business strategies and customer requirements. Meeting Notes:

Environment

Claro is seeking an RMM solution that supports multi-tenant management and is considering NinjaOne as a primary option. Discussions are ongoing regarding VMware alternatives and financial impacts on technology decisions.

Claro is seeking an RMM solution that supports multi-tenant management and is considering NinjaOne as a primary option. Discussions are ongoing regarding VMware alternatives and financial impacts on technology decisions. Detailed Discussion:

RMM Needs: John Woodfin emphasized the importance of having a centralized platform for managing customer environments. NinjaOne’s multi-tenant capability was noted as a key feature. Alternative Solutions: Manuel Zelaya mentioned other RMM options that SHI supports, including Kaseya VSA, as potential alternatives if needed. VMware Alternatives: John Woodfin shared insights on the challenges of shifting financial models and the ongoing decision-making process regarding VMware licensing.

RMM Needs: John Woodfin emphasized the importance of having a centralized platform for managing customer environments. NinjaOne’s multi-tenant capability was noted as a key feature. Alternative Solutions: Manuel Zelaya mentioned other RMM options that SHI supports, including Kaseya VSA, as potential alternatives if needed. VMware Alternatives: John Woodfin shared insights on the challenges of shifting financial models and the ongoing decision-making process regarding VMware licensing. Technical Notes:

NinjaOne supports multi-tenant environments, making it suitable for managing multiple customer accounts from a single platform. SHI provides a range of RMM solutions, with a preference for tier-one applications that offer robust support.

NinjaOne supports multi-tenant environments, making it suitable for managing multiple customer accounts from a single platform. SHI provides a range of RMM solutions, with a preference for tier-one applications that offer robust support. List all speakers/Participants of Transcript:

Nicole Agoncillo Angel Santiago John Woodfin Manuel Zelaya Andres Castagna

Nicole Agoncillo Angel Santiago John Woodfin Manuel Zelaya Andres Castagna Potential

Next Steps

Customer Needs Assessment:

Customer Needs Assessment:

Claro team to
