Trip Report | Solarwinds | Claro

Customer: Claro
AE: Nicole
Topic: Solarwinds
Meeting Date 04/17/2025

*Internal notes – Please read and edit before sending externally*

Action Items:

Item

Owner

Next Steps/Detail

Due Date

1

Manuel Z

attend the demo scheduled for to engage with John and provide additional insights.

05/15

2

Nicole A

Discuss proration and budget management strategies to align with Claro's renewal timelines and budget constraints.

05/16

Item Owner Next Steps/Detail Due Date 1 Manuel Z attend the demo scheduled for to engage with John and provide additional insights. 05/15 2 Nicole A Discuss proration and budget management strategies to align with Claro's renewal timelines and budget constraints. 05/16

Summary

The conversation was primarily a sync-up meeting involving participants from SolarWinds, SHI, and Claro. The primary focus was on aligning efforts to support Claro, particularly addressing their interest in SolarWinds' observability platform. Key participants discussed current account management, technical capabilities, and upcoming opportunities for collaboration. The meeting aimed to clarify account details, set up a demo for Claro, and discuss the potential for integrating SolarWinds solutions into Claro's operations. Emphasis was placed on understanding Claro's needs, particularly around security infrastructure and observability solutions, and ensuring the proposed solutions align with their budget and strategic goals.

Agenda

Introductions and informal discussion. Clarification of account details and history. Discussion on SolarWinds' observability platform. Upcoming demo and technical engagement. Budget considerations and renewal timelines. Next steps and action items.

Introductions and informal discussion. Clarification of account details and history. Discussion on SolarWinds' observability platform. Upcoming demo and technical engagement. Budget considerations and renewal timelines. Next steps and action items.

Opps Identified & BANTC

Opportunity 1: Observability Platform Integration • B:
Claro's budget is limited but potentially flexible through proration and budget management. • A: John Woodfin is a key decision-maker for Claro's IT procurement. • N: Claro needs enhanced observability and security solutions to consolidate tools and improve efficiency. • T: A demo is scheduled, indicating a short-term timeline for decision-making. • C: Potential competitors are other observability and security platform providers, but SolarWinds offers unique multi-tenant capabilities.

Initiatives

Security

Enhancing Claro's security posture. Storage: Not directly discussed, focus was on observability and security.

Security

Enhancing Claro's security posture. Storage: Not directly discussed, focus was on observability and security.

Tech Profile Updates

Claro is currently using SolarWinds' NPM, NTA, and NCM. They are looking to consolidate tools under a single license model for better management and efficiency.

Claro is currently using SolarWinds' NPM, NTA, and NCM. They are looking to consolidate tools under a single license model for better management and efficiency.

Meeting Notes

Environment

Claro operates under American Mobile, with a complex organizational structure across multiple countries. The focus is on the US operations and improving their IT infrastructure.

Claro operates under American Mobile, with a complex organizational structure across multiple countries. The focus is on the US operations and improving their IT infrastructure.

Detailed Discussion

Nicholas Montefusco-Vega discussed the benefits of SolarWinds' observability platform, emphasizing its multi-tenant capabilities and potential cost savings through proration. David Atkinson provided background on Claro's historical needs and budgetary constraints, highlighting the importance of security infrastructure improvements. Manuel Zelaya confirmed the technical capabilities and support options available for Claro.

Nicholas Montefusco-Vega discussed the benefits of SolarWinds' observability platform, emphasizing its multi-tenant capabilities and potential cost savings through proration. David Atkinson provided background on Claro's historical needs and budgetary constraints, highlighting the importance of security infrastructure improvements. Manuel Zelaya confirmed the technical capabilities and support options available for Claro.

Technical Notes

The observability platform includes features like log analyzing, IP address management, user device tracking, and AI-powered anomaly detection. Multi-tenant capabilities allow for multiple instances under a single license, facilitating easier management across different organizational units. Proration of costs for renewals was discussed as a potential financial benefit for Claro.

The observability platform includes features like log analyzing, IP address management, user device tracking, and AI-powered anomaly detection. Multi-tenant capabilities allow for multiple instances under a single license, facilitating easier management across different organizational units. Proration of costs for renewals was discussed as a potential financial benefit for Claro. List all speakers/Participants of Transcript:

Manuel Zelaya (SHI) Nicholas Montefusco-Vega (SolarWinds) Nicole Agoncillo (SHI) David Atkinson (SHI) John Woodfin (Claro, mentioned as a key contact)

Manuel Zelaya (SHI) Nicholas Montefusco-Vega (SolarWinds) Nicole Agoncillo (SHI) David Atkinson (SHI) John Woodfin (Claro, mentioned as a key contact)

Potential Next steps

Demo Participation:

Demo Participation:

Who: Manuel Zelaya, Nicholas Montefusco-Vega, John Woodfin, and potentially other Claro representatives. Action Item: Manuel Zelaya to attend the demo scheduled for Monday, April 21st, to engage with John and provide additional insights.

Who: Manuel Zelaya, Nicholas Montefusco-Vega, John Woodfin, and potentially other Claro representatives. Action Item: Manuel Zelaya to attend the demo scheduled for Monday, April 21st, to engage with John and provide additional insights.

Technical and Sales Follow-up:

Technical and Sales Follow-up:

Who: Nicholas Montefusco-Vega, David Atkinson. Action Item: Ensure an engineer is present during the demo to address any technical queries. Nicholas to coordinate internally to confirm technical support availability.

Who: Nicholas Montefusco-Vega, David Atkinson. Action Item: Ensure an engineer is present during the demo to address any technical queries. Nicholas to coordinate internally to confirm technical support availability.

Budget and Renewal Strategy:

Budget and Renewal Strategy:

Who: Nicholas Montefusco-Vega, John Woodfin. Action Item: Discuss proration and budget management strategies to align with Claro's renewal timelines and budget constraints.

Who: Nicholas Montefusco-Vega, John Woodfin. Action Item: Discuss proration and budget management strategies to align with Claro's renewal timelines and budget constraints.

Post-Demo Sync:

Post-Demo Sync:

Who: Manuel Zelaya, Nicholas Montefusco-Vega, David Atkinson. Action Item: Schedule a follow-up meeting post-demo to gather feedback and outline next steps for potential implementation and collaboration.

Who: Manuel Zelaya, Nicholas Montefusco-Vega, David Atkinson. Action Item: Schedule a follow-up meeting post-demo to gather feedback and outline next steps for potential implementation and collaboration.
